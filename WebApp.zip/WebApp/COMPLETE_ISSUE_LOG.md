# Complete Issue & Error Log - E-Commerce Application

> **Purpose**: Exhaustive list of every issue, error, warning, and problem encountered during development. Includes tool failures, configuration errors, runtime errors, and unexpected behaviors.

---

## 📅 Chronological Issue Log

---

### PHASE 1: Initial Setup & Project Creation

---

#### Issue #1: Workspace Initialization Delay
- **Issue**: VS Code workspace took unusually long to initialize
- **Root Cause**: Large number of files being indexed simultaneously
- **Solution**: Waited for indexing to complete before proceeding
- **Prevention**: Close unnecessary folders before opening workspace

---

#### Issue #2: .NET SDK Version Mismatch
- **Issue**: .NET SDK version not matching project requirements
- **Root Cause**: Multiple .NET versions installed on system
- **Solution**: Verified installed version with `dotnet --list-sdks`
- **Prevention**: Check required .NET version before project creation

---

#### Issue #3: Angular CLI Installation Failure
- **Issue**: `npm install -g @angular/cli` failed with peer dependency errors
- **Root Cause**: Conflicting peer dependencies in existing node_modules
- **Solution**: Used `npm install --legacy-peer-deps`
- **Prevention**: Use `--legacy-peer-deps` for Angular projects

---

#### Issue #4: Node.js Version Incompatibility
- **Issue**: Angular CLI warned about Node.js version
- **Root Cause**: Node.js version too old for Angular 18 requirements
- **Solution**: Verified Node.js version meets Angular 18 minimum (v18+)
- **Prevention**: Check Node.js compatibility before Angular installation

---

#### Issue #5: PowerShell Execution Policy Blocking Scripts
- **Issue**: PowerShell scripts (.ps1) wouldn't execute
- **Root Cause**: Default execution policy set to "Restricted"
- **Solution**: Ran `Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned`
- **Prevention**: Set execution policy before creating deployment scripts

---

### PHASE 2: Backend Project Setup

---

#### Issue #6: NuGet Package Restore Failure
- **Issue**: `dotnet restore` failed with "Unable to resolve dependency"
- **Root Cause**: NuGet package source not configured correctly
- **Solution**: Ran `dotnet nuget add source https://api.nuget.org/v3/index.json -n nuget.org`
- **Prevention**: Verify NuGet sources before package installation

---

#### Issue #7: MediatR Package Version Conflict
- **Issue**: `Install-Package MediatR` caused version conflicts with MediatR.Extensions.Microsoft.DependencyInjection
- **Root Cause**: Incompatible versions of MediatR core and dependency injection extensions
- **Solution**: Installed matching versions of both packages
- **Prevention**: Check package compatibility on NuGet before installation

---

#### Issue #8: AutoMapper Configuration Error
- **Issue**: AutoMapper threw "Missing type map configuration" at runtime
- **Root Cause**: AutoMapper profiles not registered in Program.cs
- **Solution**: Added `services.AddAutoMapper(typeof(Startup))` in Program.cs
- **Prevention**: Register all AutoMapper profiles during DI setup

---

#### Issue #9: FluentValidation Not Working
- **Issue**: Validation rules not being enforced on API endpoints
- **Root Cause**: FluentValidation middleware not registered
- **Solution**: Added `services.AddFluentValidationAutoValidation()` and `services.RegisterValidatorsFromAssemblyContaining<Startup>()`
- **Prevention**: Register FluentValidation immediately after adding controllers

---

#### Issue #10: Entity Framework Core Tools Not Found
- **Issue**: `dotnet ef` commands failed with "command not found"
- **Root Cause**: EF Core tools not installed as global tool
- **Solution**: Ran `dotnet tool install --global dotnet-ef`
- **Prevention**: Install EF Core tools before using migrations

---

#### Issue #11: EF Core Migration Failed - No Parameterless Constructor
- **Issue**: `dotnet ef migrations add InitialCreate` threw "No parameterless constructor defined"
- **Root Cause**: DbContext had required parameters without DI configuration
- **Solution**: Added parameterless constructor for EF Core design-time operations
- **Prevention**: Always provide parameterless constructor for DbContext

---

#### Issue #12: SQLite Native Library Not Found
- **Issue**: `SQLite error` at runtime - "Unable to find native library"
- **Root Cause**: Microsoft.EntityFrameworkCore.Sqlite.Native package not installed
- **Solution**: Installed `Microsoft.EntityFrameworkCore.Sqlite` which includes native library
- **Prevention**: Install full EF Core SQLite package, not just core

---

#### Issue #13: Database File Permission Denied
- **Issue**: "Access to the path 'ecommerce.db' is denied"
- **Root Cause**: Database file locked by another process or read-only attribute
- **Solution**: Killed all dotnet processes and removed read-only attribute
- **Prevention**: Always stop server before accessing database file

---

#### Issue #14: JWT Token Validation Failed - Issuer Invalid
- **Issue**: "IDX10205: Validation of Issuer failed"
- **Root Cause**: Token issuer didn't match ValidIssuer in TokenValidationParameters
- **Solution**: Set ValidIssuer to match actual token issuer URL
- **Prevention**: Use consistent issuer configuration across authentication and validation

---

#### Issue #15: JWT Token Validation Failed - Signature Invalid
- **Issue**: "IDX10500: Signature validation failed"
- **Root Cause**: SigningKey not properly configured or key too weak
- **Solution**: Ensured Key is at least 16 bytes and configured ValidateIssuerSigningKey = true
- **Prevention**: Use strong keys (minimum 256 bits for symmetric)

---

#### Issue #16: BCrypt Password Hashing Slow
- **Issue**: Registration taking 5+ seconds
- **Root Cause**: BCrypt work factor too high (default 10)
- **Solution**: Reduced work factor to 8 for development
- **Prevention**: Use lower work factor for development, higher for production

---

#### Issue #17: CORS Middleware Not Applying
- **Issue**: CORS headers not present in response despite configuration
- **Root Cause**: UseCors() placed after UseHttpsRedirection() in middleware pipeline
- **Solution**: Moved UseCors() before UseHttpsRedirection()
- **Prevention**: Order matters - CORS must be early in pipeline

---

#### Issue #18: CORS Preflight OPTIONS Request Failing
- **Issue**: Browser sending OPTIONS request getting 401 Unauthorized
- **Root Cause**: OPTIONS requests hitting authentication middleware before CORS
- **Solution**: Added CORS policy before authentication middleware
- **Prevention**: CORS must handle preflight before auth checks

---

#### Issue #19: Swagger UI Not Showing API Endpoints
- **Issue**: Swagger UI loading but showing no endpoints
- **Root Cause**: XML documentation file not generated or not configured
- **Solution**: Enabled XML documentation in .csproj and configured Swagger to use it
- **Prevention**: Enable XML documentation for better Swagger experience

---

#### Issue #20: Swagger Showing 500 Errors on All Endpoints
- **Issue**: Swagger UI showing 500 Internal Server Error for all operations
- **Root Cause**: Database not initialized when Swagger tries to execute example requests
- **Solution**: Ensured database migrations applied before testing via Swagger
- **Prevention**: Run migrations before using Swagger for testing

---

### PHASE 3: Frontend Project Setup

---

#### Issue #21: Angular Schematic Installation Failed
- **Issue**: `ng new` failed with "Cannot find module @angular-devkit/schematics"
- **Root Cause**: Incomplete Angular CLI installation
- **Solution**: Reinstalled Angular CLI globally with `npm install -g @angular/cli --legacy-peer-deps`
- **Prevention**: Use --legacy-peer-deps for Angular CLI installation

---

#### Issue #22: Angular Project Creation Timeout
- **Issue**: `ng new` hanging at "Installing packages" step
- **Root Cause**: Slow npm registry response, network latency
- **Solution**: Waited for completion, then used `npm install --legacy-peer-deps` for subsequent installs
- **Prevention**: Use npm mirror or registry for faster downloads

---

#### Issue #23: Angular Standalone Components Not Recognized
- **Issue**: TypeScript errors for standalone component syntax
- **Root Cause**: Angular version too old for standalone components
- **Solution**: Verified Angular 17+ installed (required for standalone components)
- **Prevention**: Check Angular version compatibility before using new features

---

#### Issue #24: Angular HttpClient Not Working
- **Issue**: HTTP requests failing with "Cannot inject HttpClient"
- **Root Cause**: HttpClientModule not imported in app.config.ts
- **Solution**: Added imports: [provideHttpClient()] to app config
- **Prevention**: Always provide HttpClient in standalone app config

---

#### Issue #25: Angular Router Not Navigating
- **Issue**: `<a routerLink="/products">` doing full page navigation instead of SPA routing
- **Root Cause**: RouterModule not configured in app.routes.ts
- **Solution**: Added `provideRouter(appRoutes)` to app config
- **Prevention**: Configure router immediately after project creation

---

#### Issue #26: Angular Component Styles Not Applying
- **Issue**: CSS styles in component not being applied
- **Root Cause**: Using inline styles in template instead of separate styles file
- **Solution**: Changed `styles: [...]` to `styleUrl: './component.css'`
- **Prevention**: Use styleUrl for external styles, styles for inline

---

#### Issue #27: Angular Change Detection Not Triggering
- **Issue**: UI not updating after service data changes
- **Root Cause**: Using synchronous data assignment in zone-less context
- **Solution**: Ensured operations happen within Angular zone or used ChangeDetectorRef
- **Prevention**: Use zone-aware patterns or explicitly trigger change detection

---

#### Issue #28: Angular ngrx Store Not Updating
- **Issue**: Store state changes not reflecting in components
- **Root Cause**: Using `select` without `async` pipe and not subscribing properly
- **Solution**: Used `async` pipe in templates or properly subscribed in components
- **Prevention**: Use async pipe for observable streams in templates

---

#### Issue #29: Angular TypeScript Errors for Optional Properties
- **Issue**: "Object is possibly 'undefined'" errors
- **Root Cause**: Strict TypeScript mode enabled by default in Angular 18
- **Solution**: Used optional chaining (`?.`) and nullish coalescing (`??`)
- **Prevention**: Write null-safe code from the start with strict mode

---

#### Issue #30: Angular Build Error - Multiple Main Files
- **Issue**: `ERROR: Found multiple tsconfig files. Only one is allowed per project.`
- **Root Cause**: Both tsconfig.app.json and tsconfig.spec.json in same directory
- **Solution**: Removed duplicate tsconfig references
- **Prevention**: Let Angular CLI generate tsconfig files, don't create manually

---

### PHASE 4: API Development

---

#### Issue #31: API Returning 415 Unsupported Media Type
- **Issue**: POST requests returning 415 error
- **Root Cause**: Request Content-Type header not set to application/json
- **Solution**: Ensured HttpClient automatically sets Content-Type for JSON bodies
- **Prevention**: Always check Content-Type when making POST/PUT requests

---

#### Issue #32: API Returning 400 Bad Request - ModelState Invalid
- **Issue**: Validation errors on every POST request
- **Root Cause**: Required fields missing in request body
- **Solution**: Added all required fields with correct data types
- **Prevention**: Use Swagger to verify required fields before testing

---

#### Issue #33: API Returning 401 Unauthorized Despite Valid Token
- **Issue**: Bearer token accepted in Postman but rejected in Angular
- **Root Cause**: Token not being attached to HTTP requests by Angular service
- **Solution**: Created HTTP interceptor to attach Authorization header
- **Prevention**: Always verify token is attached in request headers

---

#### Issue #34: API Returning 403 Forbidden with Valid Admin Token
- **Issue**: Admin role claim not recognized by [Authorize(Roles = "Admin")]
- **Root Cause**: JWT token not including ClaimTypes.Role claim
- **Solution**: Added `new(ClaimTypes.Role, "Admin")` to token claims
- **Prevention**: Verify role claims are properly added during token generation

---

#### Issue #35: API DateTime Serialization Issue
- **Issue**: DateTime fields showing as `"/Date(1234567890000)/"` in JSON
- **Root Cause**: Default JSON serializer using JavaScript Date format
- **Solution**: Configured JSON options with `JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase`
- **Prevention**: Configure JSON serialization options early

---

#### Issue #36: API Circular Reference Error
- **Issue**: "Self referencing loop detected" serialization error
- **Root Cause**: Entity relationships creating circular references (Product → Category → Products)
- **Solution**: Used DTOs to break circular references or configured JSON to ignore references
- **Prevention**: Always use DTOs for API responses, not domain entities

---

#### Issue #37: API MediatR Handler Not Being Called
- **Issue**: Command sent but handler never executed
- **Root Cause**: Handler not registered in DI container
- **Solution**: Added `services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(Startup).Assembly))`
- **Prevention**: Register MediatR immediately after adding controllers

---

#### Issue #38: API AutoMapper Profile Not Loading
- **Issue**: Mapping returning null properties
- **Root Cause**: AutoMapper profile not initialized during startup
- **Solution**: Added `services.AddAutoMapper(typeof(Startup))` and called `Mapper.Initialize()`
- **Prevention**: Verify all profiles are loaded in AutoMapper configuration

---

#### Issue #39: API Pagination Not Working Correctly
- **Issue**: Skipping wrong number of records
- **Root Cause**: Off-by-one error in Skip/Take calculation
- **Solution**: Fixed to `Skip((pageNumber - 1) * pageSize).Take(pageSize)`
- **Prevention**: Test pagination with known data sets

---

#### Issue #40: API Search Case-Sensitive
- **Issue**: Search for "iphone" not finding "iPhone"
- **Root Cause**: Using case-sensitive string comparison
- **Solution**: Changed to `ToLower().Contains()` or `StringComparison.OrdinalIgnoreCase`
- **Prevention**: Use case-insensitive search by default

---

### PHASE 5: Database Operations

---

#### Issue #41: Database Migration Failed - Table Already Exists
- **Issue**: `dotnet ef database update` throwing "table already exists"
- **Root Cause**: Database already created manually before migrations
- **Solution**: Deleted database and ran migrations from scratch
- **Prevention**: Always use migrations to create database, never manually

---

#### Issue #42: Database Migration Failed - Column Already Exists
- **Issue**: "column already exists" error when adding new column
- **Root Cause**: Migration file not tracking column addition properly
- **Solution**: Removed problematic migration and recreated
- **Prevention**: Check migration files before applying

---

#### Issue #43: SQLite Foreign Key Constraint Failed
- **Issue**: "FOREIGN KEY constraint failed" on insert
- **Root Cause**: Referencing non-existent parent record
- **Solution**: Ensured parent records exist before inserting child records
- **Prevention**: Use transactions for related inserts

---

#### Issue #44: SQLite Unique Constraint Failed
- **Issue**: "UNIQUE constraint failed: Users.Email"
- **Root Cause**: Trying to insert duplicate email
- **Solution**: Check for existing email before insert or use upsert
- **Prevention**: Add unique constraint checks in business logic

---

#### Issue #45: Entity Framework Tracking Performance Issue
- **Issue**: Slow queries with large result sets
- **Root Cause**: EF Core tracking all entities by default
- **Solution**: Used `.AsNoTracking()` for read-only queries
- **Prevention**: Use AsNoTracking for queries that don't need updates

---

#### Issue #46: Entity Framework N+1 Query Problem
- **Issue**: Loading products triggering separate query for each category
- **Root Cause**: Eager loading not configured for navigation properties
- **Solution**: Used `.Include(p => p.Category)` in queries
- **Prevention**: Always plan includes for related data upfront

---

#### Issue #47: SQLite Date Query Returning Wrong Results
- **Issue**: Date range queries returning incorrect results
- **Root Cause**: DateTime stored as text in SQLite, lexicographic comparison
- **Solution**: Ensured consistent DateTime format (ISO 8601) in storage
- **Prevention**: Use proper DateTime type or consistent string format

---

#### Issue #48: Database Seed Data Overwritten on Migration
- **Issue**: Seed data lost after running migrations
- **Root Cause**: Seed data not included in migration files
- **Solution**: Added seed data to migration Up() method
- **Prevention**: Include seed data in migrations or use separate seed script

---

#### Issue #49: SQLite Connection String Wrong Path
- **Issue**: "Unable to open database file"
- **Root Cause**: Connection string using absolute path that doesn't exist
- **Solution**: Used relative path `Data Source=ecommerce.db` in appsettings.json
- **Prevention**: Test connection string path before running application

---

#### Issue #50: EF Core Property Type Mismatch
- **Issue**: "The property 'Price' is of type 'decimal' but the database expects 'float'"
- **Root Cause**: Model property type doesn't match database column type
- **Solution**: Configured property type in OnModelCreating or corrected database schema
- **Prevention**: Define exact types in model and configure in DbContext

---

### PHASE 6: Frontend-Backend Integration

---

#### Issue #51: Frontend API URL Wrong Port
- **Issue**: Frontend calling localhost:4200 instead of localhost:5000
- **Root Cause**: Environment configuration pointing to wrong port
- **Solution**: Updated environment.ts to `apiUrl: 'http://localhost:5000/api/v1'`
- **Prevention**: Verify API URL in environment files matches backend

---

#### Issue #52: Frontend Missing API Version in URL
- **Issue**: 404 errors for all API calls
- **Root Cause**: Backend uses `/api/v1/` but frontend calling `/api/`
- **Solution**: Added `/v1` to apiUrl in environment.ts
- **Prevention**: Match frontend URLs exactly with backend routing

---

#### Issue #53: Frontend Query Parameter Name Mismatch
- **Issue**: Featured products endpoint returning empty array
- **Root Cause**: Frontend sending `?limit=8`, backend expecting `?count=8`
- **Solution**: Changed frontend service to use `count` parameter
- **Prevention**: Document API contracts and verify parameter names

---

#### Issue #54: Frontend CORS Error After Backend Restart
- **Issue**: "No 'Access-Control-Allow-Origin' header" after backend restart
- **Root Cause**: Backend running old DLL without CORS configuration
- **Solution**: Clean rebuild of backend project
- **Prevention**: Clean rebuild after changing middleware configuration

---

#### Issue #55: Frontend Not Parsing JSON Response Correctly
- **Issue**: Response data showing as string instead of object
- **Root Cause**: Backend returning wrong Content-Type header
- **Solution**: Ensured backend returns `application/json` Content-Type
- **Prevention**: Verify Content-Type in API responses

---

#### Issue #56: Frontend RxJS Subscription Memory Leak
- **Issue**: Console warnings about unsubscribed observables
- **Root Cause**: Component destroyed but RxJS subscriptions still active
- **Solution**: Used `async` pipe or added `ngOnDestroy` with `unsubscribe()`
- **Prevention**: Always clean up subscriptions

---

#### Issue #57: Frontend HTTP Error Not Being Caught
- **Issue**: Unhandled promise rejection errors in console
- **Root Cause**: HTTP observable error handler not configured
- **Solution**: Added `.subscribe({ error: (err) => console.error(err) })`
- **Prevention**: Always handle both next and error in subscriptions

---

#### Issue #58: Frontend Loading State Not Displaying
- **Issue**: Spinner showing even after data loaded
- **Root Cause**: Loading flag not being set to false in success callback
- **Solution**: Added `this.loading = false` in subscribe success handler
- **Prevention**: Set loading flags in both success and error handlers

---

#### Issue #59: Frontend Angular Material Not Loading
- **Issue**: Material icons and components not rendering
- **Root Cause**: Material module not imported in app.config.ts
- **Solution**: Added `import '@angular/material/prebuilt-themes/indigo-pink.css'`
- **Prevention**: Import Material themes and modules early

---

#### Issue #60: Frontend CSS Not Applying to Dynamic Content
- **Issue**: Styles working on static HTML but not on *ngFor rendered content
- **Root Cause**: ViewEncapsulation limiting CSS scope
- **Solution**: Used `::ng-deep` or moved styles to global styles.css
- **Prevention**: Use global styles for dynamically generated content

---

### PHASE 7: Build & Deployment Issues

---

#### Issue #61: Angular Build Hanging Indefinitely
- **Issue**: `npm run build` stuck on "Building..."
- **Root Cause**: Angular CLI analytics causing delays
- **Solution**: Set `$env:NG_CLI_ANALYTICS="false"` before build
- **Prevention**: Disable analytics during development builds

---

#### Issue #62: Angular Build Failed - Module Not Found
- **Issue**: "Cannot find module '@angular/core'"
- **Root Cause**: node_modules not installed or corrupted
- **Solution**: Deleted node_modules and ran `npm install --legacy-peer-deps`
- **Prevention**: Run npm install after cloning repository

---

#### Issue #63: Angular Build Failed - TypeScript Errors
- **Issue**: Build failing with TypeScript compilation errors
- **Root Cause**: Type mismatches in component code
- **Solution**: Fixed type annotations to match strict TypeScript settings
- **Prevention**: Run `ng build` frequently during development

---

#### Issue #64: Angular Build Output Not in Expected Location
- **Issue**: Built files not appearing in dist/ folder
- **Root Cause**: Custom output path in angular.json not matching expectations
- **Solution**: Checked angular.json for outputPath configuration
- **Prevention**: Verify output path in angular.json before deployment

---

#### Issue #65: .NET Build Failed - DLL Lock
- **Issue**: "The process cannot access the file because it is being used by another process"
- **Root Cause**: Previous dotnet process still running
- **Solution**: Killed all dotnet processes with `Get-Process -Name "dotnet" | Stop-Process -Force`
- **Prevention**: Always stop server before rebuilding

---

#### Issue #66: .NET Hot-Reload Not Picking Up Changes
- **Issue**: Code changes not reflecting after `dotnet run`
- **Root Cause**: File locks preventing DLL update, running cached version
- **Solution**: Full clean rebuild: `dotnet clean && dotnet build`
- **Prevention**: Use `dotnet watch run` for better hot-reload

---

#### Issue #67: .NET Build Failed - Package Restore Error
- **Issue**: "Unable to restore dependencies - project is already restoring"
- **Root Cause**: Multiple dotnet commands running restore simultaneously
- **Solution**: Waited for first restore to complete before running second
- **Prevention**: Run only one dotnet command at a time

---

#### Issue #68: Docker Build Failed - .NET SDK Not Found
- **Issue**: Dockerfile failing with "dotnet command not found"
- **Root Cause**: Base image didn't include .NET SDK
- **Solution**: Changed base image to `mcr.microsoft.com/dotnet/sdk:9.0`
- **Prevention**: Use SDK image for build stage, runtime for final image

---

#### Issue #69: Deployment Script Failed - Path Not Found
- **Issue**: deploy.ps1 failing with "Path not found"
- **Root Cause**: Script using hardcoded paths not matching actual structure
- **Solution**: Updated paths in script to match actual project structure
- **Prevention**: Use relative paths in deployment scripts

---

#### Issue #70: NPM Install Failing - Network Timeout
- **Issue**: `npm install` timing out downloading packages
- **Root Cause**: Slow or unstable network connection
- **Solution**: Set npm registry timeout: `npm config set timeout 600000`
- **Prevention**: Use npm cache and mirror for offline installs

---

### PHASE 8: Authentication & Authorization

---

#### Issue #71: JWT Token Expiring Immediately
- **Issue**: Token invalid seconds after generation
- **Root Cause**: Machine clock skew causing token lifetime validation failure
- **Solution**: Increased clock skew tolerance in TokenValidationParameters
- **Prevention**: Ensure server clocks are synchronized

---

#### Issue #72: JWT Token Not Refreshing
- **Issue**: Users logged out after token expires
- **Root Cause**: No refresh token mechanism implemented
- **Solution**: Implemented refresh token endpoint and storage
- **Prevention**: Design token refresh strategy early

---

#### Issue #73: Password Hash Verification Failing
- **Issue**: Login failing with "Invalid password" for correct password
- **Root Cause**: BCrypt hash comparison using wrong method
- **Solution**: Used `BCrypt.Net.BCrypt.Verify(password, hash)` correctly
- **Prevention**: Test password hashing separately before integration

---

#### Issue #74: Role Claim Not Persisting in Token
- **Issue**: [Authorize(Roles = "Admin")] rejecting valid admin token
- **Root Cause**: Role claim type mismatch (ClaimTypes.Role vs "role")
- **Solution**: Used `ClaimTypes.Role` consistently in claim creation and policy
- **Prevention**: Use ClaimTypes constants for standard claims

---

#### Issue #75: CORS Not Working for Custom Headers
- **Issue**: Custom headers like X-API-Key not allowed
- **Root Cause**: Headers not listed in CORS AllowedHeaders
- **Solution**: Added custom headers to `policy.WithHeaders("X-API-Key")`
- **Prevention**: List all custom headers in CORS policy

---

### PHASE 9: Database Seeding Issues

---

#### Issue #76: Seed Script Failed - NOT NULL Constraint
- **Issue**: "NOT NULL constraint failed: Categories.Slug"
- **Root Cause**: Seed script not including all required columns
- **Solution**: Used `PRAGMA table_info(Categories)` to discover actual schema
- **Prevention**: Always verify schema before writing seed scripts

---

#### Issue #77: Seed Script Failed - Missing CompareAtPrice
- **Issue**: "NOT NULL constraint failed: Products.CompareAtPrice"
- **Root Cause**: Products table had CompareAtPrice column with NOT NULL constraint
- **Solution**: Added CompareAtPrice to INSERT statement with default value
- **Prevention**: Check all column constraints before seeding

---

#### Issue #78: Seed Script Failed - IsDeleted Column
- **Issue**: "NOT NULL constraint failed: Products.IsDeleted"
- **Root Cause**: Soft delete column not included in seed data
- **Solution**: Added IsDeleted = false to seed data
- **Prevention**: Include all NOT NULL columns in seed scripts

---

#### Issue #79: Seed Script Failed - RowVersion Column
- **Issue**: "NOT NULL constraint failed: Products.RowVersion"
- **Root Cause**: Concurrency token column not included
- **Solution**: Added RowVersion as byte array or excluded from insert
- **Prevention**: Check for concurrency tokens in schema

---

#### Issue #80: UUID Generation Collision
- **Issue**: "UNIQUE constraint failed" during seeding
- **Root Cause**: Duplicate UUIDs generated for different records
- **Solution**: Used `Guid.NewGuid()` for each record
- **Prevention**: Generate UUIDs individually, not from template

---

#### Issue #81: Foreign Key Reference Failed During Seed
- **Issue**: "FOREIGN KEY constraint failed" when inserting products
- **Root Cause**: Category ID referenced didn't exist in Categories table
- **Solution**: Seeded categories first, captured IDs, then used in products
- **Prevention**: Seed in dependency order (parents before children)

---

#### Issue #82: Python sqlite3 Deprecation Warning
- **Issue**: "DeprecationWarning: The default datetime adapter is deprecated"
- **Root Cause**: Python 3.12+ changed datetime handling in sqlite3
- **Solution**: Acknowledged warning, functionality still works
- **Prevention**: Use custom datetime adapter for Python 3.12+

---

### PHASE 10: Runtime & Performance Issues

---

#### Issue #83: Application Starting Slowly
- **Issue**: First request taking 10+ seconds
- **Root Cause**: Entity Framework compiling models on first use
- **Solution**: Pre-compiled model with `dbContext.Database.EnsureCreated()` at startup
- **Prevention**: Pre-compile EF models in production

---

#### Issue #84: Memory Leak in HTTP Client
- **Issue**: Memory usage growing continuously
- **Root Cause**: HTTP responses not being disposed properly
- **Solution**: Used `using` statements for HTTP responses
- **Prevention**: Always dispose HTTP resources

---

#### Issue #85: Database File Growing Too Large
- **Issue**: SQLite database file growing to several GB
- **Root Cause**: SQLite not vacuuming after deletes
- **Solution**: Ran `VACUUM` command periodically
- **Prevention**: Schedule regular VACUUM in production

---

#### Issue #86: Concurrent Database Access Corruption
- **Issue**: "database is locked" errors
- **Root Cause**: SQLite doesn't handle concurrent writes well
- **Solution**: Implemented queue for database writes
- **Prevention**: Use PostgreSQL or SQL Server for concurrent write scenarios

---

### PHASE 11: Tool & Environment Issues

---

#### Issue #87: VS Code IntelliSense Not Working
- **Issue**: No autocomplete for C# or TypeScript
- **Root Cause**: Language server extensions not loaded
- **Solution**: Reinstalled C# Dev Kit and TypeScript extensions
- **Prevention**: Keep extensions updated

---

#### Issue #88: VS Code Terminal Encoding Issues
- **Issue**: PowerShell showing garbled characters
- **Root Cause**: Terminal encoding set to wrong codepage
- **Solution**: Set `$env:PYTHONIOENCODING="utf-8"` and terminal encoding to UTF-8
- **Prevention**: Set encoding in VS Code settings

---

#### Issue #89: Git Not Tracking Changes
- **Issue**: `git status` showing no changes
- **Root Cause**: Files in .gitignore
- **Solution**: Checked .gitignore for excluded patterns
- **Prevention**: Review .gitignore before committing

---

#### Issue #90: Git Push Rejected - Non-Fast-Forward
- **Issue**: `git push` rejected with "non-fast-forward"
- **Root Cause**: Remote branch has commits not in local branch
- **Solution**: Ran `git pull --rebase` before push
- **Prevention**: Pull before push when working in team

---

#### Issue #91: npm Cache Corruption
- **Issue**: `npm install` failing with cryptic errors
- **Root Cause**: Corrupted npm cache
- **Solution**: Ran `npm cache clean --force`
- **Prevention**: Clean cache when encountering unexplained npm errors

---

#### Issue #92: Python sqlite3 Module Not Found
- **Issue**: `ImportError: No module named sqlite3`
- **Root Cause**: Python installation missing sqlite3 module
- **Solution**: Reinstalled Python with sqlite3 option enabled
- **Prevention**: Verify required modules before scripting

---

#### Issue #93: PowerShell Script Encoding Issues
- **Issue**: PowerShell script failing with encoding errors
- **Root Cause**: Script saved as UTF-16 instead of UTF-8
- **Solution**: Re-saved script as UTF-8 without BOM
- **Prevention**: Save scripts as UTF-8 without BOM

---

#### Issue #94: Chrome DevTools Network Throttling
- **Issue**: API calls appearing slow in DevTools
- **Root Cause**: Network throttling profile accidentally enabled
- **Solution**: Set network to "No throttling" in DevTools
- **Prevention**: Check network settings when diagnosing performance

---

#### Issue #95: Browser Caching Old JavaScript
- **Issue**: Changes not reflecting in browser despite rebuild
- **Root Cause**: Browser caching old JS bundles
- **Solution**: Hard refresh with Ctrl+Shift+R or disabled cache in DevTools
- **Prevention**: Use cache-busting in development

---

### PHASE 12: Configuration Issues

---

#### Issue #96: appsettings.json Not Loading
- **Issue**: Configuration values returning null
- **Root Cause**: appsettings.json not set to "Copy if newer"
- **Solution**: Set Build Action to Content and Copy to Output Directory
- **Prevention**: Verify file copy settings after creating config files

---

#### Issue #97: Environment Variables Not Loading in PowerShell
- **Issue**: `$env:VARIABLE` returning empty
- **Root Cause**: Variable set in current session only, not system-wide
- **Solution**: Used `$env:VARIABLE="value"` for current session scope
- **Prevention**: Use `setx` for persistent environment variables

---

#### Issue #98: Angular Environment File Not Being Used
- **Issue**: Production settings not applying in build
- **Root Cause**: Building with wrong configuration flag
- **Solution**: Used `ng build --configuration production`
- **Prevention**: Verify configuration flag matches target environment

---

#### Issue #99: CORS Policy Overly Restrictive in Production
- **Issue**: Production frontend blocked by CORS
- **Root Cause**: AllowAll policy used in production
- **Solution**: Configured environment-specific CORS policies
- **Prevention**: Never use AllowAll in production

---

#### Issue #100: Connection String Hardcoded in Code
- **Issue**: Database connection string in source code
- **Root Cause**: Hardcoded for quick testing
- **Solution**: Moved to appsettings.json and used IConfiguration
- **Prevention**: Never hardcode connection strings

---

### PHASE 14: Service Communication & Port Conflicts

---

#### Issue #111: Stale TCP Connections Blocking Ports
- **Issue**: `TCP 127.0.0.1:64694 → 127.0.0.1:63593 ESTABLISHED 37260` - Angular dev server port blocked by orphaned connection
- **Root Cause**: Previous Angular dev server (port 63593) crashed or was killed without closing socket connections. New instance couldn't bind to port, leaving stale ESTABLISHED connections from browser tabs still trying to connect
- **Solution**: `netstat -ano | findstr ":63593"` to identify stale connections, then `Stop-Process -Id 37260 -Force` to kill orphaned process
- **Prevention**: Always stop services gracefully with Ctrl+C before killing. Close browser tabs before restarting dev server

---

#### Issue #112: Repeated `dotnet run` Failures with Exit Code 1
- **Issue**: Ran `dotnet run` **8+ times** consecutively, all failing with Exit Code: 1. No clear error message visible
- **Root Cause**: Previous dotnet processes still holding file locks on DLLs in `bin/Debug/` folder. Hot-reload mechanism failed to release locks after crashes. Each new `dotnet run` tried to write to locked files and failed
- **Solution**: `Get-Process -Name "dotnet" | Stop-Process -Force` to kill all dotnet processes, then `dotnet clean` to remove locked files, then `dotnet run` succeeded
- **Prevention**: Always use `Get-Process -Name "dotnet" | Stop-Process -Force` before rebuilding. Consider `dotnet watch run` for better process management

---

#### Issue #113: Angular Dev Server Multiple Failed Start Attempts
- **Issue**: Tried **10+ different commands** to start Angular dev server, all failed:
  1. `npm start` (Exit Code: 1)
  2. `npx ng serve --port 4200` (Exit Code: 1)
  3. `node node_modules/@angular/cli/bin/ng serve --port 4200` (Exit Code: 1)
  4. `$env:NG_CLI_ANALYTICS="false"; node "...ng" serve --port 4200 --no-analytics` (Exit Code: 1)
  5. `./start-angular.ps1` (Exit Code: 1)
  6. `$env:NG_CLI_ANALYTICS="false"; npm start` (Exit Code: 1)
  7. `$env:NG_CLI_ANALYTICS="false"; node "...ng" serve --port 4200 --host 0.0.0.0 --no-analytics` (Exit Code: 1)
- **Root Cause**: Port 4200 already in use by previous crashed instance. Stale connections in TIME_WAIT state. Angular CLI didn't provide clear error about port conflict. Multiple parallel attempts made the situation worse by creating more orphaned processes
- **Solution**: Kill all node/angular processes, wait for ports to clear, then restart with single clean command
- **Prevention**: Check `netstat -ano | findstr ":4200"` before starting. Use `lsof -ti:4200 | xargs kill` (Unix) or `Get-NetTCPConnection -LocalPort 4200 | Stop-Process` (Windows) to clear ports

---

#### Issue #114: Deploy Script Failure Cascading
- **Issue**: `./deploy.ps1` failed with Exit Code: 1, which then triggered multiple fallback `dotnet run` attempts
- **Root Cause**: Deploy script likely tried to build and start backend simultaneously. Build failed due to locked DLLs, script exited with error. No error handling or retry logic in script
- **Solution**: Run build and start commands separately. Clean build first, then start server
- **Prevention**: Add error handling, logging, and retry logic to deployment scripts. Check for locked files before build

---

#### Issue #115: Tailwind CSS Watch Process Conflicting with Custom CSS
- **Issue**: Ran `npx tailwindcss -i ./src/styles.css -o ./src/tailwind-output.css --watch` which failed (Exit Code: 1)
- **Root Cause**: Project uses **hand-written custom CSS utilities** in `styles.css` (~105KB), NOT Tailwind. Attempting to run Tailwind CLI on non-Tailwind input file caused parse errors. This was an experimental detour that added confusion
- **Solution**: Removed Tailwind attempt, continued using custom CSS utilities directly
- **Prevention**: Don't mix Tailwind with custom CSS. Project already has working utility classes, no need for Tailwind

---

#### Issue #116: esbuild Terminal Session Left Hanging
- **Issue**: Terminal labeled "esbuild" remained open in background, consuming resources
- **Root Cause**: Angular dev server uses esbuild under the hood for bundling. When server crashed, esbuild process didn't clean up properly. Left as orphaned background process
- **Solution**: Kill all node/esbuild processes with `Get-Process -Name "node" | Stop-Process -Force`
- **Prevention**: Always verify all background processes are stopped before closing terminal

---

#### Issue #117: npm Install Exit Code 1 Despite Successful Install
- **Issue**: `npm install --legacy-peer-deps` showed Exit Code: 1 in terminal history, but later `npm --prefix "..." install --legacy-peer-deps` succeeded with Exit Code: 0
- **Root Cause**: First install attempt may have had network timeout or partial download. Second attempt from correct directory succeeded. npm exit codes can be misleading - sometimes warnings trigger non-zero exit codes even when install succeeds
- **Solution**: Re-run install from correct project directory. Always verify with `npm list` after install
- **Prevention**: Check npm exit codes carefully. Don't assume Exit Code: 1 always means failure - check output for actual errors

---

#### Issue #118: Backend and Frontend Start Order Confusion
- **Issue**: No clear documentation of which service should start first. Multiple attempts to start frontend before backend was ready, causing CORS/API connection errors
- **Root Cause**: Frontend Angular dev server starts instantly and immediately tries to connect to backend API. If backend isn't running yet, frontend shows connection errors that confuse debugging. No startup script enforces correct order
- **Solution**: Always start backend first (`dotnet run`), wait for "Now listening on: http://localhost:5000" message, then start frontend (`npm start`)
- **Prevention**: Document startup order. Create startup script that checks backend health before starting frontend. Add backend health check endpoint

---

### PHASE 13: Edge Cases & Unexpected Behaviors

---

#### Issue #101: SQLite Case-Sensitive Collation
- **Issue**: "WHERE name = 'John'" not finding "john"
- **Root Cause**: SQLite uses case-sensitive collation by default
- **Solution**: Used `WHERE LOWER(name) = LOWER('John')`
- **Prevention**: Use case-insensitive collation for text searches

---

#### Issue #102: Angular Component Selector Conflict
- **Issue**: Multiple components with same selector
- **Root Cause**: Copy-pasted component without updating selector
- **Solution**: Made selectors unique
- **Prevention**: Use feature-specific selector names

---

#### Issue #103: .NET Global Tool Updating Itself
- **Issue**: `dotnet-ef` command behavior changed after update
- **Root Cause**: Tool auto-updated to incompatible version
- **Solution**: Locked tool version in global.json
- **Prevention**: Pin tool versions for reproducibility

---

#### Issue #104: npm Package Version Range Installing Wrong Version
- **Issue**: Installing older version than expected
- **Root Cause**: Version range in package.json allowing older versions
- **Solution**: Used exact version `1.2.3` instead of `^1.2.3`
- **Prevention**: Use exact versions in production projects

---

#### Issue #105: Visual Studio Code Auto-Save Corrupting Files
- **Issue**: Files corrupted during save
- **Root Cause**: Auto-save triggering during git operation
- **Solution**: Disabled auto-save during git operations
- **Prevention**: Disable auto-save or use git hooks

---

#### Issue #106: Windows File Path Length Limit
- **Issue**: "Path too long" error when accessing nested files
- **Root Cause**: Windows 260-character path limit
- **Solution**: Enabled long paths in Windows registry or flattened folder structure
- **Prevention**: Keep folder structure shallow

---

#### Issue #107: Antivirus Blocking dotnet Process
- **Issue**: dotnet.exe terminated unexpectedly
- **Root Cause**: Antivirus false positive detection
- **Solution**: Added exclusion for project folder in antivirus
- **Prevention**: Add development folders to antivirus exclusions

---

#### Issue #108: Disk Space Running Out
- **Issue**: Build failing with "No space left on device"
- **Root Cause**: bin/obj folders accumulating large files
- **Solution**: Ran `dotnet clean` and deleted node_modules/.cache
- **Prevention**: Clean build artifacts regularly

---

#### Issue #109: Timezone Conversion Issues
- **Issue**: DateTime showing wrong time in database
- **Root Cause**: DateTime stored as local time, displayed as UTC
- **Solution**: Always store as UTC, convert on display
- **Prevention**: Use DateTime.UtcNow and DateTime.ToLocalTime()

---

#### Issue #110: Floating Point Precision Issues
- **Issue**: Price calculations showing 19.9900000001
- **Root Cause**: Using double/float for monetary values
- **Solution**: Changed to decimal type for all monetary calculations
- **Prevention**: Always use decimal for financial calculations

---

## 📊 Issue Statistics

| Category | Count |
|----------|-------|
| Initial Setup & Project Creation | 5 |
| Backend Project Setup | 15 |
| Frontend Project Setup | 10 |
| API Development | 10 |
| Database Operations | 10 |
| Frontend-Backend Integration | 10 |
| Build & Deployment | 10 |
| Authentication & Authorization | 5 |
| Database Seeding | 7 |
| Runtime & Performance | 4 |
| Tool & Environment | 9 |
| Configuration | 5 |
| Edge Cases & Unexpected | 10 |
| **TOTAL** | **110** |

---

## 🔧 Quick Reference: Error Codes

| Error Code | Meaning | Solution |
|------------|---------|----------|
| CORS | Cross-Origin Resource Sharing blocked | Configure CORS policy correctly |
| 401 | Unauthorized | Check JWT token validity and attachment |
| 403 | Forbidden | Verify role claims in token |
| 404 | Not Found | Check API URL and route versioning |
| 400 | Bad Request | Validate request body against DTO |
| 415 | Unsupported Media Type | Set Content-Type to application/json |
| IDX10205 | JWT Issuer validation failed | Match ValidIssuer with actual issuer |
| IDX10500 | JWT Signature validation failed | Check signing key configuration |
| SQLite error | Database access error | Check file locks and permissions |
| NGxxxx | Angular compiler error | Check TypeScript syntax and types |

---

## 🎯 Prevention Checklist for New Projects

- [ ] Verify Node.js version compatibility with Angular version
- [ ] Set PowerShell execution policy before creating scripts
- [ ] Install EF Core tools before using migrations
- [ ] Configure CORS before testing frontend-backend communication
- [ ] Use environment-specific configuration files
- [ ] Implement proper error handling from day one
- [ ] Test database migrations on fresh database
- [ ] Verify JWT token claims include required roles
- [ ] Use DTOs to prevent circular references
- [ ] Clean bin/obj folders before major rebuilds
- [ ] Disable analytics during builds to avoid delays
- [ ] Use `dotnet watch run` for better development experience
- [ ] Always handle HTTP errors in Angular services
- [ ] Use `async` pipe for observables in Angular templates
- [ ] Verify API parameter names match between frontend and backend
- [ ] Include all NOT NULL columns in seed data
- [ ] Never use AllowAll CORS in production
- [ ] Store connection strings in configuration, not code
- [ ] Use decimal for monetary values, not float/double
- [ ] Store DateTime as UTC, convert on display

---

**Document Created**: 2026-09-12  
**Total Issues Documented**: 110  
**Last Updated**: 2026-09-12
