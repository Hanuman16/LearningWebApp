# Seed script for E-Commerce database
$baseUrl = "http://localhost:5000/api/v1"
$ErrorActionPreference = "Stop"

Write-Host "=== E-Commerce Database Seeder ===" -ForegroundColor Cyan

# Step 1: Register admin user
Write-Host "`n[1/4] Registering admin user..." -ForegroundColor Yellow
$registerBody = @{
    FirstName = "Admin"
    LastName = "User"
    Email = "admin@ecommerce.com"
    Password = "Admin@123"
    PhoneNumber = "1234567890"
} | ConvertTo-Json -Depth 5

try {
    $regResponse = Invoke-RestMethod -Uri "$baseUrl/auth/register" -Method Post -Body $registerBody -ContentType "application/json" -UseBasicParsing
    Write-Host "  Admin user registered successfully!" -ForegroundColor Green
} catch {
    if ($_.Exception.Response.StatusCode -eq 409) {
        Write-Host "  Admin user already exists." -ForegroundColor Yellow
    } else {
        Write-Host "  Error: $_" -ForegroundColor Red
        exit 1
    }
}

# Step 2: Login to get JWT token
Write-Host "`n[2/4] Logging in to get authentication token..." -ForegroundColor Yellow
$loginBody = @{
    Email = "admin@ecommerce.com"
    Password = "Admin@123"
} | ConvertTo-Json

try {
    $loginResponse = Invoke-RestMethod -Uri "$baseUrl/auth/login" -Method Post -Body $loginBody -ContentType "application/json" -UseBasicParsing
    $token = $loginResponse.accessToken
    Write-Host "  Login successful! Token received." -ForegroundColor Green
} catch {
    Write-Host "  Login failed: $_" -ForegroundColor Red
    Write-Host "  Response: $($_.ErrorDetails.Message)" -ForegroundColor Red
    exit 1
}

# Set up auth header
$headers = @{
    "Authorization" = "Bearer $token"
    "Content-Type" = "application/json"
}

# Step 3: Create categories
Write-Host "`n[3/4] Creating categories..." -ForegroundColor Yellow
$categoryIds = @{}
$categories = @(
    @{ Name = "Electronics"; Description = "Electronic devices and gadgets"; Slug = "electronics" },
    @{ Name = "Clothing"; Description = "Fashion and apparel"; Slug = "clothing" },
    @{ Name = "HomeGarden"; Description = "Home improvement and garden supplies"; Slug = "home-garden" },
    @{ Name = "Books"; Description = "Books and publications"; Slug = "books" },
    @{ Name = "Sports"; Description = "Sports equipment and accessories"; Slug = "sports" },
    @{ Name = "Toys"; Description = "Toys and games for all ages"; Slug = "toys" }
)

foreach ($cat in $categories) {
    try {
        $catBody = $cat | ConvertTo-Json
        $catResponse = Invoke-RestMethod -Uri "$baseUrl/categories" -Method Post -Body $catBody -ContentType "application/json" -Headers $headers -UseBasicParsing
        $categoryIds[$cat.Name] = $catResponse.id
        Write-Host "  Created: $($cat.Name) (ID: $($catResponse.id))" -ForegroundColor Green
    } catch {
        Write-Host "  Error creating $($cat.Name): $_" -ForegroundColor Red
    }
}

# Step 4: Create products
Write-Host "`n[4/4] Creating products..." -ForegroundColor Yellow
$products = @(
    @{
        Name = "Wireless Bluetooth Headphones"
        Description = "Premium noise-cancelling wireless headphones with 30-hour battery life"
        Price = 79.99m
        StockQuantity = 150
        CategoryId = $categoryIds["Electronics"]
        IsFeatured = $true
        IsActive = $true
        Slug = "wireless-bluetooth-headphones"
    },
    @{
        Name = "Smart Watch Pro"
        Description = "Advanced smartwatch with health monitoring and GPS tracking"
        Price = 299.99m
        StockQuantity = 75
        CategoryId = $categoryIds["Electronics"]
        IsFeatured = $true
        IsActive = $true
        Slug = "smart-watch-pro"
    },
    @{
        Name = "4K Ultra HD Smart TV"
        Description = "55-inch 4K Smart TV with HDR and built-in streaming apps"
        Price = 599.99m
        StockQuantity = 30
        CategoryId = $categoryIds["Electronics"]
        IsFeatured = $true
        IsActive = $true
        Slug = "4k-ultra-hd-smart-tv"
    },
    @{
        Name = "Laptop Backpack"
        Description = "Water-resistant laptop backpack with USB charging port"
        Price = 49.99m
        StockQuantity = 200
        CategoryId = $categoryIds["Clothing"]
        IsFeatured = $true
        IsActive = $true
        Slug = "laptop-backpack"
    },
    @{
        Name = "Men Casual T-Shirt"
        Description = "Comfortable cotton blend t-shirt available in multiple colors"
        Price = 24.99m
        StockQuantity = 500
        CategoryId = $categoryIds["Clothing"]
        IsFeatured = $false
        IsActive = $true
        Slug = "mens-casual-tshirt"
    },
    @{
        Name = "Running Shoes"
        Description = "Lightweight running shoes with advanced cushioning technology"
        Price = 129.99m
        StockQuantity = 100
        CategoryId = $categoryIds["Clothing"]
        IsFeatured = $true
        IsActive = $true
        Slug = "running-shoes"
    },
    @{
        Name = "Garden Tool Set"
        Description = "Complete 10-piece garden tool set with carrying case"
        Price = 89.99m
        StockQuantity = 60
        CategoryId = $categoryIds["HomeGarden"]
        IsFeatured = $false
        IsActive = $true
        Slug = "garden-tool-set"
    },
    @{
        Name = "Smart LED Light Bulbs 4-Pack"
        Description = "WiFi-enabled color-changing LED bulbs compatible with voice assistants"
        Price = 39.99m
        StockQuantity = 300
        CategoryId = $categoryIds["HomeGarden"]
        IsFeatured = $true
        IsActive = $true
        Slug = "smart-led-light-bulbs"
    },
    @{
        Name = "Programming Python Book"
        Description = "Comprehensive guide to Python programming for beginners and advanced developers"
        Price = 44.99m
        StockQuantity = 150
        CategoryId = $categoryIds["Books"]
        IsFeatured = $false
        IsActive = $true
        Slug = "programming-python-book"
    },
    @{
        Name = "Fitness Resistance Bands Set"
        Description = "Set of 5 resistance bands with different tension levels for home workouts"
        Price = 29.99m
        StockQuantity = 250
        CategoryId = $categoryIds["Sports"]
        IsFeatured = $false
        IsActive = $true
        Slug = "fitness-resistance-bands"
    },
    @{
        Name = "Yoga Mat Premium"
        Description = "Non-slip exercise yoga mat with carrying strap"
        Price = 34.99m
        StockQuantity = 180
        CategoryId = $categoryIds["Sports"]
        IsFeatured = $false
        IsActive = $true
        Slug = "yoga-mat-premium"
    },
    @{
        Name = "Building Blocks Set"
        Description = "500-piece creative building blocks set for kids ages 6+"
        Price = 49.99m
        StockQuantity = 120
        CategoryId = $categoryIds["Toys"]
        IsFeatured = $false
        IsActive = $true
        Slug = "building-blocks-set"
    }
)

foreach ($product in $products) {
    try {
        $prodBody = $product | ConvertTo-Json -Depth 5
        $prodResponse = Invoke-RestMethod -Uri "$baseUrl/products" -Method Post -Body $prodBody -ContentType "application/json" -Headers $headers -UseBasicParsing
        Write-Host "  Created: $($product.Name) (ID: $($prodResponse.id))" -ForegroundColor Green
    } catch {
        Write-Host "  Error creating $($product.Name): $_" -ForegroundColor Red
    }
}

Write-Host "`n=== Seeding Complete! ===" -ForegroundColor Green
Write-Host "Admin Login: admin@ecommerce.com / Admin@123" -ForegroundColor Cyan
