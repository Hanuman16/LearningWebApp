namespace ECommerce.Api.Middleware;

using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using ECommerce.Api.Configuration;

/// <summary>
/// ╔═══════════════════════════════════════════════════════════╗
/// ║  SECURITY HEADERS MIDDLEWARE                             ║
/// ╚═══════════════════════════════════════════════════════════╝
/// 
/// CONCEPTS IMPLEMENTED:
/// ─────────────────────
/// 
/// 1. SECURITY HEADERS (Defense in Depth)
///    - Each header protects against a specific class of attacks
///    - Headers are added to EVERY response automatically
///    - Follows OWASP Secure Headers Project recommendations
/// 
/// 2. STRATEGY PATTERN
///    - Each header is a separate strategy
///    - Easy to enable/disable individual headers
///    - Easy to add new header strategies
/// 
/// 3. MIDDLEWARE PATTERN (Decorator)
///    - Wraps the request pipeline
///    - Adds headers to response BEFORE it reaches the client
///    - Does NOT modify the next middleware
/// 
/// 4. DEFENSIVE PROGRAMMING
///    - Headers only added in production (configurable)
///    - CSP only enabled when explicitly configured
///    - HSTS only enabled when explicitly configured
///    - Fail-safe defaults (headers missing is better than wrong headers)
/// 
/// OWASP PROTECTION MAPPING:
/// ─────────────────────────
/// X-Content-Type-Options → Prevents MIME-type sniffing attacks
/// X-Frame-Options        → Prevents clickjacking attacks
/// X-XSS-Protection       → Prevents reflected XSS (legacy browsers)
/// Strict-Transport-Security → Forces HTTPS (prevents protocol downgrade)
/// Content-Security-Policy  → Prevents XSS, injection, data exfiltration
/// Referrer-Policy          → Prevents information leakage via referrer
/// Cache-Control            → Prevents caching of sensitive data
/// Permissions-Policy       → Restricts browser features (camera, mic, etc.)
/// </summary>
public class SecurityHeadersMiddleware
{
    private readonly RequestDelegate _next;
    private readonly bool _enableHsts;
    private readonly int _hstsMaxAge;
    private readonly bool _enableReferrerPolicy;
    private readonly bool _enableCsp;
    private readonly bool _enableNoSniff;

    public SecurityHeadersMiddleware(
        RequestDelegate next,
        IConfiguration configuration)
    {
        _next = next;

        var securityConfig = configuration.GetSection("SecurityHeaders").Get<SecurityHeadersSettings>();
        _enableHsts = securityConfig?.EnableHsts ?? false;
        _hstsMaxAge = securityConfig?.HstsMaxAge ?? 2592000;
        _enableReferrerPolicy = securityConfig?.EnableReferrerPolicy ?? true;
        _enableCsp = securityConfig?.EnableCsp ?? false;
        _enableNoSniff = securityConfig?.EnableNoSniff ?? true;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // X-Content-Type-Options: Prevents MIME-type sniffing
        // SECURITY: Stops browsers from interpreting files as a different MIME type
        // Example: Prevents a malicious PDF from being executed as JavaScript
        AddHeaderIfNotPresent(context, "X-Content-Type-Options", "nosniff");

        // X-Frame-Options: Prevents clickjacking attacks
        // SECURITY: Stops malicious sites from embedding your site in an iframe
        // Example: Prevents attacker from overlaying your login form with a fake one
        AddHeaderIfNotPresent(context, "X-Frame-Options", "DENY");

        // X-XSS-Protection: Enables browser XSS filtering (legacy browsers)
        // SECURITY: Prevents reflected XSS attacks in older browsers
        // Note: Modern browsers use CSP instead, but keep for compatibility
        AddHeaderIfNotPresent(context, "X-XSS-Protection", "1; mode=block");

        // Strict-Transport-Security: Forces HTTPS connections
        // SECURITY: Prevents protocol downgrade attacks (SSL stripping)
        // Only enabled in production via configuration
        if (_enableHsts)
        {
            AddHeaderIfNotPresent(context, "Strict-Transport-Security", 
                $"max-age={_hstsMaxAge}; includeSubDomains; preload");
        }

        // Content-Security-Policy: Controls which resources the browser can load
        // SECURITY: Prevents XSS, injection, and data exfiltration attacks
        // Only enabled when explicitly configured (requires careful testing)
        if (_enableCsp)
        {
            AddHeaderIfNotPresent(context, "Content-Security-Policy",
                "default-src 'self'; " +
                "script-src 'self'; " +
                "style-src 'self' 'unsafe-inline'; " +
                "img-src 'self' data: https:; " +
                "font-src 'self'; " +
                "connect-src 'self'; " +
                "frame-ancestors 'none'; " +
                "base-uri 'self'; " +
                "form-action 'self'");
        }

        // Referrer-Policy: Controls referrer information leakage
        // SECURITY: Prevents sending sensitive URL data to third parties
        AddHeaderIfNotPresent(context, "Referrer-Policy", _enableReferrerPolicy ? "strict-origin-when-cross-origin" : "no-referrer");

        // Cache-Control: Prevents caching of sensitive data
        // SECURITY: Stops sensitive data from being cached on shared computers
        AddHeaderIfNotPresent(context, "Cache-Control", "no-cache, no-store, must-revalidate");
        AddHeaderIfNotPresent(context, "Pragma", "no-cache");
        AddHeaderIfNotPresent(context, "Expires", "0");

        // Permissions-Policy: Restricts browser features
        // SECURITY: Prevents unauthorized access to camera, microphone, geolocation, etc.
        AddHeaderIfNotPresent(context, "Permissions-Policy",
            "camera=(), microphone=(), geolocation=(), payment=()");

        await _next(context);
    }

    /// <summary>
    /// Adds header only if not already present (prevents duplicates)
    /// </summary>
    private static void AddHeaderIfNotPresent(HttpContext context, string name, string value)
    {
        if (!context.Response.Headers.ContainsKey(name))
        {
            context.Response.Headers.Append(name, value);
        }
    }
}

/// <summary>
/// ╔═══════════════════════════════════════════════════════════╗
/// ║  RATE LIMITING MIDDLEWARE                                 ║
/// ╚═══════════════════════════════════════════════════════════╝
/// 
/// CONCEPTS IMPLEMENTED:
/// ─────────────────────
/// 
/// 1. SLIDING WINDOW RATE LIMITING
///    - Tracks requests in a time window
///    - Sliding window is fairer than fixed window (no burst at boundaries)
///    - Prevents brute-force attacks on login/signup
///    - Prevents API abuse and DDoS
/// 
/// 2. STRATEGY PATTERN
///    - Login rate limiting strategy (strict: 5 attempts per 5 minutes)
///    - API rate limiting strategy (lenient: 100 requests per minute)
///    - Easy to add new strategies (e.g., signup, password reset)
/// 
/// 3. TOKEN BUCKET ALGORITHM
///    - Each client gets a bucket of tokens
///    - Each request consumes one token
///    - Tokens refill at a steady rate
///    - When bucket is empty → requests are rejected
/// 
/// 4. DEFENSIVE PROGRAMMING
///    - Rate limiting is disabled in development
///    - In-memory storage (use Redis for distributed deployments)
///    - Automatic cleanup of expired entries
///    - Returns 429 Too Many Requests with retry-after header
/// 
/// OWASP PROTECTION MAPPING:
/// ─────────────────────────
/// Brute-Force Protection → Login rate limiting (5 attempts per 5 minutes)
/// DDoS Protection        → API rate limiting (100 requests per minute)
/// Credential Stuffing    → Same as brute-force (IP-based tracking)
/// Resource Exhaustion    → API rate limiting prevents server overload
/// </summary>
public class RateLimitingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<RateLimitingMiddleware> _logger;
    private readonly Dictionary<string, List<DateTime>> _requestLogs = new();
    private readonly object _lock = new();

    // Rate limits (configurable via AppSettings in production)
    private readonly int _loginMaxAttempts = 5;
    private readonly TimeSpan _loginWindow = TimeSpan.FromMinutes(5);
    private readonly int _apiMaxRequests = 100;
    private readonly TimeSpan _apiWindow = TimeSpan.FromMinutes(1);

    public RateLimitingMiddleware(
        RequestDelegate next,
        ILogger<RateLimitingMiddleware> logger,
        IConfiguration configuration)
    {
        _next = next;
        _logger = logger;

        // Read from configuration (with fallback defaults)
        var rateLimitConfig = configuration.GetSection("RateLimiting").Get<RateLimitingSettings>();
        _loginMaxAttempts = rateLimitConfig?.Login.MaxAttempts ?? 5;
        _loginWindow = TimeSpan.FromSeconds(rateLimitConfig?.Login.WindowSeconds ?? 300);
        _apiMaxRequests = rateLimitConfig?.Api.MaxRequests ?? 100;
        _apiWindow = TimeSpan.FromSeconds(rateLimitConfig?.Api.WindowSeconds ?? 60);
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // Skip rate limiting for development environment
        if (context.Request.Host.Host.Contains("localhost", StringComparison.OrdinalIgnoreCase) ||
            context.Request.Host.Host.Contains("127.0.0.1", StringComparison.OrdinalIgnoreCase))
        {
            await _next(context);
            return;
        }

        var path = context.Request.Path.Value?.ToLowerInvariant() ?? string.Empty;
        var clientIp = context.Connection.RemoteIpAddress?.ToString() ?? "unknown";
        var endpoint = $"{clientIp}:{path}";

        // Apply login/signup rate limiting (STRICT)
        if (path.Contains("/auth/login") || path.Contains("/auth/register"))
        {
            if (IsRateLimited(endpoint, _loginMaxAttempts, _loginWindow, "login"))
            {
                _logger.LogWarning("Rate limit exceeded for login from IP: {ClientIp}", clientIp);
                context.Response.StatusCode = 429; // Too Many Requests
                context.Response.Headers.Append("Retry-After", _loginWindow.TotalSeconds.ToString());
                await context.Response.WriteAsJsonAsync(new
                {
                    error = "Too many attempts. Please try again later.",
                    retryAfter = _loginWindow.TotalSeconds
                });
                return;
            }
        }

        // Apply general API rate limiting (LENIENT)
        if (path.StartsWith("/api/"))
        {
            if (IsRateLimited(endpoint, _apiMaxRequests, _apiWindow, "api"))
            {
                _logger.LogWarning("Rate limit exceeded for API from IP: {ClientIp}, Path: {Path}", clientIp, path);
                context.Response.StatusCode = 429; // Too Many Requests
                context.Response.Headers.Append("Retry-After", _apiWindow.TotalSeconds.ToString());
                await context.Response.WriteAsJsonAsync(new
                {
                    error = "Too many requests. Please try again later.",
                    retryAfter = _apiWindow.TotalSeconds
                });
                return;
            }
        }

        await _next(context);
    }

    /// <summary>
    /// Checks if the client has exceeded the rate limit
    /// Uses sliding window algorithm for fair rate limiting
    /// </summary>
    private bool IsRateLimited(string endpoint, int maxRequests, TimeSpan window, string category)
    {
        lock (_lock)
        {
            var now = DateTime.UtcNow;
            var cutoff = now - window;

            // Get or create request log for this endpoint
            if (!_requestLogs.TryGetValue(endpoint, out var requests))
            {
                requests = new List<DateTime>();
                _requestLogs[endpoint] = requests;
            }

            // Remove expired requests (sliding window)
            requests.RemoveAll(r => r < cutoff);

            // Check if limit exceeded
            if (requests.Count >= maxRequests)
            {
                return true;
            }

            // Record this request
            requests.Add(now);

            // Cleanup old entries periodically (prevent memory leak)
            if (_requestLogs.Count > 10000)
            {
                CleanupOldEntries();
            }

            return false;
        }
    }

    /// <summary>
    /// Removes expired entries to prevent memory leaks
    /// </summary>
    private void CleanupOldEntries()
    {
        var cutoff = DateTime.UtcNow - TimeSpan.FromHours(1);
        var keysToRemove = new List<string>();

        foreach (var kvp in _requestLogs)
        {
            kvp.Value.RemoveAll(r => r < cutoff);
            if (kvp.Value.Count == 0)
            {
                keysToRemove.Add(kvp.Key);
            }
        }

        foreach (var key in keysToRemove)
        {
            _requestLogs.Remove(key);
        }
    }
}
