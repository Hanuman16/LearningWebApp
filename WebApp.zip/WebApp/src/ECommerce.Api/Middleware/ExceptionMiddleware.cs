namespace ECommerce.Api.Middleware;

using System.Net;
using System.Text.Json;
using Core.Exceptions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

/// <summary>
/// Global exception handling middleware.
/// WHY: Catches all unhandled exceptions and returns consistent error responses.
/// SECURITY: Never exposes stack traces or internal details to clients.
/// DEBUG: Logs full exception details server-side for debugging.
/// PERFORMANCE: Minimal overhead - only runs on exceptions.
/// </summary>
public class ExceptionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionMiddleware> _logger;

    public ExceptionMiddleware(RequestDelegate next, ILogger<ExceptionMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            await HandleExceptionAsync(context, ex);
        }
    }

    private async Task HandleExceptionAsync(HttpContext context, Exception exception)
    {
        // Log the full exception for debugging
        _logger.LogError(exception, "Unhandled exception occurred: {Message}", exception.Message);

        var response = context.Response;
        var problemDetails = new ProblemDetails();

        switch (exception)
        {
            case ValidationException ex:
                // WHY: Validation exceptions are client errors (400)
                response.StatusCode = (int)HttpStatusCode.BadRequest;
                problemDetails = new ProblemDetails
                {
                    Status = (int)HttpStatusCode.BadRequest,
                    Title = "Validation Error",
                    Detail = ex.Message,
                    Type = "https://tools.ietf.org/html/rfc7231#section-6.5.1"
                };
                break;

            case NotFoundException ex:
                // WHY: Not found exceptions are client errors (404)
                response.StatusCode = (int)HttpStatusCode.NotFound;
                problemDetails = new ProblemDetails
                {
                    Status = (int)HttpStatusCode.NotFound,
                    Title = "Not Found",
                    Detail = ex.Message,
                    Type = "https://tools.ietf.org/html/rfc7231#section-6.5.4"
                };
                break;

            case ConflictException ex:
                // WHY: Conflict exceptions are client errors (409)
                response.StatusCode = (int)HttpStatusCode.Conflict;
                problemDetails = new ProblemDetails
                {
                    Status = (int)HttpStatusCode.Conflict,
                    Title = "Conflict",
                    Detail = ex.Message,
                    Type = "https://tools.ietf.org/html/rfc7231#section-6.5.8"
                };
                break;

            case SecurityException ex:
                // WHY: Security exceptions are unauthorized (401)
                response.StatusCode = (int)HttpStatusCode.Unauthorized;
                problemDetails = new ProblemDetails
                {
                    Status = (int)HttpStatusCode.Unauthorized,
                    Title = "Unauthorized",
                    Detail = "You are not authorized to access this resource.",
                    Type = "https://tools.ietf.org/html/rfc7235#section-3.1"
                };
                break;

            case UnauthorizedAccessException ex:
                // WHY: Access denied exceptions are forbidden (403)
                response.StatusCode = (int)HttpStatusCode.Forbidden;
                problemDetails = new ProblemDetails
                {
                    Status = (int)HttpStatusCode.Forbidden,
                    Title = "Forbidden",
                    Detail = "You do not have permission to access this resource.",
                    Type = "https://tools.ietf.org/html/rfc7231#section-6.5.3"
                };
                break;

            default:
                // WHY: All other exceptions are internal server errors (500)
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                problemDetails = new ProblemDetails
                {
                    Status = (int)HttpStatusCode.InternalServerError,
                    Title = "An unexpected error occurred.",
                    Detail = "An unexpected error occurred. Please try again later.",
                    Type = "https://tools.ietf.org/html/rfc7231#section-6.6.1"
                };
                break;
        }

        // Set response content type
        response.ContentType = "application/problem+json";

        // Serialize and write the response
        var options = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
        var result = JsonSerializer.Serialize(problemDetails, options);
        await response.WriteAsync(result);
    }
}
