namespace ECommerce.Api.Configuration;

/// <summary>
/// ╔═══════════════════════════════════════════════════════════╗
/// ║  AZURE CONFIGURATION SETTINGS                            ║
/// ╚═══════════════════════════════════════════════════════════╝
/// 
/// CONCEPTS IMPLEMENTED:
/// ─────────────────────
/// 
/// 1. OPTIONS PATTERN (Strongly-typed Configuration)
///    - All Azure settings are strongly-typed classes
///    - Validated at startup using IValidateOptions
///    - Environment-based configuration (dev/staging/prod)
/// 
/// 2. SEPARATION OF CONFIG AND SECRETS
///    - Configuration values from appsettings.json
///    - Secrets from Azure Key Vault (production)
///    - Environment variables for local development
/// 
/// 3. DEFENSIVE PROGRAMMING
///    - Validates required settings at startup
///    - Throws InvalidOperationException if missing
///    - Provides helpful error messages
/// 
/// 4. SOLID PRINCIPLES:
///    - SRP: Each class represents one Azure service
///    - ISP: Small, focused interfaces
///    - DIP: Depends on abstractions (IConfiguration)
/// </summary>
public static class AzureSettings
{
    /// <summary>
    /// Azure Blob Storage configuration
    /// WHY: Store product images, user uploads, backups
    /// </summary>
    public class AzureBlobStorageSettings
    {
        /// <summary>
        /// Azure Storage Account connection string
        /// EXAMPLE: "DefaultEndpointsProtocol=https;AccountName=..."
        /// </summary>
        public string ConnectionString { get; set; } = string.Empty;

        /// <summary>
        /// Container name for product images
        /// DEFAULT: "product-images"
        /// </summary>
        public string ProductImagesContainer { get; set; } = "product-images";

        /// <summary>
        /// Container name for user uploads
        /// DEFAULT: "user-uploads"
        /// </summary>
        public string UserUploadsContainer { get; set; } = "user-uploads";

        /// <summary>
        /// Container name for backups
        /// DEFAULT: "backups"
        /// </summary>
        public string BackupsContainer { get; set; } = "backups";

        /// <summary>
        /// Maximum file size in bytes (50MB)
        /// DEFAULT: 52428800
        /// </summary>
        public long MaxFileSize { get; set; } = 52428800;

        /// <summary>
        /// Allowed file extensions (whitelist)
        /// DEFAULT: [".jpg", ".jpeg", ".png", ".gif", ".webp", ".pdf"]
        /// </summary>
        public string[] AllowedExtensions { get; set; } = [".jpg", ".jpeg", ".png", ".gif", ".webp", ".pdf"];

        /// <summary>
        /// Cache control header for public containers (1 day)
        /// DEFAULT: "public, max-age=86400"
        /// </summary>
        public string CacheControl { get; set; } = "public, max-age=86400";
    }

    /// <summary>
    /// Azure Service Bus configuration
    /// WHY: Async messaging for order processing, notifications, email
    /// </summary>
    public class AzureServiceBusSettings
    {
        /// <summary>
        /// Azure Service Bus connection string
        /// EXAMPLE: "Endpoint=sb://your-namespace.servicebus.windows.net/..."
        /// </summary>
        public string ConnectionString { get; set; } = string.Empty;

        /// <summary>
        /// Queue name for order processing
        /// DEFAULT: "order-queue"
        /// </summary>
        public string OrderQueue { get; set; } = "order-queue";

        /// <summary>
        /// Topic name for notifications
        /// DEFAULT: "notification-topic"
        /// </summary>
        public string NotificationTopic { get; set; } = "notification-topic";

        /// <summary>
        /// Subscription name for email notifications
        /// DEFAULT: "email-subscription"
        /// </summary>
        public string EmailSubscription { get; set; } = "email-subscription";

        /// <summary>
        /// Subscription name for SMS notifications
        /// DEFAULT: "sms-subscription"
        /// </summary>
        public string SmsSubscription { get; set; } = "sms-subscription";

        /// <summary>
        /// Maximum message time-to-live (24 hours)
        /// DEFAULT: TimeSpan.FromHours(24)
        /// </summary>
        public TimeSpan MessageTimeToLive { get; set; } = TimeSpan.FromHours(24);

        /// <summary>
        /// Maximum delivery count before dead-lettering
        /// DEFAULT: 10
        /// </summary>
        public int MaxDeliveryCount { get; set; } = 10;
    }

    /// <summary>
    /// Azure Key Vault configuration
    /// WHY: Secure secret management (JWT keys, connection strings)
    /// </summary>
    public class AzureKeyVaultSettings
    {
        /// <summary>
        /// Key Vault DNS name
        /// EXAMPLE: "https://your-keyvault.vault.azure.net/"
        /// </summary>
        public string VaultUri { get; set; } = string.Empty;

        /// <summary>
        /// Enable Key Vault integration
        /// WHY: Disable for local development, enable in production
        /// DEFAULT: false
        /// </summary>
        public bool Enabled { get; set; } = false;

        /// <summary>
        /// Refresh interval for cached secrets (1 hour)
        /// DEFAULT: TimeSpan.FromHours(1)
        /// </summary>
        public TimeSpan RefreshInterval { get; set; } = TimeSpan.FromHours(1);
    }

    /// <summary>
    /// Azure Redis Cache configuration
    /// WHY: Distributed caching for scalability
    /// </summary>
    public class AzureRedisCacheSettings
    {
        /// <summary>
        /// Redis connection string
        /// EXAMPLE: "your-cache.redis.cache.windows.net:6380,password=...,ssl=true"
        /// </summary>
        public string ConnectionString { get; set; } = string.Empty;

        /// <summary>
        /// Redis instance name (for multiple instances)
        /// DEFAULT: "ecommerce"
        /// </summary>
        public string InstanceName { get; set; } = "ecommerce";

        /// <summary>
        /// Default cache expiration (10 minutes)
        /// DEFAULT: TimeSpan.FromMinutes(10)
        /// </summary>
        public TimeSpan DefaultExpiration { get; set; } = TimeSpan.FromMinutes(10);
    }

    /// <summary>
    /// Azure Cosmos DB configuration
    /// WHY: NoSQL database for product catalog, user preferences
    /// </summary>
    public class AzureCosmosDbSettings
    {
        /// <summary>
        /// Cosmos DB account URI
        /// EXAMPLE: "https://your-account.documents.azure.com:443/"
        /// </summary>
        public string AccountUri { get; set; } = string.Empty;

        /// <summary>
        /// Cosmos DB primary key
        /// WHY: Stored in Key Vault in production
        /// </summary>
        public string PrimaryKey { get; set; } = string.Empty;

        /// <summary>
        /// Database name for e-commerce data
        /// DEFAULT: "ECommerce"
        /// </summary>
        public string DatabaseName { get; set; } = "ECommerce";

        /// <summary>
        /// Container name for products
        /// DEFAULT: "products"
        /// </summary>
        public string ProductsContainer { get; set; } = "products";

        /// <summary>
        /// Container name for orders
        /// DEFAULT: "orders"
        /// </summary>
        public string OrdersContainer { get; set; } = "orders";

        /// <summary>
        /// Partition key path for products
        /// DEFAULT: "/categoryId"
        /// </summary>
        public string ProductsPartitionKey { get; set; } = "/categoryId";

        /// <summary>
        /// Partition key path for orders
        /// DEFAULT: "/userId"
        /// </summary>
        public string OrdersPartitionKey { get; set; } = "/userId";
    }

    /// <summary>
    /// Azure Application Insights configuration
    /// WHY: Application performance monitoring (APM), telemetry
    /// </summary>
    public class AzureApplicationInsightsSettings
    {
        /// <summary>
        /// Application Insights connection string
        /// EXAMPLE: "InstrumentationKey=xxx;IngestionEndpoint=https://..."
        /// </summary>
        public string ConnectionString { get; set; } = string.Empty;

        /// <summary>
        /// Enable Application Insights
        /// WHY: Disable for local development to reduce noise
        /// DEFAULT: false
        /// </summary>
        public bool Enabled { get; set; } = false;

        /// <summary>
        /// Sampling percentage (100 = sample everything)
        /// DEFAULT: 100
        /// </summary>
        public double SamplingPercentage { get; set; } = 100;
    }

    /// <summary>
    /// Azure CDN configuration
    /// WHY: Content delivery network for static assets
    /// </summary>
    public class AzureCdnSettings
    {
        /// <summary>
        /// CDN endpoint hostname
        /// EXAMPLE: "your-cdn.azureedge.net"
        /// </summary>
        public string Hostname { get; set; } = string.Empty;

        /// <summary>
        /// Enable CDN for static assets
        /// DEFAULT: false
        /// </summary>
        public bool Enabled { get; set; } = false;

        /// <summary>
        /// Cache TTL in seconds (1 year)
        /// DEFAULT: 31536000
        /// </summary>
        public int CacheTtl { get; set; } = 31536000;
    }
}
