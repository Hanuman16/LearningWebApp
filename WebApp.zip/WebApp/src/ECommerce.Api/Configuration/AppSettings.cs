namespace ECommerce.Api.Configuration;

using Microsoft.AspNetCore.HttpOverrides;

/// <summary>
/// ╔═══════════════════════════════════════════════════════════╗
/// ║  APP SETTINGS - Strongly-typed Configuration             ║
/// ╚═══════════════════════════════════════════════════════════╝
/// 
/// CONCEPTS IMPLEMENTED:
/// ─────────────────────
/// 
/// 1. OPTIONS PATTERN (Configuration)
///    - Strongly-typed configuration classes
///    - Binds appsettings.json / environment variables to C# objects
///    - Type-safe access to configuration values
///    - Enables validation of configuration at startup
/// 
/// 2. SEPARATION OF CONFIG AND SECRETS
///    - Secrets come from environment variables (not hardcoded)
///    - appsettings.json contains defaults only
///    - Environment variables override appsettings values
///    - This follows the 12-Factor App methodology
/// 
/// 3. DEFENSIVE PROGRAMMING
///    - All values have fallback defaults
///    - Missing required values cause startup failure (fail-fast)
///    - No runtime null reference exceptions from config
/// 
/// 4. ENVIRONMENT-BASED CONFIGURATION
///    - Development: Debug mode, verbose errors, localhost
///    - Production: Hidden errors, rate limiting, secure CORS
///    - Detected via ASPNETCORE_ENVIRONMENT variable
/// </summary>
public class AppSettings
{
    /// <summary>
    /// Current environment: Development, Staging, Production
    /// Default: Development (shows verbose errors, Swagger)
    /// </summary>
    public string Environment { get; set; } = "Development";

    /// <summary>
    /// JWT Authentication Settings
    /// SECURITY: Key must be at least 32 characters
    /// </summary>
    public JwtSettings Jwt { get; set; } = new();

    /// <summary>
    /// CORS Settings
    /// SECURITY: In production, only allow specific origins
    /// </summary>
    public CorsSettings Cors { get; set; } = new();

    /// <summary>
    /// Database Connection String
    /// SECURITY: Never hardcode - use environment variables or secret manager
    /// </summary>
    public string ConnectionString { get; set; } = string.Empty;

    /// <summary>
    /// Redis Caching Settings
    /// PERFORMANCE: Empty connection string disables caching
    /// </summary>
    public RedisSettings Redis { get; set; } = new();

    /// <summary>
    /// File Upload Settings
    /// SECURITY: Validate file types, sizes, and prevent path traversal
    /// </summary>
    public FileUploadSettings FileUpload { get; set; } = new();

    /// <summary>
    /// Rate Limiting Settings
    /// SECURITY: Protect against brute-force and DDoS attacks
    /// </summary>
    public RateLimitingSettings RateLimiting { get; set; } = new();

    /// <summary>
    /// Security Headers Settings
    /// SECURITY: Protect against XSS, clickjacking, MIME sniffing
    /// </summary>
    public SecurityHeadersSettings SecurityHeaders { get; set; } = new();
}

/// <summary>
/// JWT Authentication Configuration
/// </summary>
public class JwtSettings
{
    /// <summary>
    /// Token issuer - who created this token
    /// </summary>
    public string Issuer { get; set; } = "ECommerceAPI";

    /// <summary>
    /// Token audience - who is this token for
    /// </summary>
    public string Audience { get; set; } = "ECommerceClient";

    /// <summary>
    /// Signing key - MUST be at least 32 characters in production
    /// SECURITY: Use environment variables or Azure Key Vault
    /// </summary>
    public string Key { get; set; } = string.Empty;

    /// <summary>
    /// Access token expiry in minutes
    /// Default: 60 minutes
    /// </summary>
    public int ExpiryMinutes { get; set; } = 60;

    /// <summary>
    /// Refresh token expiry in days
    /// Default: 7 days
    /// </summary>
    public int RefreshTokenDays { get; set; } = 7;
}

/// <summary>
/// CORS Configuration
/// SECURITY: In production, restrict to specific origins
/// </summary>
public class CorsSettings
{
    /// <summary>
    /// Allowed frontend origins (comma-separated in env vars)
    /// Development: localhost:4200
    /// Production: https://yourdomain.com
    /// </summary>
    public string[] AllowedOrigins { get; set; } = new[] { "http://localhost:4200" };
}

/// <summary>
/// Redis Caching Configuration
/// </summary>
public class RedisSettings
{
    /// <summary>
    /// Redis connection string
    /// Empty string disables caching (uses in-memory cache instead)
    /// </summary>
    public string ConnectionString { get; set; } = string.Empty;

    /// <summary>
    /// Prefix for all cache keys
    /// Prevents key collisions with other applications
    /// </summary>
    public string InstanceName { get; set; } = "ECommerce_";
}

/// <summary>
/// File Upload Security Configuration
/// SECURITY: Validate file types, sizes, and prevent path traversal attacks
/// </summary>
public class FileUploadSettings
{
    /// <summary>
    /// Maximum file size in bytes (default: 50MB)
    /// SECURITY: Prevents denial-of-service via large uploads
    /// </summary>
    public long MaxFileSize { get; set; } = 50 * 1024 * 1024;

    /// <summary>
    /// Allowed file extensions (whitelist approach - MOST SECURE)
    /// SECURITY: Never use blacklist (attackers find bypasses)
    /// </summary>
    public string[] AllowedExtensions { get; set; } = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" };

    /// <summary>
    /// Maximum ZIP extraction depth (prevents zip-slip attacks)
    /// SECURITY: Prevents "zip bomb" and path traversal attacks
    /// </summary>
    public int MaxExtractionDepth { get; set; } = 5;
}

/// <summary>
/// Rate Limiting Configuration
/// SECURITY: Protect against brute-force and DDoS attacks
/// </summary>
public class RateLimitingSettings
{
    /// <summary>
    /// Login endpoint rate limiting
    /// Max attempts before lockout
    /// </summary>
    public LoginRateLimit Login { get; set; } = new();

    /// <summary>
    /// General API rate limiting
    /// Max requests per time window
    /// </summary>
    public ApiRateLimit Api { get; set; } = new();
}

/// <summary>
/// Login Rate Limiting Settings
/// SECURITY: Prevent brute-force password attacks
/// </summary>
public class LoginRateLimit
{
    /// <summary>
    /// Maximum login attempts allowed
    /// Default: 5 attempts
    /// </summary>
    public int MaxAttempts { get; set; } = 5;

    /// <summary>
    /// Time window in seconds (default: 5 minutes)
    /// </summary>
    public int WindowSeconds { get; set; } = 300;
}

/// <summary>
/// API Rate Limiting Settings
/// SECURITY: Prevent API abuse and DDoS
/// </summary>
public class ApiRateLimit
{
    /// <summary>
    /// Maximum requests per time window
    /// Default: 100 requests per minute
    /// </summary>
    public int MaxRequests { get; set; } = 100;

    /// <summary>
    /// Time window in seconds (default: 1 minute)
    /// </summary>
    public int WindowSeconds { get; set; } = 60;
}

/// <summary>
/// Security Headers Configuration
/// SECURITY: Protect against XSS, clickjacking, MIME sniffing, and more
/// </summary>
public class SecurityHeadersSettings
{
    /// <summary>
    /// Enable HSTS (HTTP Strict Transport Security)
    /// Forces browsers to use HTTPS for all future requests
    /// </summary>
    public bool EnableHsts { get; set; } = false; // Only enable in production

    /// <summary>
    /// HSTS max age in seconds (default: 30 days)
    /// </summary>
    public int HstsMaxAge { get; set; } = 2592000;

    /// <summary>
    /// Enable Referrer Policy
    /// Controls how much referrer information is sent with requests
    /// </summary>
    public bool EnableReferrerPolicy { get; set; } = true;

    /// <summary>
    /// Enable Content Security Policy
    /// Controls which resources the browser is allowed to load
    /// </summary>
    public bool EnableCsp { get; set; } = false; // Enable in production with careful testing

    /// <summary>
    /// Enable X-Download-Options
    /// Prevents IE from executing downloads in site context
    /// </summary>
    public bool EnableNoSniff { get; set; } = true;
}
