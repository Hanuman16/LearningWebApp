namespace ECommerce.Api.Controllers;

using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

/// <summary>
/// Admin dashboard and reporting controller.
/// WHY: Provides analytics and reporting for administrators.
/// SECURITY: Admin-only access.
/// </summary>
[ApiController]
[Route("api/v1/[controller]")]
[Authorize(Roles = "Admin")]
public class DashboardController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly ILogger<DashboardController> _logger;

    public DashboardController(IMediator mediator, ILogger<DashboardController> logger)
    {
        _mediator = mediator;
        _logger = logger;
    }

    /// <summary>
    /// Gets dashboard overview statistics.
    /// </summary>
    [HttpGet("overview")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetOverview(CancellationToken cancellationToken)
    {
        try
        {
            var overview = await _mediator.Send(new GetDashboardOverviewQuery(), cancellationToken);
            return Ok(overview);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving dashboard overview");
            return StatusCode(500, "An error occurred while retrieving dashboard overview.");
        }
    }

    /// <summary>
    /// Gets sales report for a date range.
    /// </summary>
    [HttpGet("sales")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetSalesReport(
        [FromQuery] DateTime? startDate,
        [FromQuery] DateTime? endDate,
        CancellationToken cancellationToken)
    {
        try
        {
            var report = await _mediator.Send(new GetSalesReportQuery(startDate ?? DateTime.UtcNow.AddDays(-30), endDate ?? DateTime.UtcNow), cancellationToken);
            return Ok(report);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving sales report");
            return StatusCode(500, "An error occurred while retrieving sales report.");
        }
    }

    /// <summary>
    /// Gets inventory report.
    /// </summary>
    [HttpGet("inventory")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetInventoryReport(CancellationToken cancellationToken)
    {
        try
        {
            var report = await _mediator.Send(new GetInventoryReportQuery(), cancellationToken);
            return Ok(report);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving inventory report");
            return StatusCode(500, "An error occurred while retrieving inventory report.");
        }
    }

    /// <summary>
    /// Gets top selling products.
    /// </summary>
    [HttpGet("products/top-selling")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetTopSellingProducts(
        [FromQuery] int limit = 10,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var products = await _mediator.Send(new GetTopSellingProductsQuery(limit), cancellationToken);
            return Ok(products);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving top selling products");
            return StatusCode(500, "An error occurred while retrieving top selling products.");
        }
    }

    /// <summary>
    /// Gets recent orders.
    /// </summary>
    [HttpGet("orders/recent")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetRecentOrders(
        [FromQuery] int count = 10,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var orders = await _mediator.Send(new GetRecentOrdersQuery(count), cancellationToken);
            return Ok(orders);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving recent orders");
            return StatusCode(500, "An error occurred while retrieving recent orders.");
        }
    }
}

public record GetDashboardOverviewQuery() : IRequest<DashboardOverviewDto>;
public record GetSalesReportQuery(DateTime StartDate, DateTime EndDate) : IRequest<SalesReportDto>;
public record GetInventoryReportQuery() : IRequest<InventoryReportDto>;
public record GetTopSellingProductsQuery(int Limit) : IRequest<IEnumerable<TopSellingProductDto>>;
public record GetRecentOrdersQuery(int Count) : IRequest<IEnumerable<RecentOrderDto>>;

public record DashboardOverviewDto(
    decimal TotalRevenue,
    int TotalOrders,
    int TotalProducts,
    int TotalCustomers,
    decimal RevenueChangePercentage,
    int OrdersChangePercentage);

public record SalesReportDto(
    decimal TotalSales,
    int TotalOrders,
    decimal AverageOrderValue,
    IEnumerable<SalesByDayDto> DailySales);

public record SalesByDayDto(DateTime Date, decimal Sales, int Orders);

public record InventoryReportDto(
    int TotalProducts,
    int InStock,
    int LowStock,
    int OutOfStock,
    decimal TotalInventoryValue);

public record TopSellingProductDto(
    Guid ProductId,
    string ProductName,
    int QuantitySold,
    decimal Revenue);

public record RecentOrderDto(
    Guid Id,
    string OrderNumber,
    string Status,
    decimal Total,
    DateTime CreatedAt,
    string CustomerName);
