namespace ECommerce.Api.Controllers;

using AutoMapper;
using ECommerce.Application.Commands.Auth;
using ECommerce.Application.Commands.Products;
using ECommerce.Application.DTOs;
using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

/// <summary>
/// AUTH CONTROLLER - JWT Authentication & Authorization
/// </summary>
[ApiController]                                              // Attribute: Enables controller-specific behavior
[Route("api/v1/[controller]")]                               // ROUTING: All endpoints under /api/v1/auth
[AllowAnonymous]                                            // SECURITY: Default = no authentication required
                                                                    // (Individual endpoints can override with [Authorize])
public class AuthController : ControllerBase
{
    // DEPENDENCY INJECTION: All dependencies provided by DI container
    private readonly IMediator _mediator;                    // MEDIATOR PATTERN: Routes auth commands to handlers
    private readonly IMapper _mapper;                        // STRATEGY PATTERN: Maps DTOs to commands
    private readonly ILogger<AuthController> _logger;        // STRUCTURED LOGGING: Logs auth events

    // CONSTRUCTOR INJECTION: Enables testing with mocks
    public AuthController(IMediator mediator, IMapper mapper, ILogger<AuthController> logger)
    {
        _mediator = mediator;
        _mapper = mapper;
        _logger = logger;
    }

    /// <summary>
    /// ╔═══════════════════════════════════════════════════════════╗
    /// ║  REGISTER - Create New User Account                      ║
    /// ╚═══════════════════════════════════════════════════════════╝
    /// 
    /// CONCEPTS:
    /// ─────────
    /// • PASSWORD HASHING (BCrypt)
    ///   - Password is hashed in HANDLER (not controller)
    ///   - BCrypt generates random SALT for each password
    ///   - Salt is embedded in hash: $2a$11$... 
    ///   - Same password + different salt = different hash
    ///   - Prevents rainbow table attacks
    ///
    /// • UNIQUE CONSTRAINT ENFORCEMENT
    ///   - Email must be unique in database
    ///   - Handler checks for existing email
    ///   - Returns 409 Conflict if email exists
    ///
    /// • INPUT VALIDATION (Two Layers)
    ///   - Layer 1: [Required], [EmailAddress], [StringLength] on DTO
    ///   - Layer 2: FluentValidation rules in handler
    ///   - Defense in depth: if one layer fails, request is rejected
    ///
    /// • HTTP SEMANTICS
    ///   - POST /register → Create user
    ///   - 201 Created → User successfully created
    ///   - Location header → /api/v1/auth/{userId}
    ///
    /// • NO PASSWORD RETURNED
    ///   - Response contains ONLY userId (NOT password)
    ///   - Password is NEVER sent in API responses
    ///   - Security best practice
    /// </summary>
    [HttpPost("register")]                                      // HTTP POST: Create new user account
    [ProducesResponseType(typeof(Guid), StatusCodes.Status201Created)]      // DOCUMENTATION: Success with user ID
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)] // DOCUMENTATION: Validation error
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)] // DOCUMENTATION: Conflict (email exists)
    public async Task<IActionResult> Register([FromBody] RegisterRequest request, CancellationToken cancellationToken)
    {
        // CQRS: Create register command
        // Command contains registration data (name, email, password)
        var command = new RegisterCommand
        {
            FirstName = request.FirstName,
            LastName = request.LastName,
            Email = request.Email,
            Password = request.Password,
            PhoneNumber = request.PhoneNumber
        };

        // MEDIATOR: Send command to handler
        // Handler: validates input → hashes password → saves to DB → returns userId
        var userId = await _mediator.Send(command, cancellationToken);
        
        // HTTP 201 Created: User successfully created
        // Location header points to new user resource
        return CreatedAtAction(nameof(GetById), new { id = userId }, new { userId });
    }

    /// <summary>
    /// ╔═══════════════════════════════════════════════════════════╗
    /// ║  LOGIN - Authenticate User & Issue JWT Token             ║
    /// ╚═══════════════════════════════════════════════════════════╝
    /// 
    /// CONCEPTS:
    /// ─────────
    /// • JWT TOKEN GENERATION
    ///   - Handler validates email/password against database
    ///   - If valid → generate JWT token with user claims
    ///   - Claims: email, roles (Admin/User), userId
    ///   - Token signed with secret key (HMACSHA256)
    ///   - Token expires in 15 minutes (access token)
    ///   - Refresh token generated (7 days, stored in DB)
    ///
    /// • TOKEN STRUCTURE (3 Parts)
    ///   - Header: { "alg": "HS256", "typ": "JWT" }
    ///   - Payload: { "email": "user@example.com", "roles": ["User"], "exp": 1234567890 }
    ///   - Signature: HMACSHA256(base64(header) + "." + base64(payload), secretKey)
    ///   - Format: base64(header).base64(payload.signature
/// </summary>
    [HttpPost("login")]                                         // HTTP POST: Authenticate user
    [ProducesResponseType(typeof(TokenResponse), StatusCodes.Status200OK)]        // DOCUMENTATION: Success with tokens
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)] // DOCUMENTATION: Validation error
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]   // DOCUMENTATION: Invalid credentials
    public async Task<IActionResult> Login([FromBody] LoginRequest request, CancellationToken cancellationToken)
    {
        // CQRS: Create login command
        // Command contains credentials (email, password) + rememberMe flag
        var command = new LoginCommand
        {
            Email = request.Email,
            Password = request.Password,
            RememberMe = request.RememberMe
        };

        // MEDIATOR: Send command to handler
        // Handler: validates credentials → generates JWT → returns access token
        var token = await _mediator.Send(command, cancellationToken);
        
        // HTTP 200 OK: Login successful
        // Response contains access token (and refresh token if RememberMe = true)
        return Ok(new TokenResponse { AccessToken = token });
    }

    /// <summary>
    /// ╔═══════════════════════════════════════════════════════════╗
    /// ║  REFRESH TOKEN - Get New Access Token                    ║
    /// ╚═══════════════════════════════════════════════════════════╝
    /// 
    /// CONCEPTS:
    /// ─────────
    /// • ACCESS TOKEN vs REFRESH TOKEN
    ///   - Access Token: Short-lived (15 min), used for API requests
    ///   - Refresh Token: Long-lived (7 days), used to get new access tokens
    ///   - Why two tokens? Security: short-lived access token reduces attack window
    ///   - If access token is stolen, attacker has only 15 minutes
    ///   - Refresh token is stored securely (HTTP-only cookie or secure storage)
    ///
    /// • TOKEN ROTATION (Security Best Practice)
    ///   - Each refresh token can only be used ONCE
    ///   - New refresh token returned with each refresh
    ///   - Old refresh token is invalidated (revoked)
    ///   - Prevents replay attacks (attacker can't reuse stolen token)
    ///   - If old token is used → detect replay → revoke ALL tokens for user
    ///
    /// • SEAMLESS AUTHENTICATION
    ///   - Client uses refresh token to get new access token
    ///   - User doesn't need to re-enter credentials
    ///   - Refresh token stored securely (httpOnly cookie, localStorage)
    ///   - Access token stored in memory (NOT localStorage)
    ///
    /// • TOKEN VALIDATION
    ///   - Handler checks: token exists, not expired, not revoked
    ///   - Also validates: IP address, user agent (optional)
    ///   - Mismatch → token revoked (possible token theft detected)
    /// </summary>
    [HttpPost("refresh")]                                       // HTTP POST: Refresh access token
    [ProducesResponseType(typeof(TokenResponse), StatusCodes.Status200OK)]        // DOCUMENTATION: Success with new token
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)] // DOCUMENTATION: Validation error
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]   // DOCUMENTATION: Invalid/expired refresh token
    public async Task<IActionResult> Refresh([FromBody] RefreshTokenRequest request)
    {
        // CQRS: Create refresh token command
        // Command contains refresh token + metadata (IP, user agent)
        var command = new RefreshTokenCommand
        {
            RefreshToken = request.RefreshToken,
            IpAddress = Request.HttpContext.Connection.RemoteIpAddress?.ToString() ?? "",  // Track IP for security
            UserAgent = Request.Headers["User-Agent"].ToString()  // Track browser for security
        };

        // MEDIATOR: Send command to handler
        // Handler: validates refresh token → generates new access token → returns it
        var token = await _mediator.Send(command);
        
        // HTTP 200 OK: Refresh successful
        // Response contains NEW access token (and new refresh token if rotation enabled)
        return Ok(new TokenResponse { AccessToken = token });
    }

    /// <summary>
    /// ╔═══════════════════════════════════════════════════════════╗
    /// ║  FORGOT PASSWORD - Send Reset Email                        ║
    /// ╚═══════════════════════════════════════════════════════════╝
    /// 
    /// CONCEPTS:
    /// ─────────
    /// • SECURITY: EMAIL ENUMERATION PREVENTION
    ///   - ALWAYS returns success message, even if email doesn't exist
    ///   - Response is IDENTICAL whether email exists or not
    ///   - Prevents attackers from discovering valid emails
    ///   - If response differed: attacker could enumerate emails
    ///
    /// • PASSWORD RESET TOKEN
    ///   - Handler generates random token (GUID or crypto-safe random)
    ///   - Token is hashed (not stored in plain text)
    ///   - Token expires after 1 hour
    ///   - Token is single-use (used once, invalidated)
    ///   - Token sent via email (not returned in API response)
    ///
    /// • DEFENSIVE PROGRAMMING
    ///   - Even if email service fails, return 200 OK
    ///   - Don't expose internal errors to client
    ///   - Log failure for debugging, but don't return to client
    /// </summary>
    [HttpPost("forgot-password")]                               // HTTP POST: Request password reset
    [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]             // DOCUMENTATION: Success (always)
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)] // DOCUMENTATION: Validation error
    public async Task<IActionResult> ForgotPassword([FromBody] ForgotPasswordRequest request, CancellationToken cancellationToken)
    {
        // CQRS: Create forgot password command
        var command = new ForgotPasswordCommand { Email = request.Email };
        
        // MEDIATOR: Send command to handler
        // Handler: generates reset token → sends email → returns true
        // NOTE: Even if email fails, we return success (security)
        var result = await _mediator.Send(command, cancellationToken);
        
        // SECURITY: Always return success to prevent email enumeration
        // Attacker can't tell if email exists or not
        return Ok(new { message = "If the email exists, a reset link has been sent." });
    }

    /// <summary>
    /// ╔═══════════════════════════════════════════════════════════╗
    /// ║  RESET PASSWORD - Set New Password                       ║
    /// ╚═══════════════════════════════════════════════════════════╝
    /// 
    /// CONCEPTS:
    /// ─────────
    /// • TOKEN VALIDATION
    ///   - Token must be valid (not expired, not revoked)
    ///   - Token must match email
    ///   - Token is single-use (used once, invalidated)
    ///   - If token is invalid → return 401 Unauthorized
    ///
    /// • PASSWORD COMPLEXITY REQUIREMENTS
    ///   - Minimum 8 characters
    ///   - At least one uppercase letter
    ///   - At least one lowercase letter
    ///   - At least one digit
    ///   - At least one special character
    ///   - Enforced by FluentValidation in handler
    ///
    /// • PASSWORD HASHING (BCrypt)
    ///   - New password is hashed before saving
    ///   - BCrypt generates random salt
    ///   - Old password hash is replaced
    ///
    /// • SECURITY: NO PASSWORD IN RESPONSE
    ///   - Response does NOT contain password
    ///   - Password is NEVER sent in API responses
    ///   - User must login again with new password
    /// </summary>
    [HttpPost("reset-password")]                                // HTTP POST: Reset password with token
    [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]             // DOCUMENTATION: Success
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)] // DOCUMENTATION: Validation error
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]     // DOCUMENTATION: Invalid/expired token
    public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordRequest request, CancellationToken cancellationToken)
    {
        // CQRS: Create reset password command
        // Command contains email, reset token, and new password
        var command = new ResetPasswordCommand
        {
            Email = request.Email,
            ResetToken = request.ResetToken,
            NewPassword = request.NewPassword
        };

        // MEDIATOR: Send command to handler
        // Handler: validates token → hashes new password → saves to DB
        var result = await _mediator.Send(command, cancellationToken);
        
        // HTTP 200 OK: Password reset successful
        // User must login again with new password
        return Ok(new { message = "Password has been reset successfully." });
    }

    /// <summary>
    /// Gets user profile by ID.
    /// WHY: Returns user profile information.
    /// SECURITY: Users can only view their own profile (or admins can view any).
    /// </summary>
    [HttpGet("{id}")]
    [Authorize]
    [ProducesResponseType(typeof(UserProfileDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id, CancellationToken cancellationToken)
    {
        // TODO: Get user from JWT claims
        var userProfile = new UserProfileDto { Id = id, Email = "user@example.com" };
        return Ok(userProfile);
    }

    /// <summary>
    /// Updates user profile.
    /// WHY: Allows users to update their profile information.
    /// SECURITY: Users can only update their own profile.
    /// </summary>
    [HttpPut("profile")]
    [Authorize]
    [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileRequest request, CancellationToken cancellationToken)
    {
        // TODO: Get user ID from JWT claims
        var command = new UpdateProfileCommand
        {
            UserId = Guid.NewGuid(),
            FirstName = request.FirstName,
            LastName = request.LastName,
            PhoneNumber = request.PhoneNumber,
            ProfileImageUri = request.ProfileImageUri
        };

        var result = await _mediator.Send(command, cancellationToken);
        return Ok(result);
    }
}
