namespace ECommerce.Api.Controllers;

using ECommerce.Application.DTOs;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

/// <summary>
/// Inventory management controller.
/// WHY: Admin endpoint for managing stock levels and transactions.
/// SECURITY: Admin-only access.
/// BUSINESS RULE: Stock cannot go below zero.
/// BUSINESS RULE: All stock changes are logged as transactions.
/// </summary>
[ApiController]
[Route("api/v1/[controller]")]
[Authorize(Roles = "Admin")]
public class InventoryController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly ILogger<InventoryController> _logger;

    public InventoryController(IMediator mediator, ILogger<InventoryController> logger)
    {
        _mediator = mediator;
        _logger = logger;
    }

    /// <summary>
    /// Gets inventory items for a product.
    /// </summary>
    [HttpGet("product/{productId}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetProductInventory(Guid productId, CancellationToken cancellationToken)
    {
        try
        {
            var items = await _mediator.Send(new GetProductInventoryQuery(productId), cancellationToken);
            return Ok(items);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving inventory");
            return StatusCode(500, "An error occurred while retrieving inventory.");
        }
    }

    /// <summary>
    /// Gets low stock items.
    /// </summary>
    [HttpGet("low-stock")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetLowStockItems(CancellationToken cancellationToken)
    {
        try
        {
            var items = await _mediator.Send(new GetLowStockItemsQuery(), cancellationToken);
            return Ok(items);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving low stock items");
            return StatusCode(500, "An error occurred while retrieving low stock items.");
        }
    }

    /// <summary>
    /// Updates stock quantity.
    /// </summary>
    [HttpPost("{inventoryItemId}/stock")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> UpdateStock(Guid inventoryItemId, [FromBody] UpdateStockRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            await _mediator.Send(new UpdateStockCommand(inventoryItemId, request.Quantity, request.ReferenceNumber, request.Notes, userId), cancellationToken);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating stock");
            return StatusCode(500, "An error occurred while updating stock.");
        }
    }

    /// <summary>
    /// Gets inventory transaction history.
    /// </summary>
    [HttpGet("{inventoryItemId}/transactions")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetTransactionHistory(Guid inventoryItemId, [FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 20, CancellationToken cancellationToken = default)
    {
        try
        {
            var transactions = await _mediator.Send(new GetTransactionHistoryQuery(inventoryItemId, pageNumber, pageSize), cancellationToken);
            return Ok(transactions);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving transaction history");
            return StatusCode(500, "An error occurred while retrieving transaction history.");
        }
    }

    /// <summary>
    /// Gets inventory summary report.
    /// </summary>
    [HttpGet("summary")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetInventorySummary(CancellationToken cancellationToken)
    {
        try
        {
            var summary = await _mediator.Send(new GetInventorySummaryQuery(), cancellationToken);
            return Ok(summary);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving inventory summary");
            return StatusCode(500, "An error occurred while retrieving inventory summary.");
        }
    }
}

public record GetProductInventoryQuery(Guid ProductId) : IRequest<IEnumerable<InventoryItemDto>>;
public record GetLowStockItemsQuery() : IRequest<IEnumerable<InventoryItemDto>>;
public record UpdateStockCommand(Guid InventoryItemId, int Quantity, string ReferenceNumber, string? Notes, string? UserId) : IRequest<Unit>;
public record GetTransactionHistoryQuery(Guid InventoryItemId, int PageNumber, int PageSize) : IRequest<PagedResponse<InventoryTransactionDto>>;
public record GetInventorySummaryQuery() : IRequest<InventorySummaryDto>;

public record InventoryItemDto(
    Guid Id,
    Guid ProductId,
    string ProductName,
    string WarehouseLocation,
    int Quantity,
    int ReservedQuantity,
    int AvailableQuantity,
    int ReorderLevel,
    bool IsActive);

public record InventoryTransactionDto(
    Guid Id,
    Guid InventoryItemId,
    string Type,
    int Quantity,
    int PreviousQuantity,
    int NewQuantity,
    string ReferenceNumber,
    string? Notes,
    string? CreatedBy,
    DateTime CreatedAt);

public record InventorySummaryDto(
    int TotalProducts,
    int TotalQuantity,
    int TotalReserved,
    int TotalAvailable,
    int LowStockCount,
    int OutOfStockCount);

public record UpdateStockRequest(int Quantity, string ReferenceNumber, string? Notes);
