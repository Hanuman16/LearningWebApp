namespace ECommerce.Api.Controllers;

using AutoMapper;
using ECommerce.Application.Commands.Products;
using ECommerce.Application.DTOs;
using ECommerce.Application.Services;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

/// <summary>
/// ╔═══════════════════════════════════════════════════════════╗
/// ║  PRODUCTS CONTROLLER - RESTful API Endpoints             ║
/// ╚═══════════════════════════════════════════════════════════╝
/// 
/// CONCEPTS IMPLEMENTED:
/// ─────────────────────
/// 1. SINGLE RESPONSIBILITY PRINCIPLE (SRP)
///    - Controller ONLY handles HTTP concerns (requests/responses)
///    - Business logic is DELEGATED to handlers via MediatR
///    - If business rules change → edit Handler, NOT Controller
///    - If HTTP API changes → edit Controller, NOT Handler
///
/// 2. DEPENDENCY INVERSION PRINCIPLE (DIP)
///    - Depends on IMediator (ABSTRACTION), NOT ProductCommandHandler (concrete)
///    - Dependencies injected via CONSTRUCTOR INJECTION
///    - Enables testing with mock mediator
///    - Enables swapping MediatR for another messaging system
///
/// 3. RESTFUL API DESIGN
///    - HTTP GET → Read operations (list, get by id, featured)
///    - HTTP POST → Create operation
///    - HTTP PUT → Update operation
///    - HTTP DELETE → Delete operation
///    - Each method has semantic meaning
///
/// 4. ROLE-BASED ACCESS CONTROL (RBAC)
///    - [AllowAnonymous] → Public endpoints (anyone can access)
///    - [Authorize(Roles = "Admin")] → Admin-only endpoints
///    - Security is declared via ATTRIBUTES (declarative security)
///
/// 5. API VERSIONING
///    - Route: /api/v1/[controller] → Supports /api/v2/ in future
///    - Allows backward compatibility when API changes
///
/// 6. CONTRACT DOCUMENTATION
///    - [ProducesResponseType] → Documents expected HTTP responses
///    - Used by Swagger/OpenAPI to generate interactive docs
///    - Clients know what status codes to expect
///
/// 7. CANCELLATION TOKEN PATTERN
///    - CancellationToken passed to all async operations
///    - If client disconnects, operation is cancelled
///    - Prevents wasted server resources
///
/// 8. MEDIATOR PATTERN (Facade)
///    - Controller sends commands/queries to IMediator
///    - Mediator ROUTES to correct handler automatically
///    - Controller doesn't know which handler processes the request
///
/// 9. PROBLEMDETAILS (RFC 7807)
///    - Standardized error response format
///    - Clients can parse errors programmatically
///    - Consistent error structure across all endpoints
///
/// 10. PAGINATION PATTERN
///     - page + pageSize parameters limit result sets
///     - Server-side pagination (only requested records fetched)
///     - Prevents loading thousands of records at once
///
/// 11. FILTERING & SORTING PATTERN
///     - Optional query parameters for filtering (categoryId, minPrice, etc.)
///     - sortBy + sortOrder for dynamic sorting
///     - Flexible search without creating multiple endpoints
///
/// 12. HATEOAS (Hypermedia as Engine of Application State)
///     - CreatedAtAction returns Location header with new resource URI
///     - Client knows where to find newly created resource
/// </summary>
[ApiController]                                              // Attribute: Enables controller-specific behavior (model validation, etc.)
[Route("api/v1/[controller]")]                               // API VERSIONING + ROUTING: All endpoints under /api/v1/products
public class ProductsController : ControllerBase            // BASE CLASS: Provides HttpContext, Ok(), CreatedAtAction(), etc.
{
    // DEPENDENCY INJECTION: Dependencies are INJECTED, NOT created internally
    // This follows DIP - we depend on abstractions (interfaces), not concretions
    private readonly IMediator _mediator;                    // MEDIATOR PATTERN: Routes commands/queries to handlers (abstraction)
    private readonly IMapper _mapper;                        // STRATEGY PATTERN: Maps between DTOs and entities (abstraction)
    private readonly ILogger<ProductsController> _logger;    // STRUCTURED LOGGING: Logs for debugging and auditing
    private readonly ProductCachingService _cacheService;    // CACHING: Memory cache for product data (performance)

    // CONSTRUCTOR INJECTION: All dependencies provided by DI container
    // WHY: Enables unit testing (inject mocks), follows DIP
    public ProductsController(
        IMediator mediator,
        IMapper mapper,
        ILogger<ProductsController> logger,
        ProductCachingService cacheService)
    {
        _mediator = mediator;                                // Assign injected mediator to readonly field
        _mapper = mapper;                                    // Assign injected mapper to readonly field
        _logger = logger;                                    // Assign injected logger to readonly field
        _cacheService = cacheService;                        // Assign caching service for performance
    }

    /// <summary>
    /// ╔═══════════════════════════════════════════════════════════╗
    /// ║  GET PRODUCTS - List with Filtering, Sorting, Pagination ║
    /// ╚═══════════════════════════════════════════════════════════╝
    /// 
    /// CONCEPTS:
    /// ─────────
    /// • CQRS PATTERN: This is a QUERY (read operation), not a COMMAND
    ///   - Queries return data, Commands change state
    ///   - Separation allows independent optimization
    ///
    /// • SERVER-SIDE FILTERING (Performance)
    ///   - Filters applied in DATABASE, not in memory
    ///   - Only matching records returned (saves bandwidth)
    ///   - Without this: GetAll().Where() loads ALL records into memory
    ///
    /// • SERVER-SIDE SORTING (Performance)
    ///   - ORDER BY in SQL, not LINQ OrderBy() in memory
    ///   - Critical for large datasets
    ///
    /// • SERVER-SIDE PAGINATION (Performance)
    ///   - SQL: SELECT * FROM Products OFFSET @skip ROWS FETCH NEXT @pageSize ROWS ONLY
    ///   - NOT: GetAll().Skip(page).Take(pageSize) — that loads EVERYTHING
    ///
    /// • OPTIONAL PARAMETERS (Flexibility)
    ///   - All filters are nullable (string?, Guid?, decimal?, bool?)
    ///   - Client can filter by any combination of parameters
    ///   - No need for separate endpoints for each filter combination
    ///
    /// • DEFAULT VALUES (Usability)
    ///   - page = 1, pageSize = 20, sortBy = "CreatedAt", sortOrder = "Desc"
    ///   - Reasonable defaults for common use case (latest products)
    ///   - Client can override any parameter
    /// </summary>
    [HttpGet]                                              // HTTP GET: Retrieve resources
    [AllowAnonymous]                                      // SECURITY: No authentication required (public catalog)
    [ProducesResponseType(typeof(IEnumerable<ProductDto>), StatusCodes.Status200OK)]  // DOCUMENTATION: Success response
    public async Task<IActionResult> GetProducts(
        [FromQuery] string? keyword,                      // FILTER: Search by name/description
        [FromQuery] Guid? categoryId,                     // FILTER: Filter by category
        [FromQuery] decimal? minPrice,                    // FILTER: Minimum price
        [FromQuery] decimal? maxPrice,                    // FILTER: Maximum price
        [FromQuery] bool? isActive,                       // FILTER: Active/inactive products
        [FromQuery] bool? isFeatured,                     // FILTER: Featured products
        [FromQuery] string sortBy = "CreatedAt",          // SORT: Field to sort by
        [FromQuery] string sortOrder = "Desc",            // SORT: Ascending or descending
        [FromQuery] int page = 1,                         // PAGINATION: Page number (1-based)
        [FromQuery] int pageSize = 20,                    // PAGINATION: Items per page
        CancellationToken cancellationToken = default)    // CANCELLATION: Cancel if client disconnects
    {
        // CQRS: Create a QUERY object (not a COMMAND)
        // Queries are DECLARATIVE — they describe WHAT data we want
        // Commands are IMPERATIVE — they describe WHAT action to take
        var command = new SearchProductsQuery
        {
            Keyword = keyword,                            // Pass filter parameters to handler
            CategoryId = categoryId,
            MinPrice = minPrice,
            MaxPrice = maxPrice,
            IsActive = isActive,
            IsFeatured = isFeatured,
            SortBy = sortBy,
            SortOrder = sortOrder,
            Page = page,
            PageSize = pageSize
        };

        // MEDIATOR PATTERN: Send query to MediatR
        // MediatR finds the correct handler (ProductCommandHandler) automatically
        // Handler applies filters, sorting, pagination in DATABASE
        var products = await _mediator.Send(command, cancellationToken);
        
        // HTTP 200 OK: Success with response body
        return Ok(products);
    }

    /// <summary>
    /// ╔═══════════════════════════════════════════════════════════╗
    /// ║  GET BY ID - Single Product Lookup                       ║
    /// ╚═══════════════════════════════════════════════════════════╝
    /// 
    /// CONCEPTS:
    /// ─────────
    /// • RESTFUL RESOURCE IDENTIFICATION
    ///   - URL: /api/v1/products/{id}
    ///   - {id} is a RESOURCE IDENTIFIER (URI template)
    ///   - Each product has a unique URI
    ///
    /// • SPECIFIC RESPONSE TYPES
    ///   - 200 OK: Product found
    ///   - 404 Not Found: Product doesn't exist
    ///   - DOCUMENTED via [ProducesResponseType] attributes
    ///
    /// • CQRS QUERY PATTERN
    ///   - GetProductByIdQuery is a simple query (only needs Id)
    ///   - No filtering, no pagination needed
    ///   - Handler includes related data (category name, image URL)
    /// </summary>
    [HttpGet("{id}")]                                        // HTTP GET with route parameter
    [AllowAnonymous]                                       // SECURITY: Public access
    [ProducesResponseType(typeof(ProductDto), StatusCodes.Status200OK)]      // DOCUMENTATION: Success
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)] // DOCUMENTATION: Not found
    public async Task<IActionResult> GetById(Guid id, CancellationToken cancellationToken)
    {
        // CQRS: Create simple query with only the required parameter
        var command = new GetProductByIdQuery { Id = id };
        
        // Send to handler → Handler queries database → Returns ProductDto
        var product = await _mediator.Send(command, cancellationToken);
        
        // 200 OK with product data
        return Ok(product);
    }

    /// <summary>
    /// ╔═══════════════════════════════════════════════════════════╗
    /// ║  GET FEATURED - Homepage Products                        ║
    /// ╚═══════════════════════════════════════════════════════════╝
    /// 
    /// CONCEPTS:
    /// ─────────
    /// • PERFORMANCE OPTIMIZATION (Limited Result Set)
    ///   - count parameter limits number of products returned
    ///   - Default: 10 products
    ///   - Prevents loading entire catalog on homepage
    ///   - Homepage needs FEW products, not ALL products
    ///
    /// • SEMANTIC ROUTING
    ///   - URL: /api/v1/products/featured
    ///   - Not: /api/v1/products?isFeatured=true
    ///   - Semantic URL describes WHAT resource we want
    ///
    /// • CQRS QUERY PATTERN
    ///   - GetFeaturedProductsQuery is optimized for homepage
    ///   - Handler applies: WHERE IsFeatured = true ORDER BY CreatedAt DESC LIMIT @count
    ///   - Database-level filtering, not in-memory
    /// </summary>
    [HttpGet("featured")]                                    // HTTP GET: Semantic route for featured products
    [AllowAnonymous]                                       // SECURITY: Public access
    [ProducesResponseType(typeof(IEnumerable<ProductDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetFeatured([FromQuery] int count = 10, CancellationToken cancellationToken = default)
    {
        // CQRS: Query with count parameter for limiting results
        var command = new GetFeaturedProductsQuery { Count = count };
        
        // Handler returns only featured products, limited by count
        var products = await _mediator.Send(command, cancellationToken);
        
        return Ok(products);
    }

    /// <summary>
    /// ╔═══════════════════════════════════════════════════════════╗
    /// ║  CREATE PRODUCT - Add New Product                        ║
    /// ╚═══════════════════════════════════════════════════════════╝
    /// 
    /// CONCEPTS IMPLEMENTED:
    /// ─────────────────────
    /// 1. CQRS PATTERN - COMMAND (Write Operation)
    ///    - Commands CHANGE STATE (create, update, delete)
    ///    - Commands are SIDE-EFFECTS (create product, save to DB)
    ///    - Commands return minimal data (just the new ID)
    ///    - Queries READ data, Commands WRITE data
    ///    - Strict separation prevents accidental state changes
    ///
    /// 2. ROLE-BASED ACCESS CONTROL (RBAC)
    ///    - [Authorize(Roles = "Admin")] → Only admins can create products
    ///    - Regular users CANNOT create products
    ///    - Security is DECLARATIVE (attribute), not imperative (if/else)
    ///    - Easier to audit: just check attributes
    ///
    /// 3. HTTP SEMANTICS
    ///    - POST = Create new resource
    ///    - 201 Created = Resource successfully created
    ///    - Location header = URI of newly created resource
    ///    - Idempotent? NO → POSTing same data twice creates TWO products
    ///
    /// 4. HATEOAS (Hypermedia as Engine of Application State)
    ///    - CreatedAtAction returns 201 with Location header
    ///    - Location: /api/v1/products/{newProductId}
    ///    - Client knows WHERE to find the new resource
    ///    - RESTful APIs use HATEOAS for discoverability
    ///
    /// 5. DTO PATTERN (Data Transfer Object)
    ///    - Client sends CreateProductRequest (DTO)
    ///    - NOT Product entity (domain model)
    ///    - DTOs prevent over-posting attacks
    ///    - DTOs hide internal entity structure
    ///
    /// 6. VALIDATION SEPARATION
    ///    - Controller validates HTTP concerns (model state)
    ///    - Handler validates BUSINESS rules (SKU uniqueness, category exists)
    ///    - Two layers of validation = defense in depth
    ///
    /// 7. CANCELLATION TOKEN
    ///    - If client disconnects during creation, operation is cancelled
    ///    - Prevents partial writes to database
    ///    - Saves server resources
    /// </summary>
    [HttpPost]                                              // HTTP POST: Create new resource
    [Authorize(Roles = "Admin")]                            // SECURITY: Admin-only (create products)
    [ProducesResponseType(typeof(Guid), StatusCodes.Status201Created)]      // DOCUMENTATION: Success with ID
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)] // DOCUMENTATION: Validation error
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)] // DOCUMENTATION: Conflict (e.g., duplicate SKU)
    public async Task<IActionResult> Create([FromBody] CreateProductRequest request, CancellationToken cancellationToken)
    {
        // MAPPER PATTERN: Convert DTO to Command
        // DTO = Data Transfer Object (what client sends)
        // Command = CQRS command (what handler expects)
        // Manual mapping here (could use AutoMapper)
        var command = new CreateProductCommand
        {
            Name = request.Name,
            Description = request.Description,
            Price = request.Price,
            CompareAtPrice = request.CompareAtPrice,
            CategoryId = request.CategoryId,
            Sku = request.Sku,
            Weight = request.Weight,
            Dimensions = request.Dimensions,
            StockQuantity = request.StockQuantity,
            LowStockThreshold = request.LowStockThreshold
        };

        // MEDIATOR PATTERN: Send command to handler
        // Handler validates business rules, creates product, saves to DB
        // Handler returns the NEW PRODUCT ID
        var productId = await _mediator.Send(command, cancellationToken);
        
        // HTTP 201 Created: Resource successfully created
        // CreatedAtAction: Returns Location header with new resource URI
        // Location: /api/v1/products/{productId}
        // This is RESTful: client knows where to find the new resource
        return CreatedAtAction(nameof(GetById), new { id = productId }, new { productId });
    }

    /// <summary>
    /// ╔═══════════════════════════════════════════════════════════╗
    /// ║  UPDATE PRODUCT - Modify Existing Product                ║
    /// ╚═══════════════════════════════════════════════════════════╝
    /// 
    /// CONCEPTS IMPLEMENTED:
    /// ─────────────────────
    /// 1. HTTP SEMANTICS: PUT vs PATCH
    ///    - PUT = Full replacement (client sends ALL fields)
    ///    - PATCH = Partial update (client sends only changed fields)
    ///    - This API uses PUT but supports partial updates
    ///    - Handler only updates non-null fields
    ///
    /// 2. OPTIMISTIC CONCURRENCY CONTROL
    ///    - RowVersion (timestamp) column tracks last modification
    ///    - If RowVersion changed since read → CONFLICT
    ///    - Prevents lost updates (two admins editing same product)
    ///    - NOT implemented yet (TODO in handler)
    ///
    /// 3. PARTIAL UPDATE PATTERN
    ///    - Client can send only fields to update
    ///    - Null fields are NOT updated
    ///    - Example: { "Price": 29.99 } updates only price
    ///    - More flexible than requiring all fields
    ///
    /// 4. CQRS COMMAND PATTERN
    ///    - UpdateProductCommand = IMPERATIVE (DO this action)
    ///    - Contains ID + fields to update
    ///    - Handler finds product, applies changes, saves
    ///
    /// 5. RBAC (Role-Based Access Control)
    ///    - [Authorize(Roles = "Admin")] → Only admins can update
    ///    - Prevents regular users from modifying products
    /// </summary>
    [HttpPut("{id}")]                                        // HTTP PUT: Replace/Update resource
    [Authorize(Roles = "Admin")]                            // SECURITY: Admin-only (update products)
    [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]             // DOCUMENTATION: Success
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)] // DOCUMENTATION: Validation error
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]       // DOCUMENTATION: Not found
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateProductRequest request, CancellationToken cancellationToken)
    {
        // MAPPER PATTERN: Convert DTO to Command
        // ID comes from route parameter, not request body
        var command = new UpdateProductCommand
        {
            Id = id,                                            // Set ID from route parameter
            Name = request.Name,
            Description = request.Description,
            Price = request.Price,
            CompareAtPrice = request.CompareAtPrice,
            CategoryId = request.CategoryId,
            Sku = request.Sku,
            Weight = request.Weight,
            Dimensions = request.Dimensions,
            StockQuantity = request.StockQuantity,
            LowStockThreshold = request.LowStockThreshold,
            IsActive = request.IsActive,
            IsFeatured = request.IsFeatured
        };

        // MEDIATOR PATTERN: Send command to handler
        // Handler validates, finds product, applies changes, saves
        var result = await _mediator.Send(command, cancellationToken);
        
        // HTTP 200 OK: Update successful
        return Ok(result);
    }

    /// <summary>
    /// ╔═══════════════════════════════════════════════════════════╗
    /// ║  DELETE PRODUCT - Remove Product                         ║
    /// ╚═══════════════════════════════════════════════════════════╝
    /// 
    /// CONCEPTS IMPLEMENTED:
    /// ─────────────────────
    /// 1. HTTP SEMANTICS: DELETE
    ///    - DELETE = Remove resource
    ///    - 204 No Content = Success with NO response body
    ///    - Standard for DELETE operations
    ///
    /// 2. SOFT DELETE vs HARD DELETE
    ///    - SOFT DELETE: Set IsDeleted = true (default)
    ///      - Data is preserved (auditing, compliance)
    ///      - Can be restored later
    ///      - Filtered out from queries (WHERE IsDeleted = false)
    ///    - HARD DELETE: Permanently remove from database
    ///      - IRREVERSIBLE (cannot recover data)
    ///      - Used for GDPR compliance ("right to be forgotten")
    ///    - This API defaults to SOFT DELETE (safer)
    ///
    /// 3. BUSINESS RULE: CASCADE DELETION
    ///    - Products with active orders CANNOT be hard deleted
    ///    - Prevents orphaned order records
    ///    - Business rule enforced in HANDLER, not controller
    ///    - Controller delegates to handler (SRP)
    ///
    /// 4. RBAC (Role-Based Access Control)
    ///    - [Authorize(Roles = "Admin")] → Only admins can delete
    ///    - Prevents accidental deletion by regular users
    /// </summary>
    [HttpDelete("{id}")]                                      // HTTP DELETE: Remove resource
    [Authorize(Roles = "Admin")]                            // SECURITY: Admin-only (delete products)
    [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]             // DOCUMENTATION: Success
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]       // DOCUMENTATION: Not found
    public async Task<IActionResult> Delete(Guid id, [FromQuery] bool hardDelete = false, CancellationToken cancellationToken = default)
    {
        // CQRS: Create delete command with hardDelete flag
        // hardDelete = false → Soft delete (default, safer)
        // hardDelete = true → Hard delete (irreversible)
        var command = new DeleteProductCommand { Id = id, HardDelete = hardDelete };

        // MEDIATOR PATTERN: Send command to handler
        // Handler checks business rules (active orders?), performs delete
        var result = await _mediator.Send(command, cancellationToken);
        
        // HTTP 200 OK: Delete successful
        return Ok(result);
    }
}
