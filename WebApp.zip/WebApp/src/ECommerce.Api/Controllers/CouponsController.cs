namespace ECommerce.Api.Controllers;

using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

/// <summary>
/// Coupon and discount management controller.
/// WHY: Admin endpoint for managing promotional codes.
/// SECURITY: Admin-only access.
/// </summary>
[ApiController]
[Route("api/v1/[controller]")]
[Authorize(Roles = "Admin")]
public class CouponsController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly ILogger<CouponsController> _logger;

    public CouponsController(IMediator mediator, ILogger<CouponsController> logger)
    {
        _mediator = mediator;
        _logger = logger;
    }

    /// <summary>
    /// Gets all coupons (admin view).
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(CancellationToken cancellationToken)
    {
        try
        {
            var coupons = await _mediator.Send(new GetAllCouponsQuery(), cancellationToken);
            return Ok(coupons);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving coupons");
            return StatusCode(500, "An error occurred while retrieving coupons.");
        }
    }

    /// <summary>
    /// Gets a coupon by ID.
    /// </summary>
    [HttpGet("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id, CancellationToken cancellationToken)
    {
        try
        {
            var coupon = await _mediator.Send(new GetCouponByIdQuery(id), cancellationToken);
            return Ok(coupon);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving coupon");
            return StatusCode(500, "An error occurred while retrieving coupon.");
        }
    }

    /// <summary>
    /// Creates a new coupon.
    /// </summary>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create([FromBody] CreateCouponRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var coupon = await _mediator.Send(new CreateCouponCommand(
                request.Code,
                request.Description,
                request.Type,
                request.Value,
                request.MinOrderAmount,
                request.MaxDiscountAmount,
                request.MaxUsageCount,
                request.StartDate,
                request.EndDate,
                request.IsActive,
                request.IsPublic), cancellationToken);
            return CreatedAtAction(nameof(GetById), new { id = coupon.Id }, coupon);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating coupon");
            return StatusCode(500, "An error occurred while creating coupon.");
        }
    }

    /// <summary>
    /// Updates a coupon.
    /// </summary>
    [HttpPut("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateCouponRequest request, CancellationToken cancellationToken)
    {
        try
        {
            await _mediator.Send(new UpdateCouponCommand(
                id,
                request.Description,
                request.Type,
                request.Value,
                request.MinOrderAmount,
                request.MaxDiscountAmount,
                request.MaxUsageCount,
                request.EndDate,
                request.IsActive,
                request.IsPublic), cancellationToken);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating coupon");
            return StatusCode(500, "An error occurred while updating coupon.");
        }
    }

    /// <summary>
    /// Deletes a coupon.
    /// </summary>
    [HttpDelete("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> Delete(Guid id, CancellationToken cancellationToken)
    {
        try
        {
            await _mediator.Send(new DeleteCouponCommand(id), cancellationToken);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting coupon");
            return StatusCode(500, "An error occurred while deleting coupon.");
        }
    }

    /// <summary>
    /// Validates a coupon code (public endpoint for checkout).
    /// </summary>
    [HttpGet("validate/{code}")]
    [ProducesResponseType(typeof(CouponValidationDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    [AllowAnonymous]
    public async Task<IActionResult> ValidateCoupon(string code, CancellationToken cancellationToken)
    {
        try
        {
            var validation = await _mediator.Send(new ValidateCouponQuery(code), cancellationToken);
            return Ok(validation);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error validating coupon");
            return StatusCode(500, "An error occurred while validating coupon.");
        }
    }
}

public record GetAllCouponsQuery() : IRequest<IEnumerable<CouponDto>>;
public record GetCouponByIdQuery(Guid Id) : IRequest<CouponDto>;
public record CreateCouponCommand(
    string Code,
    string Description,
    string Type,
    decimal Value,
    decimal? MinOrderAmount,
    decimal? MaxDiscountAmount,
    int? MaxUsageCount,
    DateTime StartDate,
    DateTime? EndDate,
    bool IsActive,
    bool IsPublic) : IRequest<CouponDto>;
public record UpdateCouponCommand(
    Guid Id,
    string Description,
    string Type,
    decimal Value,
    decimal? MinOrderAmount,
    decimal? MaxDiscountAmount,
    int? MaxUsageCount,
    DateTime? EndDate,
    bool IsActive,
    bool IsPublic) : IRequest<Unit>;
public record DeleteCouponCommand(Guid Id) : IRequest<Unit>;
public record ValidateCouponQuery(string Code) : IRequest<CouponValidationDto>;

public record CouponDto(
    Guid Id,
    string Code,
    string Description,
    string Type,
    decimal Value,
    decimal? MinOrderAmount,
    decimal? MaxDiscountAmount,
    int? MaxUsageCount,
    int UsedCount,
    DateTime StartDate,
    DateTime? EndDate,
    bool IsActive,
    bool IsPublic);

public record CouponValidationDto(
    bool IsValid,
    string? ErrorMessage,
    decimal? DiscountAmount,
    decimal? DiscountPercentage);

public record CreateCouponRequest(
    string Code,
    string Description,
    string Type,
    decimal Value,
    decimal? MinOrderAmount,
    decimal? MaxDiscountAmount,
    int? MaxUsageCount,
    DateTime StartDate,
    DateTime? EndDate,
    bool IsActive,
    bool IsPublic);

public record UpdateCouponRequest(
    string Description,
    string Type,
    decimal Value,
    decimal? MinOrderAmount,
    decimal? MaxDiscountAmount,
    int? MaxUsageCount,
    DateTime? EndDate,
    bool IsActive,
    bool IsPublic);
