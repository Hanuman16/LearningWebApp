namespace ECommerce.Api.Controllers;

using AutoMapper;
using ECommerce.Application.Commands.Cart;
using ECommerce.Application.DTOs;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

/// <summary>
/// Shopping cart management controller.
/// WHY: Centralizes cart operations for the shopping experience.
/// BUSINESS RULE: Cart items persist across sessions for authenticated users.
/// BUSINESS RULE: Guest carts can be merged on login.
/// </summary>
[ApiController]
[Route("api/v1/[controller]")]
public class CartController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly IMapper _mapper;
    private readonly ILogger<CartController> _logger;

    public CartController(IMediator mediator, IMapper mapper, ILogger<CartController> logger)
    {
        _mediator = mediator;
        _mapper = mapper;
        _logger = logger;
    }

    /// <summary>
    /// Gets the current user's shopping cart.
    /// WHY: Retrieves cart with items, pricing, and totals.
    /// SECURITY: Users can only access their own cart.
    /// </summary>
    [HttpGet]
    [ProducesResponseType(typeof(CartDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetCart(CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (!string.IsNullOrEmpty(userId) && Guid.TryParse(userId, out var userIdGuid))
            {
                var userCart = await _mediator.Send(new GetCartQuery { UserId = userIdGuid }, cancellationToken);
                return Ok(userCart);
            }

            // Guest cart using cookie
            var guestCartId = Request.Cookies["guest_cart_id"];
            if (string.IsNullOrEmpty(guestCartId))
                return Ok(new CartDto { Id = Guid.Empty, Items = new List<CartItemDto>() });

            var guestQuery = new GetGuestCartQuery { CartId = Guid.Parse(guestCartId) };
            var guestCart = await _mediator.Send(guestQuery, cancellationToken);
            return Ok(guestCart);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving cart for user");
            return StatusCode(500, "An error occurred while retrieving your cart.");
        }
    }

    /// <summary>
    /// Adds an item to the shopping cart.
    /// WHY: Allows users to add products to their cart.
    /// BUSINESS RULE: Quantity cannot exceed available stock.
    /// BUSINESS RULE: If item exists, quantity is updated instead of adding duplicate.
    /// </summary>
    [HttpPost]
    [ProducesResponseType(typeof(CartDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> AddItem([FromBody] AddCartItemRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (!string.IsNullOrEmpty(userId) && Guid.TryParse(userId, out var userIdGuid))
            {
                var command = new AddCartItemCommand
                {
                    UserId = userIdGuid,
                    ProductId = request.ProductId,
                    Quantity = request.Quantity
                };

                var userCart = await _mediator.Send(command, cancellationToken);
                return CreatedAtAction(nameof(GetCart), new { }, userCart);
            }

            // Guest cart using cookie
            var guestCartId = Request.Cookies["guest_cart_id"];
            if (string.IsNullOrEmpty(guestCartId))
            {
                guestCartId = Guid.NewGuid().ToString();
                Response.Cookies.Append("guest_cart_id", guestCartId, new CookieOptions { Expires = DateTime.Now.AddDays(30) });
            }

            var guestCommand = new AddGuestCartItemCommand
            {
                CartId = Guid.Parse(guestCartId),
                ProductId = request.ProductId,
                Quantity = request.Quantity
            };

            var guestCart = await _mediator.Send(guestCommand, cancellationToken);
            return CreatedAtAction(nameof(GetCart), new { }, guestCart);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error adding item to cart");
            return StatusCode(500, "An error occurred while adding item to cart.");
        }
    }

    /// <summary>
    /// Updates the quantity of a cart item.
    /// WHY: Allows users to modify item quantities.
    /// BUSINESS RULE: Quantity must be positive.
    /// BUSINESS RULE: Cannot exceed available stock.
    /// </summary>
    [HttpPut("items/{cartItemId}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateItem(Guid cartItemId, [FromBody] UpdateCartItemRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var command = new UpdateCartItemCommand
            {
                CartItemId = cartItemId,
                Quantity = request.Quantity
            };

            await _mediator.Send(command, cancellationToken);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating cart item");
            return StatusCode(500, "An error occurred while updating cart item.");
        }
    }

    /// <summary>
    /// Removes an item from the shopping cart.
    /// WHY: Allows users to remove items they no longer want.
    /// </summary>
    [HttpDelete("items/{cartItemId}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> RemoveItem(Guid cartItemId, CancellationToken cancellationToken)
    {
        try
        {
            await _mediator.Send(new RemoveCartItemCommand { CartItemId = cartItemId }, cancellationToken);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error removing cart item");
            return StatusCode(500, "An error occurred while removing cart item.");
        }
    }

    /// <summary>
    /// Applies a coupon code to the cart.
    /// WHY: Allows users to apply discount codes.
    /// BUSINESS RULE: Coupon must be valid and not expired.
    /// BUSINESS RULE: Minimum order amount must be met.
    /// BUSINESS RULE: Usage limits must not be exceeded.
    /// </summary>
    [HttpPost("coupons")]
    [ProducesResponseType(typeof(CartDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> ApplyCoupon([FromBody] ApplyCouponRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId) || !Guid.TryParse(userId, out var userIdGuid))
                return Unauthorized();

            var cart = await _mediator.Send(new ApplyCouponCommand { UserId = userIdGuid, CouponCode = request.CouponCode }, cancellationToken);
            return Ok(cart);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error applying coupon");
            return StatusCode(500, "An error occurred while applying coupon.");
        }
    }

    /// <summary>
    /// Removes the applied coupon from the cart.
    /// WHY: Allows users to remove discount codes.
    /// </summary>
    [HttpDelete("coupons")]
    [ProducesResponseType(typeof(CartDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> RemoveCoupon(CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId) || !Guid.TryParse(userId, out var userIdGuid))
                return Unauthorized();

            var cart = await _mediator.Send(new RemoveCouponCommand { UserId = userIdGuid }, cancellationToken);
            return Ok(cart);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error removing coupon");
            return StatusCode(500, "An error occurred while removing coupon.");
        }
    }

    /// <summary>
    /// Clears all items from the shopping cart.
    /// WHY: Allows users to reset their cart.
    /// </summary>
    [HttpDelete("clear")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> ClearCart(CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId) || !Guid.TryParse(userId, out var userIdGuid))
                return Unauthorized();

            await _mediator.Send(new ClearCartCommand { UserId = userIdGuid }, cancellationToken);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error clearing cart");
            return StatusCode(500, "An error occurred while clearing cart.");
        }
    }
}
