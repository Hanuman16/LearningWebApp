namespace ECommerce.Api.Controllers;

using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

/// <summary>
/// Address management controller.
/// WHY: Users can manage multiple shipping/billing addresses.
/// BUSINESS RULE: Users can only access their own addresses.
/// BUSINESS RULE: One default address per type.
/// </summary>
[ApiController]
[Route("api/v1/[controller]")]
[Authorize]
public class AddressesController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly ILogger<AddressesController> _logger;

    public AddressesController(IMediator mediator, ILogger<AddressesController> logger)
    {
        _mediator = mediator;
        _logger = logger;
    }

    /// <summary>
    /// Gets all addresses for the current user.
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var addresses = await _mediator.Send(new GetAllAddressesQuery(userId), cancellationToken);
            return Ok(addresses);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving addresses");
            return StatusCode(500, "An error occurred while retrieving addresses.");
        }
    }

    /// <summary>
    /// Gets an address by ID.
    /// </summary>
    [HttpGet("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var address = await _mediator.Send(new GetAddressByIdQuery(id, userId), cancellationToken);
            return Ok(address);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving address");
            return StatusCode(500, "An error occurred while retrieving address.");
        }
    }

    /// <summary>
    /// Creates a new address.
    /// </summary>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create([FromBody] CreateAddressRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var address = await _mediator.Send(new CreateAddressCommand(
                userId,
                request.FirstName,
                request.LastName,
                request.Line1,
                request.Line2,
                request.City,
                request.State,
                request.PostalCode,
                request.Country,
                request.PhoneNumber,
                request.IsDefault,
                request.Type), cancellationToken);
            return CreatedAtAction(nameof(GetById), new { id = address.Id }, address);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating address");
            return StatusCode(500, "An error occurred while creating address.");
        }
    }

    /// <summary>
    /// Updates an address.
    /// </summary>
    [HttpPut("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateAddressRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            await _mediator.Send(new UpdateAddressCommand(
                id,
                userId,
                request.FirstName,
                request.LastName,
                request.Line1,
                request.Line2,
                request.City,
                request.State,
                request.PostalCode,
                request.Country,
                request.PhoneNumber,
                request.IsDefault,
                request.Type), cancellationToken);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating address");
            return StatusCode(500, "An error occurred while updating address.");
        }
    }

    /// <summary>
    /// Deletes an address.
    /// </summary>
    [HttpDelete("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> Delete(Guid id, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            await _mediator.Send(new DeleteAddressCommand(id, userId), cancellationToken);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting address");
            return StatusCode(500, "An error occurred while deleting address.");
        }
    }
}

public record GetAllAddressesQuery(string UserId) : IRequest<IEnumerable<AddressDto>>;
public record GetAddressByIdQuery(Guid Id, string UserId) : IRequest<AddressDto>;
public record CreateAddressCommand(
    string UserId,
    string FirstName,
    string LastName,
    string Line1,
    string? Line2,
    string City,
    string State,
    string PostalCode,
    string Country,
    string PhoneNumber,
    bool IsDefault,
    string Type) : IRequest<AddressDto>;
public record UpdateAddressCommand(
    Guid Id,
    string UserId,
    string FirstName,
    string LastName,
    string Line1,
    string? Line2,
    string City,
    string State,
    string PostalCode,
    string Country,
    string PhoneNumber,
    bool IsDefault,
    string Type) : IRequest<Unit>;
public record DeleteAddressCommand(Guid Id, string UserId) : IRequest<Unit>;

public record AddressDto(
    Guid Id,
    string FirstName,
    string LastName,
    string Line1,
    string? Line2,
    string City,
    string State,
    string PostalCode,
    string Country,
    string PhoneNumber,
    bool IsDefault,
    string Type);

public record CreateAddressRequest(
    string FirstName,
    string LastName,
    string Line1,
    string? Line2,
    string City,
    string State,
    string PostalCode,
    string Country,
    string PhoneNumber,
    bool IsDefault,
    string Type);

public record UpdateAddressRequest(
    string FirstName,
    string LastName,
    string Line1,
    string? Line2,
    string City,
    string State,
    string PostalCode,
    string Country,
    string PhoneNumber,
    bool IsDefault,
    string Type);
