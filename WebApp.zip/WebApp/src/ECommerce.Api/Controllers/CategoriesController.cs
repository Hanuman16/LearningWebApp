namespace ECommerce.Api.Controllers;

using ECommerce.Application.Commands.Products;
using ECommerce.Application.DTOs;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

/// <summary>
/// Category controller for CRUD operations.
/// WHY: Centralizes category endpoints.
/// SECURITY: Admin endpoints require Admin role.
/// </summary>
[ApiController]
[Route("api/v1/[controller]")]
public class CategoriesController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly ILogger<CategoriesController> _logger;

    public CategoriesController(IMediator mediator, ILogger<CategoriesController> logger)
    {
        _mediator = mediator;
        _logger = logger;
    }

    /// <summary>
    /// Gets all categories with hierarchy.
    /// WHY: Returns category tree for navigation.
    /// </summary>
    [HttpGet]
    [AllowAnonymous]
    [ProducesResponseType(typeof(IEnumerable<CategoryDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetCategories(CancellationToken cancellationToken)
    {
        // TODO: Query all active categories with hierarchy
        var categories = new List<CategoryDto>();
        return Ok(categories);
    }

    /// <summary>
    /// Gets a category by ID.
    /// WHY: Single category lookup.
    /// </summary>
    [HttpGet("{id}")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(CategoryDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id, CancellationToken cancellationToken)
    {
        // TODO: Get category by ID
        var category = new CategoryDto { Id = id, Name = "Electronics" };
        return Ok(category);
    }

    /// <summary>
    /// Creates a new category.
    /// WHY: Admin endpoint for adding categories.
    /// SECURITY: Requires authentication.
    /// </summary>
    [HttpPost]
    [Authorize]
    [ProducesResponseType(typeof(Guid), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create([FromBody] CreateCategoryRequest request, CancellationToken cancellationToken)
    {
        // TODO: Create category command
        var categoryId = Guid.NewGuid();
        return CreatedAtAction(nameof(GetById), new { id = categoryId }, new { categoryId });
    }

    /// <summary>
    /// Updates an existing category.
    /// WHY: Admin endpoint for updating category details.
    /// SECURITY: Requires Admin role.
    /// </summary>
    [HttpPut("{id}")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateCategoryRequest request, CancellationToken cancellationToken)
    {
        // TODO: Update category command
        return Ok(true);
    }

    /// <summary>
    /// Deletes a category.
    /// WHY: Admin endpoint for removing categories.
    /// SECURITY: Requires Admin role.
    /// BUSINESS RULE: Category cannot be deleted if it has products.
    /// </summary>
    [HttpDelete("{id}")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(Guid id, CancellationToken cancellationToken)
    {
        // TODO: Check if category has products
        // TODO: Delete category
        return Ok(true);
    }
}
