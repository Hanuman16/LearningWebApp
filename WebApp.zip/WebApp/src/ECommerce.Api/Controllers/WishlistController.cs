namespace ECommerce.Api.Controllers;

using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

/// <summary>
/// Wishlist management controller.
/// WHY: Allows users to save products for later.
/// BUSINESS RULE: Users can only access their own wishlists.
/// </summary>
[ApiController]
[Route("api/v1/[controller]")]
[Authorize]
public class WishlistController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly ILogger<WishlistController> _logger;

    public WishlistController(IMediator mediator, ILogger<WishlistController> logger)
    {
        _mediator = mediator;
        _logger = logger;
    }

    /// <summary>
    /// Gets the user's wishlist items.
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetWishlistItems(CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var items = await _mediator.Send(new GetWishlistItemsQuery(userId), cancellationToken);
            return Ok(items);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving wishlist");
            return StatusCode(500, "An error occurred while retrieving wishlist.");
        }
    }

    /// <summary>
    /// Adds a product to the wishlist.
    /// </summary>
    [HttpPost("items")]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> AddItem([FromBody] AddToWishlistRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            await _mediator.Send(new AddToWishlistCommand(userId, request.ProductId), cancellationToken);
            return CreatedAtAction(nameof(GetWishlistItems), new { });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error adding to wishlist");
            return StatusCode(500, "An error occurred while adding to wishlist.");
        }
    }

    /// <summary>
    /// Removes a product from the wishlist.
    /// </summary>
    [HttpDelete("items/{productId}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> RemoveItem(Guid productId, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            await _mediator.Send(new RemoveFromWishlistCommand(userId, productId), cancellationToken);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error removing from wishlist");
            return StatusCode(500, "An error occurred while removing from wishlist.");
        }
    }
}

public record GetWishlistItemsQuery(string UserId) : IRequest<IEnumerable<Guid>>;
public record AddToWishlistCommand(string UserId, Guid ProductId) : IRequest<Unit>;
public record RemoveFromWishlistCommand(string UserId, Guid ProductId) : IRequest<Unit>;

public record AddToWishlistRequest(Guid ProductId);
