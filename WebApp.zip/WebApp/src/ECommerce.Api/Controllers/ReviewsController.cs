namespace ECommerce.Api.Controllers;

using AutoMapper;
using ECommerce.Application.Commands.Reviews;
using ECommerce.Application.DTOs;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

/// <summary>
/// Product reviews and ratings controller.
/// WHY: Allows customers to review and rate products.
/// BUSINESS RULE: Only verified purchasers can leave reviews.
/// BUSINESS RULE: One review per user per product.
/// </summary>
[ApiController]
[Route("api/v1/[controller]")]
public class ReviewsController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly IMapper _mapper;
    private readonly ILogger<ReviewsController> _logger;

    public ReviewsController(IMediator mediator, IMapper mapper, ILogger<ReviewsController> logger)
    {
        _mediator = mediator;
        _mapper = mapper;
        _logger = logger;
    }

    /// <summary>
    /// Gets reviews for a product.
    /// </summary>
    [HttpGet("product/{productId}")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetProductReviews(Guid productId, CancellationToken cancellationToken)
    {
        try
        {
            var query = new GetProductReviewsQuery { ProductId = productId };
            var reviews = await _mediator.Send(query, cancellationToken);
            return Ok(reviews);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving reviews");
            return StatusCode(500, "An error occurred while retrieving reviews.");
        }
    }

    /// <summary>
    /// Creates a review for a product.
    /// </summary>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> CreateReview([FromBody] CreateReviewRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var command = new CreateReviewCommand
            {
                UserId = Guid.Parse(userId),
                ProductId = request.ProductId,
                Rating = request.Rating,
                Title = request.Title,
                Comment = request.Comment
            };
            var review = await _mediator.Send(command, cancellationToken);
            return CreatedAtAction(nameof(GetUserReview), new { reviewId = review.Id }, review);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating review");
            return StatusCode(500, "An error occurred while creating review.");
        }
    }

    /// <summary>
    /// Gets the current user's review for a product.
    /// </summary>
    [HttpGet("user/{productId}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetUserReview(Guid productId, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var command = new GetUserReviewQuery
            {
                UserId = Guid.Parse(userId),
                ProductId = productId
            };
            var review = await _mediator.Send(command, cancellationToken);
            return Ok(review);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving user review");
            return StatusCode(500, "An error occurred while retrieving review.");
        }
    }

    /// <summary>
    /// Updates the user's review.
    /// </summary>
    [HttpPut("{reviewId}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> UpdateReview(Guid reviewId, [FromBody] UpdateReviewRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var command = new UpdateReviewCommand
            {
                UserId = Guid.Parse(userId),
                ReviewId = reviewId,
                Rating = request.Rating,
                Title = request.Title,
                Comment = request.Comment
            };
            await _mediator.Send(command, cancellationToken);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating review");
            return StatusCode(500, "An error occurred while updating review.");
        }
    }

    /// <summary>
    /// Deletes the user's review.
    /// </summary>
    [HttpDelete("{reviewId}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> DeleteReview(Guid reviewId, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var command = new DeleteReviewCommand
            {
                UserId = Guid.Parse(userId),
                ReviewId = reviewId
            };
            await _mediator.Send(command, cancellationToken);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting review");
            return StatusCode(500, "An error occurred while deleting review.");
        }
    }

    /// <summary>
    /// Marks a review as helpful (admin only).
    /// </summary>
    [HttpPost("{reviewId}/helpful")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [Authorize(Roles = "Admin, Moderator")]
    public async Task<IActionResult> MarkHelpful(Guid reviewId, CancellationToken cancellationToken)
    {
        try
        {
            var command = new MarkHelpfulCommand { ReviewId = reviewId };
            await _mediator.Send(command, cancellationToken);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error marking review as helpful");
            return StatusCode(500, "An error occurred while marking review.");
        }
    }
}

// HTTP Request DTOs for Reviews
public record CreateReviewRequest(Guid ProductId, int Rating, string Title, string Comment);
public record UpdateReviewRequest(int Rating, string Title, string Comment);
