namespace ECommerce.Api.Controllers;

using ECommerce.Application.DTOs;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

/// <summary>
/// Notification management controller.
/// WHY: Users can view and manage their notifications.
/// SECURITY: Users can only access their own notifications.
/// </summary>
[ApiController]
[Route("api/v1/[controller]")]
[Authorize]
public class NotificationsController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly ILogger<NotificationsController> _logger;

    public NotificationsController(IMediator mediator, ILogger<NotificationsController> logger)
    {
        _mediator = mediator;
        _logger = logger;
    }

    /// <summary>
    /// Gets notifications for the current user.
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(
        [FromQuery] int pageNumber = 1,
        [FromQuery] int pageSize = 20,
        [FromQuery] bool? isRead = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var notifications = await _mediator.Send(new GetAllNotificationsQuery(userId, pageNumber, pageSize, isRead), cancellationToken);
            return Ok(notifications);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving notifications");
            return StatusCode(500, "An error occurred while retrieving notifications.");
        }
    }

    /// <summary>
    /// Gets a notification by ID.
    /// </summary>
    [HttpGet("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var notification = await _mediator.Send(new GetNotificationByIdQuery(id, userId), cancellationToken);
            return Ok(notification);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving notification");
            return StatusCode(500, "An error occurred while retrieving notification.");
        }
    }

    /// <summary>
    /// Marks a notification as read.
    /// </summary>
    [HttpPut("{id}/read")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> MarkAsRead(Guid id, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            await _mediator.Send(new MarkAsReadCommand(id, userId), cancellationToken);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error marking notification as read");
            return StatusCode(500, "An error occurred while marking notification as read.");
        }
    }

    /// <summary>
    /// Marks all notifications as read.
    /// </summary>
    [HttpPut("read-all")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> MarkAllAsRead(CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            await _mediator.Send(new MarkAllAsReadCommand(userId), cancellationToken);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error marking all notifications as read");
            return StatusCode(500, "An error occurred while marking all notifications as read.");
        }
    }

    /// <summary>
    /// Deletes a notification.
    /// </summary>
    [HttpDelete("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> Delete(Guid id, CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            await _mediator.Send(new DeleteNotificationCommand(id, userId), cancellationToken);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting notification");
            return StatusCode(500, "An error occurred while deleting notification.");
        }
    }

    /// <summary>
    /// Gets unread notification count.
    /// </summary>
    [HttpGet("unread-count")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetUnreadCount(CancellationToken cancellationToken)
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var count = await _mediator.Send(new GetUnreadCountQuery(userId), cancellationToken);
            return Ok(new { Count = count });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving unread count");
            return StatusCode(500, "An error occurred while retrieving unread count.");
        }
    }
}

public record GetAllNotificationsQuery(string UserId, int PageNumber, int PageSize, bool? IsRead) : IRequest<PagedResponse<NotificationDto>>;
public record GetNotificationByIdQuery(Guid Id, string UserId) : IRequest<NotificationDto>;
public record MarkAsReadCommand(Guid Id, string UserId) : IRequest<Unit>;
public record MarkAllAsReadCommand(string UserId) : IRequest<Unit>;
public record DeleteNotificationCommand(Guid Id, string UserId) : IRequest<Unit>;
public record GetUnreadCountQuery(string UserId) : IRequest<int>;

public record NotificationDto(
    Guid Id,
    string Title,
    string Message,
    string Type,
    string Channel,
    bool IsRead,
    string? ActionType,
    string? ActionUrl,
    DateTime? ReadAt,
    DateTime CreatedAt);
