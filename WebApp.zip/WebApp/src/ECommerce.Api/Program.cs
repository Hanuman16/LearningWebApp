// WHY: Program.cs is the entry point for the ASP.NET Core application.
// SECURITY: Configures security headers, CORS, and authentication.
// PERFORMANCE: Enables compression, caching, and rate limiting.
// DEBUG: Configures Serilog for structured logging.

using Asp.Versioning;
using ECommerce.Api.Middleware;
using ECommerce.Application.Extensions;
using ECommerce.Infrastructure.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Serilog;
using System.Text;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

// Configure Serilog for structured logging
// WHY: Serilog provides structured logging with multiple sinks
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Information()
    .MinimumLevel.Override("Microsoft", Serilog.Events.LogEventLevel.Warning)
    .MinimumLevel.Override("Microsoft.Hosting.Lifetime", Serilog.Events.LogEventLevel.Information)
    .MinimumLevel.Override("Microsoft.EntityFrameworkCore", Serilog.Events.LogEventLevel.Warning)
    .Enrich.FromLogContext()
    .Enrich.WithProperty("Application", "ECommerce API")
    .WriteTo.Console(restrictedToMinimumLevel: Serilog.Events.LogEventLevel.Information)
    .WriteTo.File("logs/log-.txt", rollingInterval: RollingInterval.Day, outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
    .CreateLogger();

builder.Host.UseSerilog();

// Add services to the container
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        // WHY: Ignore circular references to prevent stack overflow
        options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
        // WHY: Include null values in JSON for clarity
        options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.Never;
        // WHY: Use camelCase property names in JSON
        options.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
    });

// WHY: Add API versioning for backward compatibility
builder.Services.AddApiVersioning(options =>
{
    options.DefaultApiVersion = new ApiVersion(1, 0);
    options.AssumeDefaultVersionWhenUnspecified = true;
    options.ReportApiVersions = true;
}).AddApiExplorer(options =>
{
    options.GroupNameFormat = "'v'VVV";
    options.SubstituteApiVersionInUrl = true;
});

// WHY: Configure Swagger for API documentation
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "E-Commerce API",
        Version = "v1",
        Description = "A full-stack e-commerce and inventory management application",
        Contact = new Microsoft.OpenApi.Models.OpenApiContact
        {
            Name = "E-Commerce Support",
            Email = "support@ecommerce.com"
        }
    });

    // WHY: Add JWT authentication to Swagger
    options.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Description = "JWT Authorization header using the Bearer scheme."
    });

    options.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new Microsoft.OpenApi.Models.OpenApiSecurityScheme
            {
                Reference = new Microsoft.OpenApi.Models.OpenApiReference
                {
                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

// WHY: Configure CORS for frontend communication
// SECURITY: Restrict CORS to specific origins (NOT AllowAll in production)
builder.Services.AddCors(options =>
{
    // SECURITY: Development policy - restricted origins only
    options.AddPolicy("AllowFrontend", policy =>
    {
        var origins = builder.Configuration.GetSection("Frontend:AllowedOrigins").Get<string[]>() 
            ?? new[] { "http://localhost:4200", "https://localhost:4200" };
        policy.WithOrigins(origins)
              .AllowAnyMethod()
              .AllowAnyHeader()
              .AllowCredentials();
    });

    // SECURITY: Production policy - even more restrictive
    options.AddPolicy("AllowProduction", policy =>
    {
        var origins = builder.Configuration.GetSection("Frontend:AllowedOrigins").Get<string[]>()
            ?? Array.Empty<string>();
        policy.WithOrigins(origins)
              .AllowAnyMethod()
              .AllowAnyHeader()
              .AllowCredentials();
    });
});

// WHY: Configure authentication with JWT
// SECURITY: Use strongly-typed configuration with IOptions pattern
// SECURITY: Never use hardcoded fallback keys in production
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = "Bearer";
    options.DefaultChallengeScheme = "Bearer";
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        // SECURITY: Fail if JWT key is missing (never use hardcoded fallback in production)
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(
            builder.Configuration["Jwt:Key"] ?? throw new InvalidOperationException("JWT Key is missing from configuration"))),
        ClockSkew = TimeSpan.Zero
    };
});

builder.Services.AddAuthorization(options =>
{
    // WHY: Define roles for authorization
    options.AddPolicy("AdminPolicy", policy => policy.RequireRole("Admin"));
    options.AddPolicy("UserPolicy", policy => policy.RequireRole("User", "Admin"));
});

// WHY: Configure memory limit for large requests
builder.Services.Configure<Microsoft.AspNetCore.Http.Json.JsonOptions>(options =>
{
    options.SerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
});

builder.Services.Configure<ApiBehaviorOptions>(options =>
{
    options.SuppressModelStateInvalidFilter = true;
});

// Register Application and Infrastructure layers
builder.Services.AddApplication(builder.Configuration);
builder.Services.AddInfrastructure(builder.Configuration);

// WHY: Configure caching for performance
// SECURITY: Cache sensitive data carefully (never cache user-specific data without proper headers)
builder.Services.AddMemoryCache();
builder.Services.AddDistributedMemoryCache();

// WHY: Register audit log repository
// SECURITY: Audit logs track all security-relevant actions for compliance
builder.Services.AddScoped<ECommerce.Core.Interfaces.IAuditLogRepository, ECommerce.Infrastructure.Data.AuditLogRepository>();

// WHY: Register product caching service for performance
builder.Services.AddScoped<ECommerce.Application.Services.ProductCachingService>();

// WHY: Configure health checks for monitoring
builder.Services.AddHealthChecks();

var app = builder.Build();

// Create and seed the database on startup
using (var scope = app.Services.CreateScope())
{
    var dbContext = scope.ServiceProvider.GetRequiredService<ECommerce.Infrastructure.Data.ECommerceDbContext>();
    try
    {
        // Create database if it doesn't exist
        if (!dbContext.Database.CanConnect())
        {
            dbContext.Database.EnsureCreated();
        }
    }
    catch (Exception ex)
    {
        var logger = scope.ServiceProvider.GetRequiredService<Microsoft.Extensions.Logging.ILogger<Program>>();
        logger.LogError(ex, "An error occurred creating the database.");
    }
}

// Configure the HTTP request pipeline
// WHY: Middleware order matters - more specific middleware first
// SECURITY: Middleware executes in order - security headers first, then auth, then controllers

// WHY: Enable Swagger in development
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "E-Commerce API v1");
    });
}

// SECURITY: Enable security headers on ALL responses
// Adds X-Content-Type-Options, X-Frame-Options, HSTS, CSP, etc.
app.UseMiddleware<SecurityHeadersMiddleware>();

// SECURITY: Validate file uploads (size, type, magic bytes, zip-slip)
// Only applies to multipart/form-data requests
app.UseMiddleware<FileUploadSecurityMiddleware>();

// SECURITY: Rate limiting (disabled for localhost in development)
// Login: 5 attempts per 5 minutes
// API: 100 requests per minute
app.UseMiddleware<RateLimitingMiddleware>();

// SECURITY: Enable CORS with restricted origins (NOT AllowAll)
app.UseCors(app.Environment.IsDevelopment() ? "AllowFrontend" : "AllowProduction");

// SECURITY: Enable HTTPS redirection (forces secure connections)
app.UseHttpsRedirection();

// SECURITY: Enable authentication and authorization
app.UseAuthentication();
app.UseAuthorization();

// WHY: Map controllers
app.MapControllers();

// SECURITY: Exception handling middleware (last before response)
// Returns generic errors in production, detailed errors in development
app.UseMiddleware<ExceptionMiddleware>();

// WHY: Enable request logging
app.UseSerilogRequestLogging();

// WHY: Health checks for monitoring
app.MapHealthChecks("/health");
app.MapHealthChecks("/health/ready", new Microsoft.AspNetCore.Diagnostics.HealthChecks.HealthCheckOptions
{
    Predicate = check => check.Tags.Contains("ready")
});
app.MapHealthChecks("/health/alive", new Microsoft.AspNetCore.Diagnostics.HealthChecks.HealthCheckOptions
{
    Predicate = check => check.Tags.Contains("alive")
});

// WHY: Run the application
app.Run();

/// <summary>
/// Minimal host builder for top-level statements.
/// WHY: Provides Program class for testing and hosting.
/// </summary>
public partial class Program { }
