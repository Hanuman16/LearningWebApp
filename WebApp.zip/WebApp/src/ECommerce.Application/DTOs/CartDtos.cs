namespace ECommerce.Application.DTOs;

/// <summary>
/// DTO for adding an item to the shopping cart.
/// WHY: Separates input model from domain entity.
/// BUSINESS RULE: Quantity must be positive and not exceed available stock.
/// </summary>
public class AddCartItemRequest
{
    public required Guid ProductId { get; set; }
    public required int Quantity { get; set; }
}

/// <summary>
/// DTO for a cart item.
/// WHY: Separates output model from domain entity.
/// PERFORMANCE: Includes computed Subtotal to avoid recalculation.
/// </summary>
public class CartItemDto
{
    public Guid Id { get; set; }
    public Guid ProductId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public string? ProductImageUrl { get; set; }
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal Subtotal { get; set; }
    public bool IsAvailable { get; set; }
}

/// <summary>
/// DTO for the shopping cart.
/// WHY: Separates output model from domain entity.
/// PERFORMANCE: Includes computed totals to avoid client-side calculation.
/// SECURITY: Totals are calculated server-side, never trusted from client.
/// </summary>
public class CartDto
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
    public string Status { get; set; } = string.Empty;
    public List<CartItemDto> Items { get; set; } = new();
    public int ItemCount { get; set; }
    public decimal Subtotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal ShippingAmount { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public string? CouponCode { get; set; }
    public DateTime UpdatedAt { get; set; }
}

/// <summary>
/// DTO for updating a cart item quantity.
/// </summary>
public class UpdateCartItemRequest
{
    public required int Quantity { get; set; }
}

/// <summary>
/// DTO for applying a coupon code.
/// </summary>
public class ApplyCouponRequest
{
    public required string CouponCode { get; set; } = string.Empty;
}
