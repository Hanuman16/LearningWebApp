namespace ECommerce.Application.DTOs;

/// <summary>
/// DTO for creating a category.
/// WHY: Separates input model from domain entity.
/// </summary>
public class CreateCategoryRequest
{
    public required string Name { get; set; }
    public string? Description { get; set; }
    public Guid? ParentCategoryId { get; set; }
    public int DisplayOrder { get; set; } = 0;
}

/// <summary>
/// DTO for updating a category.
/// WHY: Separates input model from domain entity.
/// </summary>
public class UpdateCategoryRequest
{
    public string? Name { get; set; }
    public string? Description { get; set; }
    public Guid? ParentCategoryId { get; set; }
    public int? DisplayOrder { get; set; }
    public bool? IsActive { get; set; }
}

/// <summary>
/// DTO for category response.
/// WHY: Separates output model from domain entity.
/// </summary>
public class CategoryDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string? Slug { get; set; }
    public string? ImageUrl { get; set; }
    public Guid? ParentCategoryId { get; set; }
    public string? ParentCategoryName { get; set; }
    public int DisplayOrder { get; set; }
    public bool IsActive { get; set; }
    public int ChildCount { get; set; }
    public DateTime CreatedAt { get; set; }
}
