namespace ECommerce.Application.DTOs;

public record ReviewDto(
    Guid Id,
    Guid ProductId,
    string UserId,
    int Rating,
    string Title,
    string Comment,
    bool IsVerifiedPurchase,
    bool IsApproved,
    int HelpfulCount,
    int NotHelpfulCount,
    DateTime CreatedAt);

public record CouponDto(
    Guid Id,
    string Code,
    string Description,
    string Type,
    decimal Value,
    decimal? MinOrderAmount,
    decimal? MaxDiscountAmount,
    int? MaxUsageCount,
    int UsedCount,
    DateTime StartDate,
    DateTime? EndDate,
    bool IsActive,
    bool IsPublic);

public record CouponValidationDto(
    bool IsValid,
    string? ErrorMessage,
    decimal? DiscountAmount,
    decimal? DiscountPercentage);

public record InventoryItemDto(
    Guid Id,
    Guid ProductId,
    string ProductName,
    string WarehouseLocation,
    int Quantity,
    int ReservedQuantity,
    int AvailableQuantity,
    int ReorderLevel,
    bool IsActive);

public record InventoryTransactionDto(
    Guid Id,
    Guid InventoryItemId,
    string Type,
    int Quantity,
    int PreviousQuantity,
    int NewQuantity,
    string ReferenceNumber,
    string? Notes,
    string? CreatedBy,
    DateTime CreatedAt);

public record InventorySummaryDto(
    int TotalProducts,
    int TotalQuantity,
    int TotalReserved,
    int TotalAvailable,
    int LowStockCount,
    int OutOfStockCount);

public record DashboardOverviewDto(
    decimal TotalRevenue,
    int TotalOrders,
    int TotalProducts,
    int TotalCustomers,
    decimal RevenueChangePercentage,
    int OrdersChangePercentage);

public record SalesReportDto(
    decimal TotalSales,
    int TotalOrders,
    decimal AverageOrderValue,
    IEnumerable<SalesByDayDto> DailySales);

public record SalesByDayDto(DateTime Date, decimal Sales, int Orders);

public record InventoryReportDto(
    int TotalProducts,
    int InStock,
    int LowStock,
    int OutOfStock,
    decimal TotalInventoryValue);

public record TopSellingProductDto(
    Guid ProductId,
    string ProductName,
    int QuantitySold,
    decimal Revenue);

public record RecentOrderDto(
    Guid Id,
    string OrderNumber,
    string Status,
    decimal Total,
    DateTime CreatedAt,
    string CustomerName);

public record AddressDto(
    Guid Id,
    string FirstName,
    string LastName,
    string Line1,
    string? Line2,
    string City,
    string State,
    string PostalCode,
    string Country,
    string PhoneNumber,
    bool IsDefault,
    string Type);

public record NotificationDto(
    Guid Id,
    string Title,
    string Message,
    string Type,
    string Channel,
    bool IsRead,
    string? ActionType,
    string? ActionUrl,
    DateTime? ReadAt,
    DateTime CreatedAt);

public record PagedResponse<T>(
    IEnumerable<T> Items,
    int TotalCount,
    int PageNumber,
    int PageSize,
    int TotalPages)
{
    public bool HasPrevious => PageNumber > 1;
    public bool HasNext => PageNumber < TotalPages;
}
