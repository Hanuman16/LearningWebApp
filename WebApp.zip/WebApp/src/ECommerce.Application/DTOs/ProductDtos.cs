namespace ECommerce.Application.DTOs;

/// <summary>
/// DTO for creating a product.
/// WHY: Separates input model from domain entity.
/// BUSINESS RULE: Product must have a name, price, and SKU.
/// </summary>
public class CreateProductRequest
{
    public required string Name { get; set; }
    public required string Description { get; set; }
    public required decimal Price { get; set; }
    public decimal? CompareAtPrice { get; set; }
    public required Guid CategoryId { get; set; }
    public required string Sku { get; set; }
    public decimal? Weight { get; set; }
    public string? Dimensions { get; set; }
    public int StockQuantity { get; set; } = 0;
    public int LowStockThreshold { get; set; } = 5;
}

/// <summary>
/// DTO for updating a product.
/// WHY: Separates input model from domain entity.
/// </summary>
public class UpdateProductRequest
{
    public string? Name { get; set; }
    public string? Description { get; set; }
    public decimal? Price { get; set; }
    public decimal? CompareAtPrice { get; set; }
    public Guid? CategoryId { get; set; }
    public string? Sku { get; set; }
    public decimal? Weight { get; set; }
    public string? Dimensions { get; set; }
    public int? StockQuantity { get; set; }
    public int? LowStockThreshold { get; set; }
    public bool? IsActive { get; set; }
    public bool? IsFeatured { get; set; }
}

/// <summary>
/// DTO for product response.
/// WHY: Separates output model from domain entity.
/// PERFORMANCE: Includes computed properties to avoid N+1 queries.
/// </summary>
public class ProductDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string? Slug { get; set; }
    public decimal Price { get; set; }
    public decimal? CompareAtPrice { get; set; }
    public int StockQuantity { get; set; }
    public Guid CategoryId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public string Sku { get; set; } = string.Empty;
    public decimal? Weight { get; set; }
    public string? Dimensions { get; set; }
    public bool IsActive { get; set; }
    public bool IsFeatured { get; set; }
    public int ViewCount { get; set; }
    public int SalesCount { get; set; }
    public decimal AverageRating { get; set; }
    public int ReviewCount { get; set; }
    public string? PrimaryImageUrl { get; set; }
    public DateTime CreatedAt { get; set; }
}

/// <summary>
/// DTO for product search/filter/sort.
/// WHY: Separates query parameters from domain entity.
/// </summary>
public class ProductSearchParams
{
    public string? Keyword { get; set; }
    public Guid? CategoryId { get; set; }
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    public bool? IsActive { get; set; }
    public bool? IsFeatured { get; set; }
    public string SortBy { get; set; } = "CreatedAt";
    public string SortOrder { get; set; } = "Desc";
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
}
