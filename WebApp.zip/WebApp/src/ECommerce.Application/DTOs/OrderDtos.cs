namespace ECommerce.Application.DTOs;

/// <summary>
/// DTO for creating an order.
/// WHY: Separates input model from domain entity.
/// SECURITY: Order totals are calculated server-side, never trusted from client.
/// </summary>
public class CreateOrderRequest
{
    public required Guid ShippingAddressId { get; set; }
    public Guid? BillingAddressId { get; set; }
    public string? CustomerNotes { get; set; }
    public string? ShippingMethodName { get; set; }
    public string? CouponCode { get; set; }
}

/// <summary>
/// DTO for an order item.
/// WHY: Separates output model from domain entity.
/// </summary>
public class OrderItemDto
{
    public Guid Id { get; set; }
    public Guid ProductId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public string? ProductImageUrl { get; set; }
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal Subtotal { get; set; }
}

/// <summary>
/// DTO for an order response.
/// WHY: Separates output model from domain entity.
/// SECURITY: Order totals are calculated server-side, never trusted from client.
/// </summary>
public class OrderDto
{
    public Guid Id { get; set; }
    public string OrderNumber { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string? CustomerNotes { get; set; }
    public string? InternalNotes { get; set; }
    public decimal Subtotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal ShippingAmount { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public string Currency { get; set; } = "USD";
    public string? ShippingMethodName { get; set; }
    public string? TrackingNumber { get; set; }
    public string? TrackingUrl { get; set; }
    public string PaymentMethod { get; set; } = string.Empty;
    public string PaymentStatus { get; set; } = string.Empty;
    public DateTime? PaidAt { get; set; }
    public DateTime? ShippedAt { get; set; }
    public DateTime? DeliveredAt { get; set; }
    public AddressDto ShippingAddress { get; set; } = null!;
    public AddressDto BillingAddress { get; set; } = null!;
    public List<OrderItemDto> Items { get; set; } = new();
    public DateTime CreatedAt { get; set; }
}

/// <summary>
/// DTO for updating order status.
/// WHY: Separates input model from domain entity.
/// BUSINESS RULE: Status transitions must follow valid workflow.
/// </summary>
public class UpdateOrderStatusRequest
{
    public required string Status { get; set; }
    public string? TrackingNumber { get; set; }
    public string? TrackingUrl { get; set; }
    public string? InternalNotes { get; set; }
}
