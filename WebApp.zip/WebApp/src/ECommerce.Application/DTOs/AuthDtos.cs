namespace ECommerce.Application.DTOs;

/// <summary>
/// DTO for user registration.
/// WHY: Separates input model from domain entity.
/// SECURITY: Password must meet complexity requirements.
/// </summary>
public class RegisterRequest
{
    public required string FirstName { get; set; }
    public required string LastName { get; set; }
    public required string Email { get; set; }
    public required string Password { get; set; }
    public string? PhoneNumber { get; set; }
}

/// <summary>
/// DTO for user login.
/// WHY: Separates input model from domain entity.
/// </summary>
public class LoginRequest
{
    public required string Email { get; set; }
    public required string Password { get; set; }
    public bool RememberMe { get; set; }
}

/// <summary>
/// DTO for JWT token response.
/// WHY: Standardized token response format.
/// </summary>
public class TokenResponse
{
    public string AccessToken { get; set; } = string.Empty;
    public string RefreshToken { get; set; } = string.Empty;
    public DateTime ExpiresAt { get; set; }
    public string TokenType { get; set; } = "Bearer";
}

/// <summary>
/// DTO for refresh token request.
/// WHY: Separates input model from domain entity.
/// </summary>
public class RefreshTokenRequest
{
    public required string RefreshToken { get; set; }
}

/// <summary>
/// DTO for password reset request.
/// WHY: Separates input model from domain entity.
/// SECURITY: Token must be validated server-side.
/// </summary>
public class ForgotPasswordRequest
{
    public required string Email { get; set; }
}

/// <summary>
/// DTO for password reset confirmation.
/// WHY: Separates input model from domain entity.
/// SECURITY: Token must be validated server-side.
/// </summary>
public class ResetPasswordRequest
{
    public required string Email { get; set; }
    public required string ResetToken { get; set; }
    public required string NewPassword { get; set; }
}

/// <summary>
/// DTO for user profile.
/// WHY: Separates output model from domain entity.
/// SECURITY: Never expose password hashes or sensitive data.
/// </summary>
public class UserProfileDto
{
    public Guid Id { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string? PhoneNumber { get; set; }
    public string? ProfileImageUri { get; set; }
    public bool EmailConfirmed { get; set; }
    public bool IsActive { get; set; }
    public DateTime? LastLoginAt { get; set; }
    public DateTime CreatedAt { get; set; }
}

/// <summary>
/// DTO for updating user profile.
/// WHY: Separates input model from domain entity.
/// </summary>
public class UpdateProfileRequest
{
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? PhoneNumber { get; set; }
    public string? ProfileImageUri { get; set; }
}
