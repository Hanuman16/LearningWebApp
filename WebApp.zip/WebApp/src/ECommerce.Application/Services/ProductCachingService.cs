namespace ECommerce.Application.Services;

using Core.Interfaces;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;

/// <summary>
/// ╔═══════════════════════════════════════════════════════════╗
/// ║  PRODUCT CACHING SERVICE                                  ║
/// ╚═══════════════════════════════════════════════════════════╝
/// 
/// CONCEPTS IMPLEMENTED:
/// ─────────────────────
/// 
/// 1. CACHING STRATEGY (Performance Optimization)
///    - Product listings cached for 5 minutes
///    - Featured products cached for 10 minutes
///    - Category products cached for 5 minutes
///    - Cache keys include sort parameters to prevent stale data
/// 
/// 2. CACHE INVALIDATION STRATEGY
///    - Cache invalidated when products are created/updated/deleted
///    - Uses cache dependencies for automatic invalidation
///    - Manual invalidation via ClearCache method
/// 
/// 3. STRATEGY PATTERN
///    - Different cache durations for different data types
///    - Featured products (longer cache - changes less frequently)
///    - Regular products (shorter cache - changes more frequently)
/// 
/// 4. DEFENSIVE PROGRAMMING
///    - Null checks on all cache operations
///    - Graceful degradation (cache miss = database query)
///    - Logging for cache hits/misses/evictions
/// 
/// 5. SOLID PRINCIPLES:
///    - SRP: Service only handles caching logic
///    - OCP: Easy to add new cache strategies
///    - DIP: Depends on IMemoryCache interface
/// </summary>
public class ProductCachingService
{
    private readonly IMemoryCache _cache;
    private readonly ILogger<ProductCachingService> _logger;

    // Cache durations
    private static readonly TimeSpan ProductListCacheDuration = TimeSpan.FromMinutes(5);
    private static readonly TimeSpan FeaturedProductsCacheDuration = TimeSpan.FromMinutes(10);
    private static readonly TimeSpan CategoryProductsCacheDuration = TimeSpan.FromMinutes(5);
    private static readonly TimeSpan ProductDetailCacheDuration = TimeSpan.FromMinutes(3);

    // Cache key patterns
    private const string ProductListKeyPrefix = "products:list:";
    private const string FeaturedProductsKey = "products:featured:";
    private const string CategoryProductsKeyPrefix = "products:category:";
    private const string ProductDetailKeyPrefix = "products:detail:";

    public ProductCachingService(
        IMemoryCache cache,
        ILogger<ProductCachingService> logger)
    {
        _cache = cache;
        _logger = logger;
    }

    /// <summary>
    /// Gets cached product list or returns null (cache miss)
    /// WHY: Cache hit = fast response, Cache miss = database query
    /// </summary>
    public IEnumerable<object>? GetProductList(string cacheKey)
    {
        if (_cache.TryGetValue(cacheKey, out var result))
        {
            _logger.LogDebug("Cache HIT for product list: {CacheKey}", cacheKey);
            return result as IEnumerable<object>;
        }

        _logger.LogDebug("Cache MISS for product list: {CacheKey}", cacheKey);
        return null;
    }

    /// <summary>
    /// Caches product list with sliding expiration
    /// WHY: Sliding expiration extends cache life with each access
    /// </summary>
    public void SetProductList(string cacheKey, IEnumerable<object> products)
    {
        var cacheEntryOptions = new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = ProductListCacheDuration,
            SlidingExpiration = TimeSpan.FromMinutes(1),
            Priority = CacheItemPriority.Normal
        };

        _cache.Set(cacheKey, products, cacheEntryOptions);
        _logger.LogDebug("Cached product list for {Minutes} minutes: {CacheKey}",
            ProductListCacheDuration.TotalMinutes, cacheKey);
    }

    /// <summary>
    /// Gets cached featured products or returns null
    /// </summary>
    public IEnumerable<object>? GetFeaturedProducts(int count)
    {
        var cacheKey = $"{FeaturedProductsKey}{count}";
        
        if (_cache.TryGetValue(cacheKey, out var result))
        {
            _logger.LogDebug("Cache HIT for featured products (count={Count})", count);
            return result as IEnumerable<object>;
        }

        _logger.LogDebug("Cache MISS for featured products (count={Count})", count);
        return null;
    }

    /// <summary>
    /// Caches featured products
    /// </summary>
    public void SetFeaturedProducts(int count, IEnumerable<object> products)
    {
        var cacheKey = $"{FeaturedProductsKey}{count}";
        var cacheEntryOptions = new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = FeaturedProductsCacheDuration,
            SlidingExpiration = TimeSpan.FromMinutes(2),
            Priority = CacheItemPriority.High
        };

        _cache.Set(cacheKey, products, cacheEntryOptions);
        _logger.LogDebug("Cached featured products for {Minutes} minutes (count={Count})",
            FeaturedProductsCacheDuration.TotalMinutes, count);
    }

    /// <summary>
    /// Gets cached category products or returns null
    /// </summary>
    public IEnumerable<object>? GetCategoryProducts(Guid categoryId, string? sortBy, string? sortOrder)
    {
        var cacheKey = $"{CategoryProductsKeyPrefix}{categoryId}:{sortBy}:{sortOrder}";
        
        if (_cache.TryGetValue(cacheKey, out var result))
        {
            _logger.LogDebug("Cache HIT for category products: {CategoryId}", categoryId);
            return result as IEnumerable<object>;
        }

        _logger.LogDebug("Cache MISS for category products: {CategoryId}", categoryId);
        return null;
    }

    /// <summary>
    /// Caches category products
    /// </summary>
    public void SetCategoryProducts(Guid categoryId, string? sortBy, string? sortOrder, IEnumerable<object> products)
    {
        var cacheKey = $"{CategoryProductsKeyPrefix}{categoryId}:{sortBy}:{sortOrder}";
        var cacheEntryOptions = new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = CategoryProductsCacheDuration,
            SlidingExpiration = TimeSpan.FromMinutes(1),
            Priority = CacheItemPriority.Normal
        };

        _cache.Set(cacheKey, products, cacheEntryOptions);
        _logger.LogDebug("Cached category products for {Minutes} minutes: {CategoryId}",
            CategoryProductsCacheDuration.TotalMinutes, categoryId);
    }

    /// <summary>
    /// Gets cached product detail or returns null
    /// </summary>
    public object? GetProductDetail(Guid productId)
    {
        var cacheKey = $"{ProductDetailKeyPrefix}{productId}";
        
        if (_cache.TryGetValue(cacheKey, out var result))
        {
            _logger.LogDebug("Cache HIT for product detail: {ProductId}", productId);
            return result;
        }

        _logger.LogDebug("Cache MISS for product detail: {ProductId}", productId);
        return null;
    }

    /// <summary>
    /// Caches product detail
    /// </summary>
    public void SetProductDetail(Guid productId, object product)
    {
        var cacheKey = $"{ProductDetailKeyPrefix}{productId}";
        var cacheEntryOptions = new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = ProductDetailCacheDuration,
            SlidingExpiration = TimeSpan.FromMinutes(30),
            Priority = CacheItemPriority.Normal
        };

        _cache.Set(cacheKey, product, cacheEntryOptions);
        _logger.LogDebug("Cached product detail for {Minutes} minutes: {ProductId}",
            ProductDetailCacheDuration.TotalMinutes, productId);
    }

    /// <summary>
    /// Invalidates cache when products are updated/created/deleted
    /// WHY: Ensures stale data is never served after modifications
    /// </summary>
    public void InvalidateProductCache(Guid? productId = null)
    {
        if (productId.HasValue)
        {
            // Invalidate specific product
            var cacheKey = $"{ProductDetailKeyPrefix}{productId.Value}";
            _cache.Remove(cacheKey);
            _logger.LogInformation("Invalidated cache for product: {ProductId}", productId);
        }
        else
        {
            // Note: IMemoryCache doesn't support bulk clearing
            // Individual entries should be removed as needed
            _logger.LogWarning("Cannot invalidate all caches - IMemoryCache does not support bulk clear");
        }
    }

    /// <summary>
    /// Clears all caches (admin operation)
    /// Note: IMemoryCache does not support bulk clearing - this is a limitation
    /// </summary>
    public void ClearAllCaches()
    {
        // IMemoryCache does not support bulk clearing
        // Individual entries can be removed using Remove() with specific keys
        _logger.LogWarning("ClearAllCaches called but IMemoryCache does not support bulk clearing");
    }

    /// <summary>
    /// Gets cache statistics
    /// </summary>
    public Dictionary<string, object> GetCacheStats()
    {
        // Note: MemoryCache doesn't expose entry count directly
        // This is a simplified stats collection
        return new Dictionary<string, object>
        {
            ["ProductListCacheDuration"] = ProductListCacheDuration.TotalMinutes,
            ["FeaturedProductsCacheDuration"] = FeaturedProductsCacheDuration.TotalMinutes,
            ["CategoryProductsCacheDuration"] = CategoryProductsCacheDuration.TotalMinutes,
            ["ProductDetailCacheDuration"] = ProductDetailCacheDuration.TotalMinutes
        };
    }
}
