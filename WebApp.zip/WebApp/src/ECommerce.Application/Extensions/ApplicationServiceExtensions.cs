namespace ECommerce.Application.Extensions;

using FluentValidation;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

/// <summary>
/// Extension methods for registering Application services.
/// WHY: Centralizes service registration for the Application layer.
/// </summary>
public static class ApplicationServiceExtensions
{
    /// <summary>
    /// Registers Application layer services.
    /// WHY: Registers MediatR, AutoMapper, FluentValidation, and other application services.
    /// </summary>
    public static IServiceCollection AddApplication(this IServiceCollection services, Microsoft.Extensions.Configuration.IConfiguration configuration)
    {
        // WHY: Register MediatR for CQRS pattern
        services.AddMediatR(cfg =>
        {
            cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly());
        });

        // WHY: Register AutoMapper for DTO mapping
        services.AddAutoMapper(typeof(ApplicationServiceExtensions).Assembly);

        // WHY: Register FluentValidation validators
        services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

        // WHY: Configure JWT settings from appsettings.json
        services.Configure<JwtSettings>(configuration.GetSection("Jwt"));

        return services;
    }
}

/// <summary>
/// JWT configuration settings.
/// WHY: Reads JWT settings from appsettings.json.
/// </summary>
public class JwtSettings
{
    public string? Issuer { get; set; }
    public string? Audience { get; set; }
    public string? Key { get; set; }
    public int ExpiryMinutes { get; set; } = 60;
}
