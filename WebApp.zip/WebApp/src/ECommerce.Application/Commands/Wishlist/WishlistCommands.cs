namespace ECommerce.Application.Commands.Wishlist;

using MediatR;

public class GetWishlistItemsQuery : IRequest<IEnumerable<Guid>>
{
    public Guid UserId { get; set; }
}

public class AddToWishlistCommand : IRequest<Unit>
{
    public Guid UserId { get; set; }
    public Guid ProductId { get; set; }
}

public class RemoveFromWishlistCommand : IRequest<Unit>
{
    public Guid UserId { get; set; }
    public Guid ProductId { get; set; }
}
