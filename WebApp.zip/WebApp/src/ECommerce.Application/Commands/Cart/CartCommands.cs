namespace ECommerce.Application.Commands.Cart;

using MediatR;

public class GetCartQuery : IRequest<DTOs.CartDto>
{
    public Guid UserId { get; set; }
}

public class AddCartItemCommand : IRequest<DTOs.CartItemDto>
{
    public Guid UserId { get; set; }
    public Guid ProductId { get; set; }
    public int Quantity { get; set; }
}

public class UpdateCartItemCommand : IRequest<Unit>
{
    public Guid CartItemId { get; set; }
    public int Quantity { get; set; }
}

public class RemoveCartItemCommand : IRequest<Unit>
{
    public Guid CartItemId { get; set; }
}

public class ApplyCouponCommand : IRequest<DTOs.CartDto>
{
    public Guid UserId { get; set; }
    public string CouponCode { get; set; } = string.Empty;
}

public class RemoveCouponCommand : IRequest<DTOs.CartDto>
{
    public Guid UserId { get; set; }
}

public class ClearCartCommand : IRequest<Unit>
{
    public Guid UserId { get; set; }
}

public class GetGuestCartQuery : IRequest<DTOs.CartDto>
{
    public Guid CartId { get; set; }
}

public class AddGuestCartItemCommand : IRequest<DTOs.CartDto>
{
    public Guid CartId { get; set; }
    public Guid ProductId { get; set; }
    public int Quantity { get; set; }
}
