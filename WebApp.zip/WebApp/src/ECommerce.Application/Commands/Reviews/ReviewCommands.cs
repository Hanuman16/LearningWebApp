namespace ECommerce.Application.Commands.Reviews;

using MediatR;

public class GetProductReviewsQuery : IRequest<IEnumerable<DTOs.ReviewDto>>
{
    public Guid ProductId { get; set; }
}

public class CreateReviewCommand : IRequest<DTOs.ReviewDto>
{
    public Guid UserId { get; set; }
    public Guid ProductId { get; set; }
    public int Rating { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Comment { get; set; } = string.Empty;
}

public class GetUserReviewQuery : IRequest<DTOs.ReviewDto>
{
    public Guid UserId { get; set; }
    public Guid ProductId { get; set; }
}

public class UpdateReviewCommand : IRequest<Unit>
{
    public Guid UserId { get; set; }
    public Guid ReviewId { get; set; }
    public int Rating { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Comment { get; set; } = string.Empty;
}

public class DeleteReviewCommand : IRequest<Unit>
{
    public Guid UserId { get; set; }
    public Guid ReviewId { get; set; }
}

public class MarkHelpfulCommand : IRequest<Unit>
{
    public Guid ReviewId { get; set; }
}
