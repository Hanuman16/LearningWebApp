namespace ECommerce.Application.Commands.Inventory;

using MediatR;

public class GetProductInventoryQuery : IRequest<IEnumerable<DTOs.InventoryItemDto>>
{
    public Guid ProductId { get; set; }
}

public class GetLowStockItemsQuery : IRequest<IEnumerable<DTOs.InventoryItemDto>>
{
}

public class UpdateStockCommand : IRequest<Unit>
{
    public Guid InventoryItemId { get; set; }
    public int Quantity { get; set; }
    public string ReferenceNumber { get; set; } = string.Empty;
    public string? Notes { get; set; }
    public Guid? UserId { get; set; }
}

public class GetTransactionHistoryQuery : IRequest<DTOs.PagedResponse<DTOs.InventoryTransactionDto>>
{
    public Guid InventoryItemId { get; set; }
    public int PageNumber { get; set; } = 1;
    public int PageSize { get; set; } = 20;
}

public class GetInventorySummaryQuery : IRequest<DTOs.InventorySummaryDto>
{
}
