namespace ECommerce.Application.Commands.Products;

using DTOs;
using MediatR;

/// <summary>
/// Command for creating a product.
/// WHY: CQRS pattern separates write operations from queries.
/// BUSINESS RULE: Product must have a name, price, and unique SKU.
/// </summary>
public class CreateProductCommand : IRequest<Guid>
{
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public decimal? CompareAtPrice { get; set; }
    public Guid CategoryId { get; set; }
    public string Sku { get; set; } = string.Empty;
    public decimal? Weight { get; set; }
    public string? Dimensions { get; set; }
    public int StockQuantity { get; set; }
    public int LowStockThreshold { get; set; } = 5;
}

/// <summary>
/// Command for updating a product.
/// WHY: Allows partial updates (only changed fields).
/// </summary>
public class UpdateProductCommand : IRequest<bool>
{
    public Guid Id { get; set; }
    public string? Name { get; set; }
    public string? Description { get; set; }
    public decimal? Price { get; set; }
    public decimal? CompareAtPrice { get; set; }
    public Guid? CategoryId { get; set; }
    public string? Sku { get; set; }
    public decimal? Weight { get; set; }
    public string? Dimensions { get; set; }
    public int? StockQuantity { get; set; }
    public int? LowStockThreshold { get; set; }
    public bool? IsActive { get; set; }
    public bool? IsFeatured { get; set; }
}

/// <summary>
/// Command for deleting a product.
/// WHY: Soft delete by default, hard delete is irreversible.
/// BUSINESS RULE: Products with active orders cannot be hard deleted.
/// </summary>
public class DeleteProductCommand : IRequest<bool>
{
    public Guid Id { get; set; }
    public bool HardDelete { get; set; }
}

/// <summary>
/// Query for searching products.
/// WHY: CQRS pattern separates queries from commands.
/// PERFORMANCE: Supports filtering, sorting, and pagination.
/// </summary>
public class SearchProductsQuery : IRequest<IEnumerable<ProductDto>>
{
    public string? Keyword { get; set; }
    public Guid? CategoryId { get; set; }
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    public bool? IsActive { get; set; }
    public bool? IsFeatured { get; set; }
    public string SortBy { get; set; } = "CreatedAt";
    public string SortOrder { get; set; } = "Desc";
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
}

/// <summary>
/// Query for getting a product by ID.
/// WHY: Single product lookup with related data.
/// PERFORMANCE: Includes category name and primary image URL.
/// </summary>
public class GetProductByIdQuery : IRequest<ProductDto>
{
    public Guid Id { get; set; }
}

/// <summary>
/// Query for getting featured products.
/// WHY: Featured products are displayed on homepage.
/// PERFORMANCE: Limited count for performance.
/// </summary>
public class GetFeaturedProductsQuery : IRequest<IEnumerable<ProductDto>>
{
    public int Count { get; set; } = 10;
}
