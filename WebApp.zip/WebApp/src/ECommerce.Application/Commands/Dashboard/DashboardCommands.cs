namespace ECommerce.Application.Commands.Dashboard;

using MediatR;

public class GetDashboardOverviewQuery : IRequest<DTOs.DashboardOverviewDto>
{
}

public class GetSalesReportQuery : IRequest<DTOs.SalesReportDto>
{
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
}

public class GetInventoryReportQuery : IRequest<DTOs.InventoryReportDto>
{
}

public class GetTopSellingProductsQuery : IRequest<IEnumerable<DTOs.TopSellingProductDto>>
{
    public int Limit { get; set; } = 10;
}

public class GetRecentOrdersQuery : IRequest<IEnumerable<DTOs.RecentOrderDto>>
{
    public int Limit { get; set; } = 10;
}
