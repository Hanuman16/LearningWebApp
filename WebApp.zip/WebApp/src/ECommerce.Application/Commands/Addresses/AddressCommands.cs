namespace ECommerce.Application.Commands.Addresses;

using Core.Entities;
using MediatR;

public class GetAllAddressesQuery : IRequest<IEnumerable<DTOs.AddressDto>>
{
    public Guid UserId { get; set; }
}

public class GetAddressByIdQuery : IRequest<DTOs.AddressDto>
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
}

public class CreateAddressCommand : IRequest<DTOs.AddressDto>
{
    public Guid UserId { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Line1 { get; set; } = string.Empty;
    public string? Line2 { get; set; }
    public string City { get; set; } = string.Empty;
    public string State { get; set; } = string.Empty;
    public string PostalCode { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
    public string PhoneNumber { get; set; } = string.Empty;
    public bool IsDefault { get; set; }
    public AddressType Type { get; set; }
}

public class UpdateAddressCommand : IRequest<Unit>
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Line1 { get; set; } = string.Empty;
    public string? Line2 { get; set; }
    public string City { get; set; } = string.Empty;
    public string State { get; set; } = string.Empty;
    public string PostalCode { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
    public string PhoneNumber { get; set; } = string.Empty;
    public bool IsDefault { get; set; }
    public AddressType Type { get; set; }
}

public class DeleteAddressCommand : IRequest<Unit>
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
}
