namespace ECommerce.Application.Commands.Notifications;

using MediatR;

public class GetAllNotificationsQuery : IRequest<DTOs.PagedResponse<DTOs.NotificationDto>>
{
    public Guid UserId { get; set; }
    public bool? IsRead { get; set; }
    public int PageNumber { get; set; } = 1;
    public int PageSize { get; set; } = 20;
}

public class GetNotificationByIdQuery : IRequest<DTOs.NotificationDto>
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
}

public class MarkAsReadCommand : IRequest<Unit>
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
}

public class MarkAllAsReadCommand : IRequest<Unit>
{
    public Guid UserId { get; set; }
}

public class DeleteNotificationCommand : IRequest<Unit>
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
}

public class GetUnreadCountQuery : IRequest<int>
{
    public Guid UserId { get; set; }
}
