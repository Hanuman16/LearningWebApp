namespace ECommerce.Application.Commands.Auth;

using MediatR;

/// <summary>
/// Command for user registration.
/// WHY: CQRS pattern separates write operations from queries.
/// </summary>
public class RegisterCommand : IRequest<Guid>
{
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string? PhoneNumber { get; set; }
}

/// <summary>
/// Command for user login.
/// WHY: Returns JWT token pair.
/// </summary>
public class LoginCommand : IRequest<string>
{
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public bool RememberMe { get; set; }
}

/// <summary>
/// Command for refreshing JWT token.
/// WHY: Issues new access token using refresh token.
/// </summary>
public class RefreshTokenCommand : IRequest<string>
{
    public string RefreshToken { get; set; } = string.Empty;
    public string IpAddress { get; set; } = string.Empty;
    public string UserAgent { get; set; } = string.Empty;
}

/// <summary>
/// Command for requesting password reset.
/// WHY: Sends password reset email.
/// </summary>
public class ForgotPasswordCommand : IRequest<bool>
{
    public string Email { get; set; } = string.Empty;
}

/// <summary>
/// Command for resetting password with token.
/// WHY: Validates token and sets new password.
/// </summary>
public class ResetPasswordCommand : IRequest<bool>
{
    public string Email { get; set; } = string.Empty;
    public string ResetToken { get; set; } = string.Empty;
    public string NewPassword { get; set; } = string.Empty;
}

/// <summary>
/// Command for updating user profile.
/// WHY: Updates user profile information.
/// </summary>
public class UpdateProfileCommand : IRequest<bool>
{
    public Guid UserId { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? PhoneNumber { get; set; }
    public string? ProfileImageUri { get; set; }
}
