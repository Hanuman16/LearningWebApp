namespace ECommerce.Application.Commands.Coupons;

using Core.Entities;
using MediatR;

public class GetAllCouponsQuery : IRequest<IEnumerable<DTOs.CouponDto>>
{
}

public class GetCouponByIdQuery : IRequest<DTOs.CouponDto>
{
    public Guid Id { get; set; }
}

public class CreateCouponCommand : IRequest<DTOs.CouponDto>
{
    public string Code { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public CouponType Type { get; set; }
    public decimal Value { get; set; }
    public decimal? MinOrderAmount { get; set; }
    public decimal? MaxDiscountAmount { get; set; }
    public int? MaxUsageCount { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public bool IsActive { get; set; }
    public bool IsPublic { get; set; }
}

public class UpdateCouponCommand : IRequest<Unit>
{
    public Guid Id { get; set; }
    public string Description { get; set; } = string.Empty;
    public CouponType Type { get; set; }
    public decimal Value { get; set; }
    public decimal? MinOrderAmount { get; set; }
    public decimal? MaxDiscountAmount { get; set; }
    public int? MaxUsageCount { get; set; }
    public DateTime? EndDate { get; set; }
    public bool IsActive { get; set; }
    public bool IsPublic { get; set; }
}

public class DeleteCouponCommand : IRequest<Unit>
{
    public Guid Id { get; set; }
}

public class ValidateCouponQuery : IRequest<DTOs.CouponValidationDto>
{
    public string Code { get; set; } = string.Empty;
}
