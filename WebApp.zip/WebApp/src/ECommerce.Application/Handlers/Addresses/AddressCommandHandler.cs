namespace ECommerce.Application.Handlers.Addresses;

using AutoMapper;
using Core.Entities;
using Core.Exceptions;
using Core.Interfaces;
using DTOs;
using ECommerce.Application.Commands.Addresses;
using ECommerce.Infrastructure.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

public class GetAllAddressesHandler : IRequestHandler<GetAllAddressesQuery, IEnumerable<AddressDto>>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;

    public GetAllAddressesHandler(ECommerceDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<IEnumerable<AddressDto>> Handle(GetAllAddressesQuery request, CancellationToken cancellationToken)
    {
        var addresses = await _context.Addresses
            .Where(a => a.UserId == request.UserId)
            .OrderByDescending(a => a.IsDefault)
            .ToListAsync(cancellationToken);

        return _mapper.Map<IEnumerable<AddressDto>>(addresses);
    }
}

public class GetAddressByIdHandler : IRequestHandler<GetAddressByIdQuery, AddressDto>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;

    public GetAddressByIdHandler(ECommerceDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<AddressDto> Handle(GetAddressByIdQuery request, CancellationToken cancellationToken)
    {
        var address = await _context.Addresses
            .FirstOrDefaultAsync(a => a.Id == request.Id && a.UserId == request.UserId, cancellationToken);

        if (address == null)
            throw new Core.Exceptions.ValidationException("Address not found");

        return _mapper.Map<AddressDto>(address);
    }
}

public class CreateAddressHandler : IRequestHandler<CreateAddressCommand, AddressDto>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;
    private readonly ILogger<CreateAddressHandler> _logger;

    public CreateAddressHandler(ECommerceDbContext context, IMapper mapper, ILogger<CreateAddressHandler> logger)
    {
        _context = context;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<AddressDto> Handle(CreateAddressCommand request, CancellationToken cancellationToken)
    {
        if (request.IsDefault)
        {
            var existingDefault = await _context.Addresses
                .FirstOrDefaultAsync(a => a.UserId == request.UserId && a.IsDefault && a.Type == request.Type, cancellationToken);

            if (existingDefault != null)
                existingDefault.IsDefault = false;
        }

        var address = new Address
        {
            UserId = request.UserId,
            FirstName = request.FirstName,
            LastName = request.LastName,
            Line1 = request.Line1,
            Line2 = request.Line2,
            City = request.City,
            State = request.State,
            PostalCode = request.PostalCode,
            Country = request.Country,
            PhoneNumber = request.PhoneNumber,
            IsDefault = request.IsDefault,
            Type = request.Type
        };

        _context.Addresses.Add(address);
        await _context.SaveChangesAsync(cancellationToken);

        return _mapper.Map<AddressDto>(address);
    }
}

public class UpdateAddressHandler : IRequestHandler<UpdateAddressCommand, Unit>
{
    private readonly ECommerceDbContext _context;
    private readonly ILogger<UpdateAddressHandler> _logger;

    public UpdateAddressHandler(ECommerceDbContext context, ILogger<UpdateAddressHandler> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<Unit> Handle(UpdateAddressCommand request, CancellationToken cancellationToken)
    {
        var address = await _context.Addresses
            .FirstOrDefaultAsync(a => a.Id == request.Id && a.UserId == request.UserId, cancellationToken);

        if (address == null)
            throw new NotFoundException("Address", request.Id);

        if (request.IsDefault)
        {
            var existingDefault = await _context.Addresses
                .FirstOrDefaultAsync(a => a.UserId == request.UserId && a.IsDefault && a.Type == request.Type && a.Id != request.Id, cancellationToken);

            if (existingDefault != null)
                existingDefault.IsDefault = false;
        }

        address.FirstName = request.FirstName;
        address.LastName = request.LastName;
        address.Line1 = request.Line1;
        address.Line2 = request.Line2;
        address.City = request.City;
        address.State = request.State;
        address.PostalCode = request.PostalCode;
        address.Country = request.Country;
        address.PhoneNumber = request.PhoneNumber;
        address.IsDefault = request.IsDefault;
        address.Type = request.Type;

        await _context.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

public class DeleteAddressHandler : IRequestHandler<DeleteAddressCommand, Unit>
{
    private readonly ECommerceDbContext _context;

    public DeleteAddressHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<Unit> Handle(DeleteAddressCommand request, CancellationToken cancellationToken)
    {
        var address = await _context.Addresses
            .FirstOrDefaultAsync(a => a.Id == request.Id && a.UserId == request.UserId, cancellationToken);

        if (address == null)
            throw new NotFoundException("Address", request.Id);

        _context.Addresses.Remove(address);
        await _context.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}
