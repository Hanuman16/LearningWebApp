namespace ECommerce.Application.Handlers.Products;

using AutoMapper;
using ECommerce.Application.Commands.Products;
using Core.Entities;
using Core.Exceptions;
using Core.Interfaces;
using DTOs;
using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

/// <summary>
/// Handler for product commands and queries.
/// WHY: Centralizes product business logic in a single class.
/// PERFORMANCE: Uses AutoMapper for DTO mapping to reduce boilerplate.
/// DEBUG: Product operations are logged for auditing.
/// </summary>
public class ProductCommandHandler : IRequestHandler<CreateProductCommand, Guid>,
                                      IRequestHandler<UpdateProductCommand, bool>,
                                      IRequestHandler<DeleteProductCommand, bool>,
                                      IRequestHandler<SearchProductsQuery, IEnumerable<ProductDto>>,
                                      IRequestHandler<GetProductByIdQuery, ProductDto>,
                                      IRequestHandler<GetFeaturedProductsQuery, IEnumerable<ProductDto>>
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    private readonly IValidator<CreateProductRequest> _createValidator;
    private readonly IValidator<UpdateProductRequest> _updateValidator;

    public ProductCommandHandler(IUnitOfWork unitOfWork, IMapper mapper,
        IValidator<CreateProductRequest> createValidator, IValidator<UpdateProductRequest> updateValidator)
    {
        _unitOfWork = unitOfWork;
        _mapper = mapper;
        _createValidator = createValidator;
        _updateValidator = updateValidator;
    }

    /// <summary>
    /// Handles product creation.
    /// WHY: Creates a new product with validation.
    /// BUSINESS RULE: SKU must be unique.
    /// BUSINESS RULE: Price must be positive.
    /// </summary>
    public async Task<Guid> Handle(CreateProductCommand command, CancellationToken cancellationToken)
    {
        // Map command to request for validation
        var request = new CreateProductRequest
        {
            Name = command.Name,
            Description = command.Description,
            Price = command.Price,
            CompareAtPrice = command.CompareAtPrice,
            CategoryId = command.CategoryId,
            Sku = command.Sku,
            Weight = command.Weight,
            Dimensions = command.Dimensions,
            StockQuantity = command.StockQuantity,
            LowStockThreshold = command.LowStockThreshold
        };

        await _createValidator.ValidateAndThrowAsync(request, cancellationToken);

        // Check if SKU already exists
        var productRepository = _unitOfWork.Repository<Product>();
        var existingProducts = productRepository.Find(p => p.Sku == command.Sku);
        if (await existingProducts.AnyAsync(cancellationToken))
            throw new ConflictException($"Product with SKU '{command.Sku}' already exists.");

        // Check if category exists
        var categoryRepository = _unitOfWork.Repository<Category>();
        var category = await categoryRepository.GetByIdAsync(command.CategoryId, cancellationToken);
        if (category == null || !category.IsActive)
            throw new NotFoundException("Category", command.CategoryId);

        // Create product
        var product = new Product
        {
            Id = Guid.NewGuid(),
            Name = command.Name,
            Description = command.Description,
            Slug = GenerateSlug(command.Name),
            Price = command.Price,
            CompareAtPrice = command.CompareAtPrice ?? 0m,
            CategoryId = command.CategoryId,
            Sku = command.Sku,
            Weight = command.Weight?.ToString() ?? string.Empty,
            Dimensions = command.Dimensions,
            StockQuantity = command.StockQuantity,
            LowStockThreshold = command.LowStockThreshold,
            IsActive = true,
            IsFeatured = false,
            ViewCount = 0,
            SalesCount = 0,
            CreatedAt = DateTime.UtcNow
        };

        await productRepository.AddAsync(product, cancellationToken);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return product.Id;
    }

    /// <summary>
    /// Handles product update.
    /// WHY: Allows partial updates (only changed fields).
    /// BUSINESS RULE: Price must remain positive if updated.
    /// </summary>
    public async Task<bool> Handle(UpdateProductCommand command, CancellationToken cancellationToken)
    {
        var productRepository = _unitOfWork.Repository<Product>();
        var product = await productRepository.GetByIdAsync(command.Id, cancellationToken);
        if (product == null)
            throw new NotFoundException("Product", command.Id);

        // Map command to request for validation
        var request = new UpdateProductRequest
        {
            Name = command.Name,
            Description = command.Description,
            Price = command.Price,
            CompareAtPrice = command.CompareAtPrice,
            CategoryId = command.CategoryId,
            Sku = command.Sku,
            Weight = command.Weight,
            Dimensions = command.Dimensions,
            StockQuantity = command.StockQuantity,
            LowStockThreshold = command.LowStockThreshold,
            IsActive = command.IsActive,
            IsFeatured = command.IsFeatured
        };

        await _updateValidator.ValidateAndThrowAsync(request, cancellationToken);

        // Update product fields
        if (!string.IsNullOrEmpty(command.Name))
        {
            product.Name = command.Name;
            product.Slug = GenerateSlug(command.Name);
        }

        if (!string.IsNullOrEmpty(command.Description))
            product.Description = command.Description;

        if (command.Price.HasValue)
            product.Price = command.Price.Value;

        if (command.CompareAtPrice.HasValue)
            product.CompareAtPrice = command.CompareAtPrice.Value;

        if (command.CategoryId.HasValue)
            product.CategoryId = command.CategoryId.Value;

        if (!string.IsNullOrEmpty(command.Sku))
            product.Sku = command.Sku;

        if (command.Weight.HasValue)
            product.Weight = command.Weight.Value.ToString();

        if (!string.IsNullOrEmpty(command.Dimensions))
            product.Dimensions = command.Dimensions;

        if (command.StockQuantity.HasValue)
            product.StockQuantity = command.StockQuantity.Value;

        if (command.LowStockThreshold.HasValue)
            product.LowStockThreshold = command.LowStockThreshold.Value;

        if (command.IsActive.HasValue)
            product.IsActive = command.IsActive.Value;

        if (command.IsFeatured.HasValue)
            product.IsFeatured = command.IsFeatured.Value;

        productRepository.Update(product);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return true;
    }

    /// <summary>
    /// Handles product deletion.
    /// WHY: Soft delete by default, hard delete is irreversible.
    /// BUSINESS RULE: Products with active orders cannot be hard deleted.
    /// </summary>
    public async Task<bool> Handle(DeleteProductCommand command, CancellationToken cancellationToken)
    {
        var productRepository = _unitOfWork.Repository<Product>();
        var product = await productRepository.GetByIdAsync(command.Id, cancellationToken);
        if (product == null)
            throw new NotFoundException("Product", command.Id);

        if (command.HardDelete)
        {
            // TODO: Check if product has active orders
            productRepository.Delete(product);
        }
        else
        {
            productRepository.SoftDelete(product);
        }

        await _unitOfWork.SaveChangesAsync(cancellationToken);
        return true;
    }

    /// <summary>
    /// Handles product search query.
    /// WHY: Supports filtering, sorting, and pagination.
    /// PERFORMANCE: Uses IQueryable for server-side filtering.
    /// </summary>
    public async Task<IEnumerable<ProductDto>> Handle(SearchProductsQuery query, CancellationToken cancellationToken)
    {
        var productRepository = _unitOfWork.Repository<Product>();
        var products = productRepository.GetAll();

        // Apply filters
        if (!string.IsNullOrEmpty(query.Keyword))
        {
            products = products.Where(p => p.Name.Contains(query.Keyword) || p.Description.Contains(query.Keyword));
        }

        if (query.CategoryId.HasValue)
            products = products.Where(p => p.CategoryId == query.CategoryId.Value);

        if (query.MinPrice.HasValue)
            products = products.Where(p => p.Price >= query.MinPrice.Value);

        if (query.MaxPrice.HasValue)
            products = products.Where(p => p.Price <= query.MaxPrice.Value);

        if (query.IsActive.HasValue)
            products = products.Where(p => p.IsActive == query.IsActive.Value);

        if (query.IsFeatured.HasValue)
            products = products.Where(p => p.IsFeatured == query.IsFeatured.Value);

        // Apply sorting
        products = query.SortBy.ToLower() switch
        {
            "name" => query.SortOrder.ToLower() == "asc" ? products.OrderBy(p => p.Name) : products.OrderByDescending(p => p.Name),
            "price" => query.SortOrder.ToLower() == "asc" ? products.OrderBy(p => p.Price) : products.OrderByDescending(p => p.Price),
            "createdat" => query.SortOrder.ToLower() == "asc" ? products.OrderBy(p => p.CreatedAt) : products.OrderByDescending(p => p.CreatedAt),
            "views" => query.SortOrder.ToLower() == "asc" ? products.OrderBy(p => p.ViewCount) : products.OrderByDescending(p => p.ViewCount),
            "sales" => query.SortOrder.ToLower() == "asc" ? products.OrderBy(p => p.SalesCount) : products.OrderByDescending(p => p.SalesCount),
            _ => products.OrderByDescending(p => p.CreatedAt)
        };

        // Apply pagination
        var skip = (query.Page - 1) * query.PageSize;
        var paginatedProducts = await products.Skip(skip).Take(query.PageSize).ToListAsync(cancellationToken);

        // Map to DTOs
        return _mapper.Map<IEnumerable<ProductDto>>(paginatedProducts);
    }

    /// <summary>
    /// Handles product by ID query.
    /// WHY: Single product lookup with related data.
    /// PERFORMANCE: Includes category name and primary image URL.
    /// </summary>
    public async Task<ProductDto> Handle(GetProductByIdQuery query, CancellationToken cancellationToken)
    {
        var productRepository = _unitOfWork.Repository<Product>();
        var product = await productRepository.GetByIdAsync(query.Id, cancellationToken);
        if (product == null)
            throw new NotFoundException("Product", query.Id);

        return _mapper.Map<ProductDto>(product);
    }

    /// <summary>
    /// Handles featured products query.
    /// WHY: Featured products are displayed on homepage.
    /// PERFORMANCE: Limited count for performance.
    /// </summary>
    public async Task<IEnumerable<ProductDto>> Handle(GetFeaturedProductsQuery query, CancellationToken cancellationToken)
    {
        var productRepository = _unitOfWork.Repository<Product>();
        var products = await productRepository
            .Find(p => p.IsFeatured && p.IsActive)
            .OrderByDescending(p => p.CreatedAt)
            .Take(query.Count)
            .ToListAsync(cancellationToken);

        return _mapper.Map<IEnumerable<ProductDto>>(products);
    }

    /// <summary>
    /// Generates a URL-friendly slug from a product name.
    /// WHY: Slugs are used in SEO-friendly URLs.
    /// PERFORMANCE: Slug is generated once at creation, not on every request.
    /// </summary>
    private string GenerateSlug(string name)
    {
        var slug = name.ToLowerInvariant();
        slug = System.Text.RegularExpressions.Regex.Replace(slug, @"[^a-z0-9]", "-");
        slug = System.Text.RegularExpressions.Regex.Replace(slug, @"-+", "-").Trim('-');
        return slug;
    }
}
