namespace ECommerce.Application.Handlers.Inventory;

using AutoMapper;
using Core.Entities;
using Core.Exceptions;
using Core.Interfaces;
using DTOs;
using ECommerce.Application.Commands.Inventory;
using ECommerce.Infrastructure.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

public class GetProductInventoryHandler : IRequestHandler<GetProductInventoryQuery, IEnumerable<InventoryItemDto>>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;

    public GetProductInventoryHandler(ECommerceDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<IEnumerable<InventoryItemDto>> Handle(GetProductInventoryQuery request, CancellationToken cancellationToken)
    {
        var items = await _context.InventoryItems
            .Include(ii => ii.Product)
            .Where(ii => ii.ProductId == request.ProductId && ii.IsActive)
            .ToListAsync(cancellationToken);

        return items.Select(ii => new InventoryItemDto(
            ii.Id,
            ii.ProductId,
            ii.Product.Name,
            ii.WarehouseLocation,
            ii.Quantity,
            ii.ReservedQuantity,
            ii.Quantity - ii.ReservedQuantity,
            ii.ReorderLevel,
            ii.IsActive
        ));
    }
}

public class GetLowStockItemsHandler : IRequestHandler<GetLowStockItemsQuery, IEnumerable<InventoryItemDto>>
{
    private readonly ECommerceDbContext _context;

    public GetLowStockItemsHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<InventoryItemDto>> Handle(GetLowStockItemsQuery request, CancellationToken cancellationToken)
    {
        var items = await _context.InventoryItems
            .Include(ii => ii.Product)
            .Where(ii => ii.IsActive && (ii.Quantity - ii.ReservedQuantity) <= ii.ReorderLevel)
            .ToListAsync(cancellationToken);

        return items.Select(ii => new InventoryItemDto(
            ii.Id,
            ii.ProductId,
            ii.Product.Name,
            ii.WarehouseLocation,
            ii.Quantity,
            ii.ReservedQuantity,
            ii.Quantity - ii.ReservedQuantity,
            ii.ReorderLevel,
            ii.IsActive
        ));
    }
}

public class UpdateStockHandler : IRequestHandler<UpdateStockCommand, Unit>
{
    private readonly ECommerceDbContext _context;
    private readonly ILogger<UpdateStockHandler> _logger;

    public UpdateStockHandler(ECommerceDbContext context, ILogger<UpdateStockHandler> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<Unit> Handle(UpdateStockCommand request, CancellationToken cancellationToken)
    {
        var inventoryItem = await _context.InventoryItems
            .Include(ii => ii.Product)
            .FirstOrDefaultAsync(ii => ii.Id == request.InventoryItemId, cancellationToken);

        if (inventoryItem == null)
            throw new NotFoundException("Inventory item", request.InventoryItemId);

        var previousQuantity = inventoryItem.Quantity;
        var newQuantity = request.Quantity;

        if (newQuantity < 0)
            throw new ValidationException("Stock quantity cannot be negative.");

        var transaction = new InventoryTransaction
        {
            InventoryItemId = inventoryItem.Id,
            ProductId = inventoryItem.ProductId,
            Type = newQuantity > previousQuantity ? InventoryTransactionType.Purchase : InventoryTransactionType.Adjustment,
            Quantity = Math.Abs(newQuantity - previousQuantity),
            PreviousQuantity = previousQuantity,
            NewQuantity = newQuantity,
            ReferenceNumber = request.ReferenceNumber,
            Notes = request.Notes ?? string.Empty,
            CreatedByUserId = request.UserId ?? Guid.Empty
        };

        inventoryItem.Quantity = newQuantity;

        _context.InventoryTransactions.Add(transaction);
        await _context.SaveChangesAsync(cancellationToken);

        _logger.LogInformation("Stock updated for product {ProductId} from {PreviousQuantity} to {NewQuantity}", 
            inventoryItem.ProductId, previousQuantity, newQuantity);

        return Unit.Value;
    }
}

public class GetTransactionHistoryHandler : IRequestHandler<GetTransactionHistoryQuery, DTOs.PagedResponse<DTOs.InventoryTransactionDto>>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;

    public GetTransactionHistoryHandler(ECommerceDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<DTOs.PagedResponse<DTOs.InventoryTransactionDto>> Handle(GetTransactionHistoryQuery request, CancellationToken cancellationToken)
    {
        var query = _context.InventoryTransactions
            .Where(t => t.InventoryItemId == request.InventoryItemId)
            .OrderByDescending(t => t.CreatedAt);

        var totalCount = await query.CountAsync(cancellationToken);
        var transactions = await query
            .Skip((request.PageNumber - 1) * request.PageSize)
            .Take(request.PageSize)
            .ToListAsync(cancellationToken);

        var totalPages = (int)Math.Ceiling(totalCount / (double)request.PageSize);

        return new PagedResponse<InventoryTransactionDto>(
            _mapper.Map<IEnumerable<InventoryTransactionDto>>(transactions),
            totalCount,
            request.PageNumber,
            request.PageSize,
            totalPages);
    }
}

public class GetInventorySummaryHandler : IRequestHandler<GetInventorySummaryQuery, InventorySummaryDto>
{
    private readonly ECommerceDbContext _context;

    public GetInventorySummaryHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<InventorySummaryDto> Handle(GetInventorySummaryQuery request, CancellationToken cancellationToken)
    {
        var items = await _context.InventoryItems
            .Where(ii => ii.IsActive)
            .ToListAsync(cancellationToken);

        var totalProducts = items.Select(ii => ii.ProductId).Distinct().Count();
        var totalQuantity = items.Sum(ii => ii.Quantity);
        var totalReserved = items.Sum(ii => ii.ReservedQuantity);
        var totalAvailable = totalQuantity - totalReserved;
        var lowStockCount = items.Count(ii => (ii.Quantity - ii.ReservedQuantity) <= ii.ReorderLevel && (ii.Quantity - ii.ReservedQuantity) > 0);
        var outOfStockCount = items.Count(ii => (ii.Quantity - ii.ReservedQuantity) <= 0);

        return new InventorySummaryDto(
            totalProducts,
            totalQuantity,
            totalReserved,
            totalAvailable,
            lowStockCount,
            outOfStockCount);
    }
}
