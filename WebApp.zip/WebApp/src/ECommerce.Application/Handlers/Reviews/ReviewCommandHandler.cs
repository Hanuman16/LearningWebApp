namespace ECommerce.Application.Handlers.Reviews;

using AutoMapper;
using Core.Entities;
using Core.Exceptions;
using Core.Interfaces;
using DTOs;
using ECommerce.Application.Commands.Reviews;
using ECommerce.Infrastructure.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

public class GetProductReviewsHandler : IRequestHandler<GetProductReviewsQuery, IEnumerable<ReviewDto>>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;

    public GetProductReviewsHandler(ECommerceDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<IEnumerable<ReviewDto>> Handle(GetProductReviewsQuery request, CancellationToken cancellationToken)
    {
        var reviews = await _context.Reviews
            .Where(r => r.ProductId == request.ProductId && r.IsApproved)
            .OrderByDescending(r => r.CreatedAt)
            .ToListAsync(cancellationToken);

        return _mapper.Map<IEnumerable<ReviewDto>>(reviews);
    }
}

public class CreateReviewHandler : IRequestHandler<CreateReviewCommand, ReviewDto>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;
    private readonly ILogger<CreateReviewHandler> _logger;

    public CreateReviewHandler(ECommerceDbContext context, IMapper mapper, ILogger<CreateReviewHandler> logger)
    {
        _context = context;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ReviewDto> Handle(CreateReviewCommand request, CancellationToken cancellationToken)
    {
        if (request.Rating < 1 || request.Rating > 5)
            throw new ValidationException("Rating must be between 1 and 5.");

        var existingReview = await _context.Reviews
            .FirstOrDefaultAsync(r => r.ProductId == request.ProductId && r.UserId == request.UserId, cancellationToken);

        if (existingReview != null)
            throw new ConflictException("You have already reviewed this product.");

        var product = await _context.Products.FirstOrDefaultAsync(p => p.Id == request.ProductId, cancellationToken);

        if (product == null)
            throw new NotFoundException("Product", request.ProductId);

        var review = new Review
        {
            ProductId = request.ProductId,
            UserId = request.UserId,
            Rating = request.Rating,
            Title = request.Title,
            Comment = request.Comment,
            IsApproved = true
        };

        _context.Reviews.Add(review);
        await _context.SaveChangesAsync(cancellationToken);

        return _mapper.Map<ReviewDto>(review);
    }
}

public class GetUserReviewHandler : IRequestHandler<GetUserReviewQuery, ReviewDto>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;

    public GetUserReviewHandler(ECommerceDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<ReviewDto> Handle(GetUserReviewQuery request, CancellationToken cancellationToken)
    {
        var review = await _context.Reviews
            .FirstOrDefaultAsync(r => r.ProductId == request.ProductId && r.UserId == request.UserId, cancellationToken);

        if (review == null)
            throw new NotFoundException("Review", "Review not found");

        return _mapper.Map<ReviewDto>(review);
    }
}

public class UpdateReviewHandler : IRequestHandler<UpdateReviewCommand, Unit>
{
    private readonly ECommerceDbContext _context;
    private readonly ILogger<UpdateReviewHandler> _logger;

    public UpdateReviewHandler(ECommerceDbContext context, ILogger<UpdateReviewHandler> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<Unit> Handle(UpdateReviewCommand request, CancellationToken cancellationToken)
    {
        if (request.Rating < 1 || request.Rating > 5)
            throw new ValidationException("Rating must be between 1 and 5.");

        var review = await _context.Reviews
            .FirstOrDefaultAsync(r => r.Id == request.ReviewId && r.UserId == request.UserId, cancellationToken);

        if (review == null)
            throw new NotFoundException("Review", request.ReviewId.ToString());

        review.Rating = request.Rating;
        review.Title = request.Title;
        review.Comment = request.Comment;

        await _context.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

public class DeleteReviewHandler : IRequestHandler<DeleteReviewCommand, Unit>
{
    private readonly ECommerceDbContext _context;

    public DeleteReviewHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<Unit> Handle(DeleteReviewCommand request, CancellationToken cancellationToken)
    {
        var review = await _context.Reviews
            .FirstOrDefaultAsync(r => r.Id == request.ReviewId && r.UserId == request.UserId, cancellationToken);

        if (review == null)
            throw new NotFoundException("Review", "Review not found");

        _context.Reviews.Remove(review);
        await _context.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

public class MarkHelpfulHandler : IRequestHandler<MarkHelpfulCommand, Unit>
{
    private readonly ECommerceDbContext _context;

    public MarkHelpfulHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<Unit> Handle(MarkHelpfulCommand request, CancellationToken cancellationToken)
    {
        var review = await _context.Reviews.FirstOrDefaultAsync(r => r.Id == request.ReviewId, cancellationToken);

        if (review == null)
            throw new NotFoundException("Review", "Review not found");

        review.HelpfulCount++;
        await _context.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}
