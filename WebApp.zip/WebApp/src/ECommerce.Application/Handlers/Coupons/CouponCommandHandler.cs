namespace ECommerce.Application.Handlers.Coupons;

using AutoMapper;
using Core.Entities;
using Core.Exceptions;
using Core.Interfaces;
using DTOs;
using ECommerce.Application.Commands.Coupons;
using ECommerce.Infrastructure.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

public class GetAllCouponsHandler : IRequestHandler<GetAllCouponsQuery, IEnumerable<CouponDto>>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;

    public GetAllCouponsHandler(ECommerceDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<IEnumerable<CouponDto>> Handle(GetAllCouponsQuery request, CancellationToken cancellationToken)
    {
        var coupons = await _context.Coupons.OrderBy(c => c.Code).ToListAsync(cancellationToken);
        return _mapper.Map<IEnumerable<CouponDto>>(coupons);
    }
}

public class GetCouponByIdHandler : IRequestHandler<GetCouponByIdQuery, CouponDto>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;

    public GetCouponByIdHandler(ECommerceDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<CouponDto> Handle(GetCouponByIdQuery request, CancellationToken cancellationToken)
    {
        var coupon = await _context.Coupons.FindAsync(new object[] { request.Id }, cancellationToken);

        if (coupon == null)
            throw new NotFoundException("Coupon", request.Id);

        return _mapper.Map<CouponDto>(coupon);
    }
}

public class CreateCouponHandler : IRequestHandler<CreateCouponCommand, CouponDto>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;
    private readonly ILogger<CreateCouponHandler> _logger;

    public CreateCouponHandler(ECommerceDbContext context, IMapper mapper, ILogger<CreateCouponHandler> logger)
    {
        _context = context;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<CouponDto> Handle(CreateCouponCommand request, CancellationToken cancellationToken)
    {
        var existingCoupon = await _context.Coupons.FirstOrDefaultAsync(c => c.Code == request.Code, cancellationToken);

        if (existingCoupon != null)
            throw new ConflictException("Coupon code already exists.");

        if (request.EndDate.HasValue && request.EndDate < request.StartDate)
            throw new ValidationException("End date must be after start date.");

        var coupon = new Coupon
        {
            Code = request.Code,
            Description = request.Description,
            Type = request.Type,
            Value = request.Value,
            MinOrderAmount = request.MinOrderAmount,
            MaxDiscountAmount = request.MaxDiscountAmount,
            MaxUsageCount = request.MaxUsageCount,
            StartDate = request.StartDate,
            EndDate = request.EndDate,
            IsActive = request.IsActive,
            IsPublic = request.IsPublic
        };

        _context.Coupons.Add(coupon);
        await _context.SaveChangesAsync(cancellationToken);

        return _mapper.Map<CouponDto>(coupon);
    }
}

public class UpdateCouponHandler : IRequestHandler<UpdateCouponCommand, Unit>
{
    private readonly ECommerceDbContext _context;
    private readonly ILogger<UpdateCouponHandler> _logger;

    public UpdateCouponHandler(ECommerceDbContext context, ILogger<UpdateCouponHandler> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<Unit> Handle(UpdateCouponCommand request, CancellationToken cancellationToken)
    {
        var coupon = await _context.Coupons.FindAsync(new object[] { request.Id }, cancellationToken);

        if (coupon == null)
            throw new NotFoundException("Coupon", request.Id);

        coupon.Description = request.Description;
        coupon.Type = request.Type;
        coupon.Value = request.Value;
        coupon.MinOrderAmount = request.MinOrderAmount;
        coupon.MaxDiscountAmount = request.MaxDiscountAmount;
        coupon.MaxUsageCount = request.MaxUsageCount;
        coupon.EndDate = request.EndDate;
        coupon.IsActive = request.IsActive;
        coupon.IsPublic = request.IsPublic;

        await _context.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

public class DeleteCouponHandler : IRequestHandler<DeleteCouponCommand, Unit>
{
    private readonly ECommerceDbContext _context;

    public DeleteCouponHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<Unit> Handle(DeleteCouponCommand request, CancellationToken cancellationToken)
    {
        var coupon = await _context.Coupons.FindAsync(new object[] { request.Id }, cancellationToken);

        if (coupon == null)
            throw new NotFoundException("Coupon", request.Id);

        _context.Coupons.Remove(coupon);
        await _context.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

public class ValidateCouponHandler : IRequestHandler<ValidateCouponQuery, CouponValidationDto>
{
    private readonly ECommerceDbContext _context;

    public ValidateCouponHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<CouponValidationDto> Handle(ValidateCouponQuery request, CancellationToken cancellationToken)
    {
        var coupon = await _context.Coupons
            .FirstOrDefaultAsync(c => c.Code == request.Code && c.IsActive, cancellationToken);

        if (coupon == null)
            return new CouponValidationDto(false, "Coupon not found.", null, null);

        if (coupon.EndDate.HasValue && coupon.EndDate.Value < DateTime.UtcNow)
            return new CouponValidationDto(false, "Coupon has expired.", null, null);

        if (coupon.StartDate > DateTime.UtcNow)
            return new CouponValidationDto(false, "Coupon is not yet active.", null, null);

        if (coupon.MaxUsageCount.HasValue && coupon.UsedCount >= coupon.MaxUsageCount)
            return new CouponValidationDto(false, "Coupon has reached its usage limit.", null, null);

        return new CouponValidationDto(true, null, coupon.Value, coupon.Type == CouponType.Percentage ? coupon.Value : null);
    }
}
