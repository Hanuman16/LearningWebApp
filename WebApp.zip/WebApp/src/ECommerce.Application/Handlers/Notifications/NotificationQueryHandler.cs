namespace ECommerce.Application.Handlers.Notifications;

using AutoMapper;
using Core.Entities;
using Core.Exceptions;
using Core.Interfaces;
using DTOs;
using ECommerce.Application.Commands.Notifications;
using ECommerce.Infrastructure.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

public class GetAllNotificationsHandler : IRequestHandler<GetAllNotificationsQuery, DTOs.PagedResponse<DTOs.NotificationDto>>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;

    public GetAllNotificationsHandler(ECommerceDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<DTOs.PagedResponse<DTOs.NotificationDto>> Handle(GetAllNotificationsQuery request, CancellationToken cancellationToken)
    {
        var query = _context.Notifications
            .Where(n => n.UserId == request.UserId);

        if (request.IsRead.HasValue)
            query = query.Where(n => n.IsRead == request.IsRead.Value);

        query = query.OrderByDescending(n => n.CreatedAt);

        var totalCount = await query.CountAsync(cancellationToken);
        var notifications = await query
            .Skip((request.PageNumber - 1) * request.PageSize)
            .Take(request.PageSize)
            .ToListAsync(cancellationToken);

        var totalPages = (int)Math.Ceiling(totalCount / (double)request.PageSize);

        return new PagedResponse<NotificationDto>(
            _mapper.Map<IEnumerable<NotificationDto>>(notifications),
            totalCount,
            request.PageNumber,
            request.PageSize,
            totalPages);
    }
}

public class GetNotificationByIdHandler : IRequestHandler<GetNotificationByIdQuery, NotificationDto>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;

    public GetNotificationByIdHandler(ECommerceDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<NotificationDto> Handle(GetNotificationByIdQuery request, CancellationToken cancellationToken)
    {
        var notification = await _context.Notifications
            .FirstOrDefaultAsync(n => n.Id == request.Id && n.UserId == request.UserId, cancellationToken);

        if (notification == null)
            throw new NotFoundException("Notification", request.Id);

        return _mapper.Map<NotificationDto>(notification);
    }
}

public class MarkAsReadHandler : IRequestHandler<MarkAsReadCommand, Unit>
{
    private readonly ECommerceDbContext _context;

    public MarkAsReadHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<Unit> Handle(MarkAsReadCommand request, CancellationToken cancellationToken)
    {
        var notification = await _context.Notifications
            .FirstOrDefaultAsync(n => n.Id == request.Id && n.UserId == request.UserId, cancellationToken);

        if (notification == null)
            throw new NotFoundException("Notification", request.Id);

        notification.IsRead = true;
        notification.ReadAt = DateTime.UtcNow;

        await _context.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

public class MarkAllAsReadHandler : IRequestHandler<MarkAllAsReadCommand, Unit>
{
    private readonly ECommerceDbContext _context;

    public MarkAllAsReadHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<Unit> Handle(MarkAllAsReadCommand request, CancellationToken cancellationToken)
    {
        var notifications = await _context.Notifications
            .Where(n => n.UserId == request.UserId && !n.IsRead)
            .ToListAsync(cancellationToken);

        foreach (var notification in notifications)
        {
            notification.IsRead = true;
            notification.ReadAt = DateTime.UtcNow;
        }

        await _context.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

public class DeleteNotificationHandler : IRequestHandler<DeleteNotificationCommand, Unit>
{
    private readonly ECommerceDbContext _context;

    public DeleteNotificationHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<Unit> Handle(DeleteNotificationCommand request, CancellationToken cancellationToken)
    {
        var notification = await _context.Notifications
            .FirstOrDefaultAsync(n => n.Id == request.Id && n.UserId == request.UserId, cancellationToken);

        if (notification == null)
            throw new NotFoundException("Notification", request.Id);

        _context.Notifications.Remove(notification);
        await _context.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

public class GetUnreadCountHandler : IRequestHandler<GetUnreadCountQuery, int>
{
    private readonly ECommerceDbContext _context;

    public GetUnreadCountHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<int> Handle(GetUnreadCountQuery request, CancellationToken cancellationToken)
    {
        return await _context.Notifications
            .CountAsync(n => n.UserId == request.UserId && !n.IsRead, cancellationToken);
    }
}
