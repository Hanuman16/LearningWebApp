namespace ECommerce.Application.Handlers.Wishlist;

using AutoMapper;
using Core.Entities;
using Core.Exceptions;
using Core.Interfaces;
using DTOs;
using ECommerce.Application.Commands.Wishlist;
using ECommerce.Infrastructure.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

public class GetWishlistItemsHandler : IRequestHandler<GetWishlistItemsQuery, IEnumerable<Guid>>
{
    private readonly ECommerceDbContext _context;

    public GetWishlistItemsHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Guid>> Handle(GetWishlistItemsQuery request, CancellationToken cancellationToken)
    {
        var wishlist = await _context.Wishlists
            .Include(w => w.Items)
            .FirstOrDefaultAsync(w => w.UserId == request.UserId, cancellationToken);

        if (wishlist == null)
            return Enumerable.Empty<Guid>();

        return wishlist.Items.Select(i => i.ProductId);
    }
}

public class AddToWishlistHandler : IRequestHandler<AddToWishlistCommand, Unit>
{
    private readonly ECommerceDbContext _context;
    private readonly ILogger<AddToWishlistHandler> _logger;

    public AddToWishlistHandler(ECommerceDbContext context, ILogger<AddToWishlistHandler> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<Unit> Handle(AddToWishlistCommand request, CancellationToken cancellationToken)
    {
        var wishlist = await _context.Wishlists
            .Include(w => w.Items)
            .FirstOrDefaultAsync(w => w.UserId == request.UserId, cancellationToken);

        if (wishlist == null)
        {
            wishlist = new Wishlist
            {
                UserId = request.UserId,
                Name = "My Wishlist",
                IsShared = false
            };
            _context.Wishlists.Add(wishlist);
        }

        var existingItem = wishlist.Items.Any(i => i.ProductId == request.ProductId);

        if (existingItem)
            throw new ConflictException("Product is already in your wishlist.");

        var product = await _context.Products.FirstOrDefaultAsync(p => p.Id == request.ProductId, cancellationToken);

        if (product == null || !product.IsActive)
            throw new NotFoundException("Product", request.ProductId);

        wishlist.Items.Add(new WishlistItem { ProductId = request.ProductId });

        await _context.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

public class RemoveFromWishlistHandler : IRequestHandler<RemoveFromWishlistCommand, Unit>
{
    private readonly ECommerceDbContext _context;

    public RemoveFromWishlistHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<Unit> Handle(RemoveFromWishlistCommand request, CancellationToken cancellationToken)
    {
        var wishlist = await _context.Wishlists
            .Include(w => w.Items)
            .FirstOrDefaultAsync(w => w.UserId == request.UserId, cancellationToken);

        if (wishlist == null)
            throw new NotFoundException("Wishlist", "Wishlist not found");

        var wishlistItem = wishlist.Items.FirstOrDefault(i => i.ProductId == request.ProductId);

        if (wishlistItem == null)
            throw new NotFoundException("Wishlist item", "Product not in wishlist");

        wishlist.Items.Remove(wishlistItem);

        await _context.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}
