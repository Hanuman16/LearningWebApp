namespace ECommerce.Application.Handlers.Dashboard;

using Core.Entities;
using DTOs;
using ECommerce.Application.Commands.Dashboard;
using ECommerce.Infrastructure.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

public class GetDashboardOverviewHandler : IRequestHandler<GetDashboardOverviewQuery, DashboardOverviewDto>
{
    private readonly ECommerceDbContext _context;

    public GetDashboardOverviewHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<DashboardOverviewDto> Handle(GetDashboardOverviewQuery request, CancellationToken cancellationToken)
    {
        var totalRevenue = await _context.Orders
            .Where(o => o.PaymentStatus == PaymentStatus.Completed)
            .SumAsync(o => o.TotalAmount, cancellationToken);

        var totalOrders = await _context.Orders.CountAsync(cancellationToken);
        var totalProducts = await _context.Products.CountAsync(p => p.IsActive, cancellationToken);
        var totalCustomers = await _context.Users.CountAsync(u => u.IsActive, cancellationToken);

        var lastMonthRevenue = await _context.Orders
            .Where(o => o.PaymentStatus == PaymentStatus.Completed && o.CreatedAt >= DateTime.UtcNow.AddMonths(-1))
            .SumAsync(o => o.TotalAmount, cancellationToken);

        var lastMonthOrders = await _context.Orders
            .CountAsync(o => o.CreatedAt >= DateTime.UtcNow.AddMonths(-1), cancellationToken);

        var revenueChange = lastMonthRevenue > 0 ? ((totalRevenue - lastMonthRevenue) / lastMonthRevenue) * 100 : 0;
        var ordersChange = lastMonthOrders > 0 ? ((totalOrders - lastMonthOrders) / (double)lastMonthOrders) * 100 : 0;

        return new DashboardOverviewDto(
            totalRevenue,
            totalOrders,
            totalProducts,
            totalCustomers,
            (decimal)revenueChange,
            (int)ordersChange);
    }
}

public class GetSalesReportHandler : IRequestHandler<GetSalesReportQuery, SalesReportDto>
{
    private readonly ECommerceDbContext _context;

    public GetSalesReportHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<SalesReportDto> Handle(GetSalesReportQuery request, CancellationToken cancellationToken)
    {
        var orders = await _context.Orders
            .Where(o => o.PaymentStatus == PaymentStatus.Completed && o.CreatedAt >= request.StartDate && o.CreatedAt <= request.EndDate)
            .ToListAsync(cancellationToken);

        var totalSales = orders.Sum(o => o.TotalAmount);
        var totalOrders = orders.Count;
        var averageOrderValue = totalOrders > 0 ? totalSales / totalOrders : 0;

        var dailySales = orders
            .GroupBy(o => o.CreatedAt.Date)
            .Select(g => new SalesByDayDto(
                g.Key,
                g.Sum(o => o.TotalAmount),
                g.Count()))
            .OrderBy(d => d.Date)
            .ToList();

        return new SalesReportDto(totalSales, totalOrders, averageOrderValue, dailySales);
    }
}

public class GetInventoryReportHandler : IRequestHandler<GetInventoryReportQuery, InventoryReportDto>
{
    private readonly ECommerceDbContext _context;

    public GetInventoryReportHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<InventoryReportDto> Handle(GetInventoryReportQuery request, CancellationToken cancellationToken)
    {
        var items = await _context.InventoryItems
            .Include(ii => ii.Product)
            .Where(ii => ii.IsActive)
            .ToListAsync(cancellationToken);

        var totalProducts = items.Select(ii => ii.ProductId).Distinct().Count();
        var inStock = items.Count(ii => (ii.Quantity - ii.ReservedQuantity) > ii.ReorderLevel);
        var lowStock = items.Count(ii => (ii.Quantity - ii.ReservedQuantity) <= ii.ReorderLevel && (ii.Quantity - ii.ReservedQuantity) > 0);
        var outOfStock = items.Count(ii => (ii.Quantity - ii.ReservedQuantity) <= 0);

        var totalInventoryValue = items.Sum(ii => ii.Quantity * ii.Product.Price);

        return new InventoryReportDto(totalProducts, inStock, lowStock, outOfStock, totalInventoryValue);
    }
}

public class GetTopSellingProductsHandler : IRequestHandler<GetTopSellingProductsQuery, IEnumerable<TopSellingProductDto>>
{
    private readonly ECommerceDbContext _context;

    public GetTopSellingProductsHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<TopSellingProductDto>> Handle(GetTopSellingProductsQuery request, CancellationToken cancellationToken)
    {
        var products = await _context.OrderItems
            .Include(oi => oi.Product)
            .GroupBy(oi => oi.ProductId)
            .Select(g => new
            {
                ProductId = g.Key,
                ProductName = g.First().Product.Name,
                QuantitySold = g.Sum(oi => oi.Quantity),
                Revenue = g.Sum(oi => oi.Quantity * oi.UnitPrice - oi.DiscountAmount)
            })
            .OrderByDescending(p => p.QuantitySold)
            .Take(request.Limit)
            .ToListAsync(cancellationToken);

        return products.Select(p => new TopSellingProductDto(
            p.ProductId,
            p.ProductName,
            p.QuantitySold,
            p.Revenue));
    }
}

public class GetRecentOrdersHandler : IRequestHandler<GetRecentOrdersQuery, IEnumerable<RecentOrderDto>>
{
    private readonly ECommerceDbContext _context;

    public GetRecentOrdersHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<RecentOrderDto>> Handle(GetRecentOrdersQuery request, CancellationToken cancellationToken)
    {
        var orders = await _context.Orders
            .OrderByDescending(o => o.CreatedAt)
            .Take(request.Limit)
            .ToListAsync(cancellationToken);

        return orders.Select(o => new RecentOrderDto(
            o.Id,
            o.OrderNumber,
            o.Status.ToString(),
            o.TotalAmount,
            o.CreatedAt,
            o.User.FirstName + " " + o.User.LastName));
    }
}
