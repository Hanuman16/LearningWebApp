namespace ECommerce.Application.Handlers.Cart;

using AutoMapper;
using Core.Entities;
using Core.Exceptions;
using Core.Interfaces;
using DTOs;
using ECommerce.Application.Commands.Cart;
using ECommerce.Infrastructure.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

public class GetCartHandler : IRequestHandler<GetCartQuery, CartDto>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;

    public GetCartHandler(ECommerceDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<CartDto> Handle(GetCartQuery request, CancellationToken cancellationToken)
    {
        var cart = await _context.Carts
            .Include(c => c.Items)
                .ThenInclude(ci => ci.Product)
            .FirstOrDefaultAsync(c => c.UserId == request.UserId && c.Status == CartStatus.Active, cancellationToken);

        if (cart == null)
        {
            cart = new Cart { UserId = request.UserId, Status = CartStatus.Active };
            _context.Carts.Add(cart);
            await _context.SaveChangesAsync(cancellationToken);
        }

        return _mapper.Map<CartDto>(cart);
    }
}

public class AddCartItemHandler : IRequestHandler<AddCartItemCommand, CartItemDto>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;
    private readonly ILogger<AddCartItemHandler> _logger;

    public AddCartItemHandler(ECommerceDbContext context, IMapper mapper, ILogger<AddCartItemHandler> logger)
    {
        _context = context;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<CartItemDto> Handle(AddCartItemCommand request, CancellationToken cancellationToken)
    {
        var cart = await _context.Carts
            .Include(c => c.Items)
            .FirstOrDefaultAsync(c => c.UserId == request.UserId && c.Status == CartStatus.Active, cancellationToken);

        if (cart == null)
        {
            cart = new Cart { UserId = request.UserId, Status = CartStatus.Active };
            _context.Carts.Add(cart);
        }

        var product = await _context.Products
            .FirstOrDefaultAsync(p => p.Id == request.ProductId && p.IsActive, cancellationToken);

        if (product == null)
            throw new NotFoundException("Product", request.ProductId);

        if (product.StockQuantity < request.Quantity)
            throw new ValidationException("Insufficient stock available.");

        var existingItem = cart.Items.FirstOrDefault(i => i.ProductId == request.ProductId);

        if (existingItem != null)
        {
            existingItem.Quantity += request.Quantity;
        }
        else
        {
            var cartItem = new CartItem
            {
                CartId = cart.Id,
                ProductId = request.ProductId,
                Quantity = request.Quantity,
                UnitPrice = product.Price
            };
            cart.Items.Add(cartItem);
        }

        await _context.SaveChangesAsync(cancellationToken);

        var newItem = cart.Items.FirstOrDefault(i => i.ProductId == request.ProductId)
            ?? throw new NotFoundException("Cart item", request.ProductId);

        return _mapper.Map<CartItemDto>(newItem);
    }
}

public class UpdateCartItemHandler : IRequestHandler<UpdateCartItemCommand, Unit>
{
    private readonly ECommerceDbContext _context;
    private readonly ILogger<UpdateCartItemHandler> _logger;

    public UpdateCartItemHandler(ECommerceDbContext context, ILogger<UpdateCartItemHandler> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<Unit> Handle(UpdateCartItemCommand request, CancellationToken cancellationToken)
    {
        var cartItem = await _context.CartItems
            .Include(ci => ci.Cart)
            .FirstOrDefaultAsync(ci => ci.Id == request.CartItemId, cancellationToken);

        if (cartItem == null)
            throw new NotFoundException("Cart item", request.CartItemId);

        var product = await _context.Products.FirstOrDefaultAsync(p => p.Id == cartItem.ProductId, cancellationToken);

        if (product == null)
            throw new NotFoundException("Product", cartItem.ProductId);

        if (product.StockQuantity < request.Quantity)
            throw new ValidationException("Insufficient stock available.");

        cartItem.Quantity = request.Quantity;
        await _context.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

public class RemoveCartItemHandler : IRequestHandler<RemoveCartItemCommand, Unit>
{
    private readonly ECommerceDbContext _context;

    public RemoveCartItemHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<Unit> Handle(RemoveCartItemCommand request, CancellationToken cancellationToken)
    {
        var cartItem = await _context.CartItems.FirstOrDefaultAsync(ci => ci.Id == request.CartItemId, cancellationToken);

        if (cartItem == null)
            throw new NotFoundException("Cart item", request.CartItemId);

        _context.CartItems.Remove(cartItem);
        await _context.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

public class ApplyCouponHandler : IRequestHandler<ApplyCouponCommand, CartDto>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;

    public ApplyCouponHandler(ECommerceDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<CartDto> Handle(ApplyCouponCommand request, CancellationToken cancellationToken)
    {
        var cart = await _context.Carts
            .Include(c => c.Items)
            .FirstOrDefaultAsync(c => c.UserId == request.UserId && c.Status == CartStatus.Active, cancellationToken);

        if (cart == null)
            throw new NotFoundException("Cart", "Active cart not found");

        var coupon = await _context.Coupons
            .FirstOrDefaultAsync(c => c.Code == request.CouponCode && c.IsActive, cancellationToken);

        if (coupon == null)
            throw new NotFoundException("Coupon", request.CouponCode);

        if (coupon.EndDate.HasValue && coupon.EndDate.Value < DateTime.UtcNow)
            throw new ValidationException("This coupon has expired.");

        if (coupon.MaxUsageCount.HasValue && coupon.UsedCount >= coupon.MaxUsageCount)
            throw new ValidationException("This coupon has reached its usage limit.");

        var cartTotal = cart.Items.Sum(i => i.UnitPrice * i.Quantity);

        if (coupon.MinOrderAmount.HasValue && cartTotal < coupon.MinOrderAmount.Value)
            throw new ValidationException($"Minimum order amount of ${coupon.MinOrderAmount.Value} required for this coupon.");

        decimal discountAmount = 0;

        if (coupon.Type == CouponType.Percentage)
        {
            discountAmount = cartTotal * (coupon.Value / 100);
            if (coupon.MaxDiscountAmount.HasValue)
                discountAmount = Math.Min(discountAmount, coupon.MaxDiscountAmount.Value);
        }
        else if (coupon.Type == CouponType.FixedAmount)
        {
            discountAmount = Math.Min(coupon.Value, cartTotal);
        }

        cart.CouponCode = request.CouponCode;
        cart.DiscountAmount = discountAmount;

        await _context.SaveChangesAsync(cancellationToken);

        return _mapper.Map<CartDto>(cart);
    }
}

public class RemoveCouponHandler : IRequestHandler<RemoveCouponCommand, CartDto>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;

    public RemoveCouponHandler(ECommerceDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<CartDto> Handle(RemoveCouponCommand request, CancellationToken cancellationToken)
    {
        var cart = await _context.Carts
            .Include(c => c.Items)
            .FirstOrDefaultAsync(c => c.UserId == request.UserId && c.Status == CartStatus.Active, cancellationToken);

        if (cart == null)
            throw new NotFoundException("Cart", "Active cart not found");

        cart.CouponCode = null;
        cart.DiscountAmount = 0;

        await _context.SaveChangesAsync(cancellationToken);

        return _mapper.Map<CartDto>(cart);
    }
}

public class ClearCartHandler : IRequestHandler<ClearCartCommand, Unit>
{
    private readonly ECommerceDbContext _context;

    public ClearCartHandler(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<Unit> Handle(ClearCartCommand request, CancellationToken cancellationToken)
    {
        var cart = await _context.Carts
            .Include(c => c.Items)
            .FirstOrDefaultAsync(c => c.UserId == request.UserId && c.Status == CartStatus.Active, cancellationToken);

        if (cart == null)
            throw new NotFoundException("Cart", "Active cart not found");

        _context.CartItems.RemoveRange(cart.Items);
        cart.CouponCode = null;
        cart.DiscountAmount = 0;

        await _context.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

public class GetGuestCartHandler : IRequestHandler<GetGuestCartQuery, CartDto>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;

    public GetGuestCartHandler(ECommerceDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<CartDto> Handle(GetGuestCartQuery request, CancellationToken cancellationToken)
    {
        var cart = await _context.Carts
            .Include(c => c.Items)
                .ThenInclude(ci => ci.Product)
            .FirstOrDefaultAsync(c => c.Id == request.CartId && c.UserId == null && c.Status == CartStatus.Active, cancellationToken);

        if (cart == null)
        {
            return new CartDto
            {
                Id = request.CartId,
                UserId = Guid.Empty,
                Status = CartStatus.Active.ToString(),
                Items = new List<CartItemDto>(),
                ItemCount = 0,
                Subtotal = 0m,
                TaxAmount = 0m,
                ShippingAmount = 0m,
                DiscountAmount = 0m,
                TotalAmount = 0m
            };
        }

        return _mapper.Map<CartDto>(cart);
    }
}

public class AddGuestCartItemHandler : IRequestHandler<AddGuestCartItemCommand, CartDto>
{
    private readonly ECommerceDbContext _context;
    private readonly IMapper _mapper;
    private readonly ILogger<AddGuestCartItemHandler> _logger;

    public AddGuestCartItemHandler(ECommerceDbContext context, IMapper mapper, ILogger<AddGuestCartItemHandler> logger)
    {
        _context = context;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<CartDto> Handle(AddGuestCartItemCommand request, CancellationToken cancellationToken)
    {
        // First, verify the product exists
        var product = await _context.Products
            .IgnoreQueryFilters()
            .AsNoTracking()
            .FirstOrDefaultAsync(p => p.Id.ToString() == request.ProductId.ToString(), cancellationToken);

        if (product == null)
            throw new NotFoundException("Product", request.ProductId);

        if (product.StockQuantity < request.Quantity)
            throw new ValidationException("Insufficient stock available.");

        // Check if cart exists (without including items to avoid tracking issues)
        var cart = await _context.Carts
            .IgnoreQueryFilters()
            .AsNoTracking()
            .FirstOrDefaultAsync(c => c.Id == request.CartId && c.UserId == null && c.Status == CartStatus.Active, cancellationToken);

        if (cart == null)
        {
            // Create new cart first
            var newCart = new Cart { Id = request.CartId, UserId = null, Status = CartStatus.Active };
            _context.Carts.Add(newCart);
            await _context.SaveChangesAsync(cancellationToken);
            
            // Now add the cart item
            var cartItem = new CartItem
            {
                CartId = newCart.Id,
                ProductId = request.ProductId,
                Quantity = request.Quantity,
                UnitPrice = product.Price
            };
            _context.CartItems.Add(cartItem);
            await _context.SaveChangesAsync(cancellationToken);
        }
        else
        {
            // Cart exists, add cart item
            var cartItem = new CartItem
            {
                CartId = request.CartId,
                ProductId = request.ProductId,
                Quantity = request.Quantity,
                UnitPrice = product.Price
            };
            _context.CartItems.Add(cartItem);

            await _context.SaveChangesAsync(cancellationToken);
        }

        // Reload the cart items and manually load products to ensure productName is mapped correctly
        // We bypass the soft delete filter by loading products separately
        _logger.LogInformation("Loading cart items for CartId: {CartId}", request.CartId);
        
        var cartItems = await _context.CartItems
            .IgnoreQueryFilters()
            .Where(ci => ci.CartId.ToString().ToLower() == request.CartId.ToString().ToLower())
            .ToListAsync(cancellationToken);

        _logger.LogInformation("Loaded {Count} cart items for CartId: {CartId}", cartItems.Count, request.CartId);

        if (cartItems.Count == 0)
        {
            // Return empty cart if no items found
            return new CartDto
            {
                Id = request.CartId,
                UserId = Guid.Empty,
                Status = CartStatus.Active.ToString(),
                Items = new List<CartItemDto>(),
                ItemCount = 0,
                Subtotal = 0m,
                TaxAmount = 0m,
                ShippingAmount = 0m,
                DiscountAmount = 0m,
                TotalAmount = 0m
            };
        }

        // Manually load products for each cart item
        var productIds = cartItems.Select(ci => ci.ProductId).ToList();
        var productIdsStr = productIds.Select(id => id.ToString().ToLower()).ToList();
        _logger.LogInformation("Looking for products with IDs: {ProductIds}", string.Join(", ", productIdsStr));
        
        // Load all products and filter in memory to avoid EF Core GUID comparison issues
        var allProducts = await _context.Products
            .IgnoreQueryFilters()
            .ToListAsync(cancellationToken);
        
        _logger.LogInformation("Total products in database: {Count}", allProducts.Count);
        
        var products = allProducts
            .Where(p => productIdsStr.Contains(p.Id.ToString().ToLower()))
            .ToDictionary(p => p.Id.ToString().ToLower(), p => p);

        _logger.LogInformation("Loaded {Count} products for cart items", products.Count);
        foreach (var prod in products.Values)
        {
            _logger.LogInformation("Product: Id={Id}, Name={Name}", prod.Id, prod.Name);
        }

        // Map cart items to DTOs manually to ensure productName is set correctly
        var cartItemDtos = cartItems.Select(ci => 
        {
            var prodKey = ci.ProductId.ToString().ToLower();
            var foundProduct = products.TryGetValue(prodKey, out var product) ? product : null;
            return new CartItemDto
            {
                Id = ci.Id,
                ProductId = ci.ProductId,
                ProductName = foundProduct?.Name ?? "Unknown",
                ProductImageUrl = foundProduct?.Images.FirstOrDefault()?.Url,
                Quantity = ci.Quantity,
                UnitPrice = ci.UnitPrice,
                Subtotal = ci.Quantity * ci.UnitPrice,
                IsAvailable = (foundProduct?.StockQuantity ?? 0) >= ci.Quantity
            };
        }).ToList();

        return new CartDto
        {
            Id = request.CartId,
            UserId = Guid.Empty,
            Status = CartStatus.Active.ToString(),
            Items = cartItemDtos,
            ItemCount = cartItemDtos.Sum(i => i.Quantity),
            Subtotal = cartItemDtos.Sum(i => i.Subtotal),
            TaxAmount = 0m,
            ShippingAmount = 0m,
            DiscountAmount = 0m,
            TotalAmount = cartItemDtos.Sum(i => i.Subtotal)
        };
    }
}
