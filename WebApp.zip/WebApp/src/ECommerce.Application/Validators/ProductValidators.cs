namespace ECommerce.Application.Validators;

using DTOs;
using FluentValidation;

/// <summary>
/// Validator for product creation requests.
/// WHY: Ensures product data is valid before processing.
/// BUSINESS RULE: Product must have a positive price and unique SKU.
/// </summary>
public class CreateProductRequestValidator : AbstractValidator<CreateProductRequest>
{
    public CreateProductRequestValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty().WithMessage("Product name is required.")
            .MaximumLength(200).WithMessage("Product name cannot exceed 200 characters.");

        RuleFor(x => x.Description)
            .NotEmpty().WithMessage("Product description is required.");

        RuleFor(x => x.Price)
            .GreaterThan(0).WithMessage("Product price must be greater than zero.");

        RuleFor(x => x.CompareAtPrice)
            .GreaterThanOrEqualTo(x => x.Price).WithMessage("Compare-at price must be greater than or equal to regular price.")
            .When(x => x.CompareAtPrice.HasValue);

        RuleFor(x => x.CategoryId)
            .NotEqual(Guid.Empty).WithMessage("Category is required.");

        RuleFor(x => x.Sku)
            .NotEmpty().WithMessage("SKU is required.")
            .MaximumLength(50).WithMessage("SKU cannot exceed 50 characters.");

        RuleFor(x => x.StockQuantity)
            .GreaterThanOrEqualTo(0).WithMessage("Stock quantity cannot be negative.");

        RuleFor(x => x.LowStockThreshold)
            .GreaterThanOrEqualTo(0).WithMessage("Low stock threshold cannot be negative.");
    }
}

/// <summary>
/// Validator for product update requests.
/// WHY: Validates optional product updates.
/// </summary>
public class UpdateProductRequestValidator : AbstractValidator<UpdateProductRequest>
{
    public UpdateProductRequestValidator()
    {
        RuleFor(x => x.Name)
            .MaximumLength(200).WithMessage("Product name cannot exceed 200 characters.")
            .When(x => !string.IsNullOrEmpty(x.Name));

        RuleFor(x => x.Price)
            .GreaterThan(0).WithMessage("Product price must be greater than zero.")
            .When(x => x.Price.HasValue);

        RuleFor(x => x.CompareAtPrice)
            .GreaterThanOrEqualTo(x => x.Price).WithMessage("Compare-at price must be greater than or equal to regular price.")
            .When(x => x.CompareAtPrice.HasValue && x.Price.HasValue);

        RuleFor(x => x.StockQuantity)
            .GreaterThanOrEqualTo(0).WithMessage("Stock quantity cannot be negative.")
            .When(x => x.StockQuantity.HasValue);

        RuleFor(x => x.LowStockThreshold)
            .GreaterThanOrEqualTo(0).WithMessage("Low stock threshold cannot be negative.")
            .When(x => x.LowStockThreshold.HasValue);
    }
}

/// <summary>
/// Validator for add cart item requests.
/// WHY: Ensures cart item data is valid before processing.
/// BUSINESS RULE: Quantity must be positive.
/// </summary>
public class AddCartItemRequestValidator : AbstractValidator<AddCartItemRequest>
{
    public AddCartItemRequestValidator()
    {
        RuleFor(x => x.ProductId)
            .NotEqual(Guid.Empty).WithMessage("Product ID is required.");

        RuleFor(x => x.Quantity)
            .GreaterThan(0).WithMessage("Quantity must be at least 1.")
            .LessThanOrEqualTo(100).WithMessage("Quantity cannot exceed 100.");
    }
}

/// <summary>
/// Validator for order creation requests.
/// WHY: Ensures order data is valid before processing.
/// SECURITY: Order totals are calculated server-side, never trusted from client.
/// </summary>
public class CreateOrderRequestValidator : AbstractValidator<CreateOrderRequest>
{
    public CreateOrderRequestValidator()
    {
        RuleFor(x => x.ShippingAddressId)
            .NotEqual(Guid.Empty).WithMessage("Shipping address is required.");

        RuleFor(x => x.BillingAddressId)
            .NotEqual(Guid.Empty).WithMessage("Billing address must be a valid GUID.")
            .When(x => x.BillingAddressId.HasValue);

        RuleFor(x => x.CustomerNotes)
            .MaximumLength(500).WithMessage("Customer notes cannot exceed 500 characters.")
            .When(x => !string.IsNullOrEmpty(x.CustomerNotes));

        RuleFor(x => x.ShippingMethodName)
            .MaximumLength(100).WithMessage("Shipping method name cannot exceed 100 characters.")
            .When(x => !string.IsNullOrEmpty(x.ShippingMethodName));

        RuleFor(x => x.CouponCode)
            .MaximumLength(50).WithMessage("Coupon code cannot exceed 50 characters.")
            .When(x => !string.IsNullOrEmpty(x.CouponCode));
    }
}
