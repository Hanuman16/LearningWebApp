namespace ECommerce.Core.Exceptions;

/// <summary>
/// Exception thrown when a security violation occurs.
/// WHY: Provides a specific exception type for security-related errors.
/// SECURITY: Used to distinguish security violations from other errors.
/// </summary>
public class SecurityException : Exception
{
    public SecurityException() : base("A security violation occurred.")
    {
    }

    public SecurityException(string message) : base(message)
    {
    }

    public SecurityException(string message, Exception innerException) : base(message, innerException)
    {
    }
}
