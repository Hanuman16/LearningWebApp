namespace ECommerce.Core.Exceptions;

/// <summary>
/// Exception thrown when a user attempts to access a resource they don't have permission to access.
/// WHY: Used for IDOR (Insecure Direct Object Reference) prevention and authorization failures.
/// SECURITY: Never expose internal resource IDs or implementation details in the message.
/// </summary>
public class ForbiddenException : Exception
{
    public ForbiddenException(string message) : base(message) { }

    public ForbiddenException(string message, Exception innerException) : base(message, innerException) { }
}
