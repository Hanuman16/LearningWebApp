namespace ECommerce.Core.Exceptions;

/// <summary>
/// Base class for all domain exceptions.
/// WHY: Domain exceptions represent business rule violations, not technical errors.
/// SECURITY: Exception messages should not expose sensitive system details.
/// DEBUG: Domain exceptions are logged at Warning level, not Error level.
/// TRADE-OFF: Using exceptions for flow control is controversial but acceptable in domain layer.
/// </summary>
public abstract class DomainException : Exception
{
    protected DomainException(string message) : base(message) { }

    protected DomainException(string message, Exception innerException) : base(message, innerException) { }
}
