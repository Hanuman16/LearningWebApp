namespace ECommerce.Core.Exceptions;

/// <summary>
/// Represents a validation error in the domain.
/// WHY: Separates validation failures from technical errors.
/// DEBUG: Log validation failures at Debug level, not Error level.
/// </summary>
public sealed class ValidationException : DomainException
{
    public ValidationException(string message) : base(message) { }

    public ValidationException(string message, Exception innerException) : base(message, innerException) { }
}
