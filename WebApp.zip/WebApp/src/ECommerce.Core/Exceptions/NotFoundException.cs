namespace ECommerce.Core.Exceptions;

/// <summary>
/// Represents a resource not found error.
/// WHY: Separates not-found errors from technical 404s.
/// DEBUG: Log not-found at Debug level to avoid noise in error tracking.
/// </summary>
public sealed class NotFoundException : DomainException
{
    public NotFoundException(string entity, object id) 
        : base($"{entity} with ID '{id}' was not found.") { }

    public NotFoundException(string entity, string message) 
        : base($"{entity}: {message}") { }
}
