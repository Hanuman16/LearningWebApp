namespace ECommerce.Core.Exceptions;

/// <summary>
/// Represents a conflict error (e.g., duplicate resource).
/// WHY: Separates conflict errors from technical 409s.
/// DEBUG: Log conflicts at Warning level, not Error level.
/// </summary>
public sealed class ConflictException : DomainException
{
    public ConflictException(string message) : base(message) { }

    public ConflictException(string message, Exception innerException) : base(message, innerException) { }
}
