namespace ECommerce.Core.Interfaces;

using ECommerce.Core.Entities;

/// <summary>
/// Unit of Work pattern for managing transactions.
/// WHY: Ensures multiple repository operations are committed atomically.
/// PERFORMANCE: Use short-lived transactions to avoid locking.
/// TRADE-OFF: Unit of Work adds complexity but ensures data consistency.
/// </summary>
public interface IUnitOfWork : IDisposable
{
    /// <summary>
    /// Gets the repository for a specific entity type.
    /// </summary>
    IRepository<T> Repository<T>() where T : BaseEntity;

    /// <summary>
    /// Commits all changes to the database.
    /// </summary>
    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Begins a new transaction.
    /// </summary>
    Task<IDisposable> BeginTransactionAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Rolls back the current transaction.
    /// </summary>
    void Rollback();
}
