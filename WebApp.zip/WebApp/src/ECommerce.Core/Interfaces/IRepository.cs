namespace ECommerce.Core.Interfaces;

using System.Linq.Expressions;

/// <summary>
/// Generic repository interface for CRUD operations.
/// WHY: Repository pattern abstracts data access and enables testing.
/// PERFORMANCE: Use AsNoTracking() for read-only queries.
/// TRADE-OFF: Repository pattern adds indirection but enables testing and swapping data sources.
/// </summary>
public interface IRepository<T>
{
    /// <summary>
    /// Gets an entity by its ID.
    /// </summary>
    Task<T?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets all entities with optional filtering and pagination.
    /// </summary>
    IQueryable<T> GetAll();

    /// <summary>
    /// Gets entities matching a predicate.
    /// </summary>
    IQueryable<T> Find(Expression<Func<T, bool>> predicate);

    /// <summary>
    /// Gets the first entity matching a predicate.
    /// </summary>
    Task<T?> FirstOrDefaultAsync(Expression<Func<T, bool>> predicate, CancellationToken cancellationToken = default);

    /// <summary>
    /// Checks if any entity matches a predicate.
    /// </summary>
    Task<bool> AnyAsync(Expression<Func<T, bool>> predicate, CancellationToken cancellationToken = default);

    /// <summary>
    /// Counts entities matching a predicate.
    /// </summary>
    Task<int> CountAsync(Expression<Func<T, bool>> predicate, CancellationToken cancellationToken = default);

    /// <summary>
    /// Adds a new entity.
    /// </summary>
    Task AddAsync(T entity, CancellationToken cancellationToken = default);

    /// <summary>
    /// Adds a range of entities.
    /// </summary>
    Task AddRangeAsync(IEnumerable<T> entities, CancellationToken cancellationToken = default);

    /// <summary>
    /// Updates an existing entity.
    /// </summary>
    void Update(T entity);

    /// <summary>
    /// Updates a range of entities.
    /// </summary>
    void UpdateRange(IEnumerable<T> entities);

    /// <summary>
    /// Soft deletes an entity (sets IsDeleted = true).
    /// </summary>
    void SoftDelete(T entity);

    /// <summary>
    /// Hard deletes an entity from the database.
    /// </summary>
    void Delete(T entity);

    /// <summary>
    /// Deletes entities matching a predicate.
    /// </summary>
    void DeleteRange(Expression<Func<T, bool>> predicate);
}
