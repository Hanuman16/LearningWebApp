namespace ECommerce.Core.Interfaces;

using ECommerce.Core.Entities;

/// <summary>
/// User-specific repository interface with authentication support.
/// WHY: Users have specific queries for authentication and profile management.
/// SECURITY: Never expose password hashes through repository methods.
/// </summary>
public interface IUserRepository : IRepository<User>
{
    /// <summary>
    /// Gets a user by email address.
    /// </summary>
    Task<User?> GetByEmailAsync(string email, CancellationToken cancellationToken = default);

    /// <summary>
    /// Checks if an email already exists.
    /// </summary>
    Task<bool> EmailExistsAsync(string email, CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets active users with pagination.
    /// </summary>
    Task<IEnumerable<User>> GetActiveUsersAsync(int page, int pageSize, CancellationToken cancellationToken = default);
}

/// <summary>
/// Order-specific repository interface with reporting capabilities.
/// WHY: Orders have complex queries for history, status tracking, and reporting.
/// PERFORMANCE: Index on UserId, Status, CreatedAt for common queries.
/// </summary>
public interface IOrderRepository : IRepository<Order>
{
    /// <summary>
    /// Gets orders by user with pagination.
    /// </summary>
    Task<IEnumerable<Order>> GetByUserIdAsync(Guid userId, int page, int pageSize, CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets orders by status.
    /// </summary>
    Task<IEnumerable<Order>> GetByStatusAsync(OrderStatus status, int page, int pageSize, CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets orders by date range.
    /// </summary>
    Task<IEnumerable<Order>> GetByDateRangeAsync(DateTime startDate, DateTime endDate, int page, int pageSize, CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets sales summary for a date range.
    /// </summary>
    Task<(decimal TotalSales, int TotalOrders)> GetSalesSummaryAsync(DateTime startDate, DateTime endDate, CancellationToken cancellationToken = default);
}

/// <summary>
/// Inventory-specific repository interface with stock management.
/// WHY: Inventory has specific queries for stock levels and transactions.
/// </summary>
public interface IInventoryRepository : IRepository<InventoryItem>
{
    /// <summary>
    /// Gets items with low stock.
    /// </summary>
    Task<IEnumerable<InventoryItem>> GetLowStockItemsAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets inventory transaction history for a product.
    /// </summary>
    Task<IEnumerable<InventoryTransaction>> GetTransactionHistoryAsync(Guid inventoryItemId, int page, int pageSize, CancellationToken cancellationToken = default);

    /// <summary>
    /// Updates stock quantity and records transaction.
    /// </summary>
    Task UpdateStockAsync(Guid inventoryItemId, int quantityChange, InventoryTransactionType transactionType, string referenceNumber, string? notes, Guid? userId, CancellationToken cancellationToken = default);
}
