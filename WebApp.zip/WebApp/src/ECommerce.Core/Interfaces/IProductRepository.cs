namespace ECommerce.Core.Interfaces;

using ECommerce.Core.Entities;

/// <summary>
/// Product-specific repository interface with search and filtering capabilities.
/// WHY: Products have complex search, filtering, and sorting requirements.
/// PERFORMANCE: Index on Name, Slug, CategoryId for search queries.
/// DEBUG: Check for products with zero stock: SELECT * FROM Products WHERE StockQuantity = 0 AND IsActive = 1
/// </summary>
public interface IProductRepository : IRepository<Product>
{
    /// <summary>
    /// Searches products by keyword in name or description.
    /// </summary>
    Task<IEnumerable<Product>> SearchAsync(string keyword, int page, int pageSize, CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets featured products.
    /// </summary>
    Task<IEnumerable<Product>> GetFeaturedAsync(int count, CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets products by category with filtering and sorting.
    /// </summary>
    Task<IEnumerable<Product>> GetByCategoryAsync(Guid categoryId, string? sortBy, string? sortOrder, int page, int pageSize, CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets products within a price range.
    /// </summary>
    Task<IEnumerable<Product>> GetByPriceRangeAsync(decimal minPrice, decimal maxPrice, int page, int pageSize, CancellationToken cancellationToken = default);

    /// <summary>
    /// Updates stock quantity for a product.
    /// </summary>
    Task UpdateStockAsync(Guid productId, int newQuantity, CancellationToken cancellationToken = default);
}
