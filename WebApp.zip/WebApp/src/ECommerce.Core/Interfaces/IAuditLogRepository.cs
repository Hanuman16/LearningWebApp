namespace ECommerce.Core.Interfaces;

using ECommerce.Core.Entities;

/// <summary>
/// ╔═══════════════════════════════════════════════════════════╗
/// ║  AUDIT LOG REPOSITORY INTERFACE                          ║
/// ╚═══════════════════════════════════════════════════════════╝
/// 
/// CONCEPTS IMPLEMENTED:
/// ─────────────────────
/// 
/// 1. REPOSITORY PATTERN
///    - Abstracts data access for audit logs
///    - Enables testing with mock repositories
///    - Separates concerns (business logic vs data access)
/// 
/// 2. SOLID PRINCIPLES:
///    - SRP: Repository only handles audit log data access
///    - ISP: Specific methods for audit log operations
///    - DIP: Depends on interface, not concrete implementation
/// </summary>
public interface IAuditLogRepository
{
    /// <summary>
    /// Records an audit log entry
    /// </summary>
    Task AddAsync(AuditLog auditLog, CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets audit logs filtered by user, action, date range
    /// </summary>
    IQueryable<AuditLog> GetByUser(Guid userId);

    /// <summary>
    /// Gets audit logs filtered by action type
    /// </summary>
    IQueryable<AuditLog> GetByAction(string actionType);

    /// <summary>
    /// Gets audit logs filtered by date range
    /// </summary>
    IQueryable<AuditLog> GetByDateRange(DateTime startDate, DateTime endDate);

    /// <summary>
    /// Gets audit logs filtered by severity
    /// </summary>
    IQueryable<AuditLog> GetBySeverity(string severity);

    /// <summary>
    /// Gets recent audit logs with pagination
    /// </summary>
    Task<IEnumerable<AuditLog>> GetRecentAsync(int page, int pageSize, CancellationToken cancellationToken = default);
}
