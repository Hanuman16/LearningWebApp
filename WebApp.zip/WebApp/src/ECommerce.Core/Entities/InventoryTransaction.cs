namespace ECommerce.Core.Entities;

/// <summary>
/// Represents a transaction in the inventory system.
/// WHY: Every stock movement must be tracked for audit and reconciliation.
/// BUSINESS RULE: Each transaction has a type (Purchase, Sale, Adjustment, Return) and quantity.
/// DEBUG: Track stock movements: SELECT * FROM InventoryTransactions WHERE ProductId = @ProductId ORDER BY CreatedAt DESC
/// </summary>
public class InventoryTransaction : BaseEntity
{
    public Guid InventoryItemId { get; set; }
    public Guid ProductId { get; set; }
    public InventoryTransactionType Type { get; set; }
    public int Quantity { get; set; }
    public int PreviousQuantity { get; set; }
    public int NewQuantity { get; set; }
    public required string ReferenceNumber { get; set; } // Order ID, PO number, etc.
    public required string Notes { get; set; }
    public Guid CreatedByUserId { get; set; }

    // Navigation properties
    public virtual InventoryItem InventoryItem { get; set; } = null!;
}

/// <summary>
/// Types of inventory transactions.
/// WHY: Enumerating transaction types enables reporting and filtering.
/// </summary>
public enum InventoryTransactionType
{
    Purchase = 1,      // Stock received from supplier
    Sale = 2,          // Stock sold to customer
    Adjustment = 3,    // Manual adjustment (correction, damage, etc.)
    Return = 4,        // Product returned by customer
    Transfer = 5,      // Transfer between warehouses
}
