namespace ECommerce.Core.Entities;

/// <summary>
/// Represents a user-role assignment (many-to-many join table).
/// WHY: ASP.NET Core Identity uses this table for role-based authorization.
/// SECURITY: Role assignments are critical for access control - audit all changes.
/// DEBUG: Check user roles: SELECT * FROM UserRoles WHERE UserId = @UserId
/// </summary>
public class UserRole : BaseEntity
{
    public Guid UserId { get; set; }
    public required string RoleName { get; set; } // "Admin", "Customer", "Moderator", etc.

    // Navigation properties
    public virtual User User { get; set; } = null!;
}
