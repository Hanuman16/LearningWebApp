namespace ECommerce.Core.Entities;

/// <summary>
/// Represents a message in the outbox pattern for reliable event processing.
/// WHY: Outbox pattern ensures events are not lost during distributed transactions.
/// BUSINESS RULE: Messages are published by background workers after successful database commits.
/// </summary>
public class OutboxMessage : BaseEntity
{
    public required string EventType { get; set; } // "OrderCreated", "PaymentCompleted", etc.
    public required string AggregateId { get; set; } // ID of the aggregate root that triggered the event
    public required string Payload { get; set; } // JSON payload of the event
    public OutboxMessageStatus Status { get; set; } = OutboxMessageStatus.Pending;
    public int RetryCount { get; set; } = 0;
    public string? Error_message { get; set; }
    public DateTime? ProcessedAt { get; set; }

    // Computed property: Should this message be retried?
    public bool ShouldRetry => Status == OutboxMessageStatus.Failed && RetryCount < 3;
}

/// <summary>
/// Status of an outbox message.
/// WHY: Tracks the lifecycle of outbox messages from pending to processed.
/// </summary>
public enum OutboxMessageStatus
{
    Pending = 1,
    Processing = 2,
    Processed = 3,
    Failed = 4,
}
