namespace ECommerce.Core.Entities;

/// <summary>
/// Represents an image associated with a product.
/// WHY: Products can have multiple images for better customer experience.
/// BUSINESS RULE: At least one image is recommended per product.
/// SECURITY: File uploads must be validated for type, size, and content.
/// </summary>
public class ProductImage : BaseEntity
{
    public Guid ProductId { get; set; }
    public required string Url { get; set; }
    public required string AltText { get; set; }
    public int DisplayOrder { get; set; } = 0;

    // Navigation property
    public virtual Product Product { get; set; } = null!;
}
