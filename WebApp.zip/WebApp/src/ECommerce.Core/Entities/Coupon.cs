namespace ECommerce.Core.Entities;

/// <summary>
/// Represents a coupon/discount code.
/// WHY: Coupons enable marketing campaigns and promotional discounts.
/// BUSINESS RULE: Coupons have validity dates, usage limits, and minimum order requirements.
/// SECURITY: Coupon codes must be validated server-side to prevent manipulation.
/// </summary>
public class Coupon : BaseEntity
{
    public required string Code { get; set; } // The actual coupon code (e.g., "SUMMER2024")
    public required string Description { get; set; }
    public CouponType Type { get; set; } = CouponType.Percentage;
    public decimal Value { get; set; } // 20 for 20% or $20
    public decimal? MinOrderAmount { get; set; } // Minimum order value to use this coupon
    public decimal? MaxDiscountAmount { get; set; } // Maximum discount cap
    public int? MaxUsageCount { get; set; } // Total times this coupon can be used
    public int UsedCount { get; set; } = 0;
    public DateTime StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsPublic { get; set; } = true; // Public vs. personalized coupons
    public Guid? CreatedByUserId { get; set; }

    // Navigation property
    public virtual ICollection<CouponUsage> Usages { get; set; } = new List<CouponUsage>();
}

/// <summary>
/// Represents a usage record of a coupon.
/// WHY: Tracks which orders used which coupons for reporting and limit enforcement.
/// </summary>
public class CouponUsage : BaseEntity
{
    public Guid CouponId { get; set; }
    public Guid OrderId { get; set; }
    public Guid UserId { get; set; }
    public decimal DiscountAmount { get; set; }

    // Navigation properties
    public virtual Coupon Coupon { get; set; } = null!;
    public virtual Order Order { get; set; } = null!;
    public virtual User User { get; set; } = null!;
}

/// <summary>
/// Type of coupon discount.
/// WHY: Supports both percentage-based and fixed-amount discounts.
/// </summary>
public enum CouponType
{
    Percentage = 1,
    FixedAmount = 2,
    FreeShipping = 3,
}
