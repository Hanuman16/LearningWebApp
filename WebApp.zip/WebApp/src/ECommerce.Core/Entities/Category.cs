namespace ECommerce.Core.Entities;

/// <summary>
/// Represents a product category for organizing products.
/// WHY: Categories enable product navigation, filtering, and reporting.
/// BUSINESS RULE: Categories can be hierarchical (parent-child relationships).
/// DEBUG: Check for circular references in ParentId navigation.
/// </summary>
public class Category : BaseEntity
{
    public required string Name { get; set; }
    public required string Description { get; set; }
    public string? Slug { get; set; }
    public string? ImageUrl { get; set; }
    public Guid? ParentCategoryId { get; set; }
    public int DisplayOrder { get; set; } = 0;
    public bool IsActive { get; set; } = true;

    // Navigation properties
    public virtual Category? ParentCategory { get; set; }
    public virtual ICollection<Category> ChildCategories { get; set; } = new List<Category>();
    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
