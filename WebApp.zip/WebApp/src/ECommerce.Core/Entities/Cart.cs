namespace ECommerce.Core.Entities;

/// <summary>
/// Represents a shopping cart owned by a user.
/// WHY: Carts allow users to collect items before checkout.
/// BUSINESS RULE: A user can have multiple carts (active + archived).
/// </summary>
public class Cart : BaseEntity
{
    public Guid? UserId { get; set; }
    public CartStatus Status { get; set; } = CartStatus.Active;
    public string? CouponCode { get; set; }
    public decimal DiscountAmount { get; set; } = 0;
    public decimal TaxAmount { get; set; } = 0;
    public decimal ShippingAmount { get; set; } = 0;

    // Computed property: Total amount
    public decimal TotalAmount => Items.Sum(i => i.Subtotal) + TaxAmount + ShippingAmount - DiscountAmount;

    // Navigation properties
    public virtual User? User { get; set; }
    public virtual ICollection<CartItem> Items { get; set; } = new List<CartItem>();
}

/// <summary>
/// Represents an item in a shopping cart.
/// WHY: Tracks individual products, quantities, and prices in a cart.
/// SECURITY: Price is stored here at the time of adding to cart (snapshot) to prevent price manipulation.
/// </summary>
public class CartItem : BaseEntity
{
    public Guid CartId { get; set; }
    public Guid ProductId { get; set; }
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; } // Price at time of adding to cart
    public decimal DiscountAmount { get; set; } = 0;

    // Computed property: Subtotal for this item
    public decimal Subtotal => (UnitPrice - DiscountAmount) * Quantity;

    // Navigation properties
    public virtual Cart Cart { get; set; } = null!;
    public virtual Product Product { get; set; } = null!;
}

/// <summary>
/// Status of a shopping cart.
/// WHY: Tracks cart lifecycle from active to completed or abandoned.
/// </summary>
public enum CartStatus
{
    Active = 1,
    Completed = 2,
    Abandoned = 3,
    Merged = 4, // Merged into another cart (e.g., after login)
}
