namespace ECommerce.Core.Entities;

/// <summary>
/// Represents an audit log entry for tracking critical system operations.
/// WHY: Audit logs are required for compliance, debugging, and security monitoring.
/// SECURITY: Sensitive data (passwords, tokens) must NEVER be logged here.
/// PERFORMANCE: Audit logs are written asynchronously to avoid blocking operations.
/// DEBUG: Track user actions: SELECT * FROM AuditLogs WHERE UserId = @UserId ORDER BY CreatedAt DESC
/// </summary>
public class AuditLog : BaseEntity
{
    public Guid? UserId { get; set; }
    public required string Action { get; set; } // "UserCreated", "OrderPlaced", "ProductUpdated", etc.
    public required string EntityType { get; set; } // "User", "Order", "Product", etc.
    public Guid? EntityId { get; set; }
    public required string OldValues { get; set; } // JSON of old values (redacted)
    public required string NewValues { get; set; } // JSON of new values (redacted)
    public required string IpAddress { get; set; }
    public required string UserAgent { get; set; }
    public AuditLogSeverity Severity { get; set; } = AuditLogSeverity.Information;
    public required string Description { get; set; }

    // Navigation property
    public virtual User? User { get; set; }
}

/// <summary>
/// Severity levels for audit logs.
/// WHY: Different severities enable filtering and alerting.
/// </summary>
public enum AuditLogSeverity
{
    Information = 1,
    Warning = 2,
    Error = 3,
    Critical = 4,
}
