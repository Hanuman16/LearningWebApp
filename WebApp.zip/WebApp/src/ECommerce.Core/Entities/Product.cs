namespace ECommerce.Core.Entities;

/// <summary>
/// Represents a product in the catalog.
/// WHY: Products are the core of the e-commerce platform - everything revolves around them.
/// BUSINESS RULE: A product must have a positive price and available quantity.
/// SECURITY: Product names and descriptions are sanitized to prevent XSS.
/// PERFORMANCE: Index on Name, Slug, and CategoryId for search queries.
/// </summary>
public class Product : BaseEntity
{
    public required string Name { get; set; }
    public required string Description { get; set; }
    public string? Slug { get; set; }
    public decimal Price { get; set; }
    public decimal CompareAtPrice { get; set; } // Original price before discount
    public int StockQuantity { get; set; } = 0;
    public int LowStockThreshold { get; set; } = 10; // Alert when stock falls below this
    public Guid CategoryId { get; set; }
    public string? Sku { get; set; } // Stock Keeping Unit
    public string? Weight { get; set; }
    public string? Dimensions { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsFeatured { get; set; } = false;
    public int ViewCount { get; set; } = 0;
    public int SalesCount { get; set; } = 0;

    // Navigation properties
    public virtual Category Category { get; set; } = null!;
    public virtual ICollection<ProductImage> Images { get; set; } = new List<ProductImage>();
    public virtual ICollection<InventoryItem> InventoryItems { get; set; } = new List<InventoryItem>();
    public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
    public virtual ICollection<CartItem> CartItems { get; set; } = new List<CartItem>();
    public virtual ICollection<WishlistItem> WishlistItems { get; set; } = new List<WishlistItem>();
    public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();
}
