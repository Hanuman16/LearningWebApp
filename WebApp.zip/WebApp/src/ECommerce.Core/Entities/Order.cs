namespace ECommerce.Core.Entities;

/// <summary>
/// Represents a customer order.
/// WHY: Orders are the core business entity - they represent completed sales.
/// BUSINESS RULE: Once an order is placed, stock is reserved and payment is processed.
/// SECURITY: Order totals are calculated server-side, never trusted from client.
/// PERFORMANCE: Index on UserId and CreatedAt for order history queries.
/// DEBUG: Check for failed orders: SELECT * FROM Orders WHERE Status = 'Failed' ORDER BY CreatedAt DESC
/// </summary>
public class Order : BaseEntity
{
    public Guid UserId { get; set; }
    public required string OrderNumber { get; set; } // Human-readable: ORD-2024-0001
    public OrderStatus Status { get; set; } = OrderStatus.Pending;
    public string? CustomerNotes { get; set; }
    public string? InternalNotes { get; set; }
    
    // Financial fields
    public decimal Subtotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal ShippingAmount { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public string Currency { get; set; } = "USD";
    
    // Shipping information
    public string? ShippingMethodName { get; set; }
    public string? TrackingNumber { get; set; }
    public string? TrackingUrl { get; set; }
    
    // Payment information
    public string? PaymentMethod { get; set; }
    public string? PaymentTransactionId { get; set; }
    public PaymentStatus PaymentStatus { get; set; } = PaymentStatus.Pending;
    
    // Dates
    public DateTime? PaidAt { get; set; }
    public DateTime? ShippedAt { get; set; }
    public DateTime? DeliveredAt { get; set; }
    public DateTime? CancelledAt { get; set; }
    public Guid? CancelledByUserId { get; set; }
    public string? CancellationReason { get; set; }
    
    // Foreign keys for addresses
    public Guid? ShippingAddressId { get; set; }
    public Guid? BillingAddressId { get; set; }

    // Navigation properties
    public virtual User User { get; set; } = null!;
    public virtual Address? ShippingAddress { get; set; }
    public virtual Address? BillingAddress { get; set; }
    public virtual ICollection<OrderItem> Items { get; set; } = new List<OrderItem>();
    public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();
    public virtual ICollection<OrderStatusHistory> StatusHistory { get; set; } = new List<OrderStatusHistory>();
}

/// <summary>
/// Represents an item within an order.
/// WHY: Orders contain multiple items, each with its own price, quantity, and product reference.
/// SECURITY: Price is stored here as a snapshot at order time to prevent disputes.
/// </summary>
public class OrderItem : BaseEntity
{
    public Guid OrderId { get; set; }
    public Guid ProductId { get; set; }
    public required string ProductName { get; set; } // Snapshot of product name
    public string? ProductSku { get; set; }
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; } // Price at order time
    public decimal DiscountAmount { get; set; } = 0;
    public decimal TaxAmount { get; set; } = 0;
    public decimal TotalAmount { get; set; }

    // Navigation properties
    public virtual Order Order { get; set; } = null!;
    public virtual Product Product { get; set; } = null!;
}

/// <summary>
/// Tracks the status history of an order.
/// WHY: Every status change is recorded for transparency and debugging.
/// BUSINESS RULE: Status changes follow a defined workflow (Pending → Processing → Shipped → Delivered).
/// </summary>
public class OrderStatusHistory : BaseEntity
{
    public Guid OrderId { get; set; }
    public OrderStatus Status { get; set; }
    public required string Comment { get; set; }
    public Guid ChangedByUserId { get; set; }

    // Navigation property
    public virtual Order Order { get; set; } = null!;
}

/// <summary>
/// Status of an order.
/// WHY: Enumerating order statuses enables workflow management and reporting.
/// </summary>
public enum OrderStatus
{
    Pending = 1,        // Order placed, awaiting payment
    Processing = 2,     // Payment confirmed, being prepared
    Confirmed = 3,      // Order confirmed by customer
    Shipped = 4,        // Order shipped with tracking
    Delivered = 5,      // Order delivered to customer
    Cancelled = 6,      // Order cancelled
    Refunded = 7,       // Order refunded
    Failed = 8,         // Payment or processing failed
}

/// <summary>
/// Status of a payment.
/// WHY: Separates payment status from order status for flexibility.
/// </summary>
public enum PaymentStatus
{
    Pending = 1,
    Completed = 2,
    Failed = 3,
    Refunded = 4,
    PartiallyRefunded = 5,
    Disputed = 6,
}
