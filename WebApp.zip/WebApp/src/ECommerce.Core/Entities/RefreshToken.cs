namespace ECommerce.Core.Entities;

/// <summary>
/// Represents a refresh token for JWT authentication.
/// WHY: Refresh tokens allow users to get new access tokens without re-authenticating.
/// SECURITY: Refresh tokens are one-time use (rotation) and have a limited lifespan.
/// SECURITY: Tokens are stored as hashes, not plain text, to prevent theft.
/// </summary>
public class RefreshToken : BaseEntity
{
    public Guid UserId { get; set; }
    public required string Token { get; set; }
    public required string IpAddress { get; set; }
    public required string UserAgent { get; set; }
    public DateTime ExpiresAt { get; set; }
    public DateTime? RevokedAt { get; set; }
    public string? RevokedByReason { get; set; }
    public bool IsExpired { get; set; }
    public bool IsActive { get; set; } = true;

    // Navigation property
    public virtual User User { get; set; } = null!;
}
