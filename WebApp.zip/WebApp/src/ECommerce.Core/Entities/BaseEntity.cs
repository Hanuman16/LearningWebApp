namespace ECommerce.Core.Entities;

/// <summary>
/// Base entity class for all domain entities.
/// WHY: Provides common properties (Id, CreatedAt, UpdatedAt, IsDeleted) to all entities.
/// PERFORMANCE: Soft delete (IsDeleted) allows data recovery and maintains referential integrity.
/// DEBUG: Filter soft-deleted records: WHERE IsDeleted = 0
/// </summary>
public abstract class BaseEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public bool IsDeleted { get; set; } = false;
    
    // WHY: RowVersion enables optimistic concurrency control
    public byte[]? RowVersion { get; set; }
}
