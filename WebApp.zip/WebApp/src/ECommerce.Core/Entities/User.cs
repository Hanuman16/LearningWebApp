namespace ECommerce.Core.Entities;

/// <summary>
/// Represents a user in the system.
/// WHY: Users are the primary actors - they browse, purchase, and manage the platform.
/// SECURITY: Passwords are hashed by ASP.NET Core Identity, never stored in plain text.
/// </summary>
public class User : BaseEntity
{
    // WHY: FirstName and LastName are separate for personalization and address formatting
    public required string FirstName { get; set; }
    public required string LastName { get; set; }
    public required string Email { get; set; }
    public string? PhoneNumber { get; set; }
    
    // WHY: Identity framework stores the hashed password here
    public required string PasswordHash { get; set; }
    
    // WHY: EmailConfirmed tracks whether the user verified their email
    public bool EmailConfirmed { get; set; }
    
    // WHY: FailedLoginAttempts enables account lockout protection
    public int FailedLoginAttempts { get; set; }
    
    // WHY: LockoutEnd tracks when an account becomes unlocked after lockout
    public DateTime? LockoutEnd { get; set; }
    
    // WHY: IsActive allows soft-deactivation without data loss
    public bool IsActive { get; set; } = true;
    
    // WHY: ProfileImageUri stores the URL to the user's profile picture
    public string? ProfileImageUri { get; set; }
    
    // WHY: LastLoginAt enables analytics and session management
    public DateTime? LastLoginAt { get; set; }

    // Navigation properties
    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
    public virtual ICollection<Cart> Carts { get; set; } = new List<Cart>();
    public virtual ICollection<Wishlist> Wishlists { get; set; } = new List<Wishlist>();
    public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();
    public virtual ICollection<RefreshToken> RefreshTokens { get; set; } = new List<RefreshToken>();
    public virtual ICollection<Address> Addresses { get; set; } = new List<Address>();
    public virtual ICollection<AuditLog> AuditLogs { get; set; } = new List<AuditLog>();
}
