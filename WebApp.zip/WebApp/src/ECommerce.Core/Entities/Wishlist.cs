namespace ECommerce.Core.Entities;

/// <summary>
/// Represents a wishlist owned by a user.
/// WHY: Wishlists allow users to save products for future purchase.
/// BUSINESS RULE: A user can have multiple wishlists (e.g., "Gift Ideas", "Future Purchase").
/// </summary>
public class Wishlist : BaseEntity
{
    public Guid UserId { get; set; }
    public required string Name { get; set; }
    public bool IsShared { get; set; } = false;
    public string? ShareCode { get; set; }

    // Navigation properties
    public virtual User User { get; set; } = null!;
    public virtual ICollection<WishlistItem> Items { get; set; } = new List<WishlistItem>();
}

/// <summary>
/// Represents an item in a wishlist.
/// WHY: Tracks individual products saved by the user.
/// </summary>
public class WishlistItem : BaseEntity
{
    public Guid WishlistId { get; set; }
    public Guid ProductId { get; set; }
    public DateTime AddedAt { get; set; } = DateTime.UtcNow;

    // Navigation properties
    public virtual Wishlist Wishlist { get; set; } = null!;
    public virtual Product Product { get; set; } = null!;
}
