namespace ECommerce.Core.Entities;

/// <summary>
/// Represents a notification for a user.
/// WHY: Notifications keep users informed about orders, promotions, and system events.
/// BUSINESS RULE: Notifications can be email, in-app, or both.
/// </summary>
public class Notification : BaseEntity
{
    public Guid UserId { get; set; }
    public required string Title { get; set; }
    public required string Message { get; set; }
    public NotificationType Type { get; set; } = NotificationType.Info;
    public NotificationChannel Channel { get; set; } = NotificationChannel.InApp;
    public bool IsRead { get; set; } = false;
    public string? ActionType { get; set; } // "ViewOrder", "ReturnToCart", etc.
    public string? ActionUrl { get; set; } // URL to navigate to when action is clicked
    public DateTime? ReadAt { get; set; }

    // Navigation property
    public virtual User User { get; set; } = null!;
}

/// <summary>
/// Type of notification.
/// WHY: Categorizes notifications for styling and filtering.
/// </summary>
public enum NotificationType
{
    Info = 1,
    Success = 2,
    Warning = 3,
    Error = 4,
}

/// <summary>
/// Channel through which a notification is delivered.
/// WHY: Supports multiple delivery channels (in-app, email, SMS).
/// </summary>
public enum NotificationChannel
{
    InApp = 1,
    Email = 2,
    SMS = 3,
    Push = 4,
}
