namespace ECommerce.Core.Entities;

/// <summary>
/// Represents a payment for an order.
/// WHY: Payments are tracked separately from orders to support partial refunds and multiple payment methods.
/// SECURITY: Payment details are never stored - only transaction IDs and status.
/// BUSINESS RULE: Total payment amounts must match order total.
/// DEBUG: Check for failed payments: SELECT * FROM Payments WHERE Status = 'Failed' ORDER BY CreatedAt DESC
/// </summary>
public class Payment : BaseEntity
{
    public Guid OrderId { get; set; }
    public required string PaymentGateway { get; set; } // "Mock", "Stripe", "PayPal", etc.
    public required string TransactionId { get; set; }
    public required string PaymentMethod { get; set; } // "CreditCard", "DebitCard", "BankTransfer", etc.
    public decimal Amount { get; set; }
    public string Currency { get; set; } = "USD";
    public PaymentStatus Status { get; set; } = PaymentStatus.Pending;
    public string? GatewayResponse { get; set; } // JSON response from payment gateway (redacted)
    public string? Error_message { get; set; }
    public DateTime? ProcessedAt { get; set; }

    // Navigation property
    public virtual Order Order { get; set; } = null!;
}
