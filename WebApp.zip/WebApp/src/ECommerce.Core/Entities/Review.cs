namespace ECommerce.Core.Entities;

/// <summary>
/// Represents a product review and rating by a customer.
/// WHY: Reviews provide social proof and help other customers make decisions.
/// BUSINESS RULE: Only verified purchasers can leave reviews.
/// SECURITY: Review content must be sanitized to prevent XSS and injection.
/// DEBUG: Check for suspicious review patterns: SELECT * FROM Reviews WHERE CreatedAt > DATEADD(hour, 1, GETDATE())
/// </summary>
public class Review : BaseEntity
{
    public Guid ProductId { get; set; }
    public Guid UserId { get; set; }
    public int Rating { get; set; } // 1-5 stars
    public required string Title { get; set; }
    public required string Comment { get; set; }
    public bool IsVerifiedPurchase { get; set; }
    public bool IsApproved { get; set; } = false; // Requires moderation
    public int HelpfulCount { get; set; } = 0;
    public int NotHelpfulCount { get; set; } = 0;

    // Navigation properties
    public virtual Product Product { get; set; } = null!;
    public virtual User User { get; set; } = null!;
}
