namespace ECommerce.Core.Entities;

/// <summary>
/// Represents a customer address.
/// WHY: Addresses are needed for shipping and billing.
/// BUSINESS RULE: Addresses are separate from User to allow multiple shipping addresses.
/// SECURITY: Addresses are PII - access must be controlled.
/// </summary>
public class Address : BaseEntity
{
    public Guid UserId { get; set; }
    public required string FirstName { get; set; }
    public required string LastName { get; set; }
    public required string Line1 { get; set; }
    public string? Line2 { get; set; }
    public required string City { get; set; }
    public required string State { get; set; }
    public required string PostalCode { get; set; }
    public required string Country { get; set; }
    public string? PhoneNumber { get; set; }
    public bool IsDefault { get; set; } = false;
    public AddressType Type { get; set; } = AddressType.Shipping;

    // Navigation property
    public virtual User User { get; set; } = null!;
}

/// <summary>
/// Type of address.
/// WHY: Distinguishes between shipping and billing addresses.
/// </summary>
public enum AddressType
{
    Shipping = 1,
    Billing = 2,
    Both = 3,
}
