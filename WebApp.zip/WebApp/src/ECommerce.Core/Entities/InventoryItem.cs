namespace ECommerce.Core.Entities;

/// <summary>
/// Represents inventory tracking for a product.
/// WHY: Inventory management is critical for e-commerce - tracks stock levels and movements.
/// BUSINESS RULE: Stock quantity cannot be negative.
/// PERFORMANCE: Index on ProductId and WarehouseId for quick lookups.
/// </summary>
public class InventoryItem : BaseEntity
{
    public Guid ProductId { get; set; }
    public required string WarehouseLocation { get; set; }
    public int Quantity { get; set; }
    public int ReservedQuantity { get; set; } = 0;
    public int ReorderLevel { get; set; } = 10;
    public bool IsActive { get; set; } = true;

    // Computed property: Available quantity (total minus reserved)
    public int AvailableQuantity => Quantity - ReservedQuantity;

    // Navigation property
    public virtual Product Product { get; set; } = null!;
    public virtual ICollection<InventoryTransaction> Transactions { get; set; } = new List<InventoryTransaction>();
}
