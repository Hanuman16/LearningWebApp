namespace ECommerce.Core.ValueObjects;

using System.Text.RegularExpressions;

/// <summary>
/// Represents an email address with validation.
/// WHY: Using a value object for email prevents bugs from using plain strings.
/// BUSINESS RULE: Emails must be valid format and unique per user.
/// SECURITY: Email validation prevents injection attacks.
/// DEBUG: Check for duplicate emails: SELECT Email, COUNT(*) FROM Users GROUP BY Email HAVING COUNT(*) > 1
/// </summary>
public readonly record struct Email
{
    /// <summary>
    /// The email address value.
    /// </summary>
    public string Value { get; }

    /// <summary>
    /// Private constructor to enforce validation.
    /// </summary>
    private Email(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException("Email cannot be empty.", nameof(value));

        if (!IsValid(value))
            throw new ArgumentException($"Invalid email format: {value}", nameof(value));

        Value = value.Trim().ToLowerInvariant();
    }

    /// <summary>
    /// Creates an Email instance.
    /// </summary>
    public static Email From(string value) => new(value);

    /// <summary>
    /// Validates an email address format.
    /// </summary>
    private static bool IsValid(string email)
    {
        if (string.IsNullOrWhiteSpace(email))
            return false;

        // Basic email validation regex
        var pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
        var regex = new Regex(pattern, RegexOptions.IgnoreCase);
        return regex.IsMatch(email);
    }

    /// <summary>
    /// Checks if this email is empty.
    /// </summary>
    public bool IsEmpty() => string.IsNullOrWhiteSpace(Value);

    /// <summary>
    /// Returns the email as a string.
    /// </summary>
    public override string ToString() => Value;

    /// <summary>
    /// Implicit conversion from string to Email.
    /// </summary>
    public static implicit operator Email(string value) => From(value);

    /// <summary>
    /// Implicit conversion from Email to string.
    /// </summary>
    public static implicit operator string(Email email) => email.Value;
}
