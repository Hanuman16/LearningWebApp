namespace ECommerce.Core.ValueObjects;

/// <summary>
/// Represents a monetary amount with currency.
/// WHY: Using a value object for money prevents bugs from using plain decimals.
/// BUSINESS RULE: Amounts must be non-negative and support up to 2 decimal places.
/// DEBUG: Check for rounding issues: Money.FromDecimal(0.1m) + Money.FromDecimal(0.2m) != Money.FromDecimal(0.3m)
/// TRADE-OFF: Using decimal instead of int (cents) for simplicity, but int would be more precise.
/// </summary>
public readonly record struct Money
{
    /// <summary>
    /// The monetary amount.
    /// </summary>
    public decimal Amount { get; }

    /// <summary>
    /// The currency code (e.g., "USD", "EUR", "GBP").
    /// </summary>
    public string Currency { get; }

    /// <summary>
    /// Private constructor to enforce validation.
    /// </summary>
    private Money(decimal amount, string currency)
    {
        if (amount < 0)
            throw new ArgumentException("Amount cannot be negative.", nameof(amount));

        if (string.IsNullOrWhiteSpace(currency))
            throw new ArgumentException("Currency cannot be empty.", nameof(currency));

        if (currency.Length != 3)
            throw new ArgumentException("Currency must be a 3-letter ISO code.", nameof(currency));

        Amount = decimal.Round(amount, 2, MidpointRounding.AwayFromZero);
        Currency = currency.ToUpperInvariant();
    }

    /// <summary>
    /// Creates a Money instance from a decimal amount in USD.
    /// </summary>
    public static Money FromUsd(decimal amount) => new(amount, "USD");

    /// <summary>
    /// Creates a Money instance from a decimal amount with specified currency.
    /// </summary>
    public static Money From(decimal amount, string currency = "USD") => new(amount, currency);

    /// <summary>
    /// Adds two Money instances (must have the same currency).
    /// </summary>
    public Money Add(Money other)
    {
        EnsureSameCurrency(other);
        return new(Amount + other.Amount, Currency);
    }

    /// <summary>
    /// Subtracts two Money instances (must have the same currency).
    /// </summary>
    public Money Subtract(Money other)
    {
        EnsureSameCurrency(other);
        var result = Amount - other.Amount;
        if (result < 0)
            throw new ArgumentException("Resulting amount cannot be negative.");

        return new(result, Currency);
    }

    /// <summary>
    /// Multiplies the amount by a factor.
    /// </summary>
    public Money Multiply(decimal factor)
    {
        if (factor < 0)
            throw new ArgumentException("Factor cannot be negative.", nameof(factor));

        return new(Amount * factor, Currency);
    }

    /// <summary>
    /// Checks if this money is zero.
    /// </summary>
    public bool IsZero() => Amount == 0m;

    /// <summary>
    /// Returns the amount as a formatted string.
    /// </summary>
    public override string ToString() => $"{Currency} {Amount:F2}";

    private void EnsureSameCurrency(Money other)
    {
        if (Currency != other.Currency)
            throw new InvalidOperationException($"Cannot operate on different currencies: {Currency} vs {other.Currency}");
    }
}
