namespace ECommerce.Core.ValueObjects;

/// <summary>
/// Represents a product quantity.
/// WHY: Using a value object for quantity prevents bugs from using plain integers.
/// BUSINESS RULE: Quantities must be non-negative integers.
/// </summary>
public readonly record struct Quantity
{
    /// <summary>
    /// The quantity value.
    /// </summary>
    public int Value { get; }

    /// <summary>
    /// Private constructor to enforce validation.
    /// </summary>
    private Quantity(int value)
    {
        if (value < 0)
            throw new ArgumentException("Quantity cannot be negative.", nameof(value));

        Value = value;
    }

    /// <summary>
    /// Creates a Quantity instance.
    /// </summary>
    public static Quantity From(int value) => new(value);

    /// <summary>
    /// Creates a zero quantity.
    /// </summary>
    public static Quantity Zero() => new(0);

    /// <summary>
    /// Adds two quantities.
    /// </summary>
    public Quantity Add(Quantity other) => new(Value + other.Value);

    /// <summary>
    /// Subtracts one quantity from another.
    /// </summary>
    public Quantity Subtract(Quantity other)
    {
        var result = Value - other.Value;
        if (result < 0)
            throw new ArgumentException("Resulting quantity cannot be negative.");

        return new(result);
    }

    /// <summary>
    /// Checks if this quantity is zero.
    /// </summary>
    public bool IsZero() => Value == 0;

    /// <summary>
    /// Checks if this quantity is out of stock.
    /// </summary>
    public bool IsOutOfStock() => Value == 0;

    /// <summary>
    /// Checks if this quantity is low (below threshold).
    /// </summary>
    public bool IsLow(int threshold) => Value > 0 && Value < threshold;

    /// <summary>
    /// Returns the quantity as a string.
    /// </summary>
    public override string ToString() => Value.ToString();
}
