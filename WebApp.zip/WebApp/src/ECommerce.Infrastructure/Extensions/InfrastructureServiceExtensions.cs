namespace ECommerce.Infrastructure.Extensions;

using Core.Interfaces;
using Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

/// <summary>
/// Extension methods for registering Infrastructure services.
/// WHY: Centralizes service registration for the Infrastructure layer.
/// </summary>
public static class InfrastructureServiceExtensions
{
    /// <summary>
    /// Registers database context and unit of work.
    /// WHY: Centralizes database configuration.
    /// SECURITY: Connection string is read from configuration, not hardcoded.
    /// PERFORMANCE: Uses SQLite for local development (easier setup, no installation needed).
    /// </summary>
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        // Register DbContext with SQLite (supports both SQLite and SQL Server)
        var connectionString = configuration.GetConnectionString("DefaultConnection") ?? string.Empty;
        var isSqlite = connectionString.StartsWith("Data Source", StringComparison.OrdinalIgnoreCase);

        if (isSqlite)
        {
            services.AddDbContext<ECommerceDbContext>(options =>
                options.UseSqlite(connectionString));
        }
        else
        {
            // SQL Server configuration (for production/Docker)
            services.AddDbContext<ECommerceDbContext>(options =>
                options.UseSqlServer(
                    connectionString,
                    sqlOptions =>
                    {
                        sqlOptions.EnableRetryOnFailure(
                            maxRetryCount: 3,
                            maxRetryDelay: TimeSpan.FromSeconds(10),
                            errorNumbersToAdd: null);
                        sqlOptions.CommandTimeout(30);
                    }));
        }

        // Register Unit of Work
        services.AddScoped<IUnitOfWork, UnitOfWork>();

        // Register specific repositories
        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<IOrderRepository, OrderRepository>();
        services.AddScoped<IInventoryRepository, InventoryRepository>();
        services.AddScoped<IProductRepository, ProductRepository>();

        // Register generic repository
        services.AddScoped(typeof(IRepository<>), typeof(Repository<>));

        return services;
    }
}
