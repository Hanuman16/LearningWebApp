﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace ECommerce.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class MakeCartUserIdNullable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("872989a3-10c2-4e33-a9ba-7a541e88e29e"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("8a32e04e-32e4-4a44-bb18-078d04b468ea"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("c13275e8-2dae-4427-b87a-a827d9c098f0"));

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("46bdddde-80e9-4911-ba05-b1bdf578e0eb"));

            migrationBuilder.AlterColumn<Guid>(
                name: "UserId",
                table: "Carts",
                type: "TEXT",
                nullable: true,
                oldClrType: typeof(Guid),
                oldType: "TEXT");

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "Id", "CreatedAt", "Description", "DisplayOrder", "ImageUrl", "IsActive", "IsDeleted", "Name", "ParentCategoryId", "RowVersion", "Slug", "UpdatedAt" },
                values: new object[,]
                {
                    { new Guid("517c9c8b-90aa-44de-8c93-7d33c159acad"), new DateTime(2026, 10, 5, 7, 14, 0, 330, DateTimeKind.Utc).AddTicks(9411), "Electronic devices and accessories", 1, null, true, false, "Electronics", null, null, "electronics", null },
                    { new Guid("64fc81b1-34f1-4674-8550-b99589d0da03"), new DateTime(2026, 10, 5, 7, 14, 0, 330, DateTimeKind.Utc).AddTicks(9594), "Apparel and fashion items", 2, null, true, false, "Clothing", null, null, "clothing", null },
                    { new Guid("c6f365f8-492b-4e63-be5b-2917250de7d4"), new DateTime(2026, 10, 5, 7, 14, 0, 330, DateTimeKind.Utc).AddTicks(9596), "Books and publications", 3, null, true, false, "Books", null, null, "books", null }
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "CreatedAt", "Email", "EmailConfirmed", "FirstName", "IsActive", "IsDeleted", "LastLoginAt", "LastName", "LockoutEnd", "PasswordHash", "PhoneNumber", "ProfileImageUri", "RowVersion", "UpdatedAt" },
                values: new object[] { new Guid("fd1fd3e0-e605-48cd-aebb-7eef82b141bc"), new DateTime(2026, 10, 5, 7, 14, 0, 337, DateTimeKind.Utc).AddTicks(6249), "admin@ecommerce.com", true, "Admin", true, false, null, "User", null, "AQAAAAEAACcQAAAAEMxJH8V7f3j5K3qZ7Q5V7X8Y9Z0A1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6Q7R8S9T0U1V2W3X4Y5Z6==", null, null, null, null });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("517c9c8b-90aa-44de-8c93-7d33c159acad"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("64fc81b1-34f1-4674-8550-b99589d0da03"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("c6f365f8-492b-4e63-be5b-2917250de7d4"));

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("fd1fd3e0-e605-48cd-aebb-7eef82b141bc"));

            migrationBuilder.AlterColumn<Guid>(
                name: "UserId",
                table: "Carts",
                type: "TEXT",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"),
                oldClrType: typeof(Guid),
                oldType: "TEXT",
                oldNullable: true);

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "Id", "CreatedAt", "Description", "DisplayOrder", "ImageUrl", "IsActive", "IsDeleted", "Name", "ParentCategoryId", "RowVersion", "Slug", "UpdatedAt" },
                values: new object[,]
                {
                    { new Guid("872989a3-10c2-4e33-a9ba-7a541e88e29e"), new DateTime(2026, 9, 12, 16, 16, 9, 493, DateTimeKind.Utc).AddTicks(8154), "Books and publications", 3, null, true, false, "Books", null, null, "books", null },
                    { new Guid("8a32e04e-32e4-4a44-bb18-078d04b468ea"), new DateTime(2026, 9, 12, 16, 16, 9, 493, DateTimeKind.Utc).AddTicks(8004), "Electronic devices and accessories", 1, null, true, false, "Electronics", null, null, "electronics", null },
                    { new Guid("c13275e8-2dae-4427-b87a-a827d9c098f0"), new DateTime(2026, 9, 12, 16, 16, 9, 493, DateTimeKind.Utc).AddTicks(8151), "Apparel and fashion items", 2, null, true, false, "Clothing", null, null, "clothing", null }
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "CreatedAt", "Email", "EmailConfirmed", "FirstName", "IsActive", "IsDeleted", "LastLoginAt", "LastName", "LockoutEnd", "PasswordHash", "PhoneNumber", "ProfileImageUri", "RowVersion", "UpdatedAt" },
                values: new object[] { new Guid("46bdddde-80e9-4911-ba05-b1bdf578e0eb"), new DateTime(2026, 9, 12, 16, 16, 9, 502, DateTimeKind.Utc).AddTicks(3343), "admin@ecommerce.com", true, "Admin", true, false, null, "User", null, "AQAAAAEAACcQAAAAEMxJH8V7f3j5K3qZ7Q5V7X8Y9Z0A1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6Q7R8S9T0U1V2W3X4Y5Z6==", null, null, null, null });
        }
    }
}
