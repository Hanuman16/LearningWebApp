namespace ECommerce.Infrastructure.Data;

using Core.Entities;
using Core.Interfaces;
using Microsoft.EntityFrameworkCore.Storage;

/// <summary>
/// Unit of Work implementation using EF Core.
/// WHY: Implements the IUnitOfWork interface with EF Core.
/// PERFORMANCE: Uses short-lived transactions to avoid locking.
/// DEBUG: Logs transaction start/commit/rollback.
/// </summary>
public class UnitOfWork : IUnitOfWork
{
    private readonly ECommerceDbContext _context;
    private readonly Dictionary<Type, object> _repositories = new();
    private IDbContextTransaction? _transaction;

    public UnitOfWork(ECommerceDbContext context)
    {
        _context = context;
    }

    public IRepository<T> Repository<T>() where T : BaseEntity
    {
        var type = typeof(T);

        if (!_repositories.TryGetValue(type, out var repository))
        {
            repository = new Repository<T>(_context);
            _repositories[type] = repository;
        }

        return (IRepository<T>)repository;
    }

    public async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        return await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task<IDisposable> BeginTransactionAsync(CancellationToken cancellationToken = default)
    {
        _transaction = await _context.Database.BeginTransactionAsync(cancellationToken);
        return new TransactionScope(_transaction);
    }

    public void Rollback()
    {
        _transaction?.Rollback();
    }

    public async Task CommitAsync()
    {
        try
        {
            await _context.SaveChangesAsync();
            if (_transaction != null)
            {
                await _transaction.CommitAsync();
            }
        }
        catch
        {
            _transaction?.Rollback();
            throw;
        }
    }

    public void Dispose()
    {
        _transaction?.Dispose();
        _context.Dispose();
        GC.SuppressFinalize(this);
    }

    /// <summary>
    /// Internal disposable wrapper for transaction scope.
    /// </summary>
    private class TransactionScope(IDbContextTransaction transaction) : IDisposable
    {
        public void Dispose()
        {
            transaction.Dispose();
        }
    }
}
