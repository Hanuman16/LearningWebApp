namespace ECommerce.Infrastructure.Data;

using Core.Entities;
using Core.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

/// <summary>
/// Product repository implementation with search and filtering.
/// WHY: Implements IProductRepository interface with EF Core queries.
/// PERFORMANCE: Index on Name, Slug, CategoryId for search queries.
/// </summary>
public class ProductRepository : IProductRepository
{
    private readonly ECommerceDbContext _context;

    public ProductRepository(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Product>> SearchAsync(string keyword, int page, int pageSize, CancellationToken cancellationToken = default)
    {
        return await _context.Products
            .Where(p => p.Name.Contains(keyword) || p.Description.Contains(keyword))
            .OrderByDescending(p => p.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);
    }

    public async Task<IEnumerable<Product>> GetFeaturedAsync(int count, CancellationToken cancellationToken = default)
    {
        return await _context.Products
            .Where(p => p.IsFeatured && p.IsActive)
            .OrderByDescending(p => p.CreatedAt)
            .Take(count)
            .ToListAsync(cancellationToken);
    }

    public async Task<IEnumerable<Product>> GetByCategoryAsync(Guid categoryId, string? sortBy, string? sortOrder, int page, int pageSize, CancellationToken cancellationToken = default)
    {
        var query = _context.Products
            .Where(p => p.CategoryId == categoryId && p.IsActive);

        query = sortBy?.ToLowerInvariant() switch
        {
            "name" => sortOrder?.ToLowerInvariant() == "desc" ? query.OrderByDescending(p => p.Name) : query.OrderBy(p => p.Name),
            "price" => sortOrder?.ToLowerInvariant() == "desc" ? query.OrderByDescending(p => p.Price) : query.OrderBy(p => p.Price),
            "created" => sortOrder?.ToLowerInvariant() == "desc" ? query.OrderByDescending(p => p.CreatedAt) : query.OrderBy(p => p.CreatedAt),
            _ => query.OrderByDescending(p => p.CreatedAt)
        };

        return await query
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);
    }

    public async Task<IEnumerable<Product>> GetByPriceRangeAsync(decimal minPrice, decimal maxPrice, int page, int pageSize, CancellationToken cancellationToken = default)
    {
        return await _context.Products
            .Where(p => p.Price >= minPrice && p.Price <= maxPrice && p.IsActive)
            .OrderBy(p => p.Price)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);
    }

    public async Task UpdateStockAsync(Guid productId, int newQuantity, CancellationToken cancellationToken = default)
    {
        var product = await _context.Products.FindAsync(new object[] { productId }, cancellationToken);
        if (product != null)
        {
            product.StockQuantity = newQuantity;
        }
    }

    public async Task AddAsync(Product entity, CancellationToken cancellationToken = default)
    {
        await _context.Products.AddAsync(entity, cancellationToken);
    }

    public async Task AddRangeAsync(IEnumerable<Product> entities, CancellationToken cancellationToken = default)
    {
        await _context.Products.AddRangeAsync(entities, cancellationToken);
    }

    public void Update(Product entity)
    {
        _context.Products.Update(entity);
    }

    public void UpdateRange(IEnumerable<Product> entities)
    {
        _context.Products.UpdateRange(entities);
    }

    public void SoftDelete(Product entity)
    {
        entity.IsActive = false;
        _context.Products.Update(entity);
    }

    public void Delete(Product entity)
    {
        _context.Products.Remove(entity);
    }

    public void DeleteRange(Expression<Func<Product, bool>> predicate)
    {
        var entities = _context.Products.Where(predicate).ToList();
        _context.Products.RemoveRange(entities);
    }

    public async Task<Product?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        return await _context.Products.FindAsync(new object[] { id }, cancellationToken);
    }

    public IQueryable<Product> GetAll()
    {
        return _context.Products.AsNoTracking();
    }

    public IQueryable<Product> Find(System.Linq.Expressions.Expression<Func<Product, bool>> predicate)
    {
        return _context.Products.AsNoTracking().Where(predicate);
    }

    public async Task<Product?> FirstOrDefaultAsync(System.Linq.Expressions.Expression<Func<Product, bool>> predicate, CancellationToken cancellationToken = default)
    {
        return await _context.Products.AsNoTracking().FirstOrDefaultAsync(predicate, cancellationToken);
    }

    public async Task<bool> AnyAsync(System.Linq.Expressions.Expression<Func<Product, bool>> predicate, CancellationToken cancellationToken = default)
    {
        return await _context.Products.AsNoTracking().AnyAsync(predicate, cancellationToken);
    }

    public async Task<IEnumerable<Product>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _context.Products.AsNoTracking().ToListAsync(cancellationToken);
    }

    public async Task<int> CountAsync(System.Linq.Expressions.Expression<Func<Product, bool>> predicate, CancellationToken cancellationToken = default)
    {
        return await _context.Products.AsNoTracking().CountAsync(predicate, cancellationToken);
    }
}
