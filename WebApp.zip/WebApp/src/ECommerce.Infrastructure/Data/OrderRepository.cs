namespace ECommerce.Infrastructure.Data;

using Core.Entities;
using Core.Interfaces;
using Core.Exceptions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Linq.Expressions;

/// <summary>
/// ╔═══════════════════════════════════════════════════════════╗
/// ║  ORDER REPOSITORY WITH IDOR PREVENTION                   ║
/// ╚═══════════════════════════════════════════════════════════╝
/// 
/// CONCEPTS IMPLEMENTED:
/// ─────────────────────
/// 
/// 1. IDOR (INSECURE DIRECT OBJECT REFERENCE) PREVENTION
///    - Users can ONLY access their own orders
///    - Admins can access all orders via admin-only methods
///    - Ownership check enforced at repository level (never trust frontend)
/// 
/// 2. DEFENSIVE PROGRAMMING
///    - Validates userId matches requested order
///    - Throws ForbiddenException if user tries to access another user's order
///    - Logs all IDOR attempts for security auditing
/// 
/// 3. REPOSITORY PATTERN
///    - Encapsulates all order data access logic
///    - Separates concerns (business logic vs data access)
/// 
/// 4. SOLID PRINCIPLES:
///    - SRP: Repository only handles order data access
///    - ISP: Specific methods for order operations
///    - DIP: Depends on DbContext (injected)
/// </summary>
public class OrderRepository : IOrderRepository
{
    private readonly ECommerceDbContext _context;
    private readonly ILogger<OrderRepository> _logger;

    public OrderRepository(
        ECommerceDbContext context,
        ILogger<OrderRepository> logger)
    {
        _context = context;
        _logger = logger;
    }

    /// <summary>
    /// Gets orders for a SPECIFIC user (IDOR prevention)
    /// SECURITY: Users can only see their own orders
    /// </summary>
    public async Task<IEnumerable<Order>> GetByUserIdAsync(
        Guid userId,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default)
    {
        return await _context.Orders
            .Where(o => o.UserId == userId) // SECURITY: Filter by owner
            .Include(o => o.Items)
            .OrderByDescending(o => o.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);
    }

    /// <summary>
    /// Gets order by ID with ownership verification
    /// SECURITY: Throws ForbiddenException if user tries to access another user's order
    /// WHY: Prevents IDOR attacks where users manipulate order IDs to access other users' data
    /// </summary>
    public async Task<Order?> GetByIdWithOwnershipCheckAsync(
        Guid orderId,
        Guid requestingUserId,
        bool isAdmin,
        CancellationToken cancellationToken = default)
    {
        var order = await _context.Orders
            .Include(o => o.Items)
            .Include(o => o.User)
            .FirstOrDefaultAsync(o => o.Id == orderId, cancellationToken);

        if (order == null)
        {
            return null;
        }

        // SECURITY: Non-admin users can only access their own orders
        if (!isAdmin && order.UserId != requestingUserId)
        {
            if (_logger.IsEnabled(LogLevel.Warning))
            {
                _logger.LogWarning("IDOR attempt blocked: User {UserId} tried to access Order {OrderId}",
                    requestingUserId, orderId);
            }
            throw new ForbiddenException("You do not have permission to access this order");
        }

        return order;
    }

    /// <summary>
    /// Gets orders by status (admin-only operation)
    /// SECURITY: Admin role required (enforced by caller via [Authorize])
    /// </summary>
    public async Task<IEnumerable<Order>> GetByStatusAsync(
        OrderStatus status,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default)
    {
        return await _context.Orders
            .Where(o => o.Status == status)
            .Include(o => o.Items)
            .OrderByDescending(o => o.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);
    }

    /// <summary>
    /// Gets orders by date range (admin-only operation)
    /// </summary>
    public async Task<IEnumerable<Order>> GetByDateRangeAsync(
        DateTime startDate,
        DateTime endDate,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default)
    {
        return await _context.Orders
            .Where(o => o.CreatedAt >= startDate && o.CreatedAt <= endDate)
            .Include(o => o.Items)
            .OrderByDescending(o => o.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);
    }

    /// <summary>
    /// Gets sales summary (admin-only operation)
    /// </summary>
    public async Task<(decimal TotalSales, int TotalOrders)> GetSalesSummaryAsync(
        DateTime startDate,
        DateTime endDate,
        CancellationToken cancellationToken = default)
    {
        var orders = await _context.Orders
            .Where(o => o.CreatedAt >= startDate && o.CreatedAt <= endDate && o.Status != OrderStatus.Cancelled)
            .ToListAsync(cancellationToken);

        var totalSales = orders.Sum(o => o.TotalAmount);
        var totalOrders = orders.Count;

        return (totalSales, totalOrders);
    }

    /// <summary>
    /// Adds a new order (ownership set by service layer)
    /// </summary>
    public async Task AddAsync(Order entity, CancellationToken cancellationToken = default)
    {
        await _context.Orders.AddAsync(entity, cancellationToken);
    }

    public async Task AddRangeAsync(IEnumerable<Order> entities, CancellationToken cancellationToken = default)
    {
        await _context.Orders.AddRangeAsync(entities, cancellationToken);
    }

    public void Update(Order entity)
    {
        _context.Orders.Update(entity);
    }

    public void UpdateRange(IEnumerable<Order> entities)
    {
        _context.Orders.UpdateRange(entities);
    }

    public void SoftDelete(Order entity)
    {
        entity.Status = OrderStatus.Cancelled;
        entity.CancelledAt = DateTime.UtcNow;
        _context.Orders.Update(entity);
    }

    public void Delete(Order entity)
    {
        _context.Orders.Remove(entity);
    }

    public void DeleteRange(Expression<Func<Order, bool>> predicate)
    {
        var entities = _context.Orders.Where(predicate).ToList();
        _context.Orders.RemoveRange(entities);
    }

    public async Task<Order?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        return await _context.Orders.FindAsync(new object[] { id }, cancellationToken);
    }

    public IQueryable<Order> GetAll()
    {
        return _context.Orders.AsNoTracking();
    }

    public IQueryable<Order> Find(Expression<Func<Order, bool>> predicate)
    {
        return _context.Orders.AsNoTracking().Where(predicate);
    }

    public async Task<Order?> FirstOrDefaultAsync(Expression<Func<Order, bool>> predicate, CancellationToken cancellationToken = default)
    {
        return await _context.Orders.AsNoTracking().FirstOrDefaultAsync(predicate, cancellationToken);
    }

    public async Task<bool> AnyAsync(System.Linq.Expressions.Expression<Func<Order, bool>> predicate, CancellationToken cancellationToken = default)
    {
        return await _context.Orders.AsNoTracking().AnyAsync(predicate, cancellationToken);
    }

    public async Task<IEnumerable<Order>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _context.Orders.AsNoTracking().ToListAsync(cancellationToken);
    }

    public async Task<int> CountAsync(System.Linq.Expressions.Expression<Func<Order, bool>> predicate, CancellationToken cancellationToken = default)
    {
        return await _context.Orders.AsNoTracking().CountAsync(predicate, cancellationToken);
    }
}
