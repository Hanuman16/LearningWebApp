namespace ECommerce.Infrastructure.Data;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using System.IO;

/// <summary>
/// DbContext factory for EF Core migrations and design-time tools.
/// WHY: Allows migrations to run outside of the application lifecycle.
/// DESIGN-TIME: Reads appsettings.json from the Api project for connection strings.
/// </summary>
public class ECommerceDbContextFactory : IDesignTimeDbContextFactory<ECommerceDbContext>
{
    public ECommerceDbContext CreateDbContext(string[] args)
    {
        // Load configuration from the Api project
        var configuration = new ConfigurationBuilder()
            .SetBasePath(Path.Combine(Directory.GetCurrentDirectory(), "..", "ECommerce.Api"))
            .AddJsonFile("appsettings.json")
            .Build();

        var connectionString = configuration.GetConnectionString("DefaultConnection") ?? string.Empty;
        var isSqlite = connectionString.StartsWith("Data Source", StringComparison.OrdinalIgnoreCase);

        var optionsBuilder = new DbContextOptionsBuilder<ECommerceDbContext>();

        if (isSqlite)
        {
            optionsBuilder.UseSqlite(connectionString);
        }
        else
        {
            optionsBuilder.UseSqlServer(connectionString, sqlOptions =>
                sqlOptions.EnableRetryOnFailure());
        }

        // Suppress pending model changes warning during design-time
        optionsBuilder.ConfigureWarnings(warnings => warnings.Ignore(Microsoft.EntityFrameworkCore.Diagnostics.RelationalEventId.PendingModelChangesWarning));

        return new ECommerceDbContext(optionsBuilder.Options);
    }
}
