namespace ECommerce.Infrastructure.Data;

using ECommerce.Core.Entities;
using ECommerce.Core.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

/// <summary>
/// ╔═══════════════════════════════════════════════════════════╗
/// ║  AUDIT LOG REPOSITORY IMPLEMENTATION                     ║
/// ╚═══════════════════════════════════════════════════════════╝
/// 
/// CONCEPTS IMPLEMENTED:
/// ─────────────────────
/// 
/// 1. REPOSITORY PATTERN
///    - Concrete implementation of IAuditLogRepository
///    - Encapsulates all data access for audit logs
///    - Uses EF Core DbContext for database operations
/// 
/// 2. SOLID PRINCIPLES:
///    - SRP: Repository only handles audit log data access
///    - DIP: Depends on DbContext (injected), not concrete implementation
///    - ISP: Specific methods for audit log operations only
/// 
/// 3. DEFENSIVE PROGRAMMING
///    - Validates all inputs before database operations
///    - Uses async/await for non-blocking I/O
///    - Proper error handling and logging
/// 
/// 4. PERFORMANCE OPTIMIZATION
///    - Uses async methods for I/O operations
///    - IQueryable for flexible querying
///    - Pagination for large result sets
/// </summary>
public class AuditLogRepository : IAuditLogRepository
{
    private readonly ECommerceDbContext _context;
    private readonly ILogger<AuditLogRepository> _logger;

    public AuditLogRepository(
        ECommerceDbContext context,
        ILogger<AuditLogRepository> logger)
    {
        _context = context;
        _logger = logger;
    }

    /// <summary>
    /// Records an audit log entry asynchronously
    /// WHY: Async operations prevent thread pool exhaustion under load
    /// SECURITY: Audit logs are immutable - once created, they cannot be modified
    /// </summary>
    public async Task AddAsync(AuditLog auditLog, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(auditLog);

        if (string.IsNullOrWhiteSpace(auditLog.Action) ||
            string.IsNullOrWhiteSpace(auditLog.EntityType) ||
            string.IsNullOrWhiteSpace(auditLog.Description) ||
            string.IsNullOrWhiteSpace(auditLog.IpAddress))
        {
            throw new ArgumentException("Audit log requires Action, EntityType, Description, and IpAddress");
        }

        await _context.AuditLogs.AddAsync(auditLog, cancellationToken);
        await _context.SaveChangesAsync(cancellationToken);

        if (_logger.IsEnabled(LogLevel.Debug))
        {
            _logger.LogDebug("Audit log recorded: {Action} for {EntityType} by User {UserId}",
                auditLog.Action, auditLog.EntityType, auditLog.UserId);
        }
    }

    /// <summary>
    /// Gets audit logs filtered by user ID
    /// WHY: Enables forensic analysis of user actions
    /// SECURITY: Users can only view their own audit logs (authorization enforced by caller)
    /// </summary>
    public IQueryable<AuditLog> GetByUser(Guid userId)
    {
        return _context.AuditLogs
            .Where(log => log.UserId == userId)
            .OrderByDescending(log => log.CreatedAt);
    }

    /// <summary>
    /// Gets audit logs filtered by action type
    /// WHY: Enables security monitoring for specific actions (e.g., "LoginFailed", "AccessDenied")
    /// SECURITY: Admin-only operation (authorization enforced by caller)
    /// </summary>
    public IQueryable<AuditLog> GetByAction(string actionType)
    {
        ArgumentNullException.ThrowIfNull(actionType);

        return _context.AuditLogs
            .Where(log => log.Action == actionType)
            .OrderByDescending(log => log.CreatedAt);
    }

    /// <summary>
    /// Gets audit logs filtered by date range
    /// WHY: Enables time-based security analysis and compliance reporting
    /// SECURITY: Admin-only operation (authorization enforced by caller)
    /// </summary>
    public IQueryable<AuditLog> GetByDateRange(DateTime startDate, DateTime endDate)
    {
        if (startDate > endDate)
        {
            throw new ArgumentException("Start date must be before end date");
        }

        return _context.AuditLogs
            .Where(log => log.CreatedAt >= startDate && log.CreatedAt <= endDate)
            .OrderByDescending(log => log.CreatedAt);
    }

    /// <summary>
    /// Gets audit logs filtered by severity level
    /// WHY: Enables alerting on critical security events
    /// SECURITY: Admin-only operation (authorization enforced by caller)
    /// </summary>
    public IQueryable<AuditLog> GetBySeverity(string severity)
    {
        if (string.IsNullOrWhiteSpace(severity))
        {
            throw new ArgumentException("Severity cannot be null or empty", nameof(severity));
        }

        return _context.AuditLogs
            .Where(log => log.Severity.ToString().Equals(severity, StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(log => log.CreatedAt);
    }

    /// <summary>
    /// Gets recent audit logs with pagination
    /// WHY: Prevents memory exhaustion from large result sets
    /// PERFORMANCE: Pagination reduces database load and network transfer
    /// </summary>
    public async Task<IEnumerable<AuditLog>> GetRecentAsync(int page, int pageSize, CancellationToken cancellationToken = default)
    {
        if (page < 1)
        {
            throw new ArgumentException("Page must be greater than 0");
        }

        if (pageSize < 1 || pageSize > 100)
        {
            throw new ArgumentException("Page size must be between 1 and 100");
        }

        return await _context.AuditLogs
            .OrderByDescending(log => log.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);
    }
}
