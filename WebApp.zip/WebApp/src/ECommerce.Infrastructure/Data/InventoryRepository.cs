namespace ECommerce.Infrastructure.Data;

using Core.Entities;
using Core.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

/// <summary>
/// Inventory repository implementation with stock management.
/// WHY: Implements IInventoryRepository interface with EF Core queries.
/// </summary>
public class InventoryRepository : IInventoryRepository
{
    private readonly ECommerceDbContext _context;

    public InventoryRepository(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<InventoryItem>> GetLowStockItemsAsync(CancellationToken cancellationToken = default)
    {
        return await _context.InventoryItems
            .Where(i => i.Quantity <= i.ReorderLevel)
            .OrderBy(i => i.Quantity)
            .ToListAsync(cancellationToken);
    }

    public async Task<IEnumerable<InventoryTransaction>> GetTransactionHistoryAsync(Guid inventoryItemId, int page, int pageSize, CancellationToken cancellationToken = default)
    {
        return await _context.InventoryTransactions
            .Where(t => t.InventoryItemId == inventoryItemId)
            .OrderByDescending(t => t.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);
    }

    public async Task UpdateStockAsync(Guid inventoryItemId, int quantityChange, InventoryTransactionType transactionType, string referenceNumber, string? notes, Guid? userId, CancellationToken cancellationToken = default)
    {
        var inventoryItem = await _context.InventoryItems.FindAsync(new object[] { inventoryItemId }, cancellationToken);
        if (inventoryItem == null)
        {
            throw new Core.Exceptions.NotFoundException("InventoryItem", inventoryItemId);
        }

        var previousQuantity = inventoryItem.Quantity;
        inventoryItem.Quantity = Math.Max(0, inventoryItem.Quantity + quantityChange);
        var newQuantity = inventoryItem.Quantity;

        var transaction = new InventoryTransaction
        {
            Id = Guid.NewGuid(),
            InventoryItemId = inventoryItemId,
            ProductId = inventoryItem.ProductId,
            Type = transactionType,
            Quantity = quantityChange,
            PreviousQuantity = previousQuantity,
            NewQuantity = newQuantity,
            ReferenceNumber = referenceNumber,
            Notes = notes ?? string.Empty,
            CreatedByUserId = userId ?? Guid.Empty
        };

        _context.InventoryTransactions.Add(transaction);
    }

    public async Task AddAsync(InventoryItem entity, CancellationToken cancellationToken = default)
    {
        await _context.InventoryItems.AddAsync(entity, cancellationToken);
    }

    public async Task AddRangeAsync(IEnumerable<InventoryItem> entities, CancellationToken cancellationToken = default)
    {
        await _context.InventoryItems.AddRangeAsync(entities, cancellationToken);
    }

    public void Update(InventoryItem entity)
    {
        _context.InventoryItems.Update(entity);
    }

    public void UpdateRange(IEnumerable<InventoryItem> entities)
    {
        _context.InventoryItems.UpdateRange(entities);
    }

    public void SoftDelete(InventoryItem entity)
    {
        entity.IsActive = false;
        _context.InventoryItems.Update(entity);
    }

    public void Delete(InventoryItem entity)
    {
        _context.InventoryItems.Remove(entity);
    }

    public void DeleteRange(Expression<Func<InventoryItem, bool>> predicate)
    {
        var entities = _context.InventoryItems.Where(predicate).ToList();
        _context.InventoryItems.RemoveRange(entities);
    }

    public async Task<InventoryItem?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        return await _context.InventoryItems.FindAsync(new object[] { id }, cancellationToken);
    }

    public IQueryable<InventoryItem> GetAll()
    {
        return _context.InventoryItems.AsNoTracking();
    }

    public IQueryable<InventoryItem> Find(System.Linq.Expressions.Expression<Func<InventoryItem, bool>> predicate)
    {
        return _context.InventoryItems.AsNoTracking().Where(predicate);
    }

    public async Task<InventoryItem?> FirstOrDefaultAsync(System.Linq.Expressions.Expression<Func<InventoryItem, bool>> predicate, CancellationToken cancellationToken = default)
    {
        return await _context.InventoryItems.AsNoTracking().FirstOrDefaultAsync(predicate, cancellationToken);
    }

    public async Task<bool> AnyAsync(System.Linq.Expressions.Expression<Func<InventoryItem, bool>> predicate, CancellationToken cancellationToken = default)
    {
        return await _context.InventoryItems.AsNoTracking().AnyAsync(predicate, cancellationToken);
    }

    public async Task<IEnumerable<InventoryItem>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _context.InventoryItems.AsNoTracking().ToListAsync(cancellationToken);
    }

    public async Task<int> CountAsync(System.Linq.Expressions.Expression<Func<InventoryItem, bool>> predicate, CancellationToken cancellationToken = default)
    {
        return await _context.InventoryItems.AsNoTracking().CountAsync(predicate, cancellationToken);
    }
}
