using System.Security.Claims;

namespace ECommerce.Shared.Helpers;

/// <summary>
/// Helper methods for common operations.
/// </summary>
public static class StringHelpers
{
    /// <summary>
    /// Generates a URL-friendly slug from a string.
    /// </summary>
    public static string GenerateSlug(string text, int maxLength = 200)
    {
        if (string.IsNullOrWhiteSpace(text))
            return string.Empty;

        var slug = text.ToLowerInvariant();

        // Replace non-alphanumeric characters with hyphens
        slug = new string(slug.Select(c => char.IsLetterOrDigit(c) ? c : '-').ToArray());

        // Remove consecutive hyphens
        while (slug.Contains("--"))
            slug = slug.Replace("--", "-");

        // Trim hyphens from start and end
        slug = slug.Trim('-');

        // Truncate to max length
        if (slug.Length > maxLength)
            slug = slug[..maxLength];

        return slug;
    }

    /// <summary>
    /// Generates a random alphanumeric string of specified length.
    /// </summary>
    public static string GenerateRandomString(int length = 32)
    {
        const string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        var random = new Random();
        return new string(Enumerable.Repeat(chars, length)
            .Select(s => s[random.Next(s.Length)]).ToArray());
    }

    /// <summary>
    /// Generates a unique order number.
    /// </summary>
    public static string GenerateOrderNumber()
    {
        var timestamp = DateTime.UtcNow.ToString("yyyyMMddHHmmss");
        var random = new Random().Next(1000, 9999);
        return $"ORD-{timestamp}-{random}";
    }

    /// <summary>
    /// Generates a unique SKU.
    /// </summary>
    public static string GenerateSku(string productName, int maxLength = 50)
    {
        var baseSku = GenerateSlug(productName).Replace("-", "").ToUpperInvariant();
        var randomSuffix = new Random().Next(1000, 9999);
        var sku = $"{baseSku}-{randomSuffix}";
        return sku.Length > maxLength ? sku[..maxLength] : sku;
    }

    /// <summary>
    /// Checks if a string is a valid email format.
    /// </summary>
    public static bool IsValidEmail(string email)
    {
        if (string.IsNullOrWhiteSpace(email))
            return false;

        try
        {
            var addr = new System.Net.Mail.MailAddress(email);
            return addr.Address == email;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Truncates a string to a specified length and appends ellipsis if truncated.
    /// </summary>
    public static string Truncate(string value, int maxLength)
    {
        if (string.IsNullOrEmpty(value)) return value;
        return value.Length <= maxLength ? value : $"{value[..(maxLength - 3)]}...";
    }
}
