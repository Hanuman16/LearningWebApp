namespace ECommerce.Shared.Helpers;

/// <summary>
/// Pagination helper methods.
/// </summary>
public static class PaginationHelpers
{
    public static (IEnumerable<T> Items, PaginationMetadata Metadata) Paginate<T>(
        IEnumerable<T> source, int pageNumber, int pageSize)
    {
        var totalCount = source.Count();
        var totalPages = (int)Math.Ceiling(totalCount / (double)pageSize);

        var items = source
            .Skip((pageNumber - 1) * pageSize)
            .Take(pageSize)
            .ToList();

        var metadata = new PaginationMetadata(
            totalCount,
            pageSize,
            pageNumber,
            totalPages,
            pageNumber > 1,
            pageNumber < totalPages
        );

        return (items, metadata);
    }
}

public record PaginationMetadata(
    int TotalCount,
    int PageSize,
    int PageNumber,
    int TotalPages,
    bool HasPrevious,
    bool HasNext)
{
    public IEnumerable<int> PageNumbers
    {
        get
        {
            for (var i = 1; i <= TotalPages; i++)
                yield return i;
        }
    }
};
