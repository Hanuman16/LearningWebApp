using System.Security.Claims;
using ECommerce.Shared.Constants;

namespace ECommerce.Shared.Helpers;

/// <summary>
/// Claims-based helper methods for user identity operations.
/// </summary>
public static class ClaimsHelpers
{
    public static string? GetUserId(ClaimsPrincipal user)
    {
        return user.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
    }

    public static string? GetEmail(ClaimsPrincipal user)
    {
        return user.FindFirst(ClaimTypes.Email)?.Value;
    }

    public static string? GetUserName(ClaimsPrincipal user)
    {
        return user.FindFirst(ClaimTypes.Name)?.Value;
    }

    public static string? GetIpAddress(ClaimsPrincipal user)
    {
        return user.FindFirst("ip_address")?.Value;
    }

    public static string? GetUserAgent(ClaimsPrincipal user)
    {
        return user.FindFirst("user_agent")?.Value;
    }

    public static bool IsInRole(ClaimsPrincipal user, string role)
    {
        return user.IsInRole(role);
    }

    public static bool IsAdmin(ClaimsPrincipal user)
    {
        return user.IsInRole(ApplicationConstants.AdminRole);
    }

    public static bool IsModerator(ClaimsPrincipal user)
    {
        return user.IsInRole(ApplicationConstants.ModeratorRole);
    }

    public static bool IsCustomer(ClaimsPrincipal user)
    {
        return user.IsInRole(ApplicationConstants.CustomerRole);
    }
}
