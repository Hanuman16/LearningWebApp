namespace ECommerce.Shared.Constants;

/// <summary>
/// Application-wide constants for roles, policies, and configuration.
/// </summary>
public static class ApplicationConstants
{
    public const string AdminRole = "Admin";
    public const string CustomerRole = "Customer";
    public const string ModeratorRole = "Moderator";

    public const string AdminPolicy = "Admin";
    public const string ModeratorPolicy = "Moderator";
    public const string CustomerPolicy = "Customer";

    public const string DefaultConnectionStringName = "DefaultConnection";
    public const string RedisConnectionStringName = "Redis";
    public const string HangfireConnectionstringName = "HangfireConnection";

    public const int DefaultPageSize = 20;
    public const int MaxPageSize = 100;
    public const int DefaultPageSizeRange = 10;

    public const int MinPasswordLength = 8;
    public const int MaxPasswordLength = 128;
    public const int MaxEmailLength = 256;
    public const int MaxNameLength = 100;
    public const int MaxDescriptionLength = 2000;
    public const int MaxSlugLength = 200;
    public const int MaxSkuLength = 50;

    public const decimal MinPrice = 0m;
    public const decimal MaxPrice = 9999999.99m;
    public const int MinQuantity = 0;
    public const int MaxQuantity = 10000;

    public const int MinRating = 1;
    public const int MaxRating = 5;

    public const int RefreshTokenExpirationDays = 7;
    public const int JwtExpirationHours = 1;
    public const int JwtRefreshTokenExpirationDays = 7;

    public const string ApiVersionPrefix = "api/v{0:v}";
    public const string ApiRoutePrefix = "api";

    public const string DefaultCurrency = "USD";
    public const string DefaultTimeZone = "UTC";

    public const string AuditLogActionCreate = "CREATE";
    public const string AuditLogActionUpdate = "UPDATE";
    public const string AuditLogActionDelete = "DELETE";
    public const string AuditLogActionRead = "READ";

    public const string NotificationTypeInformation = "Information";
    public const string NotificationTypeWarning = "Warning";
    public const string NotificationTypeSuccess = "Success";
    public const string NotificationTypeError = "Error";

    public const string NotificationChannelEmail = "Email";
    public const string NotificationChannelInApp = "InApp";
    public const string NotificationChannelSms = "SMS";

    public const string OrderStatusPending = "Pending";
    public const string OrderStatusProcessing = "Processing";
    public const string OrderStatusShipped = "Shipped";
    public const string OrderStatusDelivered = "Delivered";
    public const string OrderStatusCancelled = "Cancelled";
    public const string OrderStatusRefunded = "Refunded";

    public const string PaymentStatusPending = "Pending";
    public const string PaymentStatusCompleted = "Completed";
    public const string PaymentStatusFailed = "Failed";
    public const string PaymentStatusRefunded = "Refunded";

    public const string CouponTypePercentage = "Percentage";
    public const string CouponTypeFixed = "Fixed";

    public const string OutboxMessageTypeOrderCreated = "OrderCreated";
    public const string OutboxMessageTypeOrderUpdated = "OrderUpdated";
    public const string OutboxMessageTypePaymentProcessed = "PaymentProcessed";

    public const string OutboxStatusPending = "Pending";
    public const string OutboxStatusProcessing = "Processing";
    public const string OutboxStatusCompleted = "Completed";
    public const string OutboxStatusFailed = "Failed";
}
