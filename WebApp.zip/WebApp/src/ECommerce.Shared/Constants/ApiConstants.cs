namespace ECommerce.Shared.Constants;

/// <summary>
/// API response status codes and messages.
/// </summary>
public static class ApiConstants
{
    public const string Success = "Success";
    public const string Created = "Created";
    public const string Updated = "Updated";
    public const string Deleted = "Deleted";
    public const string NotFound = "NotFound";
    public const string BadRequest = "BadRequest";
    public const string Unauthorized = "Unauthorized";
    public const string Forbidden = "Forbidden";
    public const string ValidationError = "ValidationError";
    public const string Conflict = "Conflict";
    public const string InternalServerError = "InternalServerError";

    public const string EmailSent = "Verification email sent successfully";
    public const string PasswordResetEmailSent = "Password reset email sent successfully";
    public const string PasswordResetSuccessful = "Password reset successful";
    public const string EmailVerified = "Email verified successfully";
    public const string RegistrationSuccessful = "Registration successful";
    public const string LoginSuccessful = "Login successful";
    public const string LogoutSuccessful = "Logout successful";
    public const string ProductCreated = "Product created successfully";
    public const string ProductUpdated = "Product updated successfully";
    public const string ProductDeleted = "Product deleted successfully";
    public const string OrderCreated = "Order created successfully";
    public const string OrderUpdated = "Order updated successfully";
    public const string OrderCancelled = "Order cancelled successfully";
}
