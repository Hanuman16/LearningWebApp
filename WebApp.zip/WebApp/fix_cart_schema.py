import sqlite3
import os

db_path = r'c:\Users\XPY1KOR\Desktop\WebApp\src\ECommerce.Api\ecommerce.db'

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Enable foreign keys
cursor.execute("PRAGMA foreign_keys = OFF")

# Check current schema
cursor.execute("PRAGMA table_info(Carts)")
columns = cursor.fetchall()
print("Current Carts table schema:")
for col in columns:
    print(f"  {col[1]}: nullable={'NO' if col[3] == 0 else 'YES'}")

# Get the current table creation SQL
cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='Carts'")
current_sql = cursor.fetchone()[0]
print(f"\nCurrent SQL:\n{current_sql}")

# Drop existing foreign key constraint by recreating the table
# First, get all existing data
cursor.execute("SELECT * FROM Carts")
existing_data = cursor.fetchall()
print(f"\nFound {len(existing_data)} existing cart rows")

# Get all indexes
cursor.execute("SELECT name, sql FROM sqlite_master WHERE type='index' AND tbl_name='Carts'")
indexes = cursor.fetchall()

# Drop the Carts_New table if it exists from a previous run
try:
    cursor.execute("DROP TABLE IF EXISTS Carts_New")
except Exception as e:
    print(f"Note: Carts_New table did not exist: {e}")

# Create a new table without the foreign key constraint
cursor.execute("""
    CREATE TABLE Carts_New (
        Id TEXT NOT NULL PRIMARY KEY,
        UserId TEXT,
        Status INTEGER NOT NULL DEFAULT 0,
        CouponCode TEXT,
        DiscountAmount REAL NOT NULL DEFAULT 0,
        TaxAmount REAL NOT NULL DEFAULT 0,
        ShippingAmount REAL NOT NULL DEFAULT 0,
        CreatedAt TEXT NOT NULL,
        UpdatedAt TEXT,
        IsDeleted INTEGER NOT NULL DEFAULT 0,
        RowVersion BLOB
    )
""")

# Copy data from old table to new table (set UserId to NULL for existing rows)
cursor.execute("""
    INSERT INTO Carts_New (Id, UserId, Status, CouponCode, DiscountAmount, TaxAmount, ShippingAmount, CreatedAt, UpdatedAt, IsDeleted, RowVersion)
    SELECT Id, NULL, Status, CouponCode, DiscountAmount, TaxAmount, ShippingAmount, CreatedAt, UpdatedAt, IsDeleted, RowVersion
    FROM Carts
""")

# Drop old table and rename new table
cursor.execute("DROP TABLE Carts")
cursor.execute("ALTER TABLE Carts_New RENAME TO Carts")

# Recreate indexes (but not the foreign key)
for index_name, index_sql in indexes:
    if index_sql and 'FK_Carts_Users_UserId' not in index_sql:
        try:
            cursor.execute(index_sql)
            print(f"Recreated index: {index_name}")
        except Exception as e:
            print(f"Warning: Could not recreate index {index_name}: {e}")

conn.commit()

# Verify the new schema
print("\nNew Carts table schema:")
cursor.execute("PRAGMA table_info(Carts)")
columns = cursor.fetchall()
for col in columns:
    print(f"  {col[1]}: nullable={'NO' if col[3] == 0 else 'YES'}")

# Check foreign keys
cursor.execute("PRAGMA foreign_key_list(Carts)")
fk = cursor.fetchall()
print(f"\nForeign keys: {fk if fk else 'None'}")

conn.close()
print("\nDatabase schema updated successfully!")
