# E-Commerce Development - Debugging Reference Guide

## How to Use This Guide

This document is organized as a **troubleshooting reference**, not just a post-mortem. When you encounter an error:

1. **Find your symptom** in the Quick Reference table below
2. **Follow the debugging decision tree** for that symptom
3. **Check the common patterns** section to avoid repeating mistakes

---

## Quick Reference: Symptom → Issue

| If you see... | Check this issue first | Likely cause |
|---|---|---|
| `405 Method Not Allowed` on anonymous requests | Issue #1 | `[Authorize]` blocking guests |
| `401 Unauthorized` when you expect success | Issue #1 | Missing/invalid JWT token |
| Build error: "duplicate record types" | Issue #2 | Local types conflicting with layer types |
| Build error: "Cannot convert string to Guid" | Issue #3 | Type mismatch between layers |
| Build error: "type not found" | Issue #4 | Missing DTO in Application layer |
| Build error: CS8618 "non-nullable must be non-null" | Issue #5 | Nullable reference type violation |
| Build error: "constructor takes 1 arguments" | Issue #6 | Wrong initialization pattern for CQRS commands |
| `NotFoundException` but data EXISTS in DB | Issue #7 | SQLite GUID comparison failure |
| `NOT NULL constraint failed` | Issue #8 | Database schema out of sync with entity |
| `FOREIGN KEY constraint failed` | Issue #9, #11 | Referential integrity or FK constraint issue |
| `DbUpdateConcurrencyException` | Issue #10 | Entity still tracked after SaveChanges |
| Navigation property is null but data exists | Issue #12 | Soft delete filter blocking Include |
| EF Core startup warning about query filters | Issue #13 | Missing matching filters on related entities |
| EF Core warning about sentinel value | Issue #14 | Enum with database default needs sentinel |

---

## Debugging Decision Trees

### Decision Tree 1: API Returns HTTP Error

```
API returned an error
│
├─ 401 Unauthorized
│  ├─ Is this an anonymous endpoint? → Remove [Authorize] or add [AllowAnonymous]
│  ├─ Is the token missing? → Check Authorization header format: "Bearer <token>"
│  └─ Is the token expired? → Refresh token or re-login
│
├─ 403 Forbidden
│  └─ User authenticated but lacks required role/permission
│
├─ 405 Method Not Allowed
│  ├─ Anonymous request? → [Authorize] at class level is blocking
│  ├─ Wrong HTTP method? → Controller expects GET but you sent POST
│  └─ Route mismatch? → Check route attributes
│
├─ 400 Bad Request
│  ├─ Invalid input? → Check FluentValidation errors in response
│  └─ Missing required fields? → Compare request body with DTO requirements
│
├─ 404 Not Found
│  ├─ Endpoint not found? → Check route prefix and action route
│  └─ Resource not found? → Check if ID exists in database
│
└─ 500 Internal Server Error
   ├─ Check server logs for exception type
   ├─ NotFoundException? → Resource doesn't exist (check database)
   ├─ SQLite error? → Check database schema and constraints
   ├─ EF Core error? → Check entity configuration and queries
   └─ NullReferenceException? → Navigation property not loaded
```

### Decision Tree 2: EF Core Query Returns Null When Data Exists

```
EF Core query returned null but data EXISTS in database
│
├─ Is the database SQLite?
│  ├─ YES → GUID comparison issue (Issue #7)
│  │   ├─ Symptom: FirstOrDefaultAsync(p => p.Id == someGuid) returns null
│  │   ├─ Fix: Use .ToString() comparison
│  │   └─ Test: Query directly with sqlite3 to confirm data exists
│  │
│  └─ NO → Continue checking
│
├─ Does the entity have a global query filter?
│  ├─ YES → Soft delete filter blocking results (Issue #12)
│  │   ├─ Symptom: Include/ThenInclude returns null navigation property
│  │   ├─ Fix: Use .IgnoreQueryFilters()
│  │   └─ Test: Remove filter temporarily to confirm
│  │
│  └─ NO → Continue checking
│
├─ Are you comparing Guid types?
│  ├─ YES → SQLite stores GUIDs as TEXT
│  │   ├─ Fix: p.Id.ToString() == otherId.ToString()
│  │   └─ Always use .ToLower() for case-insensitive comparison
│  │
│  └─ NO → Continue checking
│
└─ Is the entity tracked elsewhere in the context?
   ├─ YES → Detach first: _context.Entry(entity).State = EntityState.Detached
   └─ NO → Check connection string and database path
```

### Decision Tree 3: Database Constraint Errors

```
SQLite constraint error
│
├─ NOT NULL constraint failed: Table.Column
│  ├─ Symptom: C# entity has nullable property but DB requires value
│  ├─ Root cause: Entity changed but DB schema not updated
│  ├─ Why: EF Core migrations not applied, SQLite doesn't support ALTER COLUMN
│  └─ Fix: Recreate table with Python/SQLite script
│     └─ Steps: Drop table → Create new → Copy data → Rename
│
├─ FOREIGN KEY constraint failed
│  ├─ Symptom: Insert fails referencing another table
│  ├─ Check 1: Referenced record exists in parent table?
│  │   └─ NO → Save parent record first with SaveChangesAsync()
│  │
│  ├─ Check 2: GUID comparison in FK columns?
│  │   └─ YES → SQLite text comparison mismatch
│  │   └─ Fix: Ensure consistent .ToString().ToLower() format
│  │
│  └─ Check 3: FK constraints too strict for development?
│     └─ YES → Disable FK: PRAGMA foreign_keys = OFF
│     └─ Or: Recreate table without FK constraints
│
└─ UNIQUE constraint failed
   └─ Duplicate key being inserted
   └─ Check if record already exists before insert
```

### Decision Tree 4: Concurrency / Tracking Issues

```
DbUpdateConcurrencyException or unexpected updates
│
├─ Symptom: "affected an unexpected number of rows"
│
├─ Did you just call SaveChangesAsync()?
│  ├─ YES → Entity still tracked in change tracker
│  │   ├─ Fix: _context.Entry(entity).State = EntityState.Detached
│  │   └─ When: After creating/saving an entity, before related operations
│  │
│  └─ NO → Continue checking
│
├─ Does the entity have RowVersion/TimeStamp?
│  ├─ YES → Optimistic concurrency tracking
│  │   ├─ RowVersion changed after first SaveChanges
│  │   ├─ Second SaveChanges uses old RowVersion → conflict
│  │   └─ Fix: Detach entity after first SaveChanges
│  │
│  └─ NO → Continue checking
│
└─ Are multiple operations using same DbContext?
   ├─ YES → Each operation should detach entities it's done with
   └─ NO → Check for concurrent requests modifying same data
```

---

## Detailed Issue Reference

---

## Issue 1: API Returns 405 Method Not Allowed

### Symptom
Anonymous users get `405 Method Not Allowed` when calling an endpoint that should be public.

### Quick Diagnosis
```
Is the endpoint anonymous? → Check for [Authorize] at class level
Is the HTTP method correct? → Verify GET/POST/PUT/DELETE matches controller
Is the route correct? → Check [Route] attributes
```

### Root Cause
`[Authorize]` attribute at controller class level blocks ALL anonymous requests, including those that should be public (like guest cart operations).

### Debugging Steps

**Step 1: Check Browser Console for Exact HTTP Status**
- **Why**: 405 ≠ 401. 405 means "method not allowed", 401 means "unauthorized"
- **What to look for**: Network tab shows status code and response headers
- **Decision point**: 405 = middleware/routing issue, 401 = authentication issue

**Step 2: Check Controller-Level Attributes**
- **Why**: `[Authorize]` at class level applies to all actions
- **Command**: Search for `[Authorize]` at the top of the controller class
- **Decision point**: If found and you need anonymous access, remove it or add `[AllowAnonymous]` to specific actions

**Step 3: Test API Directly (Bypass Frontend)**
- **Why**: Isolates backend from frontend issues
- **Command**:
  ```powershell
  # Test with auth (should work)
  Invoke-RestMethod -Uri "http://localhost:5000/api/v1/cart" -Headers @{"Authorization"="Bearer <token>"}
  
  # Test without auth (will fail if [Authorize] present)
  Invoke-RestMethod -Uri "http://localhost:5000/api/v1/cart"
  ```
- **Decision point**: If auth works but anonymous fails → `[Authorize]` is the cause

### Solution
```csharp
// Before (blocks anonymous)
[Authorize]
public class CartController : ControllerBase { ... }

// After (allows anonymous)
public class CartController : ControllerBase { ... }
// Then handle auth vs guest logic inside actions
```

### How to Avoid This
- **Rule**: Never put `[Authorize]` at class level if you need public endpoints
- **Alternative**: Use `[Authorize]` at action level for specific protected endpoints
- **Pattern**: For mixed auth/public controllers, omit class-level `[Authorize]` and check `User.Identity.IsAuthenticated` inside actions

---

## Issue 2: Build Error - Duplicate Record Types

### Symptom
Build fails with errors about duplicate type definitions in the same namespace.

### Quick Diagnosis
```
Build error mentions "duplicate" or "conflicting" types?
├─ Check if type is defined locally in controller
├─ Check if type exists in Application layer
└─ If both exist → Remove local definition
```

### Root Cause
Local record types in the controller file have the same name and namespace as DTOs in the Application layer, causing compilation conflicts.

### Debugging Steps

**Step 1: Run `dotnet build` and Read Error Messages**
- **Why**: Build errors include exact file, line, and type name
- **What to look for**: "The type 'X' already exists" or "Cannot declare local type"
- **Decision point**: Note the exact type name and file location

**Step 2: Search for the Type Definition**
- **Command**: `Select-String -Path "*.cs" -Pattern "record TypeName"`
- **What to look for**: Multiple files defining the same type
- **Decision point**: If found in both controller and Application layer → conflict

**Step 3: Verify Application Layer Already Has the Type**
- **Why**: Clean Architecture requires DTOs in Application layer
- **What to look for**: Same properties, same name in `ECommerce.Application/DTOs/`
- **Decision point**: If Application layer has it → remove local definition

### Solution
```csharp
// Before (has local record - BAD)
public record AddCartItemRequest(string UserId, string ProductId, int Quantity);

// After (uses Application layer type)
using ECommerce.Application.Commands.Cart;
// Controller now uses the Application layer DTO automatically
```

### How to Avoid This
- **Rule**: Never define DTOs in the API layer
- **Pattern**: All request/response types belong in `ECommerce.Application/DTOs/`
- **Check**: Before creating a local type, search the Application layer first

---

## Issue 3: Build Error - Type Mismatch (string vs Guid)

### Symptom
Build fails with "Cannot convert from 'string' to 'Guid'" or similar type errors.

### Quick Diagnosis
```
Type mismatch error?
├─ Check the entity model → What type does the entity use?
├─ Check the command/DTO → Does it match the entity?
└─ Check the controller → Does it match the command/DTO?
```

### Root Cause
Local types used `string` for GUID values, but entities and commands use actual `Guid` type. This creates type mismatches when passing data between layers.

### Debugging Steps

**Step 1: Read the Build Error for Exact Type Mismatch**
- **Why**: Error says exactly which types don't match
- **What to look for**: "Cannot convert from 'X' to 'Y'"
- **Decision point**: Note which side has which type

**Step 2: Check Entity Model for Correct Type**
- **Why**: Entity is the source of truth for data types
- **Command**: Open `Core/Entities/` and find the relevant entity
- **What to look for**: Property type (e.g., `Guid UserId`)
- **Decision point**: All layers should match the entity type

**Step 3: Compare All Layers**
- **Why**: Find where the type diverges
- **Check**: Entity → DTO → Command → Controller → all should use same type
- **Decision point**: Fix the layer that doesn't match the entity

### Solution
```csharp
// Before (string for GUID - BAD)
record AddCartItemRequest(string UserId, string ProductId, int Quantity);

// After (Guid - CORRECT)
// Use Application layer DTO which has:
public Guid UserId { get; set; }
public Guid ProductId { get; set; }
```

### How to Avoid This
- **Rule**: Always use `Guid` type for database GUID columns
- **Never**: Store GUIDs as strings in DTOs or commands
- **Pattern**: Entity defines the type, all layers follow

---

## Issue 4: Build Error - Type Not Found

### Symptom
Build fails with "The type or namespace 'X' could not be found".

### Quick Diagnosis
```
Type not found?
├─ Is it in the correct namespace? → Add using statement
├─ Is it in the correct project? → Move type to proper layer
├─ Is the project reference correct? → Add project reference
└─ Does the type exist? → Create it
```

### Root Cause
Controller references DTOs that were never created in the Application layer.

### Debugging Steps

**Step 1: Check Build Output for Missing Type Names**
- **Why**: Build output lists exact missing type names
- **What to look for**: "Cannot find type X" with file and line number
- **Decision point**: Note all missing type names

**Step 2: Search Application Layer for Existing Types**
- **Command**: `Select-String -Path "ECommerce.Application/**/*.cs" -Pattern "class X"`
- **What to look for**: Similar types that might be the intended one
- **Decision point**: If similar type exists → use it, if not → create it

**Step 3: Review Controller Action to Determine Required Properties**
- **Why**: DTO needs exactly the properties the action uses
- **What to look for**: Properties accessed in the controller action
- **Decision point**: Create DTO with only required properties

### Solution
```csharp
// In ECommerce.Application/DTOs/CartDtos.cs
public class UpdateCartItemRequest
{
    public Guid CartItemId { get; set; }
    public int Quantity { get; set; }
}

public class ApplyCouponRequest
{
    public string Code { get; set; }
}
```

### How to Avoid This
- **Rule**: Define DTOs before implementing controller actions
- **Pattern**: Start with DTOs, then implement handlers, then controller
- **Check**: Before referencing a type, verify it exists in the Application layer

---

## Issue 5: Build Error - CS8618 Non-Nullable Property

### Symptom
Build warning/error: `CS8618: Non-nullable property 'X' must contain a non-null value at exit`.

### Quick Diagnosis
```
CS8618 error?
├─ Is the property supposed to be nullable? → Change to T?
├─ Is it initialized in constructor? → Add initialization
└─ Is it set by EF Core? → Make nullable or add [Required]
```

### Root Cause
C# nullable reference types detected that a property will be null after object construction, but the type is declared as non-nullable.

### Debugging Steps

**Step 1: Read the CS8618 Warning**
- **Why**: Warning specifies exact property and class
- **What to look for**: "Non-nullable property 'X' in class 'Y'"
- **Decision point**: Note which property needs to be nullable

**Step 2: Determine if Null is Valid**
- **Why**: Some properties should never be null, others naturally can be
- **Question**: Can this property legitimately be null?
  - Guest cart UserId → Yes, null is valid
  - Product Name → No, should never be null
- **Decision point**: If null is valid → make nullable, if not → initialize

**Step 3: Check How EF Core Sets the Property**
- **Why**: EF Core uses parameterless constructor then sets properties
- **What to look for**: Properties set by EF Core after construction
- **Decision point**: EF Core-set properties that can be null → make nullable

### Solution
```csharp
// Before (guest carts will fail)
public class Cart : BaseEntity
{
    public Guid UserId { get; set; }  // Non-nullable
    public virtual User User { get; set; }
}

// After (supports guest carts)
public class Cart : BaseEntity
{
    public Guid? UserId { get; set; }  // Nullable
    public virtual User? User { get; set; }  // Nullable navigation
}
```

### How to Avoid This
- **Rule**: Make navigation properties nullable (`virtual User?`)
- **Rule**: Make optional foreign keys nullable (`Guid?`)
- **Pattern**: If EF Core can set it after construction, and it can be null → use `T?`

---

## Issue 6: Build Error - Wrong Constructor Pattern

### Symptom
Build error: "Type does not contain a constructor that takes N arguments".

### Quick Diagnosis
```
Constructor error?
├─ Is it a record type? → Use positional initialization: new Type(value)
├─ Is it a class? → Use property initialization: new Type { Prop = value }
└─ Check the type definition to determine correct pattern
```

### Root Cause
CQRS commands are classes with parameterless constructors and public properties, not record types with positional constructors.

### Debugging Steps

**Step 1: Read the Build Error**
- **Why**: Error specifies exact type and expected argument count
- **What to look for**: "does not contain a constructor that takes 1 arguments"
- **Decision point**: Note the type name

**Step 2: Examine the Type Definition**
- **Why**: Determines if it's a record (positional) or class (property)
- **What to look for**:
  - `record Type(...)` → Positional constructor
  - `class Type { public T Prop { get; set; } }` → Property initialization
- **Decision point**: Class = property initialization, Record = positional

**Step 3: Check Other Similar Types in the Project**
- **Why**: Ensure consistency with project patterns
- **What to look for**: How other commands/DTOs are initialized
- **Decision point**: Follow existing project patterns

### Solution
```csharp
// Before (wrong - record style for class)
new RemoveCartItemCommand(cartItemId)

// After (correct - property initialization for class)
new RemoveCartItemCommand { CartItemId = cartItemId }
```

### How to Avoid This
- **Rule**: CQRS commands are classes → use property initialization
- **Rule**: Records use positional syntax → `new Record(value1, value2)`
- **Check**: Look at the type definition before initializing

---

## Issue 7: EF Core Returns Null When Data Exists (SQLite GUID Issue)

### Symptom
`NotFoundException` or `FirstOrDefaultAsync` returns null, but you verified the data exists in the database using a direct query.

### Quick Diagnosis
```
EF Core returns null but data EXISTS?
├─ Is database SQLite? → GUID comparison issue
├─ Does entity have soft delete filter? → IgnoreQueryFilters
└─ Are you comparing Guid types? → Use ToString()
```

### Root Cause
SQLite stores GUIDs as TEXT. EF Core's Guid comparison doesn't work reliably because SQLite's type affinity causes mismatched comparison behavior.

### Debugging Steps

**Step 1: Check Server Logs for the Exact ID Being Searched**
- **Why**: Confirms which ID EF Core is looking for
- **What to look for**: Exception message with the ID
- **Decision point**: Note the exact GUID string

**Step 2: Verify Data Exists Using Direct SQLite Query**
- **Why**: Confirms the issue is with EF Core, not missing data
- **Command**:
  ```python
  import sqlite3
  conn = sqlite3.connect('ecommerce.db')
  cursor = conn.cursor()
  cursor.execute("SELECT * FROM Products WHERE Id = '0ddd6e8d-0716-4bd3-8007-08afe34c4856'")
  print(cursor.fetchone())
  ```
- **Decision point**: If data exists → EF Core query issue, not data issue

**Step 3: Examine the EF Core Query**
- **Why**: Identifies the comparison method being used
- **What to look for**: `p.Id == someGuid` (direct Guid comparison)
- **Decision point**: Direct Guid comparison in SQLite → likely the issue

**Step 4: Research SQLite GUID Behavior**
- **Why**: Understand why the comparison fails
- **Fact**: SQLite has no native GUID type, stores as TEXT
- **Fact**: EF Core sends Guid as binary, SQLite compares as text
- **Decision point**: Need string-based comparison

**Step 5: Test String-Based Comparison**
- **Why**: Validates the hypothesis
- **Change**: `p.Id.ToString() == otherId.ToString()`
- **Decision point**: If this works → confirmed GUID comparison issue

### Solution
```csharp
// Before (fails in SQLite)
var product = await _context.Products
    .FirstOrDefaultAsync(p => p.Id == request.ProductId);

// After (works in SQLite)
var product = await _context.Products
    .IgnoreQueryFilters()
    .FirstOrDefaultAsync(p => p.Id.ToString() == request.ProductId.ToString());
```

### How to Avoid This
- **Rule**: In SQLite, always compare GUIDs as strings: `.ToString().ToLower()`
- **Rule**: Use `.ToLower()` for case-insensitive comparison
- **Pattern**: `p.Id.ToString().ToLower() == otherId.ToString().ToLower()`
- **Note**: This is a SQLite-specific issue, not present in SQL Server/PostgreSQL

### When You See This Again
1. Check if database is SQLite
2. Verify data exists with direct query
3. Change GUID comparison to `.ToString()`
4. Add `.IgnoreQueryFilters()` if soft delete filter is present

---

## Issue 8: NOT NULL Constraint Failed

### Symptom
SQLite error: `NOT NULL constraint failed: TableName.ColumnName`.

### Quick Diagnosis
```
NOT NULL constraint failed?
├─ Check C# entity → Is property nullable?
├─ Check database schema → Is column NOT NULL?
└─ If mismatch → Schema out of sync
```

### Root Cause
C# entity property was changed to nullable (`Guid?`) but the SQLite database schema still has the NOT NULL constraint. SQLite doesn't support ALTER COLUMN to change nullability.

### Debugging Steps

**Step 1: Check Server Logs for Exact Error**
- **Why**: SQLite error specifies exact table and column
- **What to look for**: `NOT NULL constraint failed: Carts.UserId`
- **Decision point**: Note table and column name

**Step 2: Check C# Entity Definition**
- **Why**: Compare C# type with database type
- **What to look for**: `public Guid? UserId` (nullable in code)
- **Decision point**: If C# is nullable but DB isn't → schema out of sync

**Step 3: Check Database Schema Directly**
- **Why**: See actual column definition in SQLite
- **Command**:
  ```python
  import sqlite3
  conn = sqlite3.connect('ecommerce.db')
  cursor = conn.cursor()
  cursor.execute("PRAGMA table_info(TableName)")
  for col in cursor.fetchall():
      print(col)
  ```
- **What to look for**: `NOT NULL` in the third column of output
- **Decision point**: If DB has NOT NULL but C# is nullable → need schema fix

**Step 4: Understand SQLite Limitations**
- **Why**: SQLite only supports `RENAME TABLE` and `ADD COLUMN` in ALTER TABLE
- **Fact**: Cannot change column type or nullability directly
- **Decision point**: Must recreate the entire table

### Solution
```python
import sqlite3

conn = sqlite3.connect('ecommerce.db')
cursor = conn.cursor()

# 1. Disable foreign keys temporarily
cursor.execute("PRAGMA foreign_keys = OFF")

# 2. Get existing data
cursor.execute("SELECT * FROM Carts")
data = cursor.fetchall()

# 3. Drop old table
cursor.execute("DROP TABLE Carts")

# 4. Create new table with correct schema
cursor.execute("""
    CREATE TABLE Carts (
        Id TEXT NOT NULL PRIMARY KEY,
        UserId TEXT,  -- Nullable (no NOT NULL)
        Status TEXT NOT NULL
    )
""")

# 5. Copy data back
for row in data:
    cursor.execute("INSERT INTO Carts VALUES (?, ?, ?)", row)

# 6. Re-enable foreign keys
cursor.execute("PRAGMA foreign_keys = ON")

conn.commit()
conn.close()
```

### How to Avoid This
- **Rule**: Always run `dotnet ef database update` after entity changes
- **Rule**: For SQLite, be aware of ALTER TABLE limitations
- **Pattern**: If schema changes don't apply, use manual script
- **Better**: Use SQL Server or PostgreSQL for development to avoid SQLite limitations

### When You See This Again
1. Check C# entity → Is it nullable?
2. Check DB schema → PRAGMA table_info
3. If mismatch → Recreate table with Python script
4. Always disable FK constraints during schema changes

---

## Issue 9: FOREIGN KEY Constraint Failed (Parent Not Saved)

### Symptom
SQLite error: `FOREIGN KEY constraint failed` when inserting a child record.

### Quick Diagnosis
```
FOREIGN KEY failed?
├─ Does the parent record exist? → Save parent first
├─ Is the ID format consistent? → Use .ToString().ToLower()
└─ Are FK constraints too strict? → Disable or remove
```

### Root Cause
Child record references a parent record that hasn't been saved to the database yet. SQLite validates foreign keys immediately during insert.

### Debugging Steps

**Step 1: Check Server Logs**
- **Why**: Confirms which foreign key failed
- **What to look for**: `FOREIGN KEY constraint failed`
- **Decision point**: Note which table has the constraint

**Step 2: Trace the Insert Sequence**
- **Why**: Identify if parent is saved before child
- **Check**: Code flow: Create parent → Add to context → Create child → Add to context → SaveChanges
- **Decision point**: If parent not saved before child → that's the issue

**Step 3: Verify EF Core Behavior**
- **Why**: EF Core tracks entities in memory but DB validates at insert time
- **Fact**: SQLite validates FK immediately after each INSERT
- **Decision point**: Need to save parent before inserting child

### Solution
```csharp
// Before (fails)
var cart = new Cart { Id = request.CartId, UserId = null };
_context.Carts.Add(cart);

var item = new CartItem { CartId = cart.Id, ... };
_context.CartItems.Add(item);

await _context.SaveChangesAsync();  // FK fails: cart not in DB yet

// After (works)
var cart = new Cart { Id = request.CartId, UserId = null };
_context.Carts.Add(cart);
await _context.SaveChangesAsync();  // Cart now in DB

var item = new CartItem { CartId = cart.Id, ... };
_context.CartItems.Add(item);
await _context.SaveChangesAsync();  // Success: cart exists
```

### How to Avoid This
- **Rule**: Save parent entity before adding children that reference it
- **Pattern**: `Add(parent) → SaveChanges() → Add(child) → SaveChanges()`
- **Alternative**: Use transactions for atomic operations

### When You See This Again
1. Check insert sequence → Parent before child?
2. If not → Add SaveChanges between parent and child
3. If still failing → Check ID format consistency

---

## Issue 10: DbUpdateConcurrencyException

### Symptom
`DbUpdateConcurrencyException: Store update, insert, or delete statement affected an unexpected number of rows`.

### Quick Diagnosis
```
Concurrency exception?
├─ Did you just call SaveChangesAsync()? → Entity still tracked
├─ Does entity have RowVersion? → Optimistic concurrency
└─ Fix: Detach entity after SaveChanges
```

### Root Cause
After `SaveChangesAsync()`, the entity is still tracked by the DbContext. When subsequent operations modify the context, EF Core tries to update the already-saved entity with stale data (old RowVersion), causing a concurrency conflict.

### Debugging Steps

**Step 1: Read the Exception Message**
- **Why**: Confirms it's a concurrency issue
- **What to look for**: `DbUpdateConcurrencyException`
- **Decision point**: Concurrency = entity tracking issue

**Step 2: Check Entity State After SaveChanges**
- **Why**: Entity might still be in `Added` or `Modified` state
- **Code**: `_context.Entry(entity).State`
- **Decision point**: If state is not `Detached` → EF Core will try to update again

**Step 3: Check for RowVersion Property**
- **Why**: RowVersion is used for optimistic concurrency
- **What to look for**: `[Timestamp]` or `byte[] RowVersion` property
- **Decision point**: RowVersion changed after first SaveChanges → second SaveChanges uses old value

**Step 4: Verify Entity is Still Tracked**
- **Why**: Confirms the root cause
- **Code**: `_context.Entry(entity).State` should be `Detached` after save
- **Decision point**: If not detached → that's the cause

### Solution
```csharp
// Before (fails on second SaveChanges)
_context.Carts.Add(cart);
await _context.SaveChangesAsync();  // Cart saved, but still tracked

var item = new CartItem { CartId = cart.Id };
_context.CartItems.Add(item);
await _context.SaveChangesAsync();  // Fails: EF tries to update cart again

// After (works)
_context.Carts.Add(cart);
await _context.SaveChangesAsync();
_context.Entry(cart).State = EntityState.Detached;  // Prevent re-update

var item = new CartItem { CartId = cart.Id };
_context.CartItems.Add(item);
await _context.SaveChangesAsync();  // Success
```

### How to Avoid This
- **Rule**: Detach entities after `SaveChangesAsync()` when done with them
- **Pattern**: `_context.Entry(entity).State = EntityState.Detached`
- **When**: After creating/saving an entity, before related operations in same context

### When You See This Again
1. Check if you called SaveChanges recently
2. Check if entity is still tracked
3. Add Detached state after SaveChanges
4. Verify RowVersion property behavior

---

## Issue 11: FOREIGN KEY Constraint Failed (FK Constraints Too Strict)

### Symptom
`FOREIGN KEY constraint failed` even after saving parent record first.

### Quick Diagnosis
```
FK failed after parent saved?
├─ Is GUID format consistent? → .ToString().ToLower()
├─ Are FK constraints enabled? → PRAGMA foreign_keys
└─ Still failing? → Recreate table without FK
```

### Root Cause
SQLite foreign key constraints combined with GUID text comparison issues cause validation failures even when the referenced record exists.

### Debugging Steps

**Step 1: Confirm Parent Record Exists**
- **Why**: Rule out missing parent
- **Command**: Direct SQLite query for parent record
- **Decision point**: If parent exists → FK constraint issue, not missing data

**Step 2: Check FK Constraints on Table**
- **Why**: See what constraints exist
- **Command**:
  ```python
  cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='CartItems'")
  print(cursor.fetchone()[0])
  ```
- **What to look for**: `FOREIGN KEY (...) REFERENCES ...`
- **Decision point**: FK constraints exist → they're causing the issue

**Step 3: Test with FK Constraints Disabled**
- **Why**: Confirm FK constraints are the blocker
- **Command**: `PRAGMA foreign_keys = OFF` before operations
- **Decision point**: If works with FK off → FK constraints are the issue

**Step 4: Evaluate Options**
- **Options**:
  1. Fix GUID format in FK columns (complex)
  2. Remove FK constraints (loses referential integrity)
  3. Use migrations with proper schema (requires DB reset)
- **Decision point**: For development → remove FK, for production → fix properly

### Solution
```python
import sqlite3

conn = sqlite3.connect('ecommerce.db')
cursor = conn.cursor()

# Disable FK
cursor.execute("PRAGMA foreign_keys = OFF")

# Get existing data
cursor.execute("SELECT * FROM CartItems")
data = cursor.fetchall()

# Drop and recreate without FK
cursor.execute("DROP TABLE CartItems")
cursor.execute("""
    CREATE TABLE CartItems (
        Id TEXT NOT NULL PRIMARY KEY,
        CartId TEXT NOT NULL,
        ProductId TEXT NOT NULL,
        Quantity INTEGER NOT NULL DEFAULT 0,
        UnitPrice REAL NOT NULL DEFAULT 0,
        -- No foreign key constraints
    )
""")

# Copy data
for row in data:
    cursor.execute("INSERT INTO CartItems VALUES (?, ?, ?, ?, ?)", row)

conn.commit()
conn.close()
```

### How to Avoid This
- **Rule**: For development/prototyping, FK constraints can be disabled
- **Rule**: For production, use SQL Server/PostgreSQL with proper GUID support
- **Pattern**: If SQLite FK issues persist, recreate table without FK

### When You See This Again
1. Confirm parent exists
2. Check FK constraints exist
3. Test with PRAGMA foreign_keys = OFF
4. If confirmed → recreate table without FK (dev) or fix GUID format (prod)

---

## Issue 12: Navigation Property is Null (Soft Delete Filter)

### Symptom
Cart items load correctly but `Product` navigation property is null, resulting in `productName` showing as "Unknown" or null.

### Quick Diagnosis
```
Navigation property null?
├─ Using .Include()? → Soft delete filter may interfere
├─ Entity has HasQueryFilter? → Use .IgnoreQueryFilters()
└─ Still null? → Load navigation property manually
```

### Root Cause
EF Core's soft delete filter (`HasQueryFilter(p => !p.IsDeleted)`) is automatically applied to `.Include()` navigation property loads. This can cause navigation properties to be null even when the related entity exists and isn't deleted.

### Debugging Steps

**Step 1: Check API Response for Missing Fields**
- **Why**: Identify which fields are null
- **What to look for**: `productName: "Unknown"` or `product: null`
- **Decision point**: Navigation property is null → loading issue

**Step 2: Check AutoMapper Configuration**
- **Why**: Understand how the field is mapped
- **What to look for**: `ci.Product.Name` mapped to `ProductName`
- **Decision point**: If `Product` is null → AutoMapper can't map → navigation not loaded

**Step 3: Examine the Query**
- **Why**: See how navigation property is loaded
- **What to look for**: `.Include(ci => ci.Product)` or `.ThenInclude()`
- **Decision point**: Using Include → filter may be interfering

**Step 4: Check for Global Query Filters**
- **Why**: Filters are automatically applied to Include
- **What to look for**: `HasQueryFilter(p => !p.IsDeleted)` in DbContext
- **Decision point**: Filter exists → likely causing the issue

**Step 5: Test with IgnoreQueryFilters**
- **Why**: Confirm filter is the cause
- **Change**: `.IgnoreQueryFilters().Include(ci => ci.Product)`
- **Decision point**: If still null → Include + Filter interaction issue

**Step 6: Implement Manual Loading**
- **Why**: Bypass EF Core navigation property loading entirely
- **Approach**: Load entities separately, join in memory
- **Decision point**: Manual loading works → confirmed EF Core Include issue

### Solution
```csharp
// Before (Include may fail with soft delete filter)
var cartItems = await _context.CartItems
    .Include(ci => ci.Product)
    .ToListAsync();

// After (manual loading - reliable)
var cartItems = await _context.CartItems
    .IgnoreQueryFilters()
    .ToListAsync();

var allProducts = await _context.Products
    .IgnoreQueryFilters()
    .ToListAsync();

var products = allProducts
    .Where(p => cartItems.Select(ci => ci.ProductId)
                         .Select(id => id.ToString().ToLower())
                         .Contains(p.Id.ToString().ToLower()))
    .ToDictionary(p => p.Id.ToString().ToLower(), p => p);

var dto = new CartItemDto {
    ProductName = products[ci.ProductId.ToString().ToLower()]?.Name ?? "Unknown"
};
```

### How to Avoid This
- **Rule**: When using soft delete filters, prefer manual loading over Include
- **Pattern**: Load parent → Load children with `.IgnoreQueryFilters()` → Join in memory
- **Alternative**: Add matching filters to all related entities (complex)

### When You See This Again
1. Check if navigation property is null
2. Check for soft delete filter on related entity
3. Try `.IgnoreQueryFilters()`
4. If still failing → Manual loading pattern

---

## Issue 13: EF Core Warning - Global Query Filter on Required Relationship

### Symptom
Startup warning: `Entity 'Product' has a global query filter defined and is the required end of a relationship with the entity 'CartItem'. This may lead to unexpected results.`

### Quick Diagnosis
```
Query filter warning?
├─ Does entity have HasQueryFilter? → Yes, soft delete
├─ Are there required navigations to this entity? → Yes
└─ Warning → Design issue, not runtime error
```

### Root Cause
When an entity has a soft delete filter and other entities have required navigation properties to it, EF Core warns that deleted products will orphan related records from a query perspective.

### Debugging Steps

**Step 1: Read the Warning**
- **Why**: Identifies which entities are affected
- **What to look for**: Entity names in the warning message
- **Decision point**: Note all affected entity pairs

**Step 2: Analyze Impact**
- **Why**: Determine if this causes runtime issues
- **Analysis**: Warnings don't cause errors but indicate potential data consistency issues
- **Decision point**: For development → ignore, for production → fix

**Step 3: Evaluate Fix Options**
- **Options**:
  1. Add matching filters to related entities
  2. Make navigation properties optional
  3. Use `.IgnoreQueryFilters()` when loading
- **Decision point**: Choose based on business requirements

### Solution (Current Workaround)
```csharp
// Use .IgnoreQueryFilters() when loading related data
var cartItems = await _context.CartItems
    .Include(ci => ci.Product)
    .IgnoreQueryFilters()
    .ToListAsync();
```

### Solution (Recommended Future Fix)
```csharp
// In ECommerceDbContext.OnModelCreating
modelBuilder.Entity<CartItem>()
    .HasQueryFilter(ci => !ci.Product.IsDeleted);

modelBuilder.Entity<OrderItem>()
    .HasQueryFilter(oi => !oi.Product.IsDeleted);
```

### How to Avoid This
- **Rule**: When adding soft delete filter, update all related entity filters
- **Pattern**: Matching filters on both sides of relationship
- **Alternative**: Make navigation properties optional

### When You See This Again
1. Read warning to identify affected entities
2. Determine if it causes runtime issues
3. For production → add matching filters
4. For development → use `.IgnoreQueryFilters()`

---

## Issue 14: EF Core Warning - Sentinel Value for Enum with Database Default

### Symptom
Startup warning: `The 'PaymentStatus' property is configured with a database-generated default, but has no configured sentinel value.`

### Quick Diagnosis
```
Sentinel value warning?
├─ Enum property with database default? → Yes
├─ EF Core can't distinguish CLR default from explicit value? → Yes
└─ Fix: Configure HasSentinel()
```

### Root Cause
Enum properties have CLR default value of 0. When the database also has a default of 0, EF Core can't tell if you explicitly set it to 0 or want the database default.

### Debugging Steps

**Step 1: Read the Warning**
- **Why**: Identifies which properties need sentinel values
- **What to look for**: Property name and entity type
- **Decision point**: Note affected properties

**Step 2: Check Entity Configuration**
- **Why**: See if defaults are configured
- **What to look for**: Property configuration in `OnModelCreating`
- **Decision point**: No sentinel configured → that's the issue

**Step 3: Determine Appropriate Default Value**
- **Why**: Sentinel should be the intended default
- **Question**: What value means "use database default"?
- **Decision point**: Choose appropriate enum value as sentinel

### Solution (Recommended)
```csharp
// In ECommerceDbContext.OnModelCreating
modelBuilder.Entity<Order>()
    .Property(o => o.PaymentStatus)
    .HasSentinel(OrderStatus.Pending);  // 0 means "use database default"

modelBuilder.Entity<Order>()
    .Property(o => o.Status)
    .HasSentinel(OrderStatus.Pending);
```

### How to Avoid This
- **Rule**: Configure sentinel values for enum properties with database defaults
- **Pattern**: `Property(e => e.EnumProp).HasSentinel(DefaultEnumValue)`
- **When**: Any enum property has `.HasDefaultValue()` or database default

### When You See This Again
1. Read warning to identify property
2. Determine appropriate default enum value
3. Add `.HasSentinel()` configuration
4. Rebuild to verify warning is gone

---

## Common Debugging Patterns

### Pattern 1: Isolate the Layer
When an error occurs, determine which layer is failing:
```
Frontend error? → Check browser console, network tab
API error? → Check server logs, test with PowerShell/curl
Database error? → Check SQLite directly with Python
Entity error? → Check C# entity definition
```

### Pattern 2: Verify Data Exists
Before assuming EF Core is broken:
```python
import sqlite3
conn = sqlite3.connect('ecommerce.db')
cursor = conn.cursor()
cursor.execute("SELECT * FROM TableName WHERE Id = 'your-id'")
print(cursor.fetchone())  # If this returns data, EF Core is the issue
```

### Pattern 3: Check SQLite Schema
When database errors occur:
```python
import sqlite3
conn = sqlite3.connect('ecommerce.db')
cursor = conn.cursor()

# Check table structure
cursor.execute("PRAGMA table_info(TableName)")
for col in cursor.fetchall():
    print(col)

# Check all tables
cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
print(cursor.fetchall())

# Check SQL to create table
cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='TableName'")
print(cursor.fetchone()[0])
```

### Pattern 4: GUID Comparison in SQLite
```csharp
// ALWAYS use this pattern for GUID comparison in SQLite
p.Id.ToString().ToLower() == otherId.ToString().ToLower()

// NEVER use direct Guid comparison
// p.Id == otherId  // May fail in SQLite
```

### Pattern 5: Entity State Management
```csharp
// After SaveChanges, if done with entity → detach it
await _context.SaveChangesAsync();
_context.Entry(entity).State = EntityState.Detached;

// Check entity state
var state = _context.Entry(entity).State;
// Added, Modified, Deleted, Unchanged, Detached
```

### Pattern 6: Bypass Soft Delete Filter
```csharp
// When you need deleted entities or Include is failing
var entities = await _context.Entities
    .IgnoreQueryFilters()
    .ToListAsync();

// For navigation properties
var parent = await _context.Parents
    .Include(p => p.Children)
    .IgnoreQueryFilters()
    .FirstOrDefaultAsync();
```

---

## Checklist: When API Returns 500 Error

- [ ] Check server logs for exception type and message
- [ ] Check if it's a database error (SQLite error message)
- [ ] Check if it's an EF Core error (EntityFrameworkCore exception)
- [ ] Check if it's a business logic error (NotFoundException, ValidationException)
- [ ] Verify data exists in database using direct query
- [ ] Check entity configuration (filters, constraints, relationships)
- [ ] Check GUID comparison (use `.ToString().ToLower()` in SQLite)
- [ ] Check foreign key constraints (parent saved? FK enabled?)
- [ ] Check entity tracking (detach after SaveChanges?)
- [ ] Check navigation property loading (soft delete filter?)

---

## Checklist: When Build Fails

- [ ] Run `dotnet build` and read all error messages
- [ ] Check for duplicate type definitions (local vs layer)
- [ ] Check type mismatches (string vs Guid, nullable vs non-nullable)
- [ ] Check missing types (DTOs in correct layer?)
- [ ] Check constructor patterns (record vs class)
- [ ] Check namespace imports (using statements)
- [ ] Check project references (can API see Application layer?)

---

## Checklist: When EF Core Query Returns Unexpected Results

- [ ] Verify data exists with direct database query
- [ ] Check for global query filters on entities
- [ ] Check GUID comparison (SQLite needs `.ToString()`)
- [ ] Check if `.Include()` is being blocked by filters
- [ ] Check entity state (is it tracked elsewhere?)
- [ ] Check if `.IgnoreQueryFilters()` is needed
- [ ] Check if manual loading pattern is required

---

## Tools & Commands Reference

### PowerShell API Testing
```powershell
# Test endpoint with auth
$token = "your-jwt-token"
Invoke-RestMethod -Uri "http://localhost:5000/api/v1/endpoint" -Headers @{"Authorization"="Bearer $token"}

# Test endpoint without auth (guest)
$guestCartId = [Guid]::NewGuid().ToString()
Invoke-RestMethod -Uri "http://localhost:5000/api/v1/cart" -Method POST -Body '{"productId":"xxx","quantity":1}' -ContentType "application/json" -Headers @{"Cookie"="guest_cart_id=$guestCartId"}

# Test with verbose output
Invoke-RestMethod -Uri "http://localhost:5000/api/v1/endpoint" -Verbose
```

### SQLite Database Inspection
```python
import sqlite3

conn = sqlite3.connect('ecommerce.db')
cursor = conn.cursor()

# List all tables
cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
print("Tables:", cursor.fetchall())

# Check table schema
cursor.execute("PRAGMA table_info(TableName)")
for col in cursor.fetchall():
    print(f"Column: {col[1]}, Type: {col[2]}, NotNull: {col[3]}, Default: {col[4]}")

# Query data
cursor.execute("SELECT * FROM TableName WHERE Id = 'your-id'")
print("Data:", cursor.fetchall())

# Check table creation SQL
cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='TableName'")
print("Schema:", cursor.fetchone()[0])

# Enable/disable foreign keys
cursor.execute("PRAGMA foreign_keys = ON")   # Enable
cursor.execute("PRAGMA foreign_keys = OFF")  # Disable

conn.close()
```

### Common EF Core Debugging
```csharp
// Check entity state
var state = _context.Entry(entity).State;

// Check tracked entities
var tracked = _context.ChangeTracker.Entries().ToList();

// Ignore soft delete filter
var entities = await _context.Entities.IgnoreQueryFilters().ToListAsync();

// No tracking (read-only)
var entities = await _context.Entities.AsNoTracking().ToListAsync();

// Raw SQL query (bypass EF Core)
var entities = await _context.Entities.FromSqlRaw("SELECT * FROM Products WHERE Id = {0}", id).ToListAsync();
```

---

## Lessons Learned

1. **SQLite is not SQL Server** - GUID handling, ALTER TABLE limitations, and type affinity differ significantly
2. **EF Core migrations don't auto-apply** - Always run `dotnet ef database update` after entity changes
3. **Soft delete filters affect Include** - Navigation properties may be null even when data exists
4. **Entity tracking causes concurrency issues** - Detach entities after SaveChanges when done with them
5. **Build errors are your friend** - They tell you exactly what's wrong and where
6. **Server logs are essential** - Always check logs before assuming the code is wrong
7. **Test API directly** - Bypass frontend to isolate backend issues
8. **Verify data exists** - Use direct database queries before blaming EF Core
9. **Clean Architecture means layer discipline** - DTOs in Application, not in API
10. **CQRS commands are classes** - Use property initialization, not constructor parameters

---

## Quick Fix Cheat Sheet

| Problem | Quick Fix |
|---|---|
| 405 on anonymous requests | Remove `[Authorize]` from controller |
| GUID comparison fails in SQLite | Use `.ToString().ToLower()` |
| NOT NULL constraint error | Recreate table with nullable column |
| FOREIGN KEY constraint error | Save parent first, or disable FK |
| Concurrency exception | Detach entity after SaveChanges |
| Navigation property null | Use `.IgnoreQueryFilters()` or manual loading |
| Build: duplicate types | Remove local type definitions |
| Build: type not found | Add using statement or create DTO |
| Build: type mismatch | Match entity type across all layers |
| Build: constructor error | Use property initialization for classes |
