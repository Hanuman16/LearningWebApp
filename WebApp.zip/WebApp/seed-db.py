import sqlite3
import uuid
from datetime import datetime

db_path = r'c:\Users\XPY1KOR\Desktop\WebApp\src\ECommerce.Api\ecommerce.db'
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Check existing tables
cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = [row[0] for row in cursor.fetchall()]
print(f"Tables found: {tables}")

# Create categories if table exists
if 'Categories' in tables:
    # Clear existing categories
    cursor.execute("DELETE FROM Categories")
    conn.commit()
    
    categories = [
        (str(uuid.uuid4()), 'Electronics', 'Electronic devices and gadgets', 'electronics', None, None, 1, 1, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'Clothing', 'Fashion and apparel', 'clothing', None, None, 1, 1, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'Home & Garden', 'Home improvement and garden supplies', 'home-garden', None, None, 1, 1, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'Books', 'Books and literature', 'books', None, None, 1, 1, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'Sports', 'Sports equipment and accessories', 'sports', None, None, 1, 1, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'Toys', 'Toys and games', 'toys', None, None, 1, 1, datetime.now(), None, 0, None),
    ]
    
    cursor.executemany(
        "INSERT INTO Categories (Id, Name, Description, Slug, ImageUrl, ParentCategoryId, DisplayOrder, IsActive, CreatedAt, UpdatedAt, IsDeleted, RowVersion) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        categories
    )
    conn.commit()
    print(f"Created {len(categories)} categories")
else:
    print("Categories table not found")

# Create products if table exists
if 'Products' in tables:
    # Get category IDs
    cursor.execute("SELECT Id, Slug FROM Categories")
    category_map = {row[1]: row[0] for row in cursor.fetchall()}
    print(f"Category map: {category_map}")
    
    products = [
        (str(uuid.uuid4()), 'Wireless Headphones', 'Premium noise-cancelling wireless headphones', 'wireless-headphones', 79.99, 99.99, 150, 10, category_map.get('electronics'), 'WH-001', None, None, 1, 1, 0, 0, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'Smart Watch', 'Fitness tracking smartwatch with heart rate monitor', 'smart-watch', 199.99, 249.99, 75, 10, category_map.get('electronics'), 'SW-001', None, None, 1, 1, 0, 0, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'Cotton T-Shirt', 'Comfortable cotton t-shirt available in multiple colors', 'cotton-t-shirt', 24.99, 34.99, 300, 10, category_map.get('clothing'), 'TS-001', None, None, 1, 1, 0, 0, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'Running Shoes', 'Lightweight running shoes with advanced cushioning', 'running-shoes', 89.99, 119.99, 120, 10, category_map.get('clothing'), 'RS-001', None, None, 1, 1, 0, 0, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'Garden Tool Set', 'Complete 10-piece garden tool set', 'garden-tool-set', 49.99, 69.99, 200, 10, category_map.get('home-garden'), 'GT-001', None, None, 1, 1, 0, 0, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'LED Desk Lamp', 'Adjustable LED desk lamp with USB charging port', 'led-desk-lamp', 34.99, 44.99, 180, 10, category_map.get('home-garden'), 'DL-001', None, None, 1, 1, 0, 0, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'Python Programming Book', 'Learn Python programming from scratch', 'python-programming-book', 39.99, 49.99, 250, 10, category_map.get('books'), 'PB-001', None, None, 1, 1, 0, 0, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'Data Science Handbook', 'Comprehensive guide to data science', 'data-science-handbook', 54.99, 69.99, 160, 10, category_map.get('books'), 'DS-001', None, None, 1, 1, 0, 0, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'Yoga Mat', 'Non-slip exercise yoga mat', 'yoga-mat', 29.99, 39.99, 220, 10, category_map.get('sports'), 'YM-001', None, None, 1, 1, 0, 0, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'Basketball', 'Official size basketball', 'basketball', 29.99, 39.99, 180, 10, category_map.get('sports'), 'BB-001', None, None, 1, 1, 0, 0, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'Building Blocks Set', 'Creative building blocks set with 500 pieces', 'building-blocks-set', 44.99, 59.99, 140, 10, category_map.get('toys'), 'BBK-001', None, None, 1, 1, 0, 0, datetime.now(), None, 0, None),
        (str(uuid.uuid4()), 'Board Game', 'Classic family board game for 2-6 players', 'board-game', 34.99, 44.99, 190, 10, category_map.get('toys'), 'BG-001', None, None, 1, 1, 0, 0, datetime.now(), None, 0, None),
    ]
    
    cursor.executemany(
        "INSERT INTO Products (Id, Name, Description, Slug, Price, CompareAtPrice, StockQuantity, LowStockThreshold, CategoryId, Sku, Weight, Dimensions, IsActive, IsFeatured, ViewCount, SalesCount, CreatedAt, UpdatedAt, IsDeleted, RowVersion) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        products
    )
    conn.commit()
    print(f"Created {len(products)} products")
else:
    print("Products table not found")

conn.close()
print("Database seeded successfully!")
