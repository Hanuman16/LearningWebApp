# E-Commerce & Inventory Management Application

A production-ready, full-stack e-commerce and inventory management application built with modern technologies and best practices.

## 📋 Table of Contents

- [Features](#features)
- [Tech Stack](#tech-stack)
- [Architecture](#architecture)
- [Project Structure](#project-structure)
- [Getting Started](#getting-started)
- [API Documentation](#api-documentation)
- [Database](#database)
- [Testing](#testing)
- [Docker](#docker)
- [CI/CD](#cicd)
- [Security](#security)
- [Contributing](#contributing)

## ✨ Features

### User Management
- User registration with email verification
- JWT authentication with refresh token rotation
- Password reset functionality
- Role-based authorization (Admin, Moderator, Customer)
- Profile management

### Product Management
- Full CRUD operations for products
- Category management with hierarchical support
- Product images support
- Product search, filtering, sorting, and pagination
- Featured products

### Inventory Management
- Stock tracking with low-stock alerts
- Inventory transactions audit trail
- Warehouse location support
- Reorder level management

### Shopping Features
- Shopping cart with coupon support
- Wishlist functionality
- Order creation and management
- Order status tracking
- Multiple payment method support
- Product reviews and ratings

### Admin Features
- Admin dashboard
- Sales and inventory reports
- Order management
- Coupon/discount management
- Audit logging

### Non-Functional Requirements
- API versioning
- Health checks
- Rate limiting
- Distributed caching with Redis
- Background job processing with Hangfire
- Structured logging with Serilog
- Global exception handling
- Request validation with FluentValidation
- CQRS pattern with MediatR
- Clean Architecture

## 🛠 Tech Stack

### Backend
- **Framework**: ASP.NET Core 9 (LTS)
- **Language**: C# 13
- **ORM**: Entity Framework Core 9
- **Database**: SQL Server 2022
- **Authentication**: JWT with refresh token rotation
- **Message Broker**: MediatR (CQRS)
- **Validation**: FluentValidation
- **Mapping**: AutoMapper
- **Background Jobs**: Hangfire
- **Caching**: Redis (StackExchange.Redis)
- **Resilience**: Polly
- **Logging**: Serilog

### Frontend (Planned)
- **Framework**: Angular 18
- **State Management**: NgRx
- **HTTP Client**: Angular HttpClient with interceptors
- **UI**: Material Design or custom component library

### DevOps
- **Containerization**: Docker & Docker Compose
- **CI/CD**: GitHub Actions
- **Monitoring**: Seq for log aggregation

## 🏗 Architecture

This application follows **Clean Architecture** principles with the **CQRS pattern**:

```
┌─────────────────────────────────────────────────────────────┐
│                        API Layer                             │
│  (Controllers, Middleware, Program.cs)                       │
├─────────────────────────────────────────────────────────────┤
│                      Application Layer                       │
│  (DTOs, Validators, Commands/Queries, Handlers, Services)   │
├─────────────────────────────────────────────────────────────┤
│                        Core Layer                            │
│  (Entities, Value Objects, Exceptions, Interfaces)          │
├─────────────────────────────────────────────────────────────┤
│                    Infrastructure Layer                      │
│  (EF Core, Repositories, Caching, Background Jobs)          │
├─────────────────────────────────────────────────────────────┤
│                      Shared Layer                            │
│  (Constants, Helpers, Extensions)                           │
└─────────────────────────────────────────────────────────────┘
```

### Design Patterns
- **CQRS**: Command Query Responsibility Segregation using MediatR
- **Repository**: Generic repository with Unit of Work pattern
- **Specification**: Query specification pattern (to be implemented)
- **Factory**: Repository factory in Unit of Work
- **Strategy**: Payment processing strategy pattern (to be implemented)

## 📁 Project Structure

```
ECommerceApplication/
├── src/
│   ├── ECommerce.Api/                    # ASP.NET Core Web API
│   │   ├── Controllers/                  # API Controllers
│   │   ├── Middleware/                   # Custom Middleware
│   │   ├── Program.cs                    # Application entry point
│   │   └── appsettings.json              # Configuration
│   ├── ECommerce.Core/                   # Domain Layer
│   │   ├── Entities/                     # Domain Entities
│   │   ├── ValueObjects/                 # Value Objects
│   │   ├── Exceptions/                   # Domain Exceptions
│   │   └── Interfaces/                   # Domain Interfaces
│   ├── ECommerce.Application/            # Application Layer
│   │   ├── DTOs/                         # Data Transfer Objects
│   │   ├── Validators/                   # FluentValidation validators
│   │   ├── Commands/                     # CQRS Commands/Queries
│   │   ├── Handlers/                     # Command/Query handlers
│   │   ├── Profiles/                     # AutoMapper profiles
│   │   └── Extensions/                   # Service extensions
│   ├── ECommerce.Infrastructure/         # Infrastructure Layer
│   │   ├── Data/                         # EF Core DbContext, Repositories
│   │   └── Extensions/                   # Service extensions
│   ├── ECommerce.Shared/                 # Shared Layer
│   │   ├── Constants/                    # Application constants
│   │   └── Helpers/                      # Helper methods
│   └── ECommerce.Application/            # Application Layer
│       ├── DTOs/                         # Data Transfer Objects
│       ├── Validators/                   # FluentValidation validators
│       ├── Commands/                     # CQRS Commands/Queries
│       ├── Handlers/                     # Command/Query handlers
│       ├── Profiles/                     # AutoMapper profiles
│       └── Extensions/                   # Service extensions
├── tests/                                # Test projects (to be created)
│   ├── ECommerce.UnitTests/
│   ├── ECommerce.IntegrationTests/
│   └── ECommerce.ApiTests/
├── frontend/                             # Angular frontend (to be created)
├── .github/workflows/                    # GitHub Actions workflows
├── docker-compose.yml                    # Docker Compose configuration
├── Dockerfile.Api                        # API Dockerfile
└── README.md                             # This file
```

## 🚀 Getting Started

### Prerequisites

- [.NET 9 SDK](https://dotnet.microsoft.com/download/dotnet/9.0)
- [SQL Server 2022](https://www.microsoft.com/en-us/sql-server/sql-server-downloads) (or Docker)
- [Redis](https://redis.io/) (or Docker)
- [Node.js 18+](https://nodejs.org/) (for Angular frontend)
- [Angular CLI](https://angular.io/cli) (for Angular frontend)

### Quick Start with Docker

```bash
# Clone the repository
git clone https://github.com/yourusername/ECommerceApplication.git
cd ECommerceApplication

# Start all services with Docker Compose
docker-compose up -d

# The application will be available at:
# API: http://localhost:5000
# Swagger UI: http://localhost:5000/swagger
# Hangfire Dashboard: http://localhost:5005/hangfire
# Seq: http://localhost:5341
```

### Manual Setup

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/ECommerceApplication.git
cd ECommerceApplication
```

2. **Restore NuGet packages**
```bash
dotnet restore ECommerceApplication.sln
```

3. **Configure database connection**
Update `src/ECommerce.Api/appsettings.json` with your SQL Server connection string.

4. **Run database migrations**
```bash
dotnet ef database update --project src/ECommerce.Infrastructure --startup-project src/ECommerce.Api
```

5. **Run the application**
```bash
dotnet run --project src/ECommerce.Api
```

6. **Access the API**
- Swagger UI: http://localhost:5000/swagger
- Health Check: http://localhost:5000/health

## 📚 API Documentation

### Authentication Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register a new user |
| POST | `/api/auth/login` | Login and get JWT token |
| POST | `/api/auth/refresh` | Refresh access token |
| POST | `/api/auth/forgot-password` | Request password reset |
| POST | `/api/auth/reset-password` | Reset password |
| GET | `/api/auth/{id}` | Get user profile |
| PUT | `/api/auth/profile` | Update profile |

### Product Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/products` | Get products (with search/filter) |
| GET | `/api/products/{id}` | Get product by ID |
| GET | `/api/products/featured` | Get featured products |
| POST | `/api/products` | Create product (Admin) |
| PUT | `/api/products/{id}` | Update product (Admin) |
| DELETE | `/api/products/{id}` | Delete product (Admin) |

### Category Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/categories` | Get all categories |
| GET | `/api/categories/{id}` | Get category by ID |
| POST | `/api/categories` | Create category (Admin) |
| PUT | `/api/categories/{id}` | Update category (Admin) |
| DELETE | `/api/categories/{id}` | Delete category (Admin) |

### Order Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/orders` | Create order |
| GET | `/api/orders/my-orders` | Get user's orders |
| GET | `/api/orders/{id}` | Get order by ID |
| PUT | `/api/orders/{id}/status` | Update order status (Admin) |
| POST | `/api/orders/{id}/cancel` | Cancel order |

> **Note**: Full API documentation is available via Swagger UI at `/swagger` when running the application.

## 🗄 Database

### Entity Relationship Diagram

The application uses the following main entities:

- **Users**: User accounts with roles and permissions
- **Products**: Product catalog with variants
- **Categories**: Hierarchical category structure
- **Orders**: Customer orders with items
- **Inventory**: Stock tracking and transactions
- **Payments**: Payment processing records
- **Reviews**: Product reviews and ratings
- **Coupons**: Discount and promotion management

### Migrations

```bash
# Add a new migration
dotnet ef migrations add "MigrationName" --project src/ECommerce.Infrastructure --startup-project src/ECommerce.Api

# Update database
dotnet ef database update --project src/ECommerce.Infrastructure --startup-project src/ECommerce.Api

# Remove last migration
dotnet ef migrations remove --project src/ECommerce.Infrastructure --startup-project src/ECommerce.Api
```

## 🧪 Testing

### Run All Tests

```bash
dotnet test ECommerceApplication.sln
```

### Run Unit Tests Only

```bash
dotnet test tests/ECommerce.UnitTests/ECommerce.UnitTests.csproj
```

### Run Integration Tests

```bash
dotnet test tests/ECommerce.IntegrationTests/ECommerce.IntegrationTests.csproj --filter "Category=Integration"
```

### Code Coverage

```bash
dotnet test ECommerceApplication.sln /p:CollectCoverage=true
```

## 🐳 Docker

### Build Images

```bash
# Build API image
docker build -f Dockerfile.Api -t ecommerce-api .

# Build all services
docker-compose build
```

### Run Services

```bash
# Start all services
docker-compose up -d

# Stop all services
docker-compose down

# Stop and remove volumes
docker-compose down -v
```

### Services

| Service | Port | Description |
|---------|------|-------------|
| API | 5000 | ASP.NET Core Web API |
| SQL Server | 1433 | Microsoft SQL Server 2022 |
| Redis | 6379 | Redis Cache |
| Hangfire | 5005 | Hangfire Dashboard |
| Seq | 5341 | Log Aggregation |

## 🔄 CI/CD

The application uses GitHub Actions for continuous integration and deployment.

### Pipeline Stages

1. **Build**: Compiles the solution and restores packages
2. **Test**: Runs unit and integration tests with code coverage
3. **Security Scan**: Audits dependencies for vulnerabilities
4. **Docker Build**: Builds and pushes Docker image
5. **Deploy**: Deploys to production environment

### Required Secrets

- `DOCKER_USERNAME`: Docker Hub username
- `DOCKER_PASSWORD`: Docker Hub password
- `AZURE_CONNECTION_STRING`: Azure connection string (for deployment)

## 🔒 Security

### Implemented Security Features

- **JWT Authentication**: Secure token-based authentication
- **Refresh Token Rotation**: Prevents token replay attacks
- **Password Hashing**: ASP.NET Identity with secure hashing
- **Input Validation**: FluentValidation for all inputs
- **SQL Injection Prevention**: Entity Framework parameterized queries
- **XSS Prevention**: Output encoding and validation
- **CORS Policy**: Configurable cross-origin policies
- **Rate Limiting**: API rate limiting (to be implemented)
- **Audit Logging**: Track all critical operations
- **HTTPS Enforcement**: Force HTTPS in production

### OWASP Top 10 Compliance

| OWASP Category | Status | Implementation |
|----------------|--------|----------------|
| A01: Broken Access Control | ✅ | Role-based authorization |
| A02: Cryptographic Failures | ✅ | Password hashing, HTTPS |
| A03: Injection | ✅ | EF Core parameterized queries |
| A04: Insecure Design | ✅ | Security-first architecture |
| A05: Security Misconfiguration | ✅ | Secure defaults |
| A06: Vulnerable Components | ✅ | Regular dependency updates |
| A07: Auth Failures | ✅ | JWT with rotation |
| A08: Data Integrity | ✅ | Audit logging, validation |
| A09: Logging Failures | ✅ | Serilog structured logging |
| A10: SSRF | ✅ | Input validation |

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Development Guidelines

- Follow [Microsoft C# Coding Standards](https://learn.microsoft.com/en-us/dotnet/csharp/fundamentals/coding-style/coding-conventions)
- Use [Angular Style Guide](https://angular.io/guide/styleguide)
- Write unit tests for all new features
- Update documentation for API changes
- Follow semantic versioning for commits

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [ASP.NET Core](https://dotnet.microsoft.com/apps/aspnet)
- [Entity Framework Core](https://entityframeworkcore.com/)
- [Angular](https://angular.io/)
- [Docker](https://www.docker.com/)
- [GitHub Actions](https://github.com/features/actions)

## 📞 Support

For support, please open an issue on [GitHub](https://github.com/yourusername/ECommerceApplication/issues) or contact the maintainers.

---

Built with ❤️ using ASP.NET Core 9 and Angular 18
