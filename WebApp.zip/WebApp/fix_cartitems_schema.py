import sqlite3
import os

db_path = r'c:\Users\XPY1KOR\Desktop\WebApp\src\ECommerce.Api\ecommerce.db'

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Enable foreign keys check for inspection only
cursor.execute("PRAGMA foreign_keys = OFF")

# Check current schema
cursor.execute("PRAGMA table_info(CartItems)")
columns = cursor.fetchall()
print("Current CartItems table schema:")
for col in columns:
    print(f"  {col[1]}: nullable={'NO' if col[3] == 0 else 'YES'}")

# Get foreign keys
cursor.execute("PRAGMA foreign_key_list(CartItems)")
fk = cursor.fetchall()
print(f"\nForeign keys: {fk}")

# Get the current table creation SQL
cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='CartItems'")
current_sql = cursor.fetchone()[0]
print(f"\nCurrent SQL:\n{current_sql}")

# Get all existing data
cursor.execute("SELECT * FROM CartItems")
existing_data = cursor.fetchall()
print(f"\nFound {len(existing_data)} existing cart item rows")

# Get all indexes
cursor.execute("SELECT name, sql FROM sqlite_master WHERE type='index' AND tbl_name='CartItems'")
indexes = cursor.fetchall()
print(f"\nIndexes: {indexes}")

# Drop the CartItems_New table if it exists from a previous run
try:
    cursor.execute("DROP TABLE IF EXISTS CartItems_New")
except Exception as e:
    print(f"Note: CartItems_New table did not exist: {e}")

# Create a new table without the foreign key constraint
cursor.execute("""
    CREATE TABLE CartItems_New (
        Id TEXT NOT NULL PRIMARY KEY,
        CartId TEXT NOT NULL,
        ProductId TEXT NOT NULL,
        Quantity INTEGER NOT NULL DEFAULT 0,
        UnitPrice REAL NOT NULL DEFAULT 0,
        DiscountAmount REAL NOT NULL DEFAULT 0,
        CreatedAt TEXT NOT NULL,
        UpdatedAt TEXT,
        IsDeleted INTEGER NOT NULL DEFAULT 0,
        RowVersion BLOB
    )
""")

# Copy data from old table to new table
cursor.execute("""
    INSERT INTO CartItems_New (Id, CartId, ProductId, Quantity, UnitPrice, DiscountAmount, CreatedAt, UpdatedAt, IsDeleted, RowVersion)
    SELECT Id, CartId, ProductId, Quantity, UnitPrice, DiscountAmount, CreatedAt, UpdatedAt, IsDeleted, RowVersion
    FROM CartItems
""")

# Drop old table and rename new table
cursor.execute("DROP TABLE CartItems")
cursor.execute("ALTER TABLE CartItems_New RENAME TO CartItems")

# Recreate indexes (but not the foreign key)
for index_name, index_sql in indexes:
    if index_sql and 'FK_CartItems' not in index_sql:
        try:
            cursor.execute(index_sql)
            print(f"Recreated index: {index_name}")
        except Exception as e:
            print(f"Warning: Could not recreate index {index_name}: {e}")

conn.commit()

# Verify the new schema
print("\nNew CartItems table schema:")
cursor.execute("PRAGMA table_info(CartItems)")
columns = cursor.fetchall()
for col in columns:
    print(f"  {col[1]}: nullable={'NO' if col[3] == 0 else 'YES'}")

# Check foreign keys
cursor.execute("PRAGMA foreign_key_list(CartItems)")
fk = cursor.fetchall()
print(f"\nForeign keys: {fk if fk else 'None'}")

conn.close()
print("\nDatabase schema updated successfully!")
