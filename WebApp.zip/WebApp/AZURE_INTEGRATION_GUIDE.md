# ╔═══════════════════════════════════════════════════════════╗
# ║  AZURE CLOUD INTEGRATION GUIDE                           ║
# ╚═══════════════════════════════════════════════════════════╝

To Enable Azure Services

Create Azure resources using the Azure CLI commands in the guide
Update appsettings.Azure.json with your connection strings
Add builder.Services.AddAzureServices(builder.Configuration); to Program.cs
Use the service interfaces in your controllers

## 📋 TABLE OF CONTENTS
1. [Architecture Overview](#architecture-overview)
2. [Azure Services Used](#azure-services-used)
3. [Configuration](#configuration)
4. [Service Registration](#service-registration)
5. [Usage Examples](#usage-examples)
6. [Deployment Guide](#deployment-guide)
7. [Security Best Practices](#security-best-practices)
8. [Cost Optimization](#cost-optimization)

---

## 🏗️ ARCHITECTURE OVERVIEW

```
┌─────────────────────────────────────────────────────────────┐
│                    ANGULAR FRONTEND                         │
│                   (localhost:4200)                          │
└────────────────────────┬────────────────────────────────────┘
                         │ HTTPS
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                   AZURE APP SERVICE                         │
│  ┌───────────────────────────────────────────────────────┐  │
│  │              .NET 9 API (ECommerce.Api)               │  │
│  │                                                       │  │
│  │  ┌─────────────┐  ┌──────────────┐  ┌─────────────┐ │  │
│  │  │  JWT Auth   │  │  CQRS/MediatR│  │  CORS/Rate  │ │  │
│  │  └─────────────┘  └──────────────┘  └─────────────┘ │  │
│  │                                                       │  │
│  │  ┌─────────────────────────────────────────────────┐ │  │
│  │  │         Azure Services Integration              │ │  │
│  │  │  • Blob Storage  • Service Bus                 │ │  │
│  │  │  • Key Vault     • Redis Cache                 │ │  │
│  │  │  • Cosmos DB     • Application Insights        │ │  │
│  │  │  • CDN           • Managed Identity            │ │  │
│  │  └─────────────────────────────────────────────────┘ │  │
│  └───────────────────────────────────────────────────────┘  │
└──────────┬──────────┬──────────┬──────────┬────────────────┘
           │          │          │          │
           ▼          ▼          ▼          ▼
    ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐
    │  Blob    │ │ Service  │ │  Key     │ │  Redis   │
    │ Storage  │ │   Bus    │ │  Vault   │ │  Cache   │
    └──────────┘ └──────────┘ └──────────┘ └──────────┘
           │          │          │          │
           ▼          ▼          ▼          ▼
    ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐
    │  Cosmos  │ │  App     │ │  CDN     │ │  SQL     │
    │   DB     │ │ Insights │ │          │ │  Server  │
    └──────────┘ └──────────┘ └──────────┘ └──────────┘
```

---

## ☁️ AZURE SERVICES USED

| Service | Purpose | Why Used |
|---------|---------|----------|
| **Azure App Service** | Host .NET 9 API | Managed hosting with auto-scaling |
| **Azure Blob Storage** | Store product images, user uploads | Scalable object storage |
| **Azure Service Bus** | Async messaging for orders, notifications | Decouples services, reliable delivery |
| **Azure Key Vault** | Secure secret management | Protects JWT keys, connection strings |
| **Azure Redis Cache** | Distributed caching | Fast data retrieval, scalability |
| **Azure Cosmos DB** | NoSQL database for products, preferences | Global distribution, auto-scaling |
| **Azure Application Insights** | Telemetry, monitoring, debugging | Application performance monitoring |
| **Azure CDN** | Deliver static assets globally | Faster content delivery worldwide |
| **Managed Identity** | Authentication without secrets | Eliminates secret management |

---

## ⚙️ CONFIGURATION

### Step 1: Create Azure Resources

```bash
# Create resource group
az group create --name ecommerce-rg --location eastus

# Create Storage Account
az storage account create --name ecommercestorage --resource-group ecommerce-rg --location eastus --sku Standard_LRS

# Create Service Bus Namespace
az servicebus namespace create --name ecommerce-sb --resource-group ecommerce-rg --location eastus --sku Standard

# Create Key Vault
az keyvault create --name ecommerce-kv --resource-group ecommerce-rg --location eastus

# Create Redis Cache
az redis create --name ecommerce-redis --resource-group ecommerce-rg --location eastus --sku Basic --port 6380

# Create Cosmos DB Account
az cosmosdb create --name ecommerce-cosmos --resource-group ecommerce-rg --kind GlobalDocumentDB

# Create Application Insights
az monitor app-insights component create --app ecommerce-appinsights --resource-group ecommerce-rg --location eastus

# Create CDN Profile (optional)
az cdn profile create --name ecommerce-cdn-profile --resource-group ecommerce-rg --location eastus
az cdn endpoint create --name ecommerce-cdn --profile-name ecommerce-cdn-profile --resource-group ecommerce-rg --location eastus
```

### Step 2: Get Connection Strings

```bash
# Get Storage Account Connection String
az storage account show-connection-string --name ecommercestorage --resource-group ecommerce-rg --output table

# Get Service Bus Connection String
az servicebus namespace authorization-policy keys list --namespace-name ecommerce-sb --resource-group ecommerce-rg --policy-name RootManageSharedAccessKey

# Get Redis Cache Connection String
az redis show --name ecommerce-redis --resource-group ecommerce-rg --key primary

# Get Cosmos DB Connection String
az cosmosdb keys list --name ecommerce-cosmos --resource-group ecommerce-rg --type connection-strings

# Get Application Insights Connection String
az monitor app-insights component show --app ecommerce-appinsights --resource-group ecommerce-rg
```

### Step 3: Update appsettings.Azure.json

Replace placeholder values with your actual connection strings:

```json
{
  "Azure": {
    "BlobStorage": {
      "ConnectionString": "YOUR_STORAGE_CONNECTION_STRING",
      "ProductImagesContainer": "product-images",
      "UserUploadsContainer": "user-uploads",
      "BackupsContainer": "backups"
    },
    "ServiceBus": {
      "ConnectionString": "YOUR_SERVICE_BUS_CONNECTION_STRING",
      "OrderQueue": "order-queue",
      "NotificationTopic": "notification-topic"
    },
    "KeyVault": {
      "VaultUri": "https://ecommerce-kv.vault.azure.net/",
      "Enabled": true
    },
    "RedisCache": {
      "ConnectionString": "YOUR_REDIS_CONNECTION_STRING",
      "InstanceName": "ecommerce"
    },
    "CosmosDb": {
      "AccountUri": "https://ecommerce-cosmos.documents.azure.com:443/",
      "PrimaryKey": "YOUR_COSMOS_DB_KEY",
      "DatabaseName": "ECommerce"
    },
    "ApplicationInsights": {
      "ConnectionString": "YOUR_APP_INSIGHTS_CONNECTION_STRING",
      "Enabled": true
    },
    "CDN": {
      "Hostname": "ecommerce-cdn.azureedge.net",
      "Enabled": true
    }
  }
}
```

---

## 🔧 SERVICE REGISTRATION

### In Program.cs

```csharp
// Add this line to register all Azure services
builder.Services.AddAzureServices(builder.Configuration);

// OR register individual services:

// Azure Blob Storage
builder.Services.AddScoped<IAzureBlobStorageService, AzureBlobStorageService>();

// Azure Service Bus
builder.Services.AddScoped<IServiceBusProducer, AzureServiceBusProducer>();
builder.Services.AddHostedService<AzureServiceBusConsumer>();

// Azure Key Vault
builder.Configuration.AddAzureKeyVault(builder.Configuration);

// Azure Redis Cache
builder.Services.AddStackExchangeRedisCache(options =>
{
    options.Configuration = configuration["Azure:RedisCache:ConnectionString"];
    options.InstanceName = "ecommerce";
});

// Azure Cosmos DB
builder.Services.AddScoped(typeof(ICosmosDbRepository<>), typeof(CosmosDbRepository<>));

// Azure Application Insights
builder.Services.AddApplicationInsightsTelemetry(configuration["Azure:ApplicationInsights:ConnectionString"]);

// Azure CDN
builder.Services.AddScoped<IAzureCdnService, AzureCdnService>();
```

---

## 💡 USAGE EXAMPLES

### 1. Azure Blob Storage - Upload Product Image

```csharp
// In ProductsController.cs
[HttpPost("upload-image")]
[Authorize(Policy = "AdminPolicy")]
public async Task<IActionResult> UploadProductImage(IFormFile file)
{
    // Upload to Azure Blob Storage
    var imageUrl = await _blobStorageService.UploadFileAsync(
        containerName: "product-images",
        fileStream: file.OpenReadStream(),
        fileName: file.FileName,
        contentType: file.ContentType,
        isPublic: true // Public container for product images
    );

    return Ok(new { ImageUrl = imageUrl });
}
```

### 2. Azure Service Bus - Send Order Message

```csharp
// In OrderCommandHandler.cs
public class CreateOrderCommandHandler : IRequestHandler<CreateOrderCommand, OrderDto>
{
    private readonly IServiceBusProducer _serviceBusProducer;

    public async Task<OrderDto> Handle(CreateOrderCommand request, CancellationToken cancellationToken)
    {
        // Create order in database
        var order = new Order(request.Items, request.UserId);
        await _unitOfWork.Orders.AddAsync(order);
        await _unitOfWork.SaveChangesAsync();

        // Send message to Service Bus for async processing
        await _serviceBusProducer.SendOrderMessageAsync(MapToDto(order));

        return MapToDto(order);
    }
}
```

### 3. Azure Redis Cache - Cache Product List

```csharp
// In ProductsController.cs
[HttpGet]
public async Task<IActionResult> GetProducts([FromQuery] int page = 1, [FromQuery] int pageSize = 20)
{
    var cacheKey = $"products_page_{page}_size_{pageSize}";

    // Try to get from cache first
    var cachedProducts = await _redisCache.GetAsync<List<ProductDto>>(cacheKey);
    if (cachedProducts != null)
    {
        return Ok(cachedProducts);
    }

    // Cache miss - get from database
    var products = await _productService.GetPagedProductsAsync(page, pageSize);

    // Cache for 5 minutes
    await _redisCache.SetAsync(cacheKey, products, TimeSpan.FromMinutes(5));

    return Ok(products);
}
```

### 4. Azure Key Vault - Get Secret

```csharp
// In AuthenticationController.cs
[HttpPost("login")]
public async Task<IActionResult> Login(LoginRequest request)
{
    // Get JWT key from Key Vault (not from appsettings.json)
    var keyVaultClient = new SecretClient(
        new Uri(_configuration["Azure:KeyVault:VaultUri"]),
        new DefaultAzureCredential());

    var jwtKey = await keyVaultClient.GetSecretAsync("JwtSigningKey");

    // Use JWT key for token validation
    var key = Encoding.UTF8.GetBytes(jwtKey.Value.Value);
    // ... rest of authentication logic
}
```

### 5. Azure Cosmos DB - Query Products

```csharp
// In ProductCosmosRepository.cs
public async Task<IEnumerable<Product>> GetProductsByCategoryAsync(string categoryId)
{
    var query = "SELECT * FROM c WHERE c.categoryId = @categoryId";
    var parameters = new SqlParameter[] { new("@categoryId", categoryId) };

    return await _cosmosRepository.QueryAsync<Product>(query, parameters);
}
```

### 6. Azure CDN - Serve Product Images

```csharp
// In ProductsController.cs
[HttpGet("{id}")]
public async Task<IActionResult> GetProduct(Guid id)
{
    var product = await _productService.GetProductByIdAsync(id);

    // Use CDN URL for product image
    var imageUrl = _cdnService.GetProductImageUrl(product.ImageBlobName, cacheBust: false);

    return Ok(new
    {
        product.Id,
        product.Name,
        product.Price,
        ImageUrl = imageUrl // CDN URL
    });
}
```

---

## 🚀 DEPLOYMENT GUIDE

### Step 1: Create Azure Resources

```bash
# Create resource group
az group create --name ecommerce-rg --location eastus

# Create all resources (see Step 1 in Configuration section)
```

### Step 2: Configure Managed Identity

```bash
# Enable Managed Identity on App Service
az webapp identity assign --name your-app-service --resource-group ecommerce-rg

# Grant Key Vault access to Managed Identity
az keyvault set-policy --name ecommerce-kv --resource-group ecommerce-rg \
    --object-id <APP_SERVICE_OBJECT_ID> --secret-permissions get list

# Grant Storage Account access to Managed Identity
az storage account set --name ecommercestorage --resource-group ecommerce-rg \
    --assign-msi-role Owner --assign-msi <APP_SERVICE_OBJECT_ID>
```

### Step 3: Configure App Settings

```bash
# Set app settings in App Service
az webapp config appsettings set --name your-app-service --resource-group ecommerce-rg \
    --settings Azure__KeyVault__Enabled=true \
             Azure__ApplicationInsights__Enabled=true \
             Azure__CDN__Enabled=true \
             ASPNETCORE_ENVIRONMENT=Production
```

### Step 4: Deploy Application

```bash
# Build and publish
dotnet publish -c Release -o ./publish

# Deploy to App Service
az webapp deploy --name your-app-service --resource-group ecommerce-rg \
    --src-path ./publish.zip --type zip
```

### Step 5: Verify Deployment

```bash
# Check application health
az webapp show-health-plan --name your-app-service --resource-group ecommerce-rg

# View application logs
az webapp log tail --name your-app-service --resource-group ecommerce-rg
```

---

## 🔒 SECURITY BEST PRACTICES

### 1. Use Managed Identity (NOT Connection Strings)

```csharp
// ❌ BAD: Hardcoded connection strings
var client = new BlobServiceClient("DefaultEndpointsProtocol=https;...");

// ✅ GOOD: Use Managed Identity
var client = new BlobServiceClient(
    new Uri("https://youraccount.blob.core.windows.net/"),
    new DefaultAzureCredential());
```

### 2. Store Secrets in Key Vault

```csharp
// ❌ BAD: Store secrets in appsettings.json
{
  "Jwt": { "Key": "your-secret-key" }
}

// ✅ GOOD: Store in Key Vault, retrieve at runtime
var jwtKey = await keyVaultClient.GetSecretAsync("JwtSigningKey");
```

### 3. Enable HTTPS Only

```csharp
// In Program.cs
app.UseHttpsRedirection();
```

### 4. Restrict CORS

```csharp
// ❌ BAD: Allow all origins
options.AddPolicy("AllowAll", policy => policy.AllowAnyOrigin());

// ✅ GOOD: Allow specific origins
options.AddPolicy("AllowFrontend", policy =>
    policy.WithOrigins("https://your-domain.com")
          .AllowAnyMethod()
          .AllowAnyHeader());
```

### 5. Enable Rate Limiting

```csharp
// In Program.cs
app.UseMiddleware<RateLimitingMiddleware>();
```

### 6. Validate File Uploads

```csharp
// In Program.cs
app.UseMiddleware<FileUploadSecurityMiddleware>();
```

---

## 💰 COST OPTIMIZATION

### 1. Use Free/Tier Options for Development

```bash
# Free tier for development
az storage account create --name devstorage --sku Standard_LRS --kind BlobStorage --access-tier Hot

# Basic tier for staging
az redis create --name staging-redis --sku Basic
```

### 2. Enable Auto-Scaling

```bash
# Auto-scale App Service based on CPU usage
az appservice plan update --name your-app-service-plan --resource-group ecommerce-rg \
    --number-of-workers 2 --min-workers 1 --max-workers 10
```

### 3. Use Sampling for Application Insights

```json
{
  "Azure": {
    "ApplicationInsights": {
      "SamplingPercentage": 20  // Sample 20% of requests
    }
  }
}
```

### 4. Set Cache Expiration

```csharp
// Cache products for 10 minutes
await _redisCache.SetAsync(cacheKey, products, TimeSpan.FromMinutes(10));

// Cache user sessions for 30 minutes
await _redisCache.SetAsync(sessionKey, session, TimeSpan.FromMinutes(30));
```

### 5. Use Azure Cost Management

```bash
# View current costs
az costmanagement export create --resource-group ecommerce-rg \
    --name monthly-cost-report --type Scheduled

# Set budget alerts
az costmanagement budget create --resource-group ecommerce-rg \
    --name monthly-budget --amount 1000 --time-grain Monthly \
    --time-range-end 2024-12-31 --time-range-start 2024-01-01 \
    --contact-emails admin@your-domain.com
```

---

## 📊 MONITORING & ALERTS

### 1. Application Insights Dashboard

```csharp
// Track custom events
_telemetryClient.TrackEvent("OrderPlaced", new Dictionary<string, string>
{
    { "OrderId", order.Id.ToString() },
    { "UserId", order.UserId.ToString() }
});

// Track custom metrics
_telemetryClient.TrackMetric("OrderValue", order.TotalAmount);
```

### 2. Set Up Alerts

```bash
# Alert on high error rate
az monitor alert-rules create --name high-error-rate --resource-group ecommerce-rg \
    --action-group your-action-group \
    --metric "Http5xx" --threshold 10 --operator GreaterThan

# Alert on high CPU usage
az monitor alert-rules create --name high-cpu --resource-group ecommerce-rg \
    --action-group your-action-group \
    --metric "Percentage CPU" --threshold 80 --operator GreaterThan
```

---

## 📝 SUMMARY

### Files Created in This Integration:

| File | Purpose |
|------|---------|
| `AzureSettings.cs` | Strongly-typed configuration classes |
| `KeyVaultConfiguration.cs` | Key Vault integration and secret refresher |
| `AzureBlobStorageService.cs` | Blob storage operations (upload, download, delete) |
| `AzureServiceBusService.cs` | Message producer and consumer |
| `AzureRedisCacheService.cs` | Distributed caching operations |
| `CosmosDbRepository.cs` | NoSQL repository pattern |
| `ApplicationInsightsService.cs` | Telemetry customization |
| `AzureCdnService.cs` | CDN URL generation and cache purging |
| `AzureServiceCollectionExtensions.cs` | Centralized service registration |
| `appsettings.Azure.json` | Azure configuration template |

### Key Concepts Implemented:

1. **Options Pattern** - Strongly-typed configuration
2. **Repository Pattern** - Abstracted data access
3. **Strategy Pattern** - Different strategies for different scenarios
4. **Decorator Pattern** - Wrapped services with additional functionality
5. **Factory Pattern** - Centralized client creation
6. **Defensive Programming** - Graceful degradation, validation
7. **SOLID Principles** - SRP, OCP, ISP, DIP followed throughout

### Next Steps:

1. Create Azure resources using Azure CLI
2. Update `appsettings.Azure.json` with your connection strings
3. Register services in `Program.cs`
4. Update controllers to use Azure services
5. Deploy to Azure App Service
6. Enable Managed Identity
7. Configure monitoring and alerts
