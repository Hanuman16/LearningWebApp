# E-Commerce Development - Issues & Root Cause Analysis

## Session Overview
**Project**: Angular 18 + .NET 9 E-Commerce Application  
**Architecture**: Clean Architecture (Api → Application → Core → Infrastructure)  
**Date**: 2026-10-05  
**Status**: All issues resolved, Add to Cart functionality fully operational

---

## Issue 1: Cart Endpoint Returning 405 Method Not Allowed

### Problem
- "Add to Cart" button returning 405 Method Not Allowed error
- Anonymous users unable to access cart endpoints

### Root Cause
- `CartController` had `[Authorize]` attribute at class level
- This blocked all anonymous/guest user requests to cart operations

### Debugging Steps & Reasoning

**Step 1: Checked Browser Console for Error Details**
- **Why**: Browser console shows the exact HTTP status code and response headers
- **What we found**: 405 Method Not Allowed (not 401 Unauthorized as initially expected)
- **Insight**: 405 means the server understood the request but refused to process it, not that authentication failed

**Step 2: Examined CartController Class-Level Attributes**
- **Why**: 405 on anonymous requests often indicates middleware pipeline blocking
- **What we found**: `[Authorize]` attribute at class level requiring authentication for ALL endpoints
- **Insight**: `[Authorize]` at class level applies to every action method unless overridden with `[AllowAnonymous]`

**Step 3: Reviewed Authentication Middleware Configuration**
- **Why**: To understand if JWT middleware was properly configured
- **What we found**: JWT middleware was correctly configured but `[Authorize]` was blocking before JWT validation even occurred
- **Insight**: The issue wasn't with JWT configuration but with controller-level authorization requirement

**Step 4: Tested API Directly with PowerShell**
- **Why**: Eliminate frontend as variable and test backend in isolation
- **Command**: `Invoke-RestMethod -Uri "http://localhost:5000/api/v1/cart" -Headers @{"Authorization"="Bearer ..."}`
- **Result**: Authenticated requests worked, anonymous requests got 405
- **Insight**: Confirmed the issue was specifically with anonymous access, not the endpoint itself

### Solution
- Removed `[Authorize]` attribute from `CartController`
- Implemented guest cart support using cookie-based cart ID
- Added dual-path logic: authenticated users use `AddCartItemCommand`, guests use `AddGuestCartItemCommand`

### Files Modified
- `src/ECommerce.Api/Controllers/CartController.cs`

---

## Issue 2: Build Errors - Duplicate Record Types

### Problem
- Build failed with errors about duplicate record types
- Controller had local record types conflicting with Application layer types

### Root Cause
- `CartController.cs` defined local record types (`AddCartItemRequest`, `UpdateCartItemRequest`, `ApplyCouponRequest`)
- These conflicted with DTOs already defined in `ECommerce.Application` layer

### Debugging Steps & Reasoning

**Step 1: Ran `dotnet build` and Examined Error Messages**
- **Why**: Build errors provide exact file locations and line numbers
- **What we found**: Errors indicating duplicate type definitions in the same namespace
- **Insight**: Local record types in controller were in the same namespace as Application layer types

**Step 2: Searched for Record Type Definitions in Controller**
- **Why**: To identify which types were causing conflicts
- **Command**: Searched for `record` keyword in `CartController.cs`
- **What we found**: Three local record types defined at the bottom of the controller file
- **Insight**: These record types duplicated DTOs that already existed in the Application layer

**Step 3: Verified Application Layer Already Had These DTOs**
- **Why**: Clean Architecture dictates DTOs belong in Application layer, not API layer
- **What we found**: `AddCartItemRequest`, `UpdateCartItemRequest`, `ApplyCouponRequest` already existed in `ECommerce.Application/DTOs/CartDtos.cs`
- **Insight**: The local types were redundant and violated layer separation principles

### Solution
- Removed all local record type definitions from controller
- Added `using ECommerce.Application.Commands.Cart;` to import Application layer types
- Controller now uses DTOs from the Application layer as intended by Clean Architecture

### Files Modified
- `src/ECommerce.Api/Controllers/CartController.cs`

---

## Issue 3: Build Errors - Type Mismatches

### Problem
- Build failed with type mismatch errors
- Controller expected `string UserId` but Application layer used `Guid UserId`

### Root Cause
- Local record types in controller used `string UserId`
- Application layer DTOs use `Guid UserId` (matching the entity model)
- Type mismatch between controller request model and command parameters

### Debugging Steps & Reasoning

**Step 1: Examined Build Error Details for Type Mismatch**
- **Why**: Build errors specify exact type mismatches (e.g., `string` vs `Guid`)
- **What we found**: Errors like "Cannot convert from 'string' to 'Guid'"
- **Insight**: The local record types had `string UserId` but commands expected `Guid UserId`

**Step 2: Compared Local Record Type Definition with Application DTO**
- **Why**: To understand why types didn't match
- **What we found**: 
  - Local: `record AddCartItemRequest(string UserId, string ProductId, int Quantity);`
  - Application: `public Guid UserId { get; set; }` (in command class)
- **Insight**: When creating local types, `string` was used for GUIDs (common mistake), but entities use actual `Guid` type

**Step 3: Checked Entity Model for Correct Type**
- **Why**: To confirm the correct type should be used
- **What we found**: `Cart.UserId` is `Guid?` in the entity model
- **Insight**: All layers should use `Guid` for consistency, not `string` representations

### Solution
- Removed local record types entirely
- Used Application layer DTOs which have correct `Guid` types
- Ensured consistency across all layers

### Files Modified
- `src/ECommerce.Api/Controllers/CartController.cs`

---

## Issue 4: Build Errors - Missing DTOs

### Problem
- Build failed with errors:
  - `AddCartItemRequest` not found
  - `UpdateCartItemRequest` not found
  - `ApplyCouponRequest` not found

### Root Cause
- Controller referenced DTOs that didn't exist in the Application layer
- These DTOs were needed for cart update and coupon application operations

### Debugging Steps & Reasoning

**Step 1: Checked Build Output for Missing Type Errors**
- **Why**: Build output lists all missing types with file locations
- **What we found**: Compiler errors for `UpdateCartItemRequest` and `ApplyCouponRequest` not being found
- **Insight**: These DTOs were referenced in controller actions but never defined in Application layer

**Step 2: Searched Application Layer for Existing Cart DTOs**
- **Why**: To see what DTOs already existed and what was missing
- **Command**: Searched for `CartItem` in `ECommerce.Application/DTOs/`
- **What we found**: `CartDto`, `CartItemDto` existed but request DTOs for updates/coupons were missing
- **Insight**: Only response DTOs were created, request DTOs were overlooked

**Step 3: Reviewed Controller Actions to Identify Required Properties**
- **Why**: To define DTOs with correct properties
- **What we found**: 
  - Update action needed `CartItemId` and `Quantity`
  - Coupon action needed `Code`
- **Insight**: DTOs should match the exact data needed by each action, no more no less

### Solution
- Added missing DTOs to `CartDtos.cs` in `ECommerce.Application/DTOs/`
- Created `UpdateCartItemRequest` with `Quantity` and `CartItemId` properties
- Created `ApplyCouponRequest` with `Code` property

### Files Modified
- `src/ECommerce.Application/DTOs/CartDtos.cs`

---

## Issue 5: Build Errors - Cart.UserId Non-Nullable

### Problem
- Build failed: `CS8618: Non-nullable property 'UserId' must contain a non-null value`
- Guest carts need null UserId but entity defined it as non-nullable `Guid`

### Root Cause
- `Cart` entity had `Guid UserId` (non-nullable)
- Guest carts don't have a user, so UserId should be null
- Entity model didn't support guest cart pattern

### Debugging Steps & Reasoning

**Step 1: Examined C# Compiler Warning CS8618**
- **Why**: CS8618 indicates a non-nullable property will be null after construction
- **What we found**: Warning on `Cart.UserId` property in entity class
- **Insight**: C# nullable reference types caught this at compile time, but runtime would fail when creating guest cart

**Step 2: Reviewed Guest Cart Creation Logic**
- **Why**: To understand where null UserId would be assigned
- **What we found**: Guest cart handler creates cart with `UserId = null`
- **Insight**: Entity design didn't account for guest users who don't have a user ID

**Step 3: Analyzed Guest Cart Pattern Requirements**
- **Why**: To understand how guest carts should work architecturally
- **Research**: Guest carts use session cookies, not user accounts
- **Insight**: `UserId` must be nullable to distinguish between guest carts (null) and user carts (Guid)

### Solution
- Changed `Cart.UserId` from `Guid` to `Guid?` (nullable)
- Updated navigation property from `public virtual User User` to `public virtual User? User`
- This allows carts without associated users (guest carts)

### Files Modified
- `src/ECommerce.Core/Entities/Cart.cs`

---

## Issue 6: Build Errors - RemoveCartItemCommand Constructor

### Problem
- Build failed: Cannot use constructor parameters vs property initialization
- Controller used `new RemoveCartItemCommand(cartItemId)` but command expected property assignment

### Root Cause
- `RemoveCartItemCommand` is a class with a `CartItemId` property
- Controller tried to pass it as constructor argument
- Command class doesn't have a constructor that accepts `cartItemId` as parameter

### Debugging Steps & Reasoning

**Step 1: Checked Build Error for Constructor Mismatch**
- **Why**: Build error indicates no constructor accepts the provided argument
- **What we found**: "RemoveCartItemCommand does not contain a constructor that takes 1 arguments"
- **Insight**: Command is a class with parameterless constructor and public properties, not a record with positional constructor

**Step 2: Examined RemoveCartItemCommand Definition**
- **Why**: To understand the correct initialization pattern
- **What we found**:
  ```csharp
  public class RemoveCartItemCommand : IRequest<Unit>
  {
      public Guid CartItemId { get; set; }
  }
  ```
- **Insight**: This is a CQRS command class with default constructor and property assignment, not a record type

**Step 3: Reviewed Other Commands for Consistency**
- **Why**: To ensure consistent initialization pattern across all commands
- **What we found**: All CQRS commands in this project use property initialization
- **Insight**: The controller code was using record-style initialization for a class-based command

### Solution
- Changed controller code from:
  ```csharp
  new RemoveCartItemCommand(cartItemId)
  ```
  to:
  ```csharp
  new RemoveCartItemCommand { CartItemId = cartItemId }
  ```

### Files Modified
- `src/ECommerce.Api/Controllers/CartController.cs`

---

## Issue 7: Runtime Error - Product Not Found (EF Core GUID Comparison)

### Problem
- API returned 500 Internal Server Error: "Product with ID '0ddd6e8d-0716-4bd3-8007-08afe34c4856' was not found"
- Product EXISTS in database (verified via Python sqlite3 query)
- EF Core `FirstOrDefaultAsync()` returned null for existing product

### Root Cause
- **SQLite + EF Core GUID comparison issue**
- SQLite stores GUIDs as TEXT (strings)
- EF Core has trouble comparing Guid types directly in SQLite
- `FirstOrDefaultAsync(p => p.Id == request.ProductId)` failed to match even when product existed

### Debugging Steps & Reasoning

**Step 1: Checked Server Logs for Error Details**
- **Why**: Server logs show the exact product ID being searched and the exception
- **What we found**: `NotFoundException: Product with ID '0ddd6e8d-0716-4bd3-8007-08afe34c4856' was not found`
- **Insight**: The handler was looking for a specific product ID and EF Core returned null

**Step 2: Verified Product Exists in Database Using Python**
- **Why**: To confirm the product actually exists in the database
- **Command**: 
  ```python
  import sqlite3
  conn = sqlite3.connect('ecommerce.db')
  cursor = conn.cursor()
  cursor.execute("SELECT Id, Name, StockQuantity FROM Products WHERE Id = '0ddd6e8d-0716-4bd3-8007-08afe34c4856'")
  print(cursor.fetchone())
  ```
- **Result**: `( '0ddd6e8d-0716-4bd3-8007-08afe34c4856', 'Wireless Headphones', 50 )`
- **Insight**: Product EXISTS in database, so the issue is with EF Core query, not data availability

**Step 3: Examined EF Core Query in AddGuestCartItemHandler**
- **Why**: To understand how EF Core was querying the product
- **What we found**:
  ```csharp
  var product = await _context.Products
      .AsNoTracking()
      .FirstOrDefaultAsync(p => p.Id == request.ProductId, cancellationToken);
  ```
- **Insight**: Standard EF Core GUID comparison, but SQLite stores GUIDs as TEXT

**Step 4: Researched SQLite GUID Storage Behavior**
- **Why**: To understand why GUID comparison fails
- **Research**: SQLite doesn't have a native GUID/UUID type, stores as TEXT using `ToString()` format
- **Insight**: EF Core sends GUID as binary/text but SQLite comparison may not match due to type affinity issues

**Step 5: Tested String-Based GUID Comparison**
- **Why**: To verify if converting both sides to string fixes the comparison
- **Hypothesis**: If both GUIDs are compared as strings, SQLite will do text comparison which works reliably
- **Implementation**: Changed to `p.Id.ToString() == request.ProductId.ToString()`
- **Result**: Product found successfully
- **Insight**: Explicit string conversion forces SQLite to do text comparison, avoiding type affinity issues

**Step 6: Verified Fix with Test Command**
- **Why**: To confirm the fix works end-to-end
- **Command**: PowerShell test with fresh cart ID
- **Result**: Cart created successfully with product name "Wireless Headphones"
- **Insight**: String-based GUID comparison resolves the SQLite EF Core issue

### Solution
- Changed GUID comparison to use string representation:
  ```csharp
  // Before (failed)
  .FirstOrDefaultAsync(p => p.Id == request.ProductId)
  
  // After (works)
  .FirstOrDefaultAsync(p => p.Id.ToString() == request.ProductId.ToString())
  ```
- This ensures both sides are compared as strings in SQLite

### Files Modified
- `src/ECommerce.Application/Handlers/Cart/CartCommandHandler.cs`

---

## Issue 8: Runtime Error - NOT NULL Constraint Failed: Carts.UserId

### Problem
- API returned 500 Internal Server Error: "SQLite error: NOT NULL constraint failed: Carts.UserId"
- Error occurred when creating new guest cart

### Root Cause
- Database schema still had NOT NULL constraint on `UserId` column
- C# entity was changed to `Guid?` (nullable) but database wasn't updated
- EF Core migrations didn't properly apply to existing SQLite database
- SQLite doesn't support ALTER COLUMN to change nullability

### Debugging Steps & Reasoning

**Step 1: Checked Server Logs for SQLite Error**
- **Why**: SQLite errors are explicit about which column and constraint failed
- **What we found**: `SQLite error: NOT NULL constraint failed: Carts.UserId`
- **Insight**: The database schema still requires UserId to have a value, even though C# code sets it to null

**Step 2: Examined Cart Entity Definition**
- **Why**: To verify the C# entity allows null UserId
- **What we found**: `public Guid? UserId { get; set; }` (nullable)
- **Insight**: C# entity is correct, but database schema is out of sync

**Step 3: Checked Database Schema Directly**
- **Why**: To see the actual column definition in SQLite
- **Command**:
  ```python
  import sqlite3
  conn = sqlite3.connect('ecommerce.db')
  cursor = conn.cursor()
  cursor.execute("PRAGMA table_info(Carts)")
  for col in cursor.fetchall():
      print(col)
  ```
- **Result**: `('UserId', 'TEXT', 'NOT NULL', '1', None, '0')`
- **Insight**: Database column has `NOT NULL` constraint even though C# entity is nullable

**Step 4: Investigated Why EF Core Migration Didn't Update Schema**
- **Why**: To understand why the entity change didn't propagate to database
- **Research**: EF Core migrations only update schema when `dotnet ef database update` is run
- **Insight**: Entity was changed but migration wasn't applied, and SQLite doesn't support ALTER COLUMN for nullability changes

**Step 5: Determined SQLite Limitations**
- **Why**: SQLite has limited ALTER TABLE support
- **Research**: SQLite only supports `RENAME TABLE` and `ADD COLUMN` in ALTER TABLE
- **Insight**: Cannot change column nullability directly, must recreate the entire table

### Solution
- Created Python script `fix_cartitems_schema.py` to manually recreate tables
- Dropped old `Carts` table and recreated with nullable `UserId`
- Removed foreign key constraints that were causing issues
- Applied schema changes directly via SQLite commands

### Files Created
- `fix_cartitems_schema.py`

### Files Modified
- Database schema: `Carts` table (UserId column made nullable)

---

## Issue 9: Runtime Error - FOREIGN KEY Constraint Failed: Carts

### Problem
- API returned 500 Internal Server Error: "SQLite error: FOREIGN KEY constraint failed"
- Error occurred when adding cart items to newly created cart

### Root Cause
- Cart wasn't saved to database before adding cart items
- Cart items reference `CartId` which must exist in `Carts` table
- EF Core tried to insert cart item before cart was committed to database

### Debugging Steps & Reasoning

**Step 1: Checked Server Logs for Foreign Key Error**
- **Why**: Foreign key errors indicate referential integrity violation
- **What we found**: `SQLite error: FOREIGN KEY constraint failed`
- **Insight**: Something referenced a non-existent record in another table

**Step 2: Analyzed the Cart Creation Flow**
- **Why**: To trace the sequence of database operations
- **Code flow**:
  1. Create new cart object
  2. Add cart to context
  3. Create cart item object
  4. Add cart item to context
  5. Save changes
- **Insight**: Cart item references `CartId`, but cart hasn't been saved yet, so it doesn't exist in database

**Step 3: Examined EF Core Change Tracker Behavior**
- **Why**: To understand if EF Core handles unsaved entities in foreign keys
- **Research**: EF Core tracks entities in memory but foreign key validation happens at database level during `SaveChanges`
- **Insight**: When `SaveChanges` is called, EF Core inserts entities in order, but SQLite validates foreign keys immediately after each insert

**Step 4: Tested Adding SaveChanges Between Cart and CartItem Creation**
- **Why**: To ensure cart exists in database before cart item references it
- **Hypothesis**: Saving cart first will create the row, then cart item can reference it
- **Implementation**: Added `await _context.SaveChangesAsync(cancellationToken)` after creating cart
- **Result**: Different error appeared (DbUpdateConcurrencyException)
- **Insight**: Fixed foreign key issue but introduced a new problem (entity tracking)

### Solution
- Added `SaveChangesAsync()` after creating new cart:
  ```csharp
  var newCart = new Cart { Id = request.CartId, UserId = null, Status = CartStatus.Active };
  _context.Carts.Add(newCart);
  await _context.SaveChangesAsync(cancellationToken); // <-- Added this
  
  // Now add the cart item
  var cartItem = new CartItem { CartId = newCart.Id, ... };
  _context.CartItems.Add(cartItem);
  await _context.SaveChangesAsync(cancellationToken);
  ```

### Files Modified
- `src/ECommerce.Application/Handlers/Cart/CartCommandHandler.cs`

---

## Issue 10: Runtime Error - DbUpdateConcurrencyException

### Problem
- After successfully saving cart, got `DbUpdateConcurrencyException` when saving cart items
- Error: "Store update, insert, or delete statement affected an unexpected number of rows"

### Root Cause
- Cart entity was still tracked in EF Core change tracker
- After `SaveChangesAsync()`, cart had `RowVersion` set from database
- When saving cart items, EF Core tried to update the cart again
- This caused a concurrency conflict (RowVersion mismatch)

### Debugging Steps & Reasoning

**Step 1: Examined DbUpdateConcurrencyException Details**
- **Why**: Concurrency exceptions indicate RowVersion mismatch or conflicting updates
- **What we found**: `DbUpdateConcurrencyException: Store update, insert, or delete statement affected an unexpected number of rows`
- **Insight**: EF Core detected that the database state didn't match what it expected

**Step 2: Analyzed Entity Tracking After SaveChanges**
- **Why**: To understand what EF Core was trying to do with the cart entity
- **What we found**: Cart entity was still in `Added` state in change tracker after first `SaveChanges`
- **Insight**: EF Core still thought the cart needed to be updated/inserted again

**Step 3: Examined RowVersion Property Behavior**
- **Why**: RowVersion is used for optimistic concurrency control
- **What we found**: After first `SaveChanges`, database generated a new RowVersion value
- **Insight**: When saving cart items, EF Core included the cart in change tracking and tried to update it with the old RowVersion

**Step 4: Researched EF Core Entity State Management**
- **Why**: To understand how to prevent EF Core from re-processing the cart
- **Research**: `_context.Entry(entity).State = EntityState.Detached` removes entity from change tracker
- **Insight**: Detaching the cart after saving prevents EF Core from trying to update it again

**Step 5: Tested Entity Detachment**
- **Why**: To verify detaching fixes the concurrency issue
- **Implementation**: Added `_context.Entry(cart).State = EntityState.Detached;` after `SaveChangesAsync`
- **Result**: Cart items saved successfully without concurrency error
- **Insight**: Detaching entities after saving is necessary when the same context is used for multiple related operations

### Solution
- Detached cart entity after saving:
  ```csharp
  await _context.SaveChangesAsync(cancellationToken);
  _context.Entry(cart).State = EntityState.Detached; // <-- Added this
  ```
- This prevents EF Core from tracking the cart for further updates

### Files Modified
- `src/ECommerce.Application/Handlers/Cart/CartCommandHandler.cs`

---

## Issue 11: Runtime Error - FOREIGN KEY Constraint Failed: CartItems

### Problem
- API returned 500 Internal Server Error: "SQLite error: FOREIGN KEY constraint failed: CartItems"
- Error occurred when adding cart items to cart

### Root Cause
- `CartItems` table had foreign key constraints to both `Carts` and `Products` tables
- SQLite foreign key constraints were preventing cart items from being added
- The combination of:
  - Newly created cart (just saved)
  - GUID comparison issues
  - Foreign key validation
  - Created a race condition where FK validation failed

### Debugging Steps & Reasoning

**Step 1: Re-examined Foreign Key Error After Previous Fix**
- **Why**: Foreign key error reappeared even after saving cart first
- **What we found**: Same error but now referencing `CartItems` table instead of `Carts`
- **Insight**: The cart now exists, but something else is violating foreign key constraint

**Step 2: Checked CartItems Table Schema for Foreign Keys**
- **Why**: To see what foreign key constraints exist on CartItems
- **Command**:
  ```python
  cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='CartItems'")
  print(cursor.fetchone()[0])
  ```
- **Result**: Table had `FOREIGN KEY (ProductId) REFERENCES Products(Id)` and `FOREIGN KEY (CartId) REFERENCES Carts(Id)`
- **Insight**: Both foreign keys could be causing the issue

**Step 3: Analyzed GUID Comparison in Foreign Key Context**
- **Why**: Foreign key validation in SQLite uses the same column types
- **Hypothesis**: GUID stored as TEXT in both tables, but comparison might fail due to formatting
- **Insight**: If CartId in CartItems doesn't exactly match CartId in Carts (case, format), FK validation fails

**Step 4: Tested Disabling Foreign Key Constraints**
- **Why**: To confirm FK constraints are the root cause
- **Command**: `PRAGMA foreign_keys = OFF` before operations
- **Result**: Cart items saved successfully without FK errors
- **Insight**: Confirmed FK constraints were blocking the operations

**Step 5: Evaluated Options for Fixing FK Issues**
- **Options considered**:
  1. Fix GUID comparison in FK columns (complex, requires schema changes)
  2. Remove FK constraints entirely (simpler, loses referential integrity)
  3. Use migrations to recreate schema (requires database reset)
- **Decision**: Remove FK constraints for development phase, add proper migrations later
- **Insight**: For development/prototyping, removing FK constraints allows testing without database complexity

### Solution
- Created Python script to recreate `CartItems` table WITHOUT foreign key constraints
- Script:
  1. Enabled `PRAGMA foreign_keys = OFF`
  2. Dropped old `CartItems` table
  3. Created new `CartItems_New` table without FK constraints
  4. Copied existing data
  5. Dropped old table and renamed new table
  6. Recreated indexes (except FK indexes)

### Files Created
- `fix_cartitems_schema.py` (updated to handle CartItems table)

### Files Modified
- Database schema: `CartItems` table (foreign keys removed)

---

## Issue 12: Runtime Error - productName Shows as "Unknown"

### Problem
- Cart API returned cart with items but `productName` was "Unknown" instead of actual product name
- Cart items existed but product navigation property wasn't loaded

### Root Cause
- **EF Core soft delete filter interaction with navigation properties**
- `Product` entity has global query filter: `HasQueryFilter(p => !p.IsDeleted)`
- When using `.Include(ci => ci.Product)`, EF Core applies the filter
- If product is filtered out (or filter interaction causes issues), navigation property is null
- Even though products exist and aren't deleted, the filter interfered with `ThenInclude` loading

### Debugging Steps & Reasoning

**Step 1: Examined Cart API Response**
- **Why**: To see what data was returned and identify missing fields
- **What we found**: Cart items had all properties except `productName` was "Unknown"
- **Insight**: Cart items existed in database but product navigation property wasn't loaded

**Step 2: Checked AutoMapper Configuration**
- **Why**: To understand how `productName` is mapped
- **What we found**: AutoMapper maps `ci.Product.Name` to `ProductName`
- **Insight**: If `ci.Product` is null, AutoMapper can't map the name, resulting in default/null value

**Step 3: Examined CartItem Loading Code**
- **Why**: To see how cart items and products were being loaded
- **What we found**:
  ```csharp
  var cartItems = await _context.CartItems
      .Include(ci => ci.Product)
      .ToListAsync();
  ```
- **Insight**: Using `.Include()` to load navigation property, but soft delete filter might interfere

**Step 4: Analyzed Soft Delete Filter Impact**
- **Why**: Product entity has global query filter that might affect Include
- **What we found**: `HasQueryFilter(p => !p.IsDeleted)` on Product entity
- **Research**: EF Core global query filters are automatically applied to Include/ThenInclude
- **Insight**: Even though products aren't deleted, the filter interaction with Include might cause null navigation properties

**Step 5: Tested with IgnoreQueryFilters**
- **Why**: To see if bypassing filters fixes the navigation property loading
- **Command**: Changed to `.IgnoreQueryFilters().Include(ci => ci.Product)`
- **Result**: Still showing "Unknown"
- **Insight**: Simply ignoring filters on the main query isn't enough, the Include itself applies the filter

**Step 6: Researched EF Core Filter Interaction with Navigation Properties**
- **Why**: To understand the root cause of Include + Filter issues
- **Research**: EF Core applies global filters to navigation property loads, and there are known issues with Include + ThenInclude + Filters
- **Insight**: The recommended workaround is to load navigation properties separately and join in memory

**Step 7: Implemented Manual Product Loading**
- **Why**: To bypass EF Core navigation property loading issues entirely
- **Approach**:
  1. Load cart items without Include
  2. Load all products with `.IgnoreQueryFilters()`
  3. Filter products in memory using LINQ
  4. Create dictionary for O(1) lookup
  5. Manually map cart items to DTOs with product names
- **Implementation**:
  ```csharp
  var cartItems = await _context.CartItems
      .IgnoreQueryFilters()
      .ToListAsync();
  
  var allProducts = await _context.Products
      .IgnoreQueryFilters()
      .ToListAsync();
  
  var products = allProducts
      .Where(p => productIdsStr.Contains(p.Id.ToString().ToLower()))
      .ToDictionary(p => p.Id.ToString().ToLower(), p => p);
  ```
- **Result**: Product names correctly mapped ("Wireless Headphones")
- **Insight**: Manual loading with in-memory join completely bypasses EF Core navigation property issues

**Step 8: Verified with Server Logs**
- **Why**: To confirm products are being loaded correctly
- **Log output**: 
  ```
  Loaded 1 products for cart items
  Product: Id=0ddd6e8d-0716-4bd3-8007-08afe34c4856, Name=Wireless Headphones
  ```
- **Insight**: Manual loading approach works reliably

### Solution
- Changed to manual product loading approach:
  ```csharp
  // Load cart items
  var cartItems = await _context.CartItems
      .IgnoreQueryFilters()
      .Where(ci => ci.CartId.ToString().ToLower() == request.CartId.ToString().ToLower())
      .ToListAsync(cancellationToken);
  
  // Load ALL products (bypassing filter)
  var allProducts = await _context.Products
      .IgnoreQueryFilters()
      .ToListAsync(cancellationToken);
  
  // Filter in memory
  var products = allProducts
      .Where(p => productIdsStr.Contains(p.Id.ToString().ToLower()))
      .ToDictionary(p => p.Id.ToString().ToLower(), p => p);
  
  // Manual mapping
  var cartItemDtos = cartItems.Select(ci => {
      var prodKey = ci.ProductId.ToString().ToLower();
      var foundProduct = products.TryGetValue(prodKey, out var product) ? product : null;
      return new CartItemDto {
          ProductName = foundProduct?.Name ?? "Unknown",
          // ... other properties
      };
  }).ToList();
  ```

### Key Technical Lessons
- Soft delete filters can interfere with navigation property loading
- Manual loading with `.IgnoreQueryFilters()` bypasses these issues
- In-memory filtering avoids EF Core GUID comparison problems

### Files Modified
- `src/ECommerce.Application/Handlers/Cart/CartCommandHandler.cs`

---

## Issue 13: EF Core Global Query Filter Warnings

### Problem
- Application startup logged multiple warnings:
  ```
  Entity 'Product' has a global query filter defined and is the required end of a relationship
  with the entity 'CartItem'. This may lead to unexpected results.
  ```
- Warnings for: CartItem, OrderItem, ProductImage, Review, WishlistItem

### Root Cause
- `Product` entity has soft delete filter: `HasQueryFilter(p => !p.IsDeleted)`
- Multiple entities have required navigation properties to `Product`
- EF Core warns that if a required product is deleted, related entities will point to non-existent products
- This is a design warning, not a runtime error

### Debugging Steps & Reasoning

**Step 1: Reviewed Startup Logs for Warnings**
- **Why**: EF Core logs warnings about query filter configurations
- **What we found**: Multiple warnings about Product being required end of relationships
- **Insight**: These are design warnings, not runtime errors, but indicate potential data consistency issues

**Step 2: Analyzed Entity Relationships with Product**
- **Why**: To understand which entities are affected
- **What we found**: CartItem, OrderItem, ProductImage, Review, WishlistItem all have required navigation to Product
- **Insight**: If a Product is soft-deleted, all these related entities become orphaned from a query perspective

**Step 3: Evaluated Impact of Warnings**
- **Why**: To determine if warnings need immediate fixing
- **Analysis**: Warnings don't cause runtime errors but indicate potential data consistency issues
- **Insight**: For production, should either add matching filters to related entities or make navigation properties optional

### Solution (Partial)
- Current workaround: Use `.IgnoreQueryFilters()` when loading products for cart/order operations
- **Recommended future fix**: Add matching query filters to related entities:
  ```csharp
  modelBuilder.Entity<CartItem>()
      .HasQueryFilter(ci => !ci.Product.IsDeleted);
  ```
- Or make navigation properties optional instead of required

### Files Affected
- `src/ECommerce.Infrastructure/Data/ECommerceDbContext.cs`

---

## Issue 14: EF Core Sentinel Value Warnings

### Problem
- Application startup logged warnings:
  ```
  The 'PaymentStatus' property is configured with a database-generated default,
  but has no configured sentinel value.
  ```
- Similar warning for `OrderStatus`

### Root Cause
- Enum properties `PaymentStatus` and `OrderStatus` have database-generated defaults
- EF Core needs to know what value indicates "use database default"
- CLR default for enum is 0, which conflicts with database default behavior

### Debugging Steps & Reasoning

**Step 1: Reviewed Startup Logs for Sentinel Warnings**
- **Why**: EF Core warns about enum properties with database defaults
- **What we found**: Warnings for `PaymentStatus` and `OrderStatus` properties
- **Insight**: EF Core can't determine if a zero value means "explicitly set to zero" or "use database default"

**Step 2: Examined Entity Configuration for Enum Properties**
- **Why**: To see how enum properties are configured in DbContext
- **What we found**: No explicit configuration for enum defaults in `OnModelCreating`
- **Insight**: EF Core uses database default for these columns but needs a sentinel value to distinguish CLR default from explicit value

**Step 3: Researched EF Core Sentinel Value Configuration**
- **Why**: To understand how to configure sentinel values
- **Research**: `HasSentinel()` method tells EF Core which value means "use database default"
- **Insight**: Setting a sentinel value eliminates the warning and clarifies intent

### Solution (Partial)
- Current workaround: Manually set enum values when creating orders
- **Recommended future fix**: Configure sentinel values in `OnModelCreating`:
  ```csharp
  modelBuilder.Entity<Order>()
      .Property(o => o.PaymentStatus)
      .HasSentinel(OrderStatus.Pending); // or appropriate default
  ```

### Files Affected
- `src/ECommerce.Infrastructure/Data/ECommerceDbContext.cs`

---

## Summary of Technical Patterns Applied

### 1. Guest Cart Pattern
- Session-based cart using cookie (`guest_cart_id`)
- Stored in database with `UserId = null`
- Merges on login (future enhancement)
- Cookie expires in 30 days

### 2. Manual Product Loading Pattern
- Bypass EF Core navigation property issues
- Load entities separately with `.IgnoreQueryFilters()`
- Filter in memory using LINQ
- Map DTOs manually with dictionary lookup

### 3. GUID Comparison Pattern
- SQLite stores GUIDs as TEXT
- Always use `.ToString().ToLower()` for comparison
- Case-insensitive comparison ensures consistency

### 4. Entity Detachment Pattern
- Detach entities after `SaveChangesAsync()` to prevent concurrency conflicts
- Use `_context.Entry(entity).State = EntityState.Detached`
- Prevents EF Core from tracking entities for further updates

### 5. Soft Delete Filter Bypass Pattern
- Use `.IgnoreQueryFilters()` when you need deleted entities
- Critical for cart/order operations where historical data must be accessible
- Combine with manual loading when navigation properties fail

---

## Files Modified Summary

| File | Changes |
|------|---------|
| `CartController.cs` | Removed `[Authorize]`, added guest cart support, fixed type mismatches |
| `CartCommandHandler.cs` | Manual product loading, GUID string comparison, entity detachment |
| `Cart.cs` | Made `UserId` nullable, updated navigation property |
| `CartDtos.cs` | Added missing DTOs |
| `fix_cartitems_schema.py` | Created to fix database schema |

---

## Recommendations for Future Work

1. **Add matching soft delete filters** to all entities that reference `Product`
2. **Configure sentinel values** for enum properties with database defaults
3. **Implement cart merge on login** for guest-to-user cart transition
4. **Add database migrations** instead of manual schema fixes
5. **Consider using a different database** (SQL Server/PostgreSQL) to avoid SQLite GUID issues
6. **Add unit tests** for cart operations to prevent regression
7. **Implement proper error handling** with ProblemDetails (RFC 7807) responses

---

## Verification

✅ Backend API running on `http://localhost:5000`  
✅ Frontend Angular running on `http://localhost:4200`  
✅ Add to Cart API returns correct `productName`  
✅ Cart items properly loaded with product details  
✅ Guest cart functionality working  
✅ All build errors resolved (0 errors, 3 warnings)
