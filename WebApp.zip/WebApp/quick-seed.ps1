# Quick seed script - runs everything in one session
$baseUrl = "http://localhost:5000/api/v1"

# Login
Write-Host "Logging in..." -ForegroundColor Cyan
$loginBody = '{"email":"test@ecommerce.com","password":"Test@123"}'
$login = Invoke-RestMethod -Uri "$baseUrl/auth/login" -Method Post -Body $loginBody -ContentType "application/json; charset=utf-8" -UseBasicParsing
$token = $login.accessToken
$headers = @{"Authorization" = "Bearer $token"; "Content-Type" = "application/json"}
Write-Host "Login successful!" -ForegroundColor Green

# Create categories
Write-Host "`nCreating categories..." -ForegroundColor Cyan
$catData = @(
    @{name="Electronics"; description="Electronic devices and gadgets"; slug="electronics"},
    @{name="Clothing"; description="Fashion and apparel"; slug="clothing"},
    @{name="HomeGarden"; description="Home improvement and garden supplies"; slug="home-garden"},
    @{name="Books"; description="Books and publications"; slug="books"},
    @{name="Sports"; description="Sports equipment and accessories"; slug="sports"},
    @{name="Toys"; description="Toys and games for all ages"; slug="toys"}
)
$catIds = @{}
foreach ($c in $catData) {
    $r = Invoke-RestMethod -Uri "$baseUrl/categories" -Method Post -Headers $headers -Body ($c | ConvertTo-Json) -UseBasicParsing
    $catIds[$c.name] = $r.id
    Write-Host "  Created: $($c.name) (ID: $($r.id))" -ForegroundColor Green
}

# Create products
Write-Host "`nCreating products..." -ForegroundColor Cyan
$prodData = @(
    @{name="Wireless Bluetooth Headphones"; description="Premium noise-cancelling wireless headphones with 30-hour battery life"; price=79.99; stockQuantity=150; categoryId=$catIds["Electronics"]; isFeatured=$true; isActive=$true; slug="wireless-bluetooth-headphones"},
    @{name="Smart Watch Pro"; description="Advanced smartwatch with health monitoring and GPS tracking"; price=299.99; stockQuantity=75; categoryId=$catIds["Electronics"]; isFeatured=$true; isActive=$true; slug="smart-watch-pro"},
    @{name="4K Ultra HD Smart TV"; description="55-inch 4K Smart TV with HDR and built-in streaming apps"; price=599.99; stockQuantity=30; categoryId=$catIds["Electronics"]; isFeatured=$true; isActive=$true; slug="4k-ultra-hd-smart-tv"},
    @{name="Laptop Backpack"; description="Water-resistant laptop backpack with USB charging port"; price=49.99; stockQuantity=200; categoryId=$catIds["Clothing"]; isFeatured=$true; isActive=$true; slug="laptop-backpack"},
    @{name="Men Casual T-Shirt"; description="Comfortable cotton blend t-shirt available in multiple colors"; price=24.99; stockQuantity=500; categoryId=$catIds["Clothing"]; isFeatured=$false; isActive=$true; slug="mens-casual-tshirt"},
    @{name="Running Shoes"; description="Lightweight running shoes with advanced cushioning technology"; price=129.99; stockQuantity=100; categoryId=$catIds["Clothing"]; isFeatured=$true; isActive=$true; slug="running-shoes"},
    @{name="Garden Tool Set"; description="Complete 10-piece garden tool set with carrying case"; price=89.99; stockQuantity=60; categoryId=$catIds["HomeGarden"]; isFeatured=$false; isActive=$true; slug="garden-tool-set"},
    @{name="Smart LED Light Bulbs 4-Pack"; description="WiFi-enabled color-changing LED bulbs compatible with voice assistants"; price=39.99; stockQuantity=300; categoryId=$catIds["HomeGarden"]; isFeatured=$true; isActive=$true; slug="smart-led-light-bulbs"},
    @{name="Programming Python Book"; description="Comprehensive guide to Python programming for beginners and advanced developers"; price=44.99; stockQuantity=150; categoryId=$catIds["Books"]; isFeatured=$false; isActive=$true; slug="programming-python-book"},
    @{name="Fitness Resistance Bands Set"; description="Set of 5 resistance bands with different tension levels for home workouts"; price=29.99; stockQuantity=250; categoryId=$catIds["Sports"]; isFeatured=$false; isActive=$true; slug="fitness-resistance-bands"},
    @{name="Yoga Mat Premium"; description="Non-slip exercise yoga mat with carrying strap"; price=34.99; stockQuantity=180; categoryId=$catIds["Sports"]; isFeatured=$false; isActive=$true; slug="yoga-mat-premium"},
    @{name="Building Blocks Set"; description="500-piece creative building blocks set for kids ages 6+"; price=49.99; stockQuantity=120; categoryId=$catIds["Toys"]; isFeatured=$false; isActive=$true; slug="building-blocks-set"}
)

foreach ($p in $prodData) {
    try {
        $r = Invoke-RestMethod -Uri "$baseUrl/products" -Method Post -Headers $headers -Body ($p | ConvertTo-Json -Depth 5) -UseBasicParsing
        Write-Host "  Created: $($p.name) (ID: $($r.id))" -ForegroundColor Green
    } catch {
        Write-Host "  Error: $($p.name) - $_" -ForegroundColor Red
    }
}

Write-Host "`n=== DONE! ===" -ForegroundColor Green
