# ECommerce Application - Local Development Setup

## Prerequisites

- [.NET 9 SDK](https://dotnet.microsoft.com/download/dotnet/9.0)
- [SQL Server Express](https://www.microsoft.com/en-us/sql-server/sql-server-downloads) or Docker
- [Node.js 18+](https://nodejs.org/) (for Angular frontend)
- [Docker Desktop](https://www.docker.com/products/docker-desktop) (optional, for containerized deployment)

## Quick Start

### Option 1: Local Development (Without Docker)

1. **Restore and Build**
```powershell
cd c:\Users\XPY1KOR\Desktop\WebApp
dotnet restore
dotnet build
```

2. **Configure Database**
   - Install SQL Server Express
   - Update connection string in `src/ECommerce.Api/appsettings.json`:
   ```json
   {
     "ConnectionStrings": {
       "DefaultConnection": "Server=localhost;Database=ECommerceDb;Trusted_Connection=True;TrustServerCertificate=True;"
     }
   }
   ```

3. **Run Database Migrations**
```powershell
dotnet ef database update --project src/ECommerce.Infrastructure --startup-project src/ECommerce.Api
```

4. **Run the Application**
```powershell
cd src/ECommerce.Api
dotnet run
```

5. **Access the Application**
   - API: http://localhost:5000
   - Swagger UI: http://localhost:5000/swagger
   - Health Check: http://localhost:5000/health

### Option 2: Docker Deployment (Recommended)

1. **Build and Start All Services**
```powershell
.\deploy.ps1
```

This will:
- Build Docker images
- Start SQL Server, Redis, Seq, and API
- Run database migrations
- Start the application

2. **Access the Application**
   - API: http://localhost:5000
   - Swagger UI: http://localhost:5000/swagger
   - Hangfire Dashboard: http://localhost:8081
   - Seq Logging: http://localhost:5341

3. **View Logs**
```powershell
# View API logs
docker compose logs -f api

# View all logs
docker compose logs -f
```

4. **Stop Services**
```powershell
docker compose down
```

## Frontend Setup

1. **Navigate to frontend directory**
```powershell
cd frontend
```

2. **Install dependencies**
```powershell
npm install
```

3. **Start Angular development server**
```powershell
npm start
```

4. **Access the frontend**
   - Angular App: http://localhost:4200

## Environment Configuration

### Required Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `ConnectionStrings__DefaultConnection` | SQL Server connection string | - |
| `Jwt__Key` | JWT signing key (min 32 chars) | - |
| `Jwt__Issuer` | JWT issuer | ECommerceAPI |
| `Jwt__Audience` | JWT audience | https://localhost:5000 |
| `Redis__ConnectionString` | Redis connection string | redis:6379 |
| `Seq__ServerUrl` | Seq logging server URL | http://seq:80 |

### Production Deployment

For production deployment:

1. Update `appsettings.Production.json` with production values
2. Set `ASPNETCORE_ENVIRONMENT=Production`
3. Use strong secrets for JWT key
4. Configure proper SSL/TLS certificates
5. Set up proper database backup strategy

## API Endpoints

### Health Checks
- `GET /health` - Basic health check
- `GET /health/ready` - Readiness check
- `GET /health/alive` - Liveness check

### API Version 1
- `GET /api/v1/products` - Get products
- `POST /api/v1/auth/register` - Register user
- `POST /api/v1/auth/login` - Login user
- `GET /api/v1/cart` - Get shopping cart
- `POST /api/v1/orders` - Create order

See Swagger UI at http://localhost:5000/swagger for complete API documentation.

## Troubleshooting

### SQL Server Connection Issues
```powershell
# Check if SQL Server is running
docker ps | findstr sqlserver

# View SQL Server logs
docker compose logs sqlserver

# Restart SQL Server
docker compose restart sqlserver
```

### Port Already in Use
```powershell
# Find process using port 5000
netstat -ano | findstr :5000

# Kill the process (replace PID)
taskkill /PID <PID> /F
```

### Database Migration Errors
```powershell
# Rollback last migration
dotnet ef migrations remove --project src/ECommerce.Infrastructure --startup-project src/ECommerce.Api

# Apply migrations
dotnet ef database update --project src/ECommerce.Infrastructure --startup-project src/ECommerce.Api
```

## Project Structure

```
ECommerceApplication/
├── src/
│   ├── ECommerce.Api/           # ASP.NET Core Web API
│   ├── ECommerce.Core/          # Domain layer
│   ├── ECommerce.Application/   # Application layer
│   ├── ECommerce.Infrastructure/ # Infrastructure layer
│   └── ECommerce.Shared/        # Shared utilities
├── frontend/                    # Angular frontend
├── tests/                       # Test projects
├── Dockerfile                   # Docker build configuration
├── docker-compose.yml           # Docker Compose configuration
├── deploy.ps1                   # Deployment script
└── README.md                    # This file
```

## Testing

### Run Unit Tests
```powershell
dotnet test tests/
```

### Run API Tests with Postman/Newman
```powershell
# Import Postman collection and run
newman run ECommerce-API.postman_collection.json
```

## Support

For issues or questions:
1. Check the logs: `docker compose logs -f`
2. Review Swagger documentation: http://localhost:5000/swagger
3. Check health endpoints: http://localhost:5000/health
