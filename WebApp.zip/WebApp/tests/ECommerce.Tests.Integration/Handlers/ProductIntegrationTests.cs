namespace ECommerce.Tests.Integration.Handlers;

using ECommerce.Application.Commands.Products;
using ECommerce.Application.Handlers.Products;
using ECommerce.Application.Profiles;
using ECommerce.Core.Entities;
using ECommerce.Core.Interfaces;
using ECommerce.Infrastructure.Data;
using ECommerce.Infrastructure.Repositories;
using ECommerce.Infrastructure.UnitOfWork;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using AutoMapper;

public class ProductIntegrationTests
{
    private readonly ECommerceDbContext _dbContext;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    private readonly ILogger<ProductCommandHandler> _logger;

    public ProductIntegrationTests()
    {
        var options = new DbContextOptionsBuilder<ECommerceDbContext>()
            .UseInMemoryDatabase("ECommerceTestDb")
            .Options;

        _dbContext = new ECommerceDbContext(options);
        _unitOfWork = new UnitOfWork(_dbContext);
        
        var configuration = new MapperConfiguration(cfg =>
        {
            cfg.AddProfile<ProductProfile>();
        });
        _mapper = configuration.CreateMapper();
        _logger = new Mock<ILogger<ProductCommandHandler>>().Object;
    }

    [Fact]
    public async Task CreateProduct_ShouldSaveToDatabase()
    {
        // Arrange
        var command = new CreateProductCommand
        {
            Name = "Integration Test Product",
            Description = "Testing database integration",
            Price = 49.99m,
            StockQuantity = 50,
            CategoryId = Guid.NewGuid(),
            Sku = "INT-001"
        };

        // Act
        var handler = new ProductCommandHandler(
            new Repository<Product>(_dbContext),
            _unitOfWork,
            _logger,
            _mapper);
        
        var result = await handler.Handle(command, CancellationToken.None);

        // Assert
        result.Should().NotBeNull();
        result.Name.Should().Be("Integration Test Product");
        
        var savedProduct = await _dbContext.Products
            .FirstOrDefaultAsync(p => p.Sku == "INT-001");
        
        savedProduct.Should().NotBeNull();
        savedProduct!.Name.Should().Be("Integration Test Product");
    }

    [Fact]
    public async Task GetProductById_ShouldReturnProduct()
    {
        // Arrange
        var product = new Product
        {
            Id = Guid.NewGuid(),
            Name = "Test Product",
            Description = "Test",
            Price = 29.99m,
            StockQuantity = 10,
            Sku = "GET-001",
            Slug = "test-product"
        };
        
        _dbContext.Products.Add(product);
        await _dbContext.SaveChangesAsync();

        // Act
        var handler = new GetProductByIdQueryHandler(
            new Repository<Product>(_dbContext),
            _mapper,
            _logger);
        
        var result = await handler.Handle(
            new GetProductByIdQuery { Id = product.Id },
            CancellationToken.None);

        // Assert
        result.Should().NotBeNull();
        result!.Name.Should().Be("Test Product");
    }

    [Fact]
    public async Task DeleteProduct_ShouldRemoveFromDatabase()
    {
        // Arrange
        var product = new Product
        {
            Id = Guid.NewGuid(),
            Name = "Delete Test",
            Description = "To be deleted",
            Price = 19.99m,
            StockQuantity = 5,
            Sku = "DEL-001",
            Slug = "delete-test",
            IsActive = true
        };
        
        _dbContext.Products.Add(product);
        await _dbContext.SaveChangesAsync();

        // Act
        var handler = new DeleteProductCommandHandler(
            new Repository<Product>(_dbContext),
            _unitOfWork,
            _logger);
        
        await handler.Handle(new DeleteProductCommand { Id = product.Id }, CancellationToken.None);

        // Assert
        var deletedProduct = await _dbContext.Products
            .FirstOrDefaultAsync(p => p.Id == product.Id);
        
        deletedProduct.Should().BeNull();
    }

    public void Dispose()
    {
        _dbContext.Database.EnsureDeleted();
        _dbContext.Dispose();
    }
}
