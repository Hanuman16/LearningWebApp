namespace ECommerce.Tests.Unit.Handlers;

using ECommerce.Application.Commands.Auth;
using ECommerce.Application.Handlers.Auth;
using ECommerce.Core.Interfaces;
using ECommerce.Core.Entities;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;

public class AuthCommandHandlerTests
{
    private readonly Mock<IUserRepository> _mockUserRepository;
    private readonly Mock<IUnitOfWork> _mockUnitOfWork;
    private readonly Mock<ILogger<AuthCommandHandler>> _mockLogger;
    private readonly AuthCommandHandler _handler;

    public AuthCommandHandlerTests()
    {
        _mockUserRepository = new Mock<IUserRepository>();
        _mockUnitOfWork = new Mock<IUnitOfWork>();
        _mockLogger = new Mock<ILogger<AuthCommandHandler>>();
        
        _handler = new AuthCommandHandler(
            _mockUserRepository.Object,
            _mockUnitOfWork.Object,
            _mockLogger.Object,
            new JwtSettings
            {
                Issuer = "test-issuer",
                Audience = "test-audience",
                Key = "ThisIsASecretKeyForTestingPurposesOnly123456789!",
                ExpiryMinutes = 60
            });
    }

    [Fact]
    public async Task Handle_ValidRegisterCommand_ReturnsUserDto()
    {
        // Arrange
        var command = new RegisterCommand
        {
            FirstName = "John",
            LastName = "Doe",
            Email = "john.doe@example.com",
            Password = "Password123!",
            PhoneNumber = "1234567890"
        };

        _mockUserRepository.Setup(x => x.GetByEmailAsync(It.IsAny<string>()))
            .ReturnsAsync((User?)null);

        _mockUnitOfWork.Setup(x => x.SaveChangesAsync())
            .ReturnsAsync(1);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Should().NotBeNull();
        result.FirstName.Should().Be("John");
        result.LastName.Should().Be("Doe");
        result.Email.Should().Be("john.doe@example.com");
    }

    [Fact]
    public async Task Handle_DuplicateEmail_ThrowsException()
    {
        // Arrange
        var command = new RegisterCommand
        {
            FirstName = "John",
            LastName = "Doe",
            Email = "john.doe@example.com",
            Password = "Password123!",
            PhoneNumber = "1234567890"
        };

        var existingUser = new User
        {
            Id = Guid.NewGuid(),
            FirstName = "Existing",
            LastName = "User",
            Email = "john.doe@example.com",
            PasswordHash = "hashedpassword"
        };

        _mockUserRepository.Setup(x => x.GetByEmailAsync(It.IsAny<string>()))
            .ReturnsAsync(existingUser);

        // Act & Assert
        await Assert.ThrowsAsync<Core.Exceptions.ValidationException>(() =>
            _handler.Handle(command, CancellationToken.None));
    }

    [Fact]
    public async Task Handle_ValidLoginCommand_ReturnsTokenResponse()
    {
        // Arrange
        var command = new LoginCommand
        {
            Email = "john.doe@example.com",
            Password = "Password123!"
        };

        var user = new User
        {
            Id = Guid.NewGuid(),
            FirstName = "John",
            LastName = "Doe",
            Email = "john.doe@example.com",
            PasswordHash = "hashedpassword",
            IsActive = true,
            EmailConfirmed = true
        };

        _mockUserRepository.Setup(x => x.GetByEmailAsync(It.IsAny<string>()))
            .ReturnsAsync(user);

        _mockUnitOfWork.Setup(x => x.SaveChangesAsync())
            .ReturnsAsync(1);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Should().NotBeNull();
        result.Should().BeOfType<TokenResponse>();
        var tokenResponse = (TokenResponse)result;
        tokenResponse.Token.Should().NotBeNullOrEmpty();
    }

    [Fact]
    public async Task Handle_InvalidPassword_ThrowsException()
    {
        // Arrange
        var command = new LoginCommand
        {
            Email = "john.doe@example.com",
            Password = "WrongPassword123!"
        };

        var user = new User
        {
            Id = Guid.NewGuid(),
            FirstName = "John",
            LastName = "Doe",
            Email = "john.doe@example.com",
            PasswordHash = "hashedpassword",
            IsActive = true
        };

        _mockUserRepository.Setup(x => x.GetByEmailAsync(It.IsAny<string>()))
            .ReturnsAsync(user);

        // Act & Assert
        await Assert.ThrowsAsync<Core.Exceptions.ValidationException>(() =>
            _handler.Handle(command, CancellationToken.None));
    }
}
