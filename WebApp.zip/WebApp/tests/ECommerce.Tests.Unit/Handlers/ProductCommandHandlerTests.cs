namespace ECommerce.Tests.Unit.Handlers;

using ECommerce.Application.Commands.Products;
using ECommerce.Application.Handlers.Products;
using ECommerce.Core.Interfaces;
using ECommerce.Core.Entities;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using AutoMapper;
using ECommerce.Application.Profiles;

public class ProductCommandHandlerTests
{
    private readonly Mock<IProductRepository> _mockProductRepository;
    private readonly Mock<IUnitOfWork> _mockUnitOfWork;
    private readonly Mock<ILogger<ProductCommandHandler>> _mockLogger;
    private readonly IMapper _mapper;
    private readonly ProductCommandHandler _handler;

    public ProductCommandHandlerTests()
    {
        _mockProductRepository = new Mock<IProductRepository>();
        _mockUnitOfWork = new Mock<IUnitOfWork>();
        _mockLogger = new Mock<ILogger<ProductCommandHandler>>();
        
        var configuration = new MapperConfiguration(cfg =>
        {
            cfg.AddProfile<ProductProfile>();
        });
        _mapper = configuration.CreateMapper();

        _handler = new ProductCommandHandler(
            _mockProductRepository.Object,
            _mockUnitOfWork.Object,
            _mockLogger.Object,
            _mapper);
    }

    [Fact]
    public async Task Handle_ValidCreateProductCommand_ReturnsProductDto()
    {
        // Arrange
        var command = new CreateProductCommand
        {
            Name = "Test Product",
            Description = "Test Description",
            Price = 99.99m,
            StockQuantity = 100,
            CategoryId = Guid.NewGuid(),
            Sku = "TEST-001"
        };

        var product = new Product
        {
            Id = Guid.NewGuid(),
            Name = "Test Product",
            Description = "Test Description",
            Price = 99.99m,
            StockQuantity = 100,
            CategoryId = command.CategoryId,
            Sku = "TEST-001",
            Slug = "test-product"
        };

        _mockUnitOfWork.Setup(x => x.SaveChangesAsync())
            .ReturnsAsync(1);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Should().NotBeNull();
        result.Name.Should().Be("Test Product");
        result.Price.Should().Be(99.99m);
    }

    [Fact]
    public async Task Handle_GetProductById_ReturnsProductDto()
    {
        // Arrange
        var productId = Guid.NewGuid();
        var product = new Product
        {
            Id = productId,
            Name = "Test Product",
            Description = "Test Description",
            Price = 99.99m,
            StockQuantity = 100
        };

        _mockProductRepository.Setup(x => x.GetByIdAsync(productId))
            .ReturnsAsync(product);

        // Act
        var result = await new GetProductByIdQueryHandler(
            _mockProductRepository.Object,
            _mapper,
            _mockLogger.Object)
            .Handle(new GetProductByIdQuery { Id = productId }, CancellationToken.None);

        // Assert
        result.Should().NotBeNull();
        result.Name.Should().Be("Test Product");
    }

    [Fact]
    public async Task Handle_GetProductById_NotFound_ReturnsNull()
    {
        // Arrange
        var productId = Guid.NewGuid();

        _mockProductRepository.Setup(x => x.GetByIdAsync(productId))
            .ReturnsAsync((Product?)null);

        // Act
        var result = await new GetProductByIdQueryHandler(
            _mockProductRepository.Object,
            _mapper,
            _mockLogger.Object)
            .Handle(new GetProductByIdQuery { Id = productId }, CancellationToken.None);

        // Assert
        result.Should().BeNull();
    }
}
