# 📚 Full-Stack Software Engineering Concepts - Complete Guide

> **Purpose**: Every software engineering concept, principle, and pattern used in this project, with exact file locations and explanations. Read this alongside the code to understand WHY every line exists.

---

## 📖 Table of Contents

1. [SOLID Principles](#1-solid-principles)
2. [Design Patterns](#2-design-patterns)
3. [Architecture Patterns](#3-architecture-patterns)
4. [Security Concepts](#4-security-concepts)
5. [Performance Patterns](#5-performance-patterns)
6. [Clean Code Principles](#6-clean-code-principles)
7. [API Design Principles](#7-api-design-principles)
8. [Frontend Architecture](#8-frontend-architecture)
9. [Database Concepts](#9-database-concepts)
10. [Error Handling Patterns](#10-error-handling-patterns)
11. [Testing Concepts](#11-testing-concepts)
12. [DevOps & Deployment](#12-devops--deployment)
13. [RxJS & Reactive Programming](#13-rxjs--reactive-programming)
14. [State Management](#14-state-management)

---

## 1. SOLID Principles

### S - Single Responsibility Principle (SRP)
**Definition**: A class should have only ONE reason to change, i.e., only ONE job or responsibility.

#### Implementation #1: Controllers
- **File**: `src/ECommerce.Api/Controllers/ProductsController.cs`
- **Concept**: Controller ONLY handles HTTP requests/responses. It does NOT contain business logic.
- **Code**:
```csharp
public class ProductsController : ControllerBase
{
    // SRP: Controller only maps HTTP → Command and returns HTTP response
    // Business logic is in ProductCommandHandler
    public async Task<IActionResult> Create([FromBody] CreateProductRequest request)
    {
        var command = new CreateProductCommand { /* map fields */ };
        var productId = await _mediator.Send(command); // Delegates to handler
        return CreatedAtAction(nameof(GetById), new { id = productId }, new { productId });
    }
}
```
- **Why it matters**: If business rules change, you edit the Handler, not the Controller. If HTTP API changes, you edit the Controller, not the Handler.

#### Implementation #2: Handlers
- **File**: `src/ECommerce.Application/Handlers/Products/ProductCommandHandler.cs`
- **Concept**: Handler ONLY contains business logic for ONE command/query. No HTTP concerns, no database details.
- **Code**:
```csharp
public class ProductCommandHandler : IRequestHandler<CreateProductCommand, Guid>
{
    // SRP: Handler only contains product creation business logic
    // Repository handles database, Validator handles validation
    public async Task<Guid> Handle(CreateProductCommand command, CancellationToken cancellationToken)
    {
        await _createValidator.ValidateAndThrowAsync(request); // Validation
        // Check SKU uniqueness (business rule)
        // Check category exists (business rule)
        // Create product (business logic)
        // Save to database (infrastructure)
    }
}
```

#### Implementation #3: Validators
- **File**: `src/ECommerce.Application/Validators/ProductValidators.cs`
- **Concept**: Validator ONLY validates input data. No business logic, no database access.
- **Code**:
```csharp
public class CreateProductRequestValidator : AbstractValidator<CreateProductRequest>
{
    // SRP: Validator only checks if input data meets rules
    // Does NOT create, update, or query anything
    RuleFor(x => x.Price).GreaterThan(0).WithMessage("Price must be positive.");
}
```

#### Implementation #4: DTOs
- **File**: `src/ECommerce.Application/DTOs/ProductDtos.cs`
- **Concept**: DTOs ONLY carry data. No behavior, no logic.
- **Code**:
```csharp
public class CreateProductRequest
{
    // DTOs are passive data containers - they have NO methods
    // This makes them easy to test, serialize, and maintain
    public required string Name { get; set; }
    public required decimal Price { get; set; }
}
```

#### Implementation #5: Services (Frontend)
- **File**: `frontend/src/app/core/services/product.service.ts`
- **Concept**: Service ONLY makes HTTP calls. No state management, no UI logic.
- **Code**:
```typescript
export class ProductService {
  // SRP: Service only handles HTTP communication with backend
  // State management is in ngrx Store
  // UI logic is in Components
  getAll(): Observable<PagedResponse<Product>> {
    return this.http.get<PagedResponse<Product>>(this.apiUrl);
  }
}
```

---

### O - Open/Closed Principle (OCP)
**Definition**: Software entities should be OPEN for extension but CLOSED for modification.

#### Implementation #1: MediatR Pipeline
- **File**: `src/ECommerce.Api/Program.cs` (service registration)
- **Concept**: New middleware can be added WITHOUT modifying existing handlers.
- **Code**:
```csharp
// OCP: Add new behaviors (logging, validation, timing) without touching handlers
builder.Services.AddMediatR(cfg => {
    cfg.RegisterServicesFromAssembly(typeof(ProductCommandHandler).Assembly);
    // To add logging: just create a new IPipelineBehavior - NO handler changes needed
});
```
- **Why it matters**: Want to add audit logging? Create a new `IAuditLoggingBehavior`. Want to add timing? Create `ITimingBehavior`. Existing code is NOT touched.

#### Implementation #2: AutoMapper Profiles
- **File**: `src/ECommerce.Application/Profiles/AutoMapperProfiles.cs`
- **Concept**: New DTO mappings are ADDITIONS, not modifications to existing code.
- **Code**:
```csharp
public class ProductProfile : Profile
{
    // OCP: Add new mappings by creating new CreateMap calls
    // Existing mappings are NOT modified when new DTOs are added
    CreateMap<Product, ProductDto>();
    CreateMap<CreateProductRequest, Product>();
    // New DTO? Just add another CreateMap - existing code untouched!
}
```

#### Implementation #3: Exception Middleware
- **File**: `src/ECommerce.Api/Middleware/ExceptionMiddleware.cs`
- **Concept**: New exception types are handled by ADDING new case branches, not modifying existing logic.
- **Code**:
```csharp
switch (exception)
{
    case ValidationException ex: // Handle validation errors
    case NotFoundException ex:   // Handle not found errors
    case ConflictException ex:   // Handle conflicts
    // OCP: Add new exception types by adding new cases
    // Existing case logic is NOT modified
}
```

---

### L - Liskov Substitution Principle (LSP)
**Definition**: Objects of a superclass should be replaceable with objects of its subclasses WITHOUT breaking the application.

#### Implementation #1: Repository Pattern
- **File**: `src/ECommerce.Application/Handlers/Products/ProductCommandHandler.cs`
- **Concept**: Any repository implementation can be substituted without changing handler logic.
- **Code**:
```csharp
public class ProductCommandHandler
{
    // LSP: _unitOfWork.Repository<Product>() can return ANY implementation
    // that follows the IRepository<T> contract
    // Swap in-memory for SQL, SQL for NoSQL - handler code doesn't change
    private readonly IUnitOfWork _unitOfWork;
}
```

#### Implementation #2: AutoMapper IProfile
- **File**: `src/ECommerce.Application/Profiles/AutoMapperProfiles.cs`
- **Concept**: All Profile classes extend `Mapper.Profile` and can be substituted.
- **Code**:
```csharp
public class UserProfile : Profile { }      // Extends Profile
public class CategoryProfile : Profile { }   // Can be substituted interchangeably
public class ProductProfile : Profile { }    // All follow the same contract
```

---

### I - Interface Segregation Principle (ISP)
**Definition**: Clients should not be forced to depend on interfaces they do not use.

#### Implementation #1: Separate DTOs for Each Operation
- **File**: `src/ECommerce.Application/DTOs/ProductDtos.cs`
- **Concept**: Create, Update, and Response DTOs are separate - clients don't see unused properties.
- **Code**:
```csharp
// ISP: Create DTO has required fields, Update DTO has optional fields
public class CreateProductRequest
{
    public required string Name { get; set; }    // Required for creation
    public required decimal Price { get; set; }  // Required for creation
}

public class UpdateProductRequest
{
    public string? Name { get; set; }            // Optional for partial update
    public decimal? Price { get; set; }          // Optional for partial update
    // Clients only depend on properties they actually use
}
```

#### Implementation #2: Specific Query/Command Types
- **File**: `src/ECommerce.Application/Commands/Products/ProductCommands.cs`
- **Concept**: Each command/query has only the properties it needs.
- **Code**:
```csharp
// ISP: GetProductByIdQuery only needs Id
public class GetProductByIdQuery : IRequest<ProductDto>
{
    public Guid Id { get; set; }  // Nothing else needed
}

// ISP: SearchProductsQuery only needs search/filter properties
public class SearchProductsQuery : IRequest<IEnumerable<ProductDto>>
{
    public string? Keyword { get; set; }
    public decimal? MinPrice { get; set; }
    public int Page { get; set; } = 1;
    // Only depends on what it uses
}
```

---

### D - Dependency Inversion Principle (DIP)
**Definition**: High-level modules should not depend on low-level modules. Both should depend on abstractions.

#### Implementation #1: Constructor Injection
- **File**: `src/ECommerce.Application/Handlers/Products/ProductCommandHandler.cs`
- **Concept**: Handler depends on abstractions (IUnitOfWork, IMapper), NOT concrete implementations.
- **Code**:
```csharp
public class ProductCommandHandler
{
    // DIP: Depends on IUnitOfWork (abstraction), NOT EF DbContext (concrete)
    // DIP: Depends on IMapper (abstraction), NOT AutoMapper (concrete)
    // DIP: Depends on IValidator (abstraction), NOT FluentValidation (concrete)
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    private readonly IValidator<CreateProductRequest> _createValidator;

    // Dependency Injection: Dependencies are injected, NOT created internally
    public ProductCommandHandler(IUnitOfWork unitOfWork, IMapper mapper,
        IValidator<CreateProductRequest> createValidator,
        IValidator<UpdateProductRequest> updateValidator)
    {
        _unitOfWork = unitOfWork;
        _mapper = mapper;
        _createValidator = createValidator;
        _updateValidator = updateValidator;
    }
}
```

#### Implementation #2: Controller Dependencies
- **File**: `src/ECommerce.Api/Controllers/ProductsController.cs`
- **Concept**: Controller depends on IMediator (abstraction), NOT on specific handlers.
- **Code**:
```csharp
public class ProductsController : ControllerBase
{
    // DIP: Depends on IMediator (abstraction), NOT ProductCommandHandler (concrete)
    // This allows swapping MediatR for another messaging system
    private readonly IMediator _mediator;
}
```

#### Implementation #3: Frontend Service Injection
- **File**: `frontend/src/app/core/services/product.service.ts`
- **Concept**: Service uses inject() for HttpClient, making it testable.
- **Code**:
```typescript
export class ProductService {
  // DIP: Uses inject(HttpClient) - depends on HttpClient abstraction
  // Can be mocked in tests without real HTTP calls
  private http = inject(HttpClient);
}
```

---

## 2. Design Patterns

### CQRS (Command Query Responsibility Segregation)
**Definition**: Separate read (query) and write (command) operations into different models.

#### Why CQRS?
- **Reads** need: pagination, filtering, sorting, caching
- **Writes** need: validation, business rules, transactions
- Combining them creates complex, hard-to-maintain code

#### Implementation: Commands (Writes)
- **File**: `src/ECommerce.Application/Commands/Products/ProductCommands.cs`
- **Code**:
```csharp
// COMMAND: Changes state (creates, updates, deletes)
public class CreateProductCommand : IRequest<Guid>
{
    // Commands are IMPERATIVE - they DO something
    public string Name { get; set; }
    public decimal Price { get; set; }
}

// QUERY: Retrieves data (reads)
public class SearchProductsQuery : IRequest<IEnumerable<ProductDto>>
{
    // Queries are DECLARATIVE - they ASK for something
    public string? Keyword { get; set; }
    public int Page { get; set; } = 1;
}
```

#### Implementation: Handlers
- **File**: `src/ECommerce.Application/Handlers/Products/ProductCommandHandler.cs`
- **Code**:
```csharp
// ONE handler manages BOTH commands and queries for a domain
public class ProductCommandHandler :
    IRequestHandler<CreateProductCommand, Guid>,      // Handles CREATE (write)
    IRequestHandler<UpdateProductCommand, bool>,      // Handles UPDATE (write)
    IRequestHandler<DeleteProductCommand, bool>,      // Handles DELETE (write)
    IRequestHandler<SearchProductsQuery, IEnumerable<ProductDto>>,  // Handles SEARCH (read)
    IRequestHandler<GetProductByIdQuery, ProductDto>, // Handles GET (read)
    IRequestHandler<GetFeaturedProductsQuery, IEnumerable<ProductDto>> // Handles GET (read)
{
    // CQRS: Same handler class, but commands and queries have different responsibilities
    // Commands: Validate → Business Rules → Save → Return ID
    // Queries: Find → Map to DTO → Return Data
}
```

#### Implementation: Mediator Pattern
- **File**: `src/ECommerce.Api/Controllers/ProductsController.cs`
- **Code**:
```csharp
// MEDIATOR: Controller doesn't know about handlers
// It just sends commands/queries to the mediator
var products = await _mediator.Send(command);
// The mediator routes to the correct handler automatically
```

---

### Repository Pattern
**Definition**: Abstracts data access logic behind a collection-like interface.

#### Implementation: IUnitOfWork & IRepository
- **File**: `src/ECommerce.Application/Handlers/Products/ProductCommandHandler.cs`
- **Code**:
```csharp
// Repository Pattern: Hides database details from business logic
var productRepository = _unitOfWork.Repository<Product>();

// Business logic talks to repository, NOT directly to database
await productRepository.AddAsync(product);
var existing = await productRepository.Find(p => p.Sku == command.Sku);

// Benefits:
// 1. Business logic doesn't know about EF Core, SQL, or queries
// 2. Easy to swap SQLite for PostgreSQL - just change repository implementation
// 3. Easy to test - mock the repository
// 4. Consistent API for all data access
```

---

### Strategy Pattern
**Definition**: Define a family of algorithms, encapsulate each one, and make them interchangeable.

#### Implementation: Exception Handling Strategy
- **File**: `src/ECommerce.Api/Middleware/ExceptionMiddleware.cs`
- **Code**:
```csharp
// Strategy Pattern: Different exception types use different response strategies
switch (exception)
{
    case ValidationException ex:
        // Strategy 1: Return 400 Bad Request with validation details
        response.StatusCode = (int)HttpStatusCode.BadRequest;
        break;
    case NotFoundException ex:
        // Strategy 2: Return 404 Not Found
        response.StatusCode = (int)HttpStatusCode.NotFound;
        break;
    case ConflictException ex:
        // Strategy 3: Return 409 Conflict
        response.StatusCode = (int)HttpStatusCode.Conflict;
        break;
}
// Each exception type has its own response strategy
// Easy to add new strategies without modifying existing ones
```

---

### Factory Pattern
**Definition**: Define an interface for creating an object, but let subclasses decide which class to instantiate.

#### Implementation: AutoMapper
- **File**: `src/ECommerce.Application/Profiles/AutoMapperProfiles.cs`
- **Code**:
```csharp
// Factory Pattern: AutoMapper creates mapped objects automatically
var product = _mapper.Map<Product>(createRequest);
// AutoMapper factory decides HOW to map based on Profile configuration
// You don't write: product.Id = request.Id; product.Name = request.Name; ...
// The factory handles all property-by-property mapping
```

---

### Decorator Pattern
**Definition**: Add behavior to objects WITHOUT modifying their structure.

#### Implementation: Middleware Pipeline
- **File**: `src/ECommerce.Api/Program.cs`
- **Code**:
```csharp
// Decorator Pattern: Each middleware wraps the next one
app.UseMiddleware<ExceptionMiddleware>();  // Wraps all subsequent middleware
app.UseCors("AllowAll");                    // Wraps authentication, routing, etc.
app.UseAuthentication();                     // Wraps authorization, endpoints
app.UseAuthorization();                      // Wraps controllers

// Each middleware ADDS behavior without changing the next middleware
// ExceptionMiddleware adds error handling
// CorsMiddleware adds CORS headers
// AuthenticationMiddleware adds auth
// They DECORATE the request/response pipeline
```

---

### Observer Pattern
**Definition**: Define a one-to-many dependency between objects so that when one object changes state, all dependents are notified.

#### Implementation: RxJS Observables (Frontend)
- **File**: `frontend/src/app/core/services/product.service.ts`
- **Code**:
```typescript
// Observer Pattern: Observable emits values, subscribers react
getAll(): Observable<PagedResponse<Product>> {
    return this.http.get<PagedResponse<Product>>(this.apiUrl);
    // HTTP client is the OBSERVER - it notifies when data arrives
}

// Component is the OBSERVER - it reacts to changes
productService.getAll().subscribe(data => {
    // This code runs when the observable emits
    this.products = data;
});
```

#### Implementation: ngrx Effects
- **File**: `frontend/src/app/core/store/effects/`
- **Concept**: Effects observe store actions and trigger side effects (HTTP calls).
- **Code**:
```typescript
// Observer Pattern: Effects observe actions and respond
loadProducts$ = createEffect(() =>
    this.actions$.pipe(
        ofType(ProductActions.loadProducts),  // Observe this action
        switchMap(() => this.productService.getAll()),  // When action fires, make HTTP call
        map(products => ProductActions.loadProductsSuccess({ products }))  // Emit new action
    )
);
```

---

### Singleton Pattern
**Definition**: Ensure a class has only ONE instance and provide global access to it.

#### Implementation: HttpClient (Angular)
- **File**: `frontend/src/app/app.config.ts`
- **Code**:
```typescript
// Singleton: Angular's HttpClient is a singleton service
// ONE instance shared across entire application
provideHttpClient(withInterceptors([authInterceptor, errorInterceptor]))
// Every service that injects HttpClient gets the SAME instance
```

#### Implementation: ngrx Store
- **File**: `frontend/src/app/core/store/root-store.ts`
- **Code**:
```typescript
// Singleton: ONE global store for entire application
provideStore(reducers)
// All components access the SAME store instance
// This is the Single Source of Truth pattern
```

---

### Builder Pattern
**Definition**: Build complex objects step by step.

#### Implementation: HttpParams (Angular)
- **File**: `frontend/src/app/core/services/product.service.ts`
- **Code**:
```typescript
// Builder Pattern: Build query parameters step by step
let httpParams = new HttpParams();
if (page) httpParams = httpParams.set('pageNumber', page.toString());
if (pageSize) httpParams = httpParams.set('pageSize', pageSize.toString());
if (search) httpParams = httpParams.set('searchQuery', search);
// Each .set() returns a NEW HttpParams (immutable builder)
// Final params object has only the non-null values
```

---

### Facade Pattern
**Definition**: Provide a simplified interface to a complex subsystem.

#### Implementation: MediatR IMediator
- **File**: `src/ECommerce.Api/Controllers/ProductsController.cs`
- **Code**:
```csharp
// Facade Pattern: IMediator simplifies complex handler routing
var productId = await _mediator.Send(command);
// Behind the scenes, MediatR:
// 1. Finds the correct handler for CreateProductCommand
// 2. Validates the command
// 3. Executes the handler
// 4. Returns the result
// Controller doesn't know about any of this complexity
```

---

## 3. Architecture Patterns

### Clean Architecture (Layered Architecture)
**Definition**: Separate code into layers with clear dependencies pointing inward.

#### Implementation: Project Structure
- **File**: `src/ECommerce.Api/`, `src/ECommerce.Application/`, `Core/`, `Infrastructure/`
- **Code**:
```
ECommerce.Api (Presentation Layer)
    ↓ depends on
ECommerce.Application (Business Logic Layer)
    ↓ depends on
Core (Domain Layer - Entities, Exceptions, Interfaces)
    ↓ depends on
ECommerce.Infrastructure (Data Access Layer)
```
- **Why it matters**:
  - **Presentation Layer** knows NOTHING about database
  - **Business Logic** knows NOTHING about HTTP
  - **Domain** is PURE - no framework dependencies
  - **Infrastructure** is a DETAIL - can be swapped

#### Implementation: Dependency Flow
- **File**: `src/ECommerce.Application/Handlers/Products/ProductCommandHandler.cs`
- **Code**:
```csharp
// Clean Architecture: Handler (Application) depends on IUnitOfWork (Domain interface)
// Infrastructure provides the concrete implementation
// This is INVERSION OF CONTROL - dependencies point INWARD
private readonly IUnitOfWork _unitOfWork;  // Interface from Core/Domain
// NOT: private readonly DbContext _dbContext;  // Concrete from Infrastructure
```

---

### CQRS (Command Query Responsibility Segregation)
**Definition**: Separate read and write operations into different models.

#### See Section 2 above for detailed CQRS explanation.

---

### Middleware Pipeline Architecture
**Definition**: Request/response processing through a chain of middleware components.

#### Implementation: Program.cs
- **File**: `src/ECommerce.Api/Program.cs`
- **Code**:
```csharp
// Middleware Pipeline: Request flows through each middleware in order
app.UseMiddleware<ExceptionMiddleware>();  // 1. Catch all exceptions
app.UseCors("AllowAll");                    // 2. Add CORS headers
app.UseHttpsRedirection();                  // 3. Redirect HTTP to HTTPS
app.UseAuthentication();                    // 4. Validate JWT token
app.UseAuthorization();                     // 5. Check user permissions
app.MapControllers();                       // 6. Route to controller

// CRITICAL: Order matters!
// CORS must be BEFORE authentication (browser sends OPTIONS before auth)
// Authentication must be BEFORE authorization (can't authorize without identity)
```

---

## 4. Security Concepts

### JWT (JSON Web Token) Authentication
**Definition**: Stateless authentication using signed tokens.

#### Implementation: Token Generation
- **File**: `src/ECommerce.Application/Handlers/Auth/AuthCommandHandler.cs`
- **Code**:
```csharp
// JWT: Token contains claims (user info) signed with secret key
var claims = new List<Claim>
{
    new(ClaimTypes.Name, user.Email),
    new(ClaimTypes.Role, "User"),
    new(ClaimTypes.Role, "Admin")  // Multiple roles supported
};

var token = new JwtSecurityToken(
    issuer: issuer,              // Who issued this token
    audience: audience,          // Who is this token for
    expires: DateTime.UtcNow.AddHours(1),  // When does it expire
    signingCredentials: credentials  // Secret key signature
);
```

#### Implementation: Token Validation
- **File**: `src/ECommerce.Api/Program.cs`
- **Code**:
```csharp
// JWT Validation: Four checks ensure token is legitimate
options.TokenValidationParameters = new TokenValidationParameters
{
    ValidateIssuer = true,        // Check: Was token issued by trusted source?
    ValidateAudience = true,      // Check: Is token meant for this API?
    ValidateLifetime = true,      // Check: Has token expired?
    ValidateIssuerSigningKey = true,  // Check: Is signature valid?
    ValidIssuer = builder.Configuration["Jwt:Issuer"],
    ValidAudience = builder.Configuration["Jwt:Audience"],
    IssuerSigningKey = new SymmetricSecurityKey(
        Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]))
};
```

---

### Role-Based Access Control (RBAC)
**Definition**: Restrict access based on user roles.

#### Implementation: Controller-Level Authorization
- **File**: `src/ECommerce.Api/Controllers/ProductsController.cs`
- **Code**:
```csharp
// RBAC: Different endpoints require different roles
[HttpGet]
[AllowAnonymous]  // Anyone can view products

[HttpPost]
[Authorize(Roles = "Admin")]  // Only Admins can create products

[HttpPut("{id}")]
[Authorize(Roles = "Admin")]  // Only Admins can update products
```

---

### Password Hashing (BCrypt)
**Definition**: One-way hashing makes passwords unreadable even if database is compromised.

#### Implementation: Auth Handler
- **File**: `src/ECommerce.Application/Handlers/Auth/AuthCommandHandler.cs`
- **Code**:
```csharp
// BCrypt: One-way hash with salt
// NEVER store plain text passwords
var hashedPassword = BCrypt.Net.BCrypt.HashPassword(password);
// Verification is comparison, NOT decryption
bool isValid = BCrypt.Net.BCrypt.Verify(inputPassword, storedHash);
// Why BCrypt?
// 1. Includes random salt (prevents rainbow table attacks)
// 2. Configurable work factor (can be increased as computers get faster)
// 3. Computationally expensive (slows down brute force attacks)
```

---

### CORS (Cross-Origin Resource Sharing)
**Definition**: Browser security feature that restricts cross-origin HTTP requests.

#### Implementation: CORS Policy
- **File**: `src/ECommerce.Api/Program.cs`
- **Code**:
```csharp
// CORS: Allows frontend (different origin) to call backend API
options.AddPolicy("AllowAll", policy =>
{
    policy.AllowAnyOrigin()    // Allow any frontend domain
          .AllowAnyMethod()    // Allow GET, POST, PUT, DELETE, OPTIONS
          .AllowAnyHeader();   // Allow any headers (including Authorization)
});

// CRITICAL: UseCors MUST be first in middleware pipeline
// Browser sends OPTIONS preflight request BEFORE actual request
// If CORS middleware is after authentication, preflight fails
app.UseCors("AllowAll");  // MUST be first!
```

---

### Input Validation (FluentValidation)
**Definition**: Validate all user input before processing.

#### Implementation: Product Validators
- **File**: `src/ECommerce.Application/Validators/ProductValidators.cs`
- **Code**:
```csharp
// FluentValidation: Declarative validation rules
RuleFor(x => x.Name)
    .NotEmpty().WithMessage("Product name is required.")  // Not null/empty
    .MaximumLength(200).WithMessage("Name cannot exceed 200 characters.");

RuleFor(x => x.Price)
    .GreaterThan(0).WithMessage("Price must be positive.");  // Business rule

RuleFor(x => x.CompareAtPrice)
    .GreaterThanOrEqualTo(x => x.Price)  // Compare-at must be >= regular price
    .When(x => x.CompareAtPrice.HasValue);  // Only validate if provided
```

---

## 5. Performance Patterns

### Pagination
**Definition**: Split large result sets into smaller pages.

#### Implementation: Search Products
- **File**: `src/ECommerce.Api/Controllers/ProductsController.cs`
- **Code**:
```csharp
// Pagination: Prevents loading thousands of products at once
[FromQuery] int page = 1,           // Which page to show
[FromQuery] int pageSize = 20       // How many items per page
{
    var command = new SearchProductsQuery
    {
        Page = page,
        PageSize = pageSize
    };
    // Server-side pagination: Only 20 records fetched from database
    // NOT: GetAll().Skip(page).Take(pageSize)  // BAD - loads ALL records
}
```

---

### DTO Projection
**Definition**: Map entities to DTOs to control what data is sent to client.

#### Implementation: ProductDto
- **File**: `src/ECommerce.Application/DTOs/ProductDtos.cs`
- **Code**:
```csharp
// DTO Projection: Only send necessary fields
public class ProductDto
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
    // NO PasswordHash, NO internal notes, NO audit fields
    // Reduces network payload and prevents data leakage
}
```

---

### AutoMapper for Mapping
**Definition**: Automated object-to-object mapping reduces boilerplate code.

#### Implementation: AutoMapper Profiles
- **File**: `src/ECommerce.Application/Profiles/AutoMapperProfiles.cs`
- **Code**:
```csharp
// AutoMapper: Eliminates manual property-by-property mapping
CreateMap<Product, ProductDto>()
    .ForMember(dest => dest.CategoryName,
        opt => opt.MapFrom(src => src.Category?.Name ?? "Unknown"))
    // Computed property: Category name from related entity
    .ForMember(dest => dest.AverageRating,
        opt => opt.MapFrom(src => src.Reviews.Any()
            ? src.Reviews.Average(r => (double)r.Rating) : 0.0))
    // Computed property: Average rating from reviews
    .ForMember(dest => dest.PrimaryImageUrl,
        opt => opt.MapFrom(src => src.Images
            .OrderBy(i => i.DisplayOrder)
            .FirstOrDefault()!.Url));
    // Computed property: First image by display order
```

---

### CancellationToken
**Definition**: Allow long operations to be cancelled if client disconnects.

#### Implementation: All Handlers
- **File**: `src/ECommerce.Application/Handlers/Products/ProductCommandHandler.cs`
- **Code**:
```csharp
// CancellationToken: Prevents wasted work if client disconnects
public async Task<Guid> Handle(CreateProductCommand command,
    CancellationToken cancellationToken)  // Passed through entire chain
{
    await productRepository.AddAsync(product, cancellationToken);
    await _unitOfWork.SaveChangesAsync(cancellationToken);
    // If client disconnects, this operation is cancelled
    // Prevents: database writes for requests no one is waiting for
}
```

---

## 6. Clean Code Principles

### DRY (Don't Repeat Yourself)
**Definition**: Every piece of knowledge should have a single, unambiguous representation.

#### Implementation: AutoMapper Profiles
- **File**: `src/ECommerce.Application/Profiles/AutoMapperProfiles.cs`
- **Code**:
```csharp
// DRY: Mapping logic defined ONCE in Profile, used everywhere
CreateMap<Product, ProductDto>();
// Instead of writing: dto.Id = product.Id; dto.Name = product.Name; ...
// in every controller, every service, every handler
```

---

### KISS (Keep It Simple, Stupid)
**Definition**: Most systems work best if they are kept simple rather than made complex.

#### Implementation: Simple Controller Actions
- **File**: `src/ECommerce.Api/Controllers/ProductsController.cs`
- **Code**:
```csharp
// KISS: Controller action is 5 lines of clear code
[HttpGet]
public async Task<IActionResult> GetProducts(...)
{
    var command = new SearchProductsQuery { /* map */ };
    var products = await _mediator.Send(command);
    return Ok(products);
}
// Clear, readable, easy to understand and maintain
```

---

### YAGNI (You Aren't Gonna Need It)
**Definition**: Don't add functionality until it is needed.

#### Implementation: TODO Comments
- **File**: `src/ECommerce.Api/Controllers/OrdersController.cs`
- **Code**:
```csharp
// YAGNI: Placeholder implementation - actual logic not yet needed
[HttpPost]
public async Task<IActionResult> CreateOrder(...)
{
    // TODO: Get user ID from JWT claims
    // TODO: Get cart from user
    // TODO: Validate cart has items
    // TODO: Calculate totals server-side
    // TODO: Process payment
    // TODO: Create order
    // TODO: Clear cart
    // TODO: Send order confirmation email

    var orderId = Guid.NewGuid();  // Placeholder - not real implementation
    return CreatedAtAction(nameof(GetById), new { id = orderId }, new { orderId });
}
// Don't implement until the feature is actually required
```

---

## 7. API Design Principles

### RESTful API Design
**Definition**: Use HTTP methods and status codes semantically.

#### Implementation: Products Controller
- **File**: `src/ECommerce.Api/Controllers/ProductsController.cs`
- **Code**:
```csharp
// REST: HTTP methods map to CRUD operations
[HttpGet]              // GET /api/v1/products → List products (READ)
[HttpGet("{id}")]      // GET /api/v1/products/123 → Get one product (READ)
[HttpPost]             // POST /api/v1/products → Create product (CREATE)
[HttpPut("{id}")]      // PUT /api/v1/products/123 → Update product (UPDATE)
[HttpDelete("{id}")]   // DELETE /api/v1/products/123 → Delete product (DELETE)

// REST: Proper HTTP status codes
return Ok(products);              // 200 OK - Success with data
return CreatedAtAction(...);      // 201 Created - Resource created
return NotFound();                // 404 Not Found - Resource doesn't exist
return BadRequest(problemDetails); // 400 Bad Request - Invalid input
```

---

### API Versioning
**Definition**: Support multiple API versions simultaneously for backward compatibility.

#### Implementation: ApiVersioning
- **File**: `src/ECommerce.Api/Program.cs`
- **Code**:
```csharp
// API Versioning: Allows frontend to specify which API version it uses
builder.Services.AddApiVersioning(options =>
{
    options.DefaultApiVersion = new ApiVersion(1, 0);  // Default to v1
    options.AssumeDefaultVersionWhenUnspecified = true; // Assume v1 if not specified
    options.ReportApiVersions = true;                  // Include version in response headers
}).AddApiExplorer(options =>
{
    options.GroupNameFormat = "'v'VVV";  // Groups by version in Swagger
    options.SubstituteApiVersionInUrl = true;  // /api/v1/products instead of /api/products
});

// URL Pattern: /api/v1/products, /api/v2/products (when it exists)
// Benefits:
// 1. Frontend can upgrade at its own pace
// 2. Old clients continue working while new clients use new version
// 3. Breaking changes can be introduced in new version
```

---

### HATEOAS (Hypermedia as the Engine of Application State)
**Definition**: API responses include links to related resources.

#### Implementation: CreatedAtAction
- **File**: `src/ECommerce.Api/Controllers/ProductsController.cs`
- **Code**:
```csharp
// HATEOAS: Response includes link to the newly created resource
return CreatedAtAction(nameof(GetById), new { id = productId }, new { productId });
// Response:
// Status: 201 Created
// Location: /api/v1/products/{productId}
// Body: { "productId": "..." }
// Client knows where to find the new resource
```

---

## 8. Frontend Architecture

### Angular Standalone Components
**Definition**: Components that don't require NgModules.

#### Implementation: App Config
- **File**: `frontend/src/app/app.config.ts`
- **Code**:
```typescript
// Standalone Components: No NgModules needed
// Providers are configured at app level, not module level
export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),           // Router configuration
    provideHttpClient(...),           // HTTP client configuration
    provideStore(reducers),           // State management configuration
    provideEffects(AuthEffects),      // Side effects configuration
    provideAnimations()               // Animation support
  ]
};
// Benefits:
// 1. Simpler setup - no NgModule boilerplate
// 2. Easier testing - providers are tree-shakeable
// 3. Better lazy loading support
```

---

### Dependency Injection (Angular)
**Definition**: Framework provides dependencies to classes, classes don't create them.

#### Implementation: Service Injection
- **File**: `frontend/src/app/core/services/product.service.ts`
- **Code**:
```typescript
// Angular DI: inject() gets the framework-provided instance
private http = inject(HttpClient);
// NOT: private http = new HttpClient();  // BAD - creates new instance
// Benefits:
// 1. HttpClient is a singleton (one instance shared)
// 2. Easy to mock in tests
// 3. Configuration (interceptors) is applied automatically
```

---

### Route Guards
**Definition**: Protect routes based on authentication/authorization state.

#### Implementation: App Routes
- **File**: `frontend/src/app/app.routes.ts`
- **Code**:
```typescript
// Route Guards: Protect routes that require authentication
export const routes: Routes = [
  {
    path: 'admin',
    canActivate: [AdminGuard],  // Only admins can access
    loadChildren: () => import('./features/admin/admin.routes')
  },
  {
    path: 'profile',
    canActivate: [AuthGuard],   // Only logged-in users can access
    component: ProfileComponent
  }
];
```

---

### HTTP Interceptors
**Definition**: Intercept HTTP requests/responses for cross-cutting concerns.

#### Implementation: Auth & Error Interceptors
- **File**: `frontend/src/app/core/interceptors/`
- **Code**:
```typescript
// HTTP Interceptor: Add JWT token to every request
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const token = getToken();  // Get from localStorage
  if (token) {
    const cloned = req.clone({
      setHeaders: { Authorization: `Bearer ${token}` }
    });
    return next(cloned);
  }
  return next(req);
};

// HTTP Interceptor: Handle errors globally
export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  return next(req).pipe(
    catchError(error => {
      // Handle 401: Clear token, redirect to login
      // Handle 403: Show unauthorized message
      // Handle 500: Show generic error
      return throwError(() => error);
    })
  );
};
// Benefits:
// 1. No need to add token to every HTTP call manually
// 2. Centralized error handling
// 3. Consistent behavior across all API calls
```

---

## 9. Database Concepts

### Soft Delete
**Definition**: Mark records as deleted instead of actually removing them.

#### Implementation: IsDeleted Column
- **File**: `Core/Entities/` (all entities)
- **Code**:
```csharp
// Soft Delete: IsDeleted flag instead of DELETE statement
public class Product
{
    public bool IsDeleted { get; set; }  // Default: false
    // When "deleted", set IsDeleted = true
    // Queries filter: WHERE IsDeleted = false
    // Benefits:
    // 1. Data can be restored
    // 2. Audit trail preserved
    // 3. Foreign key relationships maintained
}
```

---

### Concurrency Control (RowVersion)
**Definition**: Detect conflicting updates using version timestamps.

#### Implementation: RowVersion Column
- **File**: `Core/Entities/` (all entities)
- **Code**:
```csharp
// Concurrency Control: RowVersion changes on every update
public class Product
{
    public byte[] RowVersion { get; set; }  // Database timestamp
    // When updating, check RowVersion matches
    // If another user updated the record, RowVersion changed
    // Conflict detected → Optimistic Concurrency Exception
    // Benefits:
    // 1. Prevents lost updates
    // 2. No database locks needed
    // 3. Better scalability than pessimistic locking
}
```

---

### GUID Primary Keys
**Definition**: Use globally unique identifiers instead of auto-increment integers.

#### Implementation: All Entity IDs
- **File**: `Core/Entities/` (all entities)
- **Code**:
```csharp
// GUID Primary Keys: Globally unique, no collisions
public class Product
{
    public Guid Id { get; set; }  // NOT int identity
    // Benefits:
    // 1. No database round-trip to get ID (can generate client-side)
    // 2. No ID prediction/security issues
    // 3. Easy to merge databases from multiple sources
    // 4. Distributed systems friendly
    // Trade-offs:
    // 1. Larger index size (16 bytes vs 4 bytes)
    // 2. Non-sequential (more index fragmentation)
}
```

---

### Slug Generation
**Definition**: Create URL-friendly strings from human-readable text.

#### Implementation: Category Profile
- **File**: `src/ECommerce.Application/Profiles/AutoMapperProfiles.cs`
- **Code**:
```csharp
// Slug Generation: Convert "Wireless Bluetooth Headphones" → "wireless-bluetooth-headphones"
private static string GenerateSlug(string name)
{
    var slug = name.ToLowerInvariant();  // "wireless bluetooth headphones"
    slug = Regex.Replace(slug, @"[^a-z0-9]", "-");  // Replace non-alphanumeric with "-"
    slug = Regex.Replace(slug, @"-+", "-");  // Collapse multiple "-" into one
    slug = slug.Trim('-');  // Remove leading/trailing "-"
    return slug;  // "wireless-bluetooth-headphones"
}
// Benefits:
// 1. SEO-friendly URLs
// 2. Human-readable
// 3. Consistent formatting
```

---

## 10. Error Handling Patterns

### ProblemDetails (RFC 7807)
**Definition**: Standardized error response format.

#### Implementation: Exception Middleware
- **File**: `src/ECommerce.Api/Middleware/ExceptionMiddleware.cs`
- **Code**:
```csharp
// ProblemDetails: Standardized error response format (RFC 7807)
var problemDetails = new ProblemDetails
{
    Status = (int)HttpStatusCode.BadRequest,
    Title = "Validation Error",
    Detail = ex.Message,
    Type = "https://tools.ietf.org/html/rfc7231#section-6.5.1"
};
// Response format:
// {
//   "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
//   "title": "Validation Error",
//   "status": 400,
//   "detail": "Product price must be greater than zero."
// }
// Benefits:
// 1. Consistent error format across all endpoints
// 2. Standardized (RFC 7807)
// 3. Machine-readable
// 4. Client can handle errors programmatically
```

---

### Custom Domain Exceptions
**Definition**: Specific exception types for different error scenarios.

#### Implementation: Custom Exceptions
- **File**: `Core/Exceptions/`
- **Code**:
```csharp
// Custom Exceptions: Specific types for different error scenarios
public class ValidationException : Exception { }      // 400 Bad Request
public class NotFoundException : Exception { }        // 404 Not Found
public class ConflictException : Exception { }         // 409 Conflict
public class SecurityException : Exception { }         // 401 Unauthorized

// Middleware catches specific types and returns appropriate HTTP status
switch (exception)
{
    case ValidationException: return BadRequest();
    case NotFoundException: return NotFound();
    case ConflictException: return Conflict();
}
// Benefits:
// 1. Clear intent (exception name explains the error)
// 2. Type-safe handling (switch on exception type)
// 3. No magic strings or error codes
```

---

## 11. Testing Concepts

### Dependency Injection for Testing
**Definition**: Inject mock dependencies to test code in isolation.

#### Implementation: Handler Constructor
- **File**: `src/ECommerce.Application/Handlers/Products/ProductCommandHandler.cs`
- **Code**:
```csharp
// DI for Testing: All dependencies are injectable
public ProductCommandHandler(IUnitOfWork unitOfWork, IMapper mapper,
    IValidator<CreateProductRequest> createValidator,
    IValidator<UpdateProductRequest> updateValidator)
{
    // In tests, inject MOCK implementations:
    // var mockUnitOfWork = new Mock<IUnitOfWork>();
    // var mockMapper = new Mock<IMapper>();
    // var handler = new ProductCommandHandler(
    //     mockUnitOfWork.Object, mockMapper.Object, ...);
    // Now test handler logic WITHOUT database, WITHOUT AutoMapper
}
```

---

## 12. DevOps & Deployment

### Structured Logging (Serilog)
**Definition**: Log events with structured data for easy querying and analysis.

#### Implementation: Serilog Configuration
- **File**: `src/ECommerce.Api/Program.cs`
- **Code**:
```csharp
// Structured Logging: Log with context, not just strings
Log.Logger = new LoggerConfiguration()
    .Enrich.FromLogContext()           // Add contextual properties
    .Enrich.WithProperty("Application", "ECommerce API")  // Add app name
    .WriteTo.Console()                 // Log to console
    .WriteTo.File("logs/log-.txt",     // Log to file with daily rotation
        rollingInterval: RollingInterval.Day);

// Usage in code:
_logger.LogError(exception, "Unhandled exception: {Message}", exception.Message);
// Log includes: timestamp, level, message, exception, application name
// Benefits:
// 1. Easy to search and filter logs
// 2. Structured data for log analysis tools
// 3. File rotation prevents disk space issues
```

---

### Environment-Specific Configuration
**Definition**: Different settings for development, staging, and production.

#### Implementation: appsettings.json
- **File**: `src/ECommerce.Api/appsettings.json`
- **Code**:
```json
// Environment-Specific Configuration
{
  "ConnectionStrings": {
    "DefaultConnection": "Data Source=ecommerce.db"  // SQLite for development
  },
  "Jwt": {
    "Issuer": "ECommerceAPI",
    "Audience": "ECommerceClient",
    "Key": "your-super-secret-key-here"  // Change in production!
  }
}
// In production:
// 1. Use PostgreSQL/SQL Server instead of SQLite
// 2. Use strong, randomly generated JWT key
// 3. Enable HTTPS only
// 4. Disable Swagger
// 5. Set appropriate logging level
```

---

## 13. RxJS & Reactive Programming

### Observable Pattern
**Definition**: Values that arrive over time, with lazy evaluation.

#### Implementation: HTTP Service
- **File**: `frontend/src/app/core/services/product.service.ts`
- **Code**:
```typescript
// Observable: Lazy, streaming data that arrives over time
getAll(): Observable<PagedResponse<Product>> {
    // NOT: return this.http.get(...).subscribe(data => data);  // WRONG
    // Returns OBSERVABLE - doesn't execute until subscribed
    return this.http.get<PagedResponse<Product>>(this.apiUrl);
}

// Subscribe: Triggers the HTTP request
this.productService.getAll().subscribe({
    next: data => this.products = data,    // Data arrived
    error: err => this.error = err.message, // Error occurred
    complete: () => console.log('Done')     // Request completed
});
```

---

### RxJS Operators
**Definition**: Functions that transform, filter, or combine observables.

#### Implementation: Effects
- **File**: `frontend/src/app/core/store/effects/`
- **Code**:
```typescript
// RxJS Operators: Transform and combine observables

// switchMap: Cancel previous request if new one arrives
// CRITICAL for search - don't show results from stale search
loadProducts$ = createEffect(() =>
    this.actions$.pipe(
        ofType(ProductActions.loadProducts),
        switchMap(() => this.productService.getAll())  // Cancels previous if new action fires
    )
);

// catchError: Handle errors gracefully
loadProducts$ = createEffect(() =>
    this.actions$.pipe(
        ofType(ProductActions.loadProducts),
        switchMap(() => this.productService.getAll()),
        catchError(error => of(ProductActions.loadProductsFailure({ error })))
        // Instead of crashing, emit a failure action
    )
);

// map: Transform emitted values
loadProductsSuccess$ = createEffect(() =>
    this.actions$.pipe(
        ofType(ProductActions.loadProducts),
        switchMap(() => this.productService.getAll()),
        map(products => ProductActions.loadProductsSuccess({ products }))
        // Transform HTTP response into store action
    )
);
```

---

## 14. State Management

### ngrx Store Pattern
**Definition**: Centralized, predictable state management using unidirectional data flow.

#### Implementation: Actions → Reducers → Selectors
- **File**: `frontend/src/app/core/store/`
- **Code**:
```typescript
// UNIDIRECTIONAL DATA FLOW:
// Component → Action → Reducer → Store → Selector → Component

// 1. ACTION: Describe WHAT happened
export const loadProducts = createAction('[Product] Load Products');
export const loadProductsSuccess = createAction(
    '[Product] Load Products Success',
    props<{ products: Product[] }>()
);

// 2. REDUCER: Pure function that updates state
export function productReducer(state, action) {
    switch (action.type) {
        case '[Product] Load Products':
            return { ...state, loading: true, error: null };
        case '[Product] Load Products Success':
            return { ...state, loading: false, products: action.products };
        default:
            return state;
    }
}

// 3. SELECTOR: Derived state queries
export const selectProducts = state => state.products.list;
export const selectProductsLoading = state => state.products.loading;

// 4. EFFECT: Handle side effects (HTTP calls)
loadProducts$ = createEffect(() =>
    this.actions$.pipe(
        ofType(ProductActions.loadProducts),
        switchMap(() => this.productService.getAll().pipe(
            map(products => ProductActions.loadProductsSuccess({ products }))
        ))
    )
);

// Benefits:
// 1. Predictable state changes
// 2. Easy debugging (time-travel debugging with DevTools)
// 3. Centralized state (single source of truth)
// 4. Easy to test (reducers are pure functions)
// 5. Easy to replay actions for debugging
```

---

### Immutability
**Definition**: Never modify existing state - always create new state.

#### Implementation: Reducers
- **File**: `frontend/src/app/core/store/reducers/`
- **Code**:
```typescript
// Immutability: Create NEW state objects, don't mutate existing ones
// WRONG: state.products.push(newProduct);  // MUTATES!
// WRONG: state.loading = false;  // MUTATES!

// CORRECT: Spread operator creates new object
return { ...state, loading: false, products: [...state.products, newProduct] };
// Benefits:
// 1. Change detection works (Angular compares references)
// 2. Time-travel debugging works
// 3. Predictable state changes
// 4. Easy to implement undo/redo
```

---

## Quick Reference Table

| Concept | Pattern | File Location |
|---------|---------|---------------|
| Single Responsibility | Separate Controllers, Handlers, Validators | All Controllers, Handlers, Validators |
| Open/Closed | MediatR pipeline, AutoMapper | Program.cs, Profiles |
| Liskov Substitution | Repository, AutoMapper Profiles | Handlers, Profiles |
| Interface Segregation | Separate DTOs, Commands/Queries | DTOs, Commands |
| Dependency Inversion | Constructor Injection | All Handlers, Controllers |
| CQRS | Commands + Queries | Commands/, Handlers/ |
| Repository | IUnitOfWork, IRepository | Handlers |
| Strategy | Exception Middleware | ExceptionMiddleware.cs |
| Factory | AutoMapper | Profiles |
| Decorator | Middleware Pipeline | Program.cs |
| Observer | RxJS Observables, ngrx Effects | Services, Effects |
| Singleton | HttpClient, ngrx Store | app.config.ts |
| Builder | HttpParams | product.service.ts |
| Facade | MediatR IMediator | Controllers |
| Clean Architecture | Layered projects | src/ folder structure |
| JWT Auth | Token generation & validation | AuthHandler, Program.cs |
| RBAC | [Authorize] attributes | Controllers |
| BCrypt | Password hashing | AuthHandler |
| CORS | AllowAll policy | Program.cs |
| Validation | FluentValidation | Validators/ |
| Pagination | Page/PageSize parameters | Controllers |
| DTO Projection | ProductDto, CategoryDto | DTOs/ |
| API Versioning | /api/v1/ routes | Program.cs |
| REST | HTTP methods & status codes | All Controllers |
| Soft Delete | IsDeleted column | All Entities |
| Concurrency | RowVersion column | All Entities |
| GUID Keys | Guid Id | All Entities |
| Structured Logging | Serilog | Program.cs |
| ngrx Store | Actions/Reducers/Selectors/Effects | core/store/ |
| RxJS | Observables, Operators | Services, Effects |
| Standalone Components | No NgModules | app.config.ts |
| HTTP Interceptors | Auth & Error interceptors | core/interceptors/ |
| Route Guards | AuthGuard, AdminGuard | app.routes.ts |

---

## 🎓 Learning Path for Freshers

### Week 1-2: Backend Fundamentals
1. Read `Program.cs` - understand middleware pipeline
2. Read `ProductsController.cs` - understand RESTful API
3. Read `ProductCommandHandler.cs` - understand CQRS
4. Read `ProductValidators.cs` - understand validation

### Week 3-4: Frontend Fundamentals
1. Read `app.config.ts` - understand Angular setup
2. Read `product.service.ts` - understand HTTP services
3. Read `root-store.ts` - understand ngrx setup
4. Read a component - understand component structure

### Week 5-6: Architecture & Patterns
1. Read all files in this guide
2. Trace a request: Controller → Command → Handler → Repository → Database
3. Trace a response: Database → Handler → DTO → Controller → JSON
4. Understand SOLID principles in context

### Week 7-8: Advanced Concepts
1. Read middleware code - understand decorators
2. Read effects code - understand observers
3. Read reducers - understand immutability
4. Read exception handling - understand strategy pattern

---

**Last Updated**: 2026-09-12
**Purpose**: Complete reference for every software engineering concept in this project
