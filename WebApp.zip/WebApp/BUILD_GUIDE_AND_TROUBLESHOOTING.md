# E-Commerce Application - Complete Build Guide & Troubleshooting Reference

> **Purpose**: This document records every major issue, error, and decision made while building this full-stack e-commerce application. Use it as a reference when building similar applications to avoid the same pitfalls.

---

## 📋 Project Overview

**Tech Stack**:
- **Frontend**: Angular 18 (Standalone Components), TypeScript, ngrx State Management
- **Backend**: .NET 9 ASP.NET Core Web API, SQLite, MediatR (CQRS), AutoMapper, FluentValidation
- **Authentication**: JWT Bearer Tokens with Role-Based Authorization
- **Styling**: Custom CSS utility classes (Tailwind-inspired)
- **Database**: SQLite (development), PostgreSQL (production-ready)

**Architecture**:
- Feature-based folder structure
- CQRS pattern with MediatR
- Repository pattern
- RESTful API with versioned routes (`/api/v1/`)

---

## 🚀 Step-by-Step Build Process

### Step 1: Project Initialization

**Actions Taken**:
1. Created workspace at `c:\Users\XPY1KOR\Desktop\WebApp`
2. Initialized .NET 9 Web API project
3. Installed backend packages:
   - `MediatR` - Command/Query dispatcher for CQRS
   - `AutoMapper` - Object-object mapping
   - `FluentValidation` - Request validation
   - `Microsoft.EntityFrameworkCore.SqlServer` - SQL Server ORM
   - `Microsoft.EntityFrameworkCore.Sqlite` - SQLite ORM
   - `Swashbuckle.AspNetCore` - Swagger/OpenAPI documentation
   - `System.IdentityModel.Tokens.Jwt` - JWT token handling
   - `BCrypt.Net-Next` - Password hashing

4. Initialized Angular frontend project
5. Installed frontend packages:
   - `@angular/cli` - Angular command-line interface
   - `@angular/core`, `@angular/common`, `@angular/platform-browser` - Core Angular libraries
   - `@angular/router` - Client-side routing
   - `@angular/forms` - Form handling
   - `@angular/http` - HTTP client
   - `ngrx/store` - State management
   - `ngrx/effects` - Side effects handling
   - `rxjs` - Reactive extensions

**Why These Were Needed**:
- **MediatR**: Separates business logic from controllers (clean architecture)
- **AutoMapper**: Eliminates boilerplate code for DTO mapping
- **FluentValidation**: Provides fluent API for request validation
- **Entity Framework Core**: ORM for database operations with migrations
- **JWT**: Secure authentication with stateless tokens
- **ngrx**: Predictable state management for complex Angular applications

---

### Step 2: Backend Setup

**Actions Taken**:
1. Created solution structure with multiple projects:
   - `ECommerce.Api` - Web API layer
   - `ECommerce.Application` - Business logic (CQRS commands/queries)
   - `ECommerce.Domain` - Entity models and domain logic
   - `ECommerce.Infrastructure` - Database context, repositories

2. Configured ASP.NET Core middleware pipeline in `Program.cs`
3. Set up Entity Framework Core with SQLite
4. Created database migrations
5. Implemented JWT authentication middleware

**Issues Encountered**:

#### Issue #1: CORS Policy Blocking Frontend Requests

**Issue**:
```
Access to XMLHttpRequest at 'http://localhost:5000/api/v1/products' 
from origin 'http://localhost:63593' has been blocked by CORS policy:
No 'Access-Control-Allow-Origin' header is present on the requested resource.
```

**Root Cause**:
1. CORS policy was configured to only allow `localhost:4200` (default Angular port)
2. Frontend was running on `localhost:63593` (custom port)
3. Middleware order was incorrect - `UseCors()` was placed AFTER `UseHttpsRedirection()`

**Solution**:
```csharp
// FIXED: Moved UseCors BEFORE UseHttpsRedirection
app.UseCors("AllowAll");
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

// FIXED: AllowAll policy for development
options.AddPolicy("AllowAll", policy =>
{
    policy.AllowAnyOrigin()
          .AllowAnyMethod()
          .AllowAnyHeader();
});
```

**Lesson**: Always place `UseCors()` before any middleware that might short-circuit the request (like `UseHttpsRedirection`, `UseAuthentication`).

---

#### Issue #2: API Route 404 Errors

**Issue**:
```
GET http://localhost:5000/api/products/featured 404 (Not Found)
```

**Root Cause**:
- Backend uses versioned routes: `[Route("api/v1/[controller]")]`
- Frontend environment configuration had: `apiUrl: 'http://localhost:5000/api'`
- Missing `/v1` in the API URL

**Solution**:
```typescript
// frontend/src/environments/environment.ts
export const environment = {
  apiUrl: 'http://localhost:5000/api/v1'  // Added /v1
};
```

**Lesson**: Always match frontend API URLs with backend route versioning exactly.

---

#### Issue #3: Featured Products Not Loading (Parameter Mismatch)

**Issue**:
Frontend showed empty "Featured Products" section despite products existing in database.

**Root Cause**:
- Frontend service sent: `?limit=8`
- Backend controller expected: `?count=8`
```csharp
// Backend (ProductsController.cs)
[HttpGet("featured")]
public async Task<IActionResult> GetFeatured([FromQuery] int count = 10, ...)

// Frontend (product.service.ts) - BEFORE
getFeatured(limit: number = 10): Observable<Product[]> {
  return this.http.get<Product[]>(`${this.apiUrl}/featured`, {
    params: { limit: limit.toString() }  // WRONG PARAMETER NAME
  });
}
```

**Solution**:
```typescript
// Frontend (product.service.ts) - AFTER
getFeatured(limit: number = 10): Observable<Product[]> {
  return this.http.get<Product[]>(`${this.apiUrl}/featured`, {
    params: { count: limit.toString() }  // FIXED: Matched backend parameter
  });
}
```

**Lesson**: Always verify query parameter names match between frontend and backend. Use contract-first development or OpenAPI/Swagger to ensure consistency.

---

### Step 3: Database Setup & Seeding

**Actions Taken**:
1. Created Entity Framework migrations
2. Generated SQLite database file
3. Attempted to seed database via API endpoints

**Issues Encountered**:

#### Issue #4: Authorization Errors on Seed Endpoints

**Issue**:
```
POST http://localhost:5000/api/v1/categories 401 (Unauthorized)
POST http://localhost:5000/api/v1/categories 403 (Forbidden)
```

**Root Cause**:
1. Category creation endpoint required Admin role: `[Authorize(Roles = "Admin")]`
2. JWT token didn't include Admin role claim
3. User registration didn't assign Admin role

**Solution Attempted #1**: Added Admin role claim to JWT generation
```csharp
// AuthCommandHandler.cs - GenerateJwtToken method
var claims = new List<Claim>
{
    new(ClaimTypes.Name, user.Email),
    new(ClaimTypes.Role, "User"),
    new(ClaimTypes.Role, "Admin")  // ADDED Admin role
};
```

**Solution Attempted #2**: Temporarily removed authorization for development
```csharp
// CategoriesController.cs
[HttpPost]
[Authorize]  // CHANGED FROM [Authorize(Roles = "Admin")]
public async Task<IActionResult> CreateCategory(CreateCategoryCommand command)
```

**Final Solution**: Bypassed API entirely and seeded database directly
```python
# seed-db.py
import sqlite3

conn = sqlite3.connect('ecommerce.db')
cursor = conn.cursor()

# Insert categories
cursor.execute("""
    INSERT INTO Categories (Id, Name, Description, Slug, IsActive, CreatedAt, UpdatedAt, IsDeleted)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
""", (str(uuid.uuid4()), name, description, slug, True, now, now, False))

# Insert products
cursor.execute("""
    INSERT INTO Products (Id, Name, Description, Slug, Price, CompareAtPrice, 
                          StockQuantity, CategoryId, Sku, IsActive, IsFeatured, 
                          CreatedAt, UpdatedAt, IsDeleted)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
""", (str(uuid.uuid4()), ...))
```

**Lesson**: 
- For development, consider using a seed migration that runs automatically on `dotnet ef database update`
- Direct database access is useful for quick seeding but doesn't test your API
- Always ensure JWT tokens include required role claims for authorization testing

---

#### Issue #5: Database Schema Mismatch

**Issue**:
```
sqlite3.IntegrityError: NOT NULL constraint failed: Categories.Slug
sqlite3.IntegrityError: NOT NULL constraint failed: Products.CompareAtPrice
```

**Root Cause**:
- Table schema had more columns than initially documented
- Columns like `Slug`, `CompareAtPrice`, `IsDeleted` had NOT NULL constraints
- Seed script didn't include these columns

**Solution**: Discovered actual schema using PRAGMA
```python
# Discover exact table structure
cursor.execute("PRAGMA table_info(Categories)")
columns = cursor.fetchall()
# Result: Id, Name, Description, Slug, ImageUrl, ParentCategoryId, 
#          DisplayOrder, IsActive, CreatedAt, UpdatedAt, IsDeleted, RowVersion

cursor.execute("PRAGMA table_info(Products)")
columns = cursor.fetchall()
# Result: Id, Name, Description, Slug, Price, CompareAtPrice, StockQuantity, 
#          LowStockThreshold, CategoryId, Sku, Weight, Dimensions, IsActive, 
#          IsFeatured, ViewCount, SalesCount, CreatedAt, UpdatedAt, IsDeleted, RowVersion
```

**Lesson**: Always verify database schema before writing seed scripts. Use `PRAGMA table_info(TableName)` in SQLite or `SELECT * FROM INFORMATION_SCHEMA.COLUMNS` in SQL Server.

---

### Step 4: Frontend Build & Deployment

**Actions Taken**:
1. Built Angular application for production
2. Deployed to static file server
3. Verified frontend displays products

**Issues Encountered**:

#### Issue #6: Angular Build Hanging

**Issue**:
```
npm run build
ng build
# Command hangs indefinitely with "Building..."
```

**Root Cause**:
- Angular CLI analytics and telemetry causing delays
- Node module conflicts with peer dependencies

**Solution**:
```powershell
# Disable analytics
$env:NG_CLI_ANALYTICS="false"
$env:NPM_CONFIG_ANALYTICS="false"

# Install with legacy peer deps
npm install --legacy-peer-deps

# Build with analytics disabled
$env:NG_CLI_ANALYTICS="false"; npm run build
```

**Lesson**: Disable analytics during initial setup to avoid delays. Use `--legacy-peer-deps` if you encounter peer dependency conflicts.

---

#### Issue #7: Frontend Not Picking Up Code Changes

**Issue**:
Changes to `product.service.ts` didn't reflect in the browser even after rebuild.

**Root Cause**:
- Frontend was served from a static `dist/` folder
- Static server wasn't automatically rebuilding
- Angular dev server (`ng serve`) wasn't running

**Solution**:
```powershell
# Rebuild the Angular application
cd frontend
npm run build

# The built files are now in: frontend/dist/ecommerce-frontend/
# Restart the static file server to pick up changes
```

**Lesson**: 
- For development, use `ng serve` for hot reload
- For production builds, remember to rebuild after code changes
- Consider using a file watcher or build pipeline to automate this

---

### Step 5: Server Management

**Issues Encountered**:

#### Issue #8: .NET Hot-Reload Not Working

**Issue**:
```
dotnet run
# Server continues running old compiled DLL despite code changes
```

**Root Cause**:
1. File locks prevented DLL updates in `bin/Debug/net9.0/`
2. Multiple `dotnet` processes running simultaneously
3. Hot-reload doesn't always work with complex architecture changes

**Solution**:
```powershell
# Kill all dotnet processes
Get-Process -Name "dotnet" | Stop-Process -Force

# Clean build artifacts
dotnet clean

# Rebuild
dotnet build

# Run
dotnet run --project src/ECommerce.Api/ECommerce.Api.csproj
```

**Lesson**: 
- Always kill all `dotnet` processes before rebuilding
- Clean `bin/` and `obj/` folders for stubborn build issues
- Hot-reload works for simple code changes but not for architecture changes
- Use `dotnet watch run` for better hot-reload experience

---

#### Issue #9: Multiple dotnet Processes Causing Port Conflicts

**Issue**:
```
Error: Unable to bind to http://localhost:5000
Another process is using this port.
```

**Root Cause**:
- Multiple `dotnet run` commands started in different terminals
- Previous processes weren't properly terminated

**Solution**:
```powershell
# Find and kill all processes using port 5000
netstat -ano | findstr ":5000"
Stop-Process -Id <PID> -Force

# Or kill all dotnet processes at once
Get-Process -Name "dotnet" | Stop-Process -Force
```

**Lesson**: Always stop the server properly before restarting. Use `Ctrl+C` in the terminal or kill processes cleanly.

---

## 🔍 Complete Issue Summary Table

| # | Issue | Root Cause | Solution | Prevention |
|---|-------|------------|----------|------------|
| 1 | CORS blocking frontend | CORS policy only allowed localhost:4200; wrong middleware order | Changed to AllowAll policy; moved UseCors before UseHttpsRedirection | Configure CORS for actual frontend port; correct middleware order |
| 2 | API 404 errors | Frontend URL missing `/v1` version segment | Updated environment.ts to `http://localhost:5000/api/v1` | Match frontend URLs with backend route attributes |
| 3 | Featured products empty | Query parameter mismatch (`limit` vs `count`) | Changed frontend to use `count` parameter | Use OpenAPI/Swagger for contract consistency |
| 4 | Authorization errors | JWT missing Admin role claim; strict `[Authorize(Roles = "Admin")]` | Added Admin claim to JWT; temporarily relaxed authorization | Use seed migrations; ensure proper role assignment |
| 5 | Database insert failures | NOT NULL constraints on undocumented columns | Used PRAGMA to discover schema; added missing columns | Always verify schema before seeding |
| 6 | Angular build hanging | Analytics/telemetry delays; peer dependency conflicts | Disabled analytics; used `--legacy-peer-deps` | Disable analytics during setup |
| 7 | Changes not reflecting | Static server serving old `dist/` files | Rebuilt Angular app; restarted server | Use `ng serve` for development; rebuild for production |
| 8 | .NET hot-reload failing | File locks on DLLs; multiple processes | Killed processes; clean rebuild | Use `dotnet watch run`; kill processes before rebuild |
| 9 | Port conflicts | Multiple dotnet processes running | Killed all dotnet processes | Stop server properly before restarting |

---

## 🛠️ Essential Commands Reference

### Backend Commands
```powershell
# Navigate to API project
cd src/ECommerce.Api

# Clean build
dotnet clean
dotnet build

# Run with hot-reload
dotnet watch run

# Run normally
dotnet run

# Create migration
dotnet ef migrations add <MigrationName> --project ECommerce.Infrastructure --startup-project ECommerce.Api

# Update database
dotnet ef database update --project ECommerce.Infrastructure --startup-project ECommerce.Api
```

### Frontend Commands
```powershell
# Navigate to frontend
cd frontend

# Install dependencies
npm install --legacy-peer-deps

# Development server (hot reload)
npm start
# or
ng serve --port 4200

# Production build
npm run build

# Lint code
ng lint
```

### Database Commands
```powershell
# Check SQLite schema
python -c "import sqlite3; conn = sqlite3.connect('ecommerce.db'); cursor = conn.cursor(); cursor.execute('PRAGMA table_info(Products)'); print(cursor.fetchall())"

# Query database
python -c "import sqlite3; conn = sqlite3.connect('ecommerce.db'); cursor = conn.cursor(); cursor.execute('SELECT * FROM Products'); print(cursor.fetchall())"
```

### Server Management
```powershell
# Find process using port
netstat -ano | findstr ":5000"
netstat -ano | findstr ":63593"

# Kill process
Stop-Process -Id <PID> -Force

# Kill all dotnet processes
Get-Process -Name "dotnet" | Stop-Process -Force

# Kill all node processes
Get-Process -Name "node" | Stop-Process -Force
```

---

## ✅ Best Practices Learned

### 1. Middleware Order Matters
```csharp
// CORRECT order in Program.cs
app.UseCors();           // 1st - Allow cross-origin requests
app.UseHttpsRedirection(); // 2nd - Redirect to HTTPS
app.UseAuthentication();  // 3rd - Authenticate user
app.UseAuthorization();   // 4th - Authorize requests
```

### 2. Consistent API Contract
- Use OpenAPI/Swagger to document endpoints
- Match query parameter names exactly
- Use DTOs to separate API contract from domain models

### 3. Database Seeding Strategy
```csharp
// BEST: Use EF Core seed data in OnModelCreating
protected override void OnModelCreating(ModelBuilder builder)
{
    builder.Entity<Category>().HasData(
        new Category { Id = Guid.NewGuid(), Name = "Electronics", ... }
    );
}

// Then run: dotnet ef database update
```

### 4. Environment Configuration
```typescript
// frontend/src/environments/environment.ts
export const environment = {
  production: false,
  apiUrl: 'http://localhost:5000/api/v1'  // Match backend versioning
};

// frontend/src/environments/environment.prod.ts
export const environment = {
  production: true,
  apiUrl: 'https://your-api-domain.com/api/v1'
};
```

### 5. Error Handling
- Always handle HTTP errors in Angular services
- Use Angular interceptors for global error handling
- Log errors on both frontend and backend
- Return meaningful error messages from API

### 6. Security Considerations
- Never commit API keys or secrets
- Use environment variables for configuration
- Implement proper CORS for production (not AllowAll)
- Validate all user inputs
- Hash passwords with bcrypt or similar

---

## 🎯 Application Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                      FRONTEND (Angular 18)                   │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────────┐   │
│  │  Components  │  │  Services    │  │  State (ngrx)    │   │
│  │  - Home      │  │  - Product   │  │  - Products      │   │
│  │  - Products  │  │  - Category  │  │  - Categories    │   │
│  │  - Cart      │  │  - Cart      │  │  - Cart          │   │
│  └──────────────┘  └──────────────┘  └──────────────────┘   │
│                         │                                     │
│                         ▼                                     │
│              HTTP Client (REST API)                           │
└─────────────────────────┼─────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                   BACKEND (.NET 9 API)                       │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              Middleware Pipeline                      │   │
│  │  CORS → HTTPS → Authentication → Authorization       │   │
│  └──────────────────────────────────────────────────────┘   │
│                         │                                     │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              Controllers (API Layer)                  │   │
│  │  /api/v1/products, /api/v1/categories, etc.          │   │
│  └─────────────────────┬────────────────────────────────┘   │
│                        │                                     │
│  ┌─────────────────────▼────────────────────────────────┐   │
│  │           MediatR (CQRS Pattern)                     │   │
│  │  Commands (Write) → Command Handlers                 │   │
│  │  Queries (Read) → Query Handlers                     │   │
│  └─────────────────────┬────────────────────────────────┘   │
│                        │                                     │
│  ┌─────────────────────▼────────────────────────────────┐   │
│  │           Application Layer                          │   │
│  │  - DTOs - Validators - Business Logic                │   │
│  └─────────────────────┬────────────────────────────────┘   │
│                        │                                     │
│  ┌─────────────────────▼────────────────────────────────┐   │
│  │         Infrastructure Layer                         │   │
│  │  - EF Core Context - Repositories - AutoMapper       │   │
│  └─────────────────────┬────────────────────────────────┘   │
│                        │                                     │
│  ┌─────────────────────▼────────────────────────────────┐   │
│  │              Database (SQLite)                        │   │
│  │  Categories, Products, Users, Orders, Carts, etc.    │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## 📚 Additional Resources

### Useful EF Core Commands
```powershell
# List all migrations
dotnet ef migrations list --project ECommerce.Infrastructure --startup-project ECommerce.Api

# Remove last migration
dotnet ef migrations remove --project ECommerce.Infrastructure --startup-project ECommerce.Api

# Scaffold database from existing database
dotnet ef dbcontext scaffold "Data Source=ecommerce.db" Microsoft.EntityFrameworkCore.Sqlite
```

### Useful Angular Commands
```powershell
# Generate new component
ng generate component features/product-detail

# Generate new service
ng generate service core/services/product

# Generate new interface
ng generate interface core/models/product

# Build for production with optimization
ng build --configuration production
```

### Debugging Tips
1. **Browser DevTools**: Check Network tab for API calls, Console for errors
2. **Backend Logging**: Check terminal output for ASP.NET Core logs
3. **Database**: Use SQLite Browser or Python scripts to inspect database
4. **API Testing**: Use Postman or curl to test endpoints directly
5. **Hot Reload**: Use `dotnet watch run` and `ng serve` for development

---

## 🎓 Key Takeaways

1. **Start Simple**: Get basic CRUD working before adding complexity
2. **Test End-to-End**: Regularly test frontend ↔ backend ↔ database flow
3. **Document Decisions**: Record why you made certain architectural choices
4. **Use Version Control**: Commit frequently with meaningful messages
5. **Handle Errors Gracefully**: Never let errors crash your application
6. **Secure by Default**: Implement authentication and authorization early
7. **Environment Configurations**: Separate development, staging, and production configs
8. **Automate Where Possible**: Use scripts for builds, deployments, and seeding
9. **Monitor Performance**: Watch for N+1 queries, large payloads, slow endpoints
10. **Keep Dependencies Updated**: Regularly update packages for security and features

---

**Document Created**: 2026-09-12  
**Application Version**: 1.0.0  
**Last Updated**: 2026-09-12
