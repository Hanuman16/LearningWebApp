export const environment = {
  production: false,
  apiUrl: 'http://localhost:5000/api/v1',
  frontendUrl: 'http://localhost:4200'
};
