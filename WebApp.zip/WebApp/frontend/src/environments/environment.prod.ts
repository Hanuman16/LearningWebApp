export const environment = {
  production: true,
  apiUrl: 'https://api.ecommerce.com/api',
  frontendUrl: 'https://www.ecommerce.com'
};
