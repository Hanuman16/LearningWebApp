import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  Product,
  Category,
  ProductSearchParams,
  PagedResponse
} from '../models/product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/products`;

  getAll(page?: number, pageSize?: number, search?: string, categoryId?: string): Observable<PagedResponse<Product>> {
    let httpParams = new HttpParams();
    
    if (page) httpParams = httpParams.set('pageNumber', page.toString());
    if (pageSize) httpParams = httpParams.set('pageSize', pageSize.toString());
    if (search) httpParams = httpParams.set('searchQuery', search);
    if (categoryId) httpParams = httpParams.set('categoryId', categoryId);

    return this.http.get<PagedResponse<Product>>(this.apiUrl, { params: httpParams });
  }

  getById(id: string): Observable<Product> {
    return this.http.get<Product>(`${this.apiUrl}/${id}`);
  }

  getFeatured(limit: number = 10): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.apiUrl}/featured`, {
      params: { count: limit.toString() }
    });
  }

  getByCategory(categoryId: string, pageNumber: number = 1, pageSize: number = 12): Observable<PagedResponse<Product>> {
    return this.http.get<PagedResponse<Product>>(`${this.apiUrl}/category/${categoryId}`, {
      params: { pageNumber: pageNumber.toString(), pageSize: pageSize.toString() }
    });
  }

  create(product: Partial<Product>): Observable<Product> {
    return this.http.post<Product>(this.apiUrl, product);
  }

  update(id: string, product: Partial<Product>): Observable<Product> {
    return this.http.put<Product>(`${this.apiUrl}/${id}`, product);
  }

  delete(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  getCategories(): Observable<Category[]> {
    return this.http.get<Category[]>(`${environment.apiUrl}/categories`);
  }

  search(query: string, pageNumber: number = 1, pageSize: number = 12): Observable<PagedResponse<Product>> {
    return this.http.get<PagedResponse<Product>>(this.apiUrl, {
      params: { searchQuery: query, pageNumber: pageNumber.toString(), pageSize: pageSize.toString() }
    });
  }
}
