import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  DashboardOverviewDto,
  SalesReportDto,
  InventoryReportDto
} from '../models/dashboard.model';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/dashboard`;

  getDashboardOverview(): Observable<DashboardOverviewDto> {
    return this.http.get<DashboardOverviewDto>(`${this.apiUrl}/overview`);
  }

  getSalesReport(startDate?: string, endDate?: string): Observable<SalesReportDto> {
    const params: any = {};
    if (startDate) params.startDate = startDate;
    if (endDate) params.endDate = endDate;
    return this.http.get<SalesReportDto>(`${this.apiUrl}/sales`, { params });
  }

  getInventoryReport(): Observable<InventoryReportDto> {
    return this.http.get<InventoryReportDto>(`${this.apiUrl}/inventory`);
  }

  getTopSellingProducts(limit?: number): Observable<any[]> {
    const params: any = {};
    if (limit) params.limit = limit;
    return this.http.get<any[]>(`${this.apiUrl}/top-selling`, { params });
  }

  getRecentOrders(count?: number): Observable<any[]> {
    const params: any = {};
    if (count) params.count = count;
    return this.http.get<any[]>(`${this.apiUrl}/recent-orders`, { params });
  }
}
