import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { InventorySummary, InventoryTransaction } from '../models/inventory.model';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/inventory`;

  getProductInventory(productId: string): Observable<InventorySummary> {
    return this.http.get<InventorySummary>(`${this.apiUrl}/${productId}`);
  }

  getLowStockItems(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/low-stock`);
  }

  updateStock(productId: string, quantity: number): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${productId}/stock`, { quantity });
  }

  getTransactionHistory(productId?: string): Observable<InventoryTransaction[]> {
    const params: any = {};
    if (productId) params.productId = productId;
    return this.http.get<InventoryTransaction[]>(`${this.apiUrl}/transactions`, { params });
  }

  getInventorySummary(): Observable<InventorySummary> {
    return this.http.get<InventorySummary>(`${this.apiUrl}/summary`);
  }
}
