export interface InventoryItem {
  id: string;
  productId: string;
  product?: Product;
  warehouseLocation: string;
  quantity: number;
  reservedQuantity: number;
  reorderLevel: number;
  isActive: boolean;
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  price: number;
}

export interface InventorySummary {
  totalItems: number;
  totalValue: number;
  lowStockItems: number;
  outOfStockItems: number;
  items: InventoryItem[];
}

export interface InventoryTransaction {
  id: string;
  inventoryItemId: string;
  productId: string;
  type: string;
  quantity: number;
  previousQuantity: number;
  newQuantity: number;
  referenceNumber: string;
  notes: string;
  createdByUserId: string;
  createdAt: string;
}
