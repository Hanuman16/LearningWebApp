export interface DashboardOverviewDto {
  totalOrders: number;
  totalRevenue: number;
  totalProducts: number;
  totalCustomers: number;
  ordersGrowth: number;
  revenueGrowth: number;
  customersGrowth: number;
  lowStockProducts: number;
  recentOrders: RecentOrderDto[];
}

export interface RecentOrderDto {
  id: string;
  orderNumber: string;
  customerEmail: string;
  totalAmount: number;
  status: string;
  createdAt: string;
}

export interface SalesReportDto {
  totalSales: number;
  totalOrders: number;
  averageOrderValue: number;
  salesByPeriod: SalesByPeriodDto[];
  topProducts: TopProductDto[];
}

export interface SalesByPeriodDto {
  period: string;
  sales: number;
  orders: number;
}

export interface TopProductDto {
  productId: string;
  productName: string;
  quantitySold: number;
  revenue: number;
}

export interface InventoryReportDto {
  totalProducts: number;
  totalInventoryValue: number;
  lowStockItems: number;
  outOfStockItems: number;
  inventoryByCategory: InventoryByCategoryDto[];
}

export interface InventoryByCategoryDto {
  categoryName: string;
  productCount: number;
  totalQuantity: number;
  totalValue: number;
}
