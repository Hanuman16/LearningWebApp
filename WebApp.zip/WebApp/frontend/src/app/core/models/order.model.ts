import { Address } from './address.model';
import { Product } from './product.model';

export interface Order {
  id: string;
  userId: string;
  orderNumber: string;
  status: string;
  customerNotes?: string;
  internalNotes?: string;
  subtotal: number;
  taxAmount: number;
  shippingAmount: number;
  discountAmount: number;
  totalAmount: number;
  currency: string;
  shippingMethodName?: string;
  trackingNumber?: string;
  trackingUrl?: string;
  paymentMethod?: string;
  paymentTransactionId?: string;
  paymentStatus: string;
  paidAt?: string;
  shippedAt?: string;
  deliveredAt?: string;
  cancelledAt?: string;
  cancelledByUserId?: string;
  cancellationReason?: string;
  items: OrderItem[];
  shippingAddress?: Address;
  billingAddress?: Address;
  createdAt: string;
  updatedAt?: string;
}

export interface OrderItem {
  id: string;
  orderId: string;
  productId: string;
  product?: Product;
  quantity: number;
  unitPrice: number;
  subtotal: number;
}

export interface CreateOrderRequest {
  shippingAddressId: string;
  billingAddressId?: string;
  shippingMethodName: string;
  paymentMethod: string;
  customerNotes?: string;
}

export interface UpdateOrderStatusRequest {
  status: string;
  internalNotes?: string;
}

export interface Payment {
  id: string;
  orderId: string;
  paymentGateway: string;
  transactionId: string;
  paymentMethod: string;
  amount: number;
  currency: string;
  status: string;
  gatewayResponse?: string;
  errorMessage?: string;
  processedAt?: string;
}

export interface PagedResponse<T> {
  items: T[];
  totalCount: number;
  page: number;
  pageSize: number;
  totalPages: number;
}
