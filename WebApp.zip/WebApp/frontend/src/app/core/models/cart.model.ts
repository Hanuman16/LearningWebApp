import { Product } from './product.model';

export interface Cart {
  id: string;
  userId: string;
  items: CartItem[];
  couponCode?: string;
  discountAmount: number;
  taxAmount: number;
  shippingAmount: number;
  subtotal: number;
  total: number;
  status: string;
  createdAt: string;
  updatedAt?: string;
}

export interface CartItem {
  id: string;
  cartId: string;
  productId: string;
  product?: Product;
  quantity: number;
  unitPrice: number;
  subtotal: number;
}

export interface AddCartItemRequest {
  productId: string;
  quantity: number;
}

export interface UpdateCartItemRequest {
  itemId: string;
  quantity: number;
}

export interface ApplyCouponRequest {
  couponCode: string;
}
