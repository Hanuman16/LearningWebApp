export interface Product {
  id: string;
  name: string;
  description: string;
  slug: string;
  price: number;
  compareAtPrice?: number;
  stockQuantity: number;
  lowStockThreshold: number;
  categoryId: string;
  category?: Category;
  sku: string;
  weight?: number;
  dimensions?: string;
  isActive: boolean;
  isFeatured: boolean;
  viewCount: number;
  salesCount: number;
  images?: ProductImage[];
  averageRating?: number;
  reviewCount?: number;
  createdAt: string;
  updatedAt?: string;
}

export interface ProductImage {
  id: string;
  productId: string;
  url: string;
  altText?: string;
  displayOrder: number;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  slug: string;
  imageUrl?: string;
  parentCategoryId?: string;
  parentCategory?: Category;
  displayOrder: number;
  isActive: boolean;
  children?: Category[];
}

export interface ProductSearchParams {
  searchQuery?: string;
  categoryId?: string;
  minPrice?: number;
  maxPrice?: number;
  sortBy?: 'name' | 'price' | 'rating' | 'newest' | 'popularity';
  sortOrder?: 'asc' | 'desc';
  pageNumber: number;
  pageSize: number;
  isActive?: boolean;
  isFeatured?: boolean;
}

export interface PagedResponse<T> {
  items: T[];
  totalCount: number;
  pageNumber: number;
  pageSize: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}
