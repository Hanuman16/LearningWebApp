import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';

/**
 * ╔═══════════════════════════════════════════════════════════╗
 * ║  ERROR INTERCEPTOR - Global Error Handling               ║
 * ╚═══════════════════════════════════════════════════════════╝
 * 
 * CONCEPTS IMPLEMENTED:
 * ─────────────────────
 * 
 * 1. HTTP INTERCEPTOR PATTERN (Global Error Handling)
 *    - Intercepts ALL HTTP responses for errors
 *    - Centralized error handling = DRY principle
 *    - WITHOUT interceptor: Would need .catch() on EVERY HTTP call
 *    - WITH interceptor: Error handled once for all requests
 *    - Consistent error handling across entire application
 * 
 * 2. RXJS ERROR HANDLING (Reactive Programming)
 *    - catchError: Catches errors in Observable stream
 *    - WITHOUT catchError: Error propagates to component → app crashes
 *    - WITH catchError: Error caught, logged, handled gracefully
 *    - throwError: Creates new Observable that emits error
 *    - () => error: Pass error to next error handler (reactive)
 * 
 * 3. HTTP STATUS CODE HANDLING
 *    - 401 Unauthorized: Token expired/invalid → logout + redirect to login
 *    - 403 Forbidden: User authenticated but not authorized → redirect to /forbidden
 *    - 404 Not Found: Resource doesn't exist → redirect to /not-found
 *    - 500 Server Error: Backend crashed → log error, show user-friendly message
 *    - Default: Log error, continue (network error, validation error, etc.)
 * 
 * 4. AUTOMATIC LOGOUT (Security)
 *    - When 401 received → token is invalid/expired
 *    - authService.logout() clears token + user state
 *    - router.navigate(['/login']) → redirect to login page
 *    - User must re-authenticate with fresh credentials
 *    - Prevents use of expired tokens
 * 
 * 5. USER EXPERIENCE (UX)
 *    - 401 → Automatic redirect to login (user doesn't see error)
 *    - 403 → Redirect to forbidden page (clear message)
 *    - 404 → Redirect to not found page (clear message)
 *    - 500 → Log error, show generic message (don't blame server)
 *    - Other → Log error, show generic message (don't expose details)
 * 
 * 6. DEFENSIVE PROGRAMMING
 *    - console.error: Log errors for debugging
 *    - Don't expose server errors to users (security)
 *    - Don't crash app on error (graceful degradation)
 *    - Return error: Allows component to handle if needed
 * 
 * 7. SEPARATION OF CONCERNS
 *    - Interceptor handles HTTP-level errors (401, 403, 404, 500)
 *    - Component handles business-level errors (validation, domain rules)
 *    - Two layers of error handling = comprehensive coverage
 * 
 * 8. CHAIN OF RESPONSIBILITY
 *    - Multiple interceptors can handle same request/response
 *    - authInterceptor adds token → errorInterceptor handles errors
 *    - Order matters: Both run for every HTTP request
 */

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  // INJECT SERVICES: Inject dependencies for error handling
  const authService = inject(AuthService);   // For logout on 401
  const router = inject(Router);             // For navigation on errors

  // EXECUTE REQUEST: Send request through interceptor chain
  // .pipe(): RxJS operator for streaming data/errors
  return next(req).pipe(
    // ERROR HANDLING: Catch any HTTP errors in the Observable stream
    // WITHOUT catchError: Error would propagate to component → app crash
    // WITH catchError: Error caught, handled gracefully
    catchError((error: HttpErrorResponse) => {
      // HTTP ERROR RESPONSE: Contains status code, message, details
      // HttpErrorResponse = Angular's type for HTTP errors
      // Unlike TypeError (network error), HttpErrorResponse has .status
      
      switch (error.status) {
        // ═══════════════════════════════════════════════════
        // 401 UNAUTHORIZED: Token expired or invalid
        // ═══════════════════════════════════════════════════
        case 401:
          // SECURITY: Token is invalid/expired
          // LOGOUT: Clear token + user state from memory
          authService.logout();
          // REDIRECT: Send user to login page
          // User must re-authenticate with fresh credentials
          router.navigate(['/login']);
          break;
          
        // ═══════════════════════════════════════════════════
        // 403 FORBIDDEN: User authenticated but not authorized
        // ═══════════════════════════════════════════════════
        case 403:
          // User is logged in but doesn't have required role
          // Example: Regular user tries to access /admin
          // REDIRECT: Show forbidden page (clear message)
          router.navigate(['/forbidden']);
          break;
          
        // ═══════════════════════════════════════════════════
        // 404 NOT FOUND: Resource doesn't exist
        // ═══════════════════════════════════════════════════
        case 404:
          // Resource (product, order, etc.) doesn't exist
          // REDIRECT: Show not found page (better UX than error)
          router.navigate(['/not-found']);
          break;
          
        // ═══════════════════════════════════════════════════
        // 500 SERVER ERROR: Backend crashed
        // ═══════════════════════════════════════════════════
        case 500:
          // SERVER FAILURE: Backend encountered unexpected error
          // LOG: For debugging (check server logs for details)
          // DON'T expose server details to user (security)
          console.error('Server error:', error.message);
          break;
          
        // ═══════════════════════════════════════════════════
        // DEFAULT: Network error, validation error, etc.
        // ═══════════════════════════════════════════════════
        default:
          // OTHER ERRORS: Network offline, validation error, etc.
          // LOG: For debugging
          // Component can handle specific errors (validation messages)
          console.error('An error occurred:', error);
          break;
      }
      
      // RE-THROW: Pass error to component for additional handling
      // throwError(() => error): Creates Observable that emits error
      // Component can subscribe to error handler for custom logic
      return throwError(() => error);
    })
  );
};
