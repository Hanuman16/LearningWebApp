import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';

/**
 * ╔═══════════════════════════════════════════════════════════╗
 * ║  AUTH INTERCEPTOR - JWT Token Injection                  ║
 * ╚═══════════════════════════════════════════════════════════╝
 * 
 * CONCEPTS IMPLEMENTED:
 * ─────────────────────
 * 
 * 1. HTTP INTERCEPTOR PATTERN (Decorator Pattern)
 *    - Intercepts ALL HTTP requests before they are sent
 *    - Modifies request (adds Authorization header)
 *    - Can also modify responses (log, transform, error handling)
 *    - Decorator Pattern: Wraps HTTP client with additional functionality
 *    - WITHOUT interceptor: Would need to add token to EVERY HTTP call
 *    - WITH interceptor: Token added automatically to ALL requests
 *    - Centralized authentication logic = DRY principle
 * 
 * 2. BEARER TOKEN AUTHENTICATION
 *    - HTTP standard for token-based authentication
 *    - Header format: Authorization: Bearer <jwt_token>
 *    - "Bearer" = token bearer proves their identity
 *    - Server validates token signature and extracts user identity
 *    - Token contains: user email, roles, expiration, unique ID
 * 
 * 3. FUNCTIONAL INTERCEPTORS (Angular 15+)
 *    - New functional style: (req, next) => {...}
 *    - OLD style: Class-based (extends HttpInterceptor)
 *    - NEW style: Pure function (simpler, testable)
 *    - HttpInterceptorFn = Type alias for interceptor function
 *    - inject() = Can inject services inside interceptor
 * 
 * 4. REQUEST CLONING (Immutability)
 *    - req.clone() = Creates modified copy of request
 *    - Original request is NOT modified (immutability)
 *    - clone({ setHeaders: {...} }) = Adds/overrides headers
 *    - Why clone? HttpRequest is immutable (can't modify directly)
 * 
 * 5. CONDITIONAL HEADER INJECTION
 *    - Only adds Authorization header if token exists
 *    - Public endpoints (login, register) don't have token
 *    - Protected endpoints (cart, orders) have token
 *    - getToken() returns null if user not logged in
 * 
 * 6. TOKEN LIFECYCLE
 *    - Token stored in AuthService (memory, NOT localStorage)
 *    - Token expires in 15 minutes
 *    - When expired → error.interceptor handles 401 → redirects to login
 *    - Refresh token used to get new access token
 * 
 * 7. SECURITY CONSIDERATIONS
 *    - Token stored in MEMORY (cleared on page refresh)
 *    - NOT in localStorage (vulnerable to XSS attacks)
 *    - NOT in sessionStorage (available across tabs)
 *    - httpOnly cookie = Best practice (not implemented yet)
 *    - HTTPS required in production (token sent over encrypted connection)
 * 
 * 8. NEXT FUNCTION (Chain of Responsibility)
 *    - next(req) = Passes request to next interceptor in chain
 *    - Multiple interceptors can modify same request
 *    - Order matters: auth interceptor must run before API calls
 *    - Returns Observable<HttpResponse>
 */

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  // INJECT SERVICES: Can inject services in functional interceptors
  const authService = inject(AuthService);
  
  // GET TOKEN: Retrieve JWT token from auth service
  // Returns null if user not logged in or token expired
  const token = authService.getToken();

  // CONDITIONAL: Only add Authorization header if token exists
  // Public endpoints (login, register) don't have token yet
  if (token) {
    // REQUEST CLONING: Create modified copy of request
    // Original request is immutable (can't modify directly)
    const cloned = req.clone({
      // SET HEADER: Add Authorization header with Bearer token
      // Header format: "Authorization: Bearer <jwt_token>"
      setHeaders: {
        Authorization: `Bearer ${token}`  // Template literal: Bearer + space + token
      }
    });
    
    // PASS TO NEXT: Send modified request to next interceptor / HTTP handler
    return next(cloned);
  }

  // NO TOKEN: Pass original request unchanged
  // Public endpoints (login, register) don't need authorization
  return next(req);
};
