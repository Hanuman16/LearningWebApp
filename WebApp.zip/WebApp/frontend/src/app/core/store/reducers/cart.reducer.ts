import { createReducer, on } from '@ngrx/store';
import {
  loadCartSuccess,
  loadCartFailure,
  addToCartSuccess,
  addToCartFailure,
  updateCartItemSuccess,
  updateCartItemFailure,
  removeFromCartSuccess,
  removeFromCartFailure,
  clearCartSuccess,
  clearCartFailure,
  applyCouponSuccess,
  applyCouponFailure,
  removeCouponSuccess,
  removeCouponFailure
} from '../actions/cart.actions';
import { CartState, initialState } from '../states/cart.state';

export const cartReducer = createReducer(
  initialState,
  on(loadCartSuccess, (state, { cart }) => ({
    ...state,
    cart,
    loading: false,
    error: null
  })),
  on(loadCartFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  on(addToCartSuccess, (state, { cart }) => ({
    ...state,
    cart,
    loading: false,
    error: null
  })),
  on(addToCartFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  on(updateCartItemSuccess, (state, { cart }) => ({
    ...state,
    cart,
    loading: false,
    error: null
  })),
  on(updateCartItemFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  on(removeFromCartSuccess, (state, { cart }) => ({
    ...state,
    cart,
    loading: false,
    error: null
  })),
  on(removeFromCartFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  on(clearCartSuccess, (state, { cart }) => ({
    ...state,
    cart,
    loading: false,
    error: null
  })),
  on(clearCartFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  on(applyCouponSuccess, (state, { cart }) => ({
    ...state,
    cart,
    loading: false,
    error: null
  })),
  on(applyCouponFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  on(removeCouponSuccess, (state, { cart }) => ({
    ...state,
    cart,
    loading: false,
    error: null
  })),
  on(removeCouponFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  }))
);
