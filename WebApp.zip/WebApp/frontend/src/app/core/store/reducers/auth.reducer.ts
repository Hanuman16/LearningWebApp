import { createReducer, on } from '@ngrx/store';
import {
  loginSuccess,
  loginFailure,
  logout,
  registerSuccess,
  registerFailure,
  setCurrentUser,
  clearCurrentUser
} from '../actions/auth.actions';
import { AuthState, initialState } from '../states/auth.state';

export const authReducer = createReducer(
  initialState,
  on(loginSuccess, (state, { response }) => ({
    ...state,
    token: response.token,
    refreshToken: response.refreshToken,
    user: response.user,
    isAuthenticated: true,
    loading: false,
    error: null
  })),
  on(loginFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  on(logout, clearCurrentUser, () => initialState),
  on(registerSuccess, (state, { response }) => ({
    ...state,
    token: response.token,
    refreshToken: response.refreshToken,
    user: response.user,
    isAuthenticated: true,
    loading: false,
    error: null
  })),
  on(registerFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  on(setCurrentUser, (state, { user }) => ({
    ...state,
    user
  }))
);
