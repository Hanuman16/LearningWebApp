import { createReducer, on } from '@ngrx/store';
import {
  loadProductsSuccess,
  loadProductsFailure,
  loadProductByIdSuccess,
  loadProductByIdFailure,
  loadFeaturedProductsSuccess,
  loadFeaturedProductsFailure,
  createProductSuccess,
  createProductFailure,
  updateProductSuccess,
  updateProductFailure,
  deleteProductSuccess,
  deleteProductFailure,
  loadCategoriesSuccess,
  loadCategoriesFailure
} from '../actions/product.actions';
import { ProductState, initialState } from '../states/product.state';

/**
 * ╔═══════════════════════════════════════════════════════════╗
 * ║  PRODUCT REDUCER - State Updates (Pure Functions)        ║
 * ╚═══════════════════════════════════════════════════════════╝
 * 
 * CONCEPTS IMPLEMENTED:
 * ─────────────────────
 * 
 * 1. REDUCER FUNCTION (State Transition Logic)
 *    - Reducer = Pure function: (state, action) → newState
 *    - SAME input ALWAYS produces SAME output (deterministic)
 *    - NO side effects (no API calls, no console.log, no Math.random)
 *    - NO mutations (never modify state directly)
 *    - Analogy: Reducer = State machine (input state + action = output state)
 *    - Each action type triggers different state transition
 * 
 * 2. CREATE REDUCER PATTERN (ngrx/store)
 *    - createReducer(initialState, ...handlers)
 *    - First param: initialState (starting state)
 *    - Remaining params: on(action, handler) pairs
 *    - Each handler: (state, actionPayload) => newState
 *    - TypeScript enforces: All actions must have handlers
 * 
 * 3. IMMUTABILITY PATTERN (Spread Operator)
 *    - NEVER: state.loading = true (MUTATES state → app breaks)
 *    - ALWAYS: { ...state, loading: true } (creates NEW state)
 *    - Spread operator: { ...state } copies all existing properties
 *    - Then override specific properties: { ...state, loading: false }
 *    - Why? Angular change detection compares object references
 *    - If reference doesn't change → Angular doesn't update UI
 * 
 * 4. UNIDIRECTIONAL DATA FLOW (Reducer Role)
 *    - Components DISPATCH actions (never modify state directly)
 *    - Reducer LISTENS for actions (on(action, handler))
 *    - Reducer PRODUCES new state (pure function)
 *    - Store UPDATES state (replaces old state with new state)
 *    - Components SELECT state (receive updated data)
 *    - Flow: Component → Action → Reducer → Store → Selector → Component
 * 
 * 5. ACTION HANDLERS (on() Function)
 *    - on(action, handler): Register handler for specific action
 *    - Multiple handlers registered for different actions
 *    - When action dispatched → matching handler called
 *    - Handler receives: (currentState, actionPayload)
 *    - Handler returns: newState (partial or full)
 * 
 * 6. PARTIAL STATE UPDATES (Selective Property Changes)
 *    - { ...state, loading: false } → Updates ONLY loading property
 *    - Other properties (products, error, etc.) remain unchanged
 *    - Spread operator copies all existing properties
 *    - Then overrides specific properties with new values
 *    - Enables: Granular state updates without affecting other properties
 * 
 * 7. LOADING STATE PATTERN (UX Optimization)
 *    - BEFORE API call: loading = true → Show spinner
 *    - AFTER API call: loading = false → Hide spinner
 *    - Prevents: Multiple simultaneous API calls
 *    - Enables: Loading indicators, disabled buttons
 * 
 * 8. ERROR STATE PATTERN (User Feedback)
 *    - On success: error = null (clear previous errors)
 *    - On failure: error = actionError (show error to user)
 *    - Component displays error message from state
 *    - Error cleared on next successful action
 * 
 * 9. ARRAY OPERATIONS (Immutability with Arrays)
 *    - ADD: [...state.products, product] → Creates NEW array with product appended
 *    - UPDATE: state.products.map(p => p.id === id ? product : p) → Creates NEW array
 *    - DELETE: state.products.filter(p => p.id !== id) → Creates NEW array
 *    - NEVER: state.products.push(product) (MUTATES array → app breaks)
 *    - Array methods (map, filter, spread) return NEW arrays
 * 
 * 10. NESTED OBJECT UPDATES (Optional Chaining)
 *     - selectedProduct: state.selectedProduct?.id === product.id ? product : state.selectedProduct
 *     - Optional chaining (?.): Handles null/undefined safely
 *     - If selectedProduct is null → returns null (no crash)
 *     - If selectedProduct.id matches → returns new product
 *     - Otherwise → returns unchanged selectedProduct
 */

export const productReducer = createReducer(
  // INITIAL STATE: Starting point for all state transitions
  initialState,
  
  // ═══════════════════════════════════════════════════════════
  // LOAD PRODUCTS SUCCESS: Handle successful product list fetch
  // ═══════════════════════════════════════════════════════════
  on(loadProductsSuccess, (state, { response }) => ({
    // IMMUTABILITY: Create NEW state object (spread existing state)
    ...state,
    // UPDATE: Replace products array with API response items
    products: response.items,
    // UPDATE: Set pagination info from API response
    totalProducts: response.totalCount,
    currentPage: response.pageNumber,
    totalPages: response.totalPages,
    // CLEAR: Stop loading spinner
    loading: false,
    // CLEAR: Clear any previous errors
    error: null
  })),
  
  // ═══════════════════════════════════════════════════════════
  // LOAD PRODUCTS FAILURE: Handle product list fetch error
  // ═══════════════════════════════════════════════════════════
  on(loadProductsFailure, (state, { error }) => ({
    ...state,
    // CLEAR: Stop loading spinner
    loading: false,
    // SET: Store error for UI to display
    error
  })),
  
  // ═══════════════════════════════════════════════════════════
  // LOAD PRODUCT BY ID SUCCESS: Handle successful single product fetch
  // ═══════════════════════════════════════════════════════════
  on(loadProductByIdSuccess, (state, { product }) => ({
    ...state,
    // SET: Store selected product for detail page
    selectedProduct: product,
    // CLEAR: Stop loading spinner
    loading: false,
    // CLEAR: Clear any previous errors
    error: null
  })),
  
  // ═══════════════════════════════════════════════════════════
  // LOAD PRODUCT BY ID FAILURE: Handle single product fetch error
  // ═══════════════════════════════════════════════════════════
  on(loadProductByIdFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  
  // ═══════════════════════════════════════════════════════════
  // LOAD FEATURED PRODUCTS SUCCESS: Handle featured products fetch
  // ═══════════════════════════════════════════════════════════
  on(loadFeaturedProductsSuccess, (state, { products }) => ({
    ...state,
    // SET: Cache featured products for homepage
    featuredProducts: products,
    loading: false,
    error: null
  })),
  
  // ═══════════════════════════════════════════════════════════
  // LOAD FEATURED PRODUCTS FAILURE: Handle featured products error
  // ═══════════════════════════════════════════════════════════
  on(loadFeaturedProductsFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  
  // ═══════════════════════════════════════════════════════════
  // CREATE PRODUCT SUCCESS: Handle new product creation
  // ═══════════════════════════════════════════════════════════
  on(createProductSuccess, (state, { product }) => ({
    ...state,
    // ARRAY OPERATION: Create NEW array with new product appended
    products: [...state.products, product],
    loading: false,
    error: null
  })),
  
  // ═══════════════════════════════════════════════════════════
  // CREATE PRODUCT FAILURE: Handle product creation error
  // ═══════════════════════════════════════════════════════════
  on(createProductFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  
  // ═══════════════════════════════════════════════════════════
  // UPDATE PRODUCT SUCCESS: Handle product update
  // ═══════════════════════════════════════════════════════════
  on(updateProductSuccess, (state, { product }) => ({
    ...state,
    // ARRAY OPERATION: Create NEW array with updated product
    // map(): Iterate over products, replace matching product with updated product
    products: state.products.map(p => p.id === product.id ? product : p),
    // NESTED UPDATE: Update selectedProduct if it's the same product
    // Optional chaining (?.): Handles null safely
    selectedProduct: state.selectedProduct?.id === product.id ? product : state.selectedProduct,
    loading: false,
    error: null
  })),
  
  // ═══════════════════════════════════════════════════════════
  // UPDATE PRODUCT FAILURE: Handle product update error
  // ═══════════════════════════════════════════════════════════
  on(updateProductFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  
  // ═══════════════════════════════════════════════════════════
  // DELETE PRODUCT SUCCESS: Handle product deletion
  // ═══════════════════════════════════════════════════════════
  on(deleteProductSuccess, (state, { id }) => ({
    ...state,
    // ARRAY OPERATION: Create NEW array with product removed
    // filter(): Remove product with matching ID
    products: state.products.filter(p => p.id !== id),
    loading: false,
    error: null
  })),
  
  // ═══════════════════════════════════════════════════════════
  // DELETE PRODUCT FAILURE: Handle product deletion error
  // ═══════════════════════════════════════════════════════════
  on(deleteProductFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  
  // ═══════════════════════════════════════════════════════════
  // LOAD CATEGORIES SUCCESS: Handle categories fetch
  // ═══════════════════════════════════════════════════════════
  on(loadCategoriesSuccess, (state, { categories }) => ({
    ...state,
    // SET: Cache categories for filter dropdown
    categories,
    loading: false,
    error: null
  })),
  
  // ═══════════════════════════════════════════════════════════
  // LOAD CATEGORIES FAILURE: Handle categories fetch error
  // ═══════════════════════════════════════════════════════════
  on(loadCategoriesFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  }))
);
