import { createReducer, on } from '@ngrx/store';
import {
  loadOrdersSuccess,
  loadOrdersFailure,
  loadOrderByIdSuccess,
  loadOrderByIdFailure,
  createOrderSuccess,
  createOrderFailure,
  updateOrderStatusSuccess,
  updateOrderStatusFailure,
  cancelOrderSuccess,
  cancelOrderFailure
} from '../actions/order.actions';
import { OrderState, initialState } from '../states/order.state';

export const orderReducer = createReducer(
  initialState,
  on(loadOrdersSuccess, (state, { response }) => ({
    ...state,
    orders: response.items,
    totalOrders: response.totalCount,
    currentPage: response.page,
    totalPages: response.totalPages,
    loading: false,
    error: null
  })),
  on(loadOrdersFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  on(loadOrderByIdSuccess, (state, { order }) => ({
    ...state,
    selectedOrder: order,
    loading: false,
    error: null
  })),
  on(loadOrderByIdFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  on(createOrderSuccess, (state, { order }) => ({
    ...state,
    orders: [order, ...state.orders],
    selectedOrder: order,
    loading: false,
    error: null
  })),
  on(createOrderFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  on(updateOrderStatusSuccess, (state, { order }) => ({
    ...state,
    orders: state.orders.map(o => o.id === order.id ? order : o),
    selectedOrder: state.selectedOrder?.id === order.id ? order : state.selectedOrder,
    loading: false,
    error: null
  })),
  on(updateOrderStatusFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  on(cancelOrderSuccess, (state, { order }) => ({
    ...state,
    orders: state.orders.map(o => o.id === order.id ? order : o),
    selectedOrder: state.selectedOrder?.id === order.id ? order : state.selectedOrder,
    loading: false,
    error: null
  })),
  on(cancelOrderFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  }))
);
