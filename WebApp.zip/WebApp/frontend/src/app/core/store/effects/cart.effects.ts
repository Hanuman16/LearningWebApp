import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { CartService } from '../../services/cart.service';
import { tap, catchError, map, of, switchMap } from 'rxjs';
import {
  loadCart,
  loadCartSuccess,
  loadCartFailure,
  addToCart,
  addToCartSuccess,
  addToCartFailure,
  updateCartItem,
  updateCartItemSuccess,
  updateCartItemFailure,
  removeFromCart,
  removeFromCartSuccess,
  removeFromCartFailure,
  clearCart,
  clearCartSuccess,
  clearCartFailure,
  applyCoupon,
  applyCouponSuccess,
  applyCouponFailure,
  removeCoupon,
  removeCouponSuccess,
  removeCouponFailure
} from '../actions/cart.actions';

@Injectable()
export class CartEffects {
  private actions$ = inject(Actions);
  private cartService = inject(CartService);

  loadCart$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(loadCart),
      switchMap(() => {
        return this.cartService.getCart().pipe(
          map(cart => loadCartSuccess({ cart })),
          catchError(error => of(loadCartFailure({ error })))
        );
      })
    );
  }, { dispatch: true });

  addToCart$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(addToCart),
      switchMap(action => {
        return this.cartService.addItem({ productId: action.productId, quantity: action.quantity }).pipe(
          map(cart => addToCartSuccess({ cart })),
          catchError(error => of(addToCartFailure({ error })))
        );
      })
    );
  }, { dispatch: true });

  updateCartItem$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(updateCartItem),
      switchMap(action => {
        return this.cartService.updateItem(action.itemId, { itemId: action.itemId, quantity: action.quantity }).pipe(
          map(cart => updateCartItemSuccess({ cart })),
          catchError(error => of(updateCartItemFailure({ error })))
        );
      })
    );
  }, { dispatch: true });

  removeFromCart$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(removeFromCart),
      tap(action => {
        this.cartService.removeItem(action.itemId).subscribe();
      }),
      switchMap(() => {
        return this.cartService.getCart().pipe(
          map(cart => removeFromCartSuccess({ cart }))
        );
      })
    );
  }, { dispatch: true });

  clearCart$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(clearCart),
      tap(() => {
        this.cartService.clearCart().subscribe();
      }),
      switchMap(() => {
        return this.cartService.getCart().pipe(
          map(cart => clearCartSuccess({ cart }))
        );
      })
    );
  }, { dispatch: true });

  applyCoupon$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(applyCoupon),
      switchMap(action => {
        return this.cartService.applyCoupon({ couponCode: action.code }).pipe(
          map(cart => applyCouponSuccess({ cart })),
          catchError(error => of(applyCouponFailure({ error })))
        );
      })
    );
  }, { dispatch: true });

  removeCoupon$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(removeCoupon),
      tap(() => {
        this.cartService.removeCoupon().subscribe();
      }),
      switchMap(() => {
        return this.cartService.getCart().pipe(
          map(cart => removeCouponSuccess({ cart }))
        );
      })
    );
  }, { dispatch: true });
}
