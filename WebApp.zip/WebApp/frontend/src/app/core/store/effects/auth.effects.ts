import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { AuthService } from '../../services/auth.service';
import { tap, catchError, map, of } from 'rxjs';
import {
  login,
  loginSuccess,
  loginFailure,
  register,
  registerSuccess,
  registerFailure,
  logout,
  setCurrentUser,
  clearCurrentUser
} from '../actions/auth.actions';
import { Router } from '@angular/router';

@Injectable()
export class AuthEffects {
  private actions$ = inject(Actions);
  private authService = inject(AuthService);
  private router = inject(Router);

  login$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(login),
      map(action => action.request),
      map(request => {
        return this.authService.login(request).toPromise();
      }),
      map((response: any) => {
        localStorage.setItem('token', response.token);
        localStorage.setItem('refreshToken', response.refreshToken);
        localStorage.setItem('user', JSON.stringify(response.user));
        return loginSuccess({ response });
      }),
      catchError(error => of(loginFailure({ error })))
    );
  }, { dispatch: true });

  register$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(register),
      map(action => action.request),
      map(request => {
        return this.authService.register(request).toPromise();
      }),
      map((response: any) => {
        localStorage.setItem('token', response.token);
        localStorage.setItem('refreshToken', response.refreshToken);
        localStorage.setItem('user', JSON.stringify(response.user));
        return registerSuccess({ response });
      }),
      catchError(error => of(registerFailure({ error })))
    );
  }, { dispatch: true });

  logout$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(logout),
      tap(() => {
        localStorage.removeItem('token');
        localStorage.removeItem('refreshToken');
        localStorage.removeItem('user');
        this.router.navigate(['/login']);
      }),
      map(() => clearCurrentUser())
    );
  }, { dispatch: true });

  initAuth$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(setCurrentUser),
      tap(() => {
        const userJson = localStorage.getItem('user');
        if (userJson) {
          const user = JSON.parse(userJson);
          // User is already logged in
        }
      })
    );
  });
}
