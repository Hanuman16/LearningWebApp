import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { ProductService } from '../../services/product.service';
import { tap, catchError, map, of, switchMap } from 'rxjs';
import {
  loadProducts,
  loadProductsSuccess,
  loadProductsFailure,
  loadProductById,
  loadProductByIdSuccess,
  loadProductByIdFailure,
  loadFeaturedProducts,
  loadFeaturedProductsSuccess,
  loadFeaturedProductsFailure,
  createProduct,
  createProductSuccess,
  createProductFailure,
  updateProduct,
  updateProductSuccess,
  updateProductFailure,
  deleteProduct,
  deleteProductSuccess,
  deleteProductFailure,
  loadCategories,
  loadCategoriesSuccess,
  loadCategoriesFailure
} from '../actions/product.actions';

/**
 * ╔═══════════════════════════════════════════════════════════╗
 * ║  PRODUCT EFFECTS - Side Effects & API Calls              ║
 * ╚═══════════════════════════════════════════════════════════╝
 * 
 * CONCEPTS IMPLEMENTED:
 * ─────────────────────
 * 
 * 1. SIDE EFFECTS (Why Effects Exist)
 *    - Reducers are PURE functions (no API calls, no timeouts, no console.log)
 *    - But applications NEED side effects (API calls, logging, navigation)
 *    - Effects = Dedicated place for SIDE EFFECTS in ngrx
 *    - Separation: Reducers handle state, Effects handle API/network
 *    - Analogy: Reducer = Accountant (tracks state), Effect = Salesperson (makes API calls)
 * 
 * 2. OBSERVER PATTERN (Reactive Programming)
 *    - Actions$ = Observable (stream of actions over time)
 *    - Effects LISTEN for actions (subscribe to stream)
 *    - When action dispatched → Effect reacts (makes API call)
 *    - Effect DISPATCHES new actions (success/failure)
 *    - Flow: Component dispatches action → Effect listens → API call → Dispatches success/failure
 * 
 * 3. CREATE EFFECT PATTERN (ngrx/effects)
 *    - createEffect(() => {...}) = Factory function for effect definitions
 *    - Takes function that returns Observable
 *    - ngrx automatically subscribes to all effects
 *    - Effect Observable is automatically subscribed (no manual .subscribe())
 *    - { dispatch: true } = Effect returns actions (default behavior)
 * 
 * 4. OF TYPE OPERATOR (Action Filtering)
 *    - ofType(loadProducts) = Filter Observable to only loadProducts actions
 *    - Analogy: WHERE clause in SQL (only pass through matching actions)
 *    - Enables: Multiple actions, each with separate effect
 *    - Without ofType: Effect would react to ALL actions (chaos)
 * 
 * 5. SWITCH MAP OPERATOR (API Call Pattern)
 *    - switchMap(action => apiCall()) = Convert action to API call
 *    - Subscribes to API call Observable when action dispatched
 *    - Maps API response to success action
 *    - Cancels previous in-flight request if new action dispatched
 *    - Analogy: switchMap = "Switch to new API call, cancel old one"
 *    - Why not mergeMap? switchMap prevents duplicate requests
 * 
 * 6. CATCH ERROR OPERATOR (Error Handling)
 *    - catchError(error => of(loadProductsFailure({ error })))
 *    - Catches API errors (network error, 404, 500)
 *    - Converts error to Observable that emits failure action
 *    - WITHOUT catchError: Error propagates to store → app crash
 *    - WITH catchError: Error converted to failure action → reducer handles it
 * 
 * 7. MAP OPERATOR (Response Transformation)
 *    - map(response => loadProductsSuccess({ response }))
 *    - Transforms API response to action payload
 *    - Analogy: map() in LINQ/JavaScript (transform each item)
 *    - API returns PagedResponse<Product>
 *    - Effect wraps it in loadProductsSuccess action
 * 
 * 8. OF FUNCTION (Error Observable Creation)
 *    - of(loadProductsFailure({ error })) = Create Observable that emits action
 *    - of() = RxJS function that creates Observable from values
 *    - of(value) = Observable that emits value then completes
 *    - Used in catchError: Convert error to success/failure action
 * 
 * 9. TAP OPERATOR (Side Effects Without Transformation)
 *    - tap(() => console.log('Action dispatched')) = Log without changing stream
 *    - tap(() => service.delete(id).subscribe()) = Fire-and-forget API call
 *    - Analogy: tap = "Peek at value without modifying it"
 *    - Used in deleteProduct$: Fire-and-forget delete (no success/failure tracking)
 * 
 * 10. DEPENDENCY INJECTION IN EFFECTS
 *     - @Injectable() = Effect can inject services
 *     - inject(Actions) = Inject ngrx actions stream
 *     - inject(ProductService) = Inject HTTP service for API calls
 *     - Effects are SERVICES (can be tested with TestBed)
 * 
 * 11. FIRE-AND-FORGET PATTERN (deleteProduct$)
 *     - tap(() => service.delete(id).subscribe()) = Fire-and-forget
 *     - Does NOT wait for delete to complete
 *     - Does NOT dispatch success/failure actions
 *     - Why? Delete is fire-and-forget (UI doesn't need response)
 *     - NOTE: This is NOT ideal (no error handling)
 *     - Better: Use switchMap + catchError for proper error handling
 * 
 * 12. EFFECTS VS REDUCERS (Separation of Concerns)
 *     - Effects: Handle SIDE EFFECTS (API calls, logging, navigation)
 *     - Reducers: Handle STATE UPDATES (pure functions, no side effects)
 *     - Effects DISPATCH actions → Reducers LISTEN for actions
 *     - Reducers UPDATE state → Effects can SELECT state
 *     - Strict separation = Predictable, testable, debuggable
 * 
 * 13. RXJS PIPELINE PATTERN
 *     - actions$.pipe(
 *         ofType(action),        // Filter: Only this action
 *         switchMap(apiCall),    // Transform: Action → API call
 *         map(success),          // Transform: API response → Success action
 *         catchError(failure)    // Handle: API error → Failure action
 *       )
 *     - Each operator has ONE job (Single Responsibility)
 *     - Pipeline is READABLE (left to right flow)
 *     - Pipeline is TESTABLE (each operator can be unit tested)
 * 
 * 14. UNIDIRECTIONAL DATA FLOW (Effects Role)
 *     - Component dispatches action → Effect listens
 *     - Effect makes API call → Dispatches success/failure action
 *     - Reducer listens for success/failure → Updates state
 *     - Component selects state → Receives updated data
 *     - Flow: Component → Action → Effect → API → Action → Reducer → State → Selector → Component
 */

@Injectable()                                              // Angular service (can inject dependencies)
export class ProductEffects {
  // INJECT: Actions stream (Observable of all dispatched actions)
  // Actions$ = Stream of actions over time (like a river of events)
  private actions$ = inject(Actions);
  
  // INJECT: Product service (HTTP calls to backend API)
  private productService = inject(ProductService);

  // ═══════════════════════════════════════════════════════════
  // LOAD PRODUCTS EFFECT
  // ═══════════════════════════════════════════════════════════
  /**
   * EFFECT: Load Products
   * TRIGGERS WHEN: Component dispatches loadProducts action
   * FLOW:
   *   1. Component dispatches: loadProducts({ page: 1, pageSize: 20 })
   *   2. Effect listens: ofType(loadProducts)
   *   3. Effect makes API call: productService.getAll(page, pageSize)
   *   4. API succeeds: Effect dispatches loadProductsSuccess({ response })
   *   5. API fails: Effect dispatches loadProductsFailure({ error })
   *   6. Reducer handles success/failure → Updates state
   */
  loadProducts$ = createEffect(() => {
    return this.actions$.pipe(
      // FILTER: Only react to loadProducts actions
      ofType(loadProducts),
      
      // TRANSFORM: Convert action to API call
      // switchMap: Cancels previous in-flight request if new action dispatched
      switchMap(action => {
        return this.productService.getAll(action.page, action.pageSize, action.search, action.categoryId).pipe(
          // TRANSFORM: Map API response to success action
          map(response => loadProductsSuccess({ response })),
          
          // HANDLE ERROR: Convert API error to failure action
          catchError(error => of(loadProductsFailure({ error })))
        );
      })
    );
  }, { dispatch: true });                                  // dispatch: true = Effect returns actions (default)

  // ═══════════════════════════════════════════════════════════
  // LOAD PRODUCT BY ID EFFECT
  // ═══════════════════════════════════════════════════════════
  /**
   * EFFECT: Load Product By Id
   * TRIGGERS WHEN: Component dispatches loadProductById action
   * FLOW:
   *   1. Component dispatches: loadProductById({ id: 'abc123' })
   *   2. Effect makes API call: productService.getById('abc123')
   *   3. API succeeds: Effect dispatches loadProductByIdSuccess({ product })
   *   4. API fails: Effect dispatches loadProductByIdFailure({ error })
   */
  loadProductById$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(loadProductById),
      switchMap(action => {
        return this.productService.getById(action.id).pipe(
          map(product => loadProductByIdSuccess({ product })),
          catchError(error => of(loadProductByIdFailure({ error })))
        );
      })
    );
  }, { dispatch: true });

  // ═══════════════════════════════════════════════════════════
  // LOAD FEATURED PRODUCTS EFFECT
  // ═══════════════════════════════════════════════════════════
  /**
   * EFFECT: Load Featured Products
   * TRIGGERS WHEN: HomeComponent dispatches loadFeaturedProducts action
   * FLOW:
   *   1. Component dispatches: loadFeaturedProducts({ limit: 10 })
   *   2. Effect makes API call: productService.getFeatured(10)
   *   3. API succeeds: Effect dispatches loadFeaturedProductsSuccess({ products })
   *   4. API fails: Effect dispatches loadFeaturedProductsFailure({ error })
   */
  loadFeaturedProducts$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(loadFeaturedProducts),
      switchMap(action => {
        return this.productService.getFeatured(action.limit).pipe(
          map((products: any) => loadFeaturedProductsSuccess({ products })),
          catchError(error => of(loadFeaturedProductsFailure({ error })))
        );
      })
    );
  }, { dispatch: true });

  // ═══════════════════════════════════════════════════════════
  // CREATE PRODUCT EFFECT
  // ═══════════════════════════════════════════════════════════
  /**
   * EFFECT: Create Product
   * TRIGGERS WHEN: Admin dispatches createProduct action (from admin form)
   * FLOW:
   *   1. Admin submits form → Component dispatches createProduct({ product: {...} })
   *   2. Effect makes API call: productService.create(product)
   *   3. API succeeds: Effect dispatches createProductSuccess({ product })
   *   4. API fails: Effect dispatches createProductFailure({ error })
   *   5. Reducer adds new product to products array
   */
  createProduct$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(createProduct),
      switchMap(action => {
        return this.productService.create(action.product).pipe(
          map(product => createProductSuccess({ product })),
          catchError(error => of(createProductFailure({ error })))
        );
      })
    );
  }, { dispatch: true });

  // ═══════════════════════════════════════════════════════════
  // UPDATE PRODUCT EFFECT
  // ═══════════════════════════════════════════════════════════
  /**
   * EFFECT: Update Product
   * TRIGGERS WHEN: Admin dispatches updateProduct action (from edit form)
   * FLOW:
   *   1. Admin edits form → Component dispatches updateProduct({ id, product })
   *   2. Effect makes API call: productService.update(id, product)
   *   3. API succeeds: Effect dispatches updateProductSuccess({ product })
   *   4. API fails: Effect dispatches updateProductFailure({ error })
   *   5. Reducer updates product in products array
   */
  updateProduct$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(updateProduct),
      switchMap(action => {
        return this.productService.update(action.id, action.product).pipe(
          map(product => updateProductSuccess({ product })),
          catchError(error => of(updateProductFailure({ error })))
        );
      })
    );
  }, { dispatch: true });

  // ═══════════════════════════════════════════════════════════
  // DELETE PRODUCT EFFECT (Fire-and-Forget)
  // ═══════════════════════════════════════════════════════════
  /**
   * EFFECT: Delete Product
   * TRIGGERS WHEN: Admin dispatches deleteProduct action (from delete confirmation)
   * FLOW:
   *   1. Admin clicks delete → Component dispatches deleteProduct({ id })
   *   2. Effect makes API call: productService.delete(id) (fire-and-forget)
   *   3. Effect IMMEDIATELY dispatches deleteProductSuccess({ id })
   *   4. Reducer removes product from products array
   * 
   * NOTE: This is FIRE-AND-FORGET pattern
   * - Does NOT wait for API call to complete
   * - Does NOT handle errors (no catchError)
   * - Product removed from UI immediately (even if delete fails on server)
   * - This is NOT ideal (better: use switchMap + catchError)
   * - TODO: Improve to handle delete failures properly
   */
  deleteProduct$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(deleteProduct),
      
      // SIDE EFFECT: Fire-and-forget API call (don't wait for response)
      tap(action => {
        this.productService.delete(action.id).subscribe();  // Fire-and-forget (no error handling)
      }),
      
      // IMMEDIATELY dispatch success (even if API call fails)
      map(action => deleteProductSuccess({ id: action.id }))
    );
  }, { dispatch: true });

  // ═══════════════════════════════════════════════════════════
  // LOAD CATEGORIES EFFECT
  // ═══════════════════════════════════════════════════════════
  /**
   * EFFECT: Load Categories
   * TRIGGERS WHEN: Component dispatches loadCategories action
   * FLOW:
   *   1. Component dispatches: loadCategories()
   *   2. Effect makes API call: productService.getCategories()
   *   3. API succeeds: Effect dispatches loadCategoriesSuccess({ categories })
   *   4. API fails: Effect dispatches loadCategoriesFailure({ error })
   *   5. Reducer caches categories for filter dropdown
   */
  loadCategories$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(loadCategories),
      switchMap(() => {
        return this.productService.getCategories().pipe(
          map(categories => loadCategoriesSuccess({ categories })),
          catchError(error => of(loadCategoriesFailure({ error })))
        );
      })
    );
  }, { dispatch: true });
}
