import { Cart } from '../../models/cart.model';

export interface CartState {
  cart: Cart | null;
  loading: boolean;
  error: any;
}

export const initialState: CartState = {
  cart: null,
  loading: false,
  error: null
};
