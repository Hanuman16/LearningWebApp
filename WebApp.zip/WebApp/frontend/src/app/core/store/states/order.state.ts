import { Order } from '../../models/order.model';

export interface OrderState {
  orders: Order[];
  selectedOrder: Order | null;
  totalOrders: number;
  currentPage: number;
  totalPages: number;
  loading: boolean;
  error: any;
}

export const initialState: OrderState = {
  orders: [],
  selectedOrder: null,
  totalOrders: 0,
  currentPage: 1,
  totalPages: 1,
  loading: false,
  error: null
};
