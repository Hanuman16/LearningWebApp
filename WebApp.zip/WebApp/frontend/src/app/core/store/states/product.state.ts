import { Product } from '../../models/product.model';

/**
 * ╔═══════════════════════════════════════════════════════════╗
 * ║  PRODUCT STATE - State Interface & Initial State         ║
 * ╚═══════════════════════════════════════════════════════════╝
 * 
 * CONCEPTS IMPLEMENTED:
 * ─────────────────────
 * 
 * 1. STATE INTERFACE (Type-Safe State Shape)
 *    - Defines the EXACT structure of product state
 *    - TypeScript enforces: Can't access state.products (typo) → compile error
 *    - Self-documenting: Interface shows all available state properties
 *    - Selectors use this type for type-safe state access
 * 
 * 2. STATE SLICE PATTERN (Feature Isolation)
 *    - ProductState contains ONLY product-related state
 *    - Does NOT contain auth state, cart state, order state
 *    - Each feature slice is INDEPENDENT
 *    - Enables modular architecture (products module can be reused)
 * 
 * 3. INITIAL STATE (Default Values)
 *    - Starting values when app loads
 *    - products: [] → Empty array (no products loaded yet)
 *    - loading: false → Not loading (will become true during API call)
 *    - error: null → No errors (will contain error if API fails)
 *    - currentPage: 1 → First page (pagination starts at 1)
 *    - totalPages: 1 → Unknown initially (set by API response)
 * 
 * 4. LOADING STATE (UX Pattern)
 *    - loading: boolean → Shows/hides spinner
 *    - BEFORE API call: loading = true → Show spinner
 *    - AFTER API call: loading = false → Hide spinner
 *    - Prevents multiple simultaneous API calls (check loading first)
 * 
 * 5. ERROR STATE (User Feedback)
 *    - error: any → Stores error message/object
 *    - If API fails: error = { message: "Network error" }
 *    - Component displays error message to user
 *    - error: null → No errors (clean state)
 * 
 * 6. PAGINATION STATE (Server-Side Pagination)
 *    - currentPage: Current page number (1-based)
 *    - totalPages: Total pages returned by API
 *    - totalProducts: Total products in database
 *    - Enables: "Previous", "Next" buttons, page numbers
 *    - Server-side: API returns only requested page (not all products)
 * 
 * 7. SELECTED ENTITY PATTERN
 *    - selectedProduct: Product | null → Currently viewed product
 *    - Set when user clicks product detail page
 *    - null → No product selected (product list view)
 *    - Enables: Product detail, edit, delete operations
 * 
 * 8. FEATURED PRODUCTS (Caching)
 *    - featuredProducts: Product[] → Homepage featured products
 *    - Loaded once, cached in state
 *    - Multiple components can read featured products without duplicate API calls
 *    - Example: HomeComponent, HeaderComponent both read featuredProducts
 * 
 * 9. CATEGORIES (Filtering Support)
 *    - categories: any[] → Product categories for filtering
 *    - Used in: Product list page filter dropdown
 *    - Loaded once, cached in state
 *    - Enables: Filter by category, search by category
 */
export interface ProductState {
  products: Product[];                  // Product list (current page results)
  selectedProduct: Product | null;      // Currently viewed product (null = list view)
  featuredProducts: Product[];          // Featured products (homepage cache)
  categories: any[];                    // Product categories (for filtering)
  totalProducts: number;                // Total products in database (for pagination)
  currentPage: number;                  // Current page number (1-based)
  totalPages: number;                   // Total pages (from API response)
  loading: boolean;                     // Loading state (true = API call in progress)
  error: any;                           // Error message/object (null = no errors)
}

/**
 * INITIAL STATE: Default values when app loads
 * - Products: Empty array (no products loaded yet)
 * - Loading: False (no API call in progress)
 * - Error: Null (no errors)
 * - Pagination: Page 1 of 1 (defaults)
 * - Selected: Null (no product selected)
 * 
 * WHY initial state matters:
 * - Reducer needs starting point (state + action → new state)
 * - Without initial state: state would be undefined → app crash
 * - TypeScript enforces: All interface properties must be initialized
 */
export const initialState: ProductState = {
  products: [],                           // Empty product list
  selectedProduct: null,                  // No product selected
  featuredProducts: [],                   // No featured products yet
  categories: [],                         // No categories loaded
  totalProducts: 0,                       // No products in database
  currentPage: 1,                         // Start at page 1
  totalPages: 1,                          // Default to 1 page
  loading: false,                         // Not loading
  error: null                             // No errors
};
