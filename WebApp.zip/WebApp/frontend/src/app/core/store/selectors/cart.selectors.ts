import { createFeatureSelector, createSelector } from '@ngrx/store';
import { CartState } from '../states/cart.state';

export const selectCartState = createFeatureSelector<CartState>('cart');

export const selectCart = createSelector(
  selectCartState,
  (state: CartState) => state.cart
);

export const selectCartLoading = createSelector(
  selectCartState,
  (state: CartState) => state.loading
);

export const selectCartError = createSelector(
  selectCartState,
  (state: CartState) => state.error
);

export const selectCartTotal = createSelector(
  selectCart,
  (cart: any) => cart?.total || 0
);

export const selectCartItemCount = createSelector(
  selectCart,
  (cart: any) => cart?.items?.reduce((total: number, item: any) => total + item.quantity, 0) || 0
);
