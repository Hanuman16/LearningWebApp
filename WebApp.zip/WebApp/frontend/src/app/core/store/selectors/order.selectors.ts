import { createFeatureSelector, createSelector } from '@ngrx/store';
import { OrderState } from '../states/order.state';

export const selectOrderState = createFeatureSelector<OrderState>('orders');

export const selectOrders = createSelector(
  selectOrderState,
  (state: OrderState) => state.orders
);

export const selectSelectedOrder = createSelector(
  selectOrderState,
  (state: OrderState) => state.selectedOrder
);

export const selectTotalOrders = createSelector(
  selectOrderState,
  (state: OrderState) => state.totalOrders
);

export const selectCurrentPage = createSelector(
  selectOrderState,
  (state: OrderState) => state.currentPage
);

export const selectTotalPages = createSelector(
  selectOrderState,
  (state: OrderState) => state.totalPages
);

export const selectOrderLoading = createSelector(
  selectOrderState,
  (state: OrderState) => state.loading
);

export const selectOrderError = createSelector(
  selectOrderState,
  (state: OrderState) => state.error
);
