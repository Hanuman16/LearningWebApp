import { createFeatureSelector, createSelector } from '@ngrx/store';
import { ProductState } from '../states/product.state';

export const selectProductState = createFeatureSelector<ProductState>('products');

export const selectProducts = createSelector(
  selectProductState,
  (state: ProductState) => state.products
);

export const selectSelectedProduct = createSelector(
  selectProductState,
  (state: ProductState) => state.selectedProduct
);

export const selectFeaturedProducts = createSelector(
  selectProductState,
  (state: ProductState) => state.featuredProducts
);

export const selectCategories = createSelector(
  selectProductState,
  (state: ProductState) => state.categories
);

export const selectTotalProducts = createSelector(
  selectProductState,
  (state: ProductState) => state.totalProducts
);

export const selectCurrentPage = createSelector(
  selectProductState,
  (state: ProductState) => state.currentPage
);

export const selectTotalPages = createSelector(
  selectProductState,
  (state: ProductState) => state.totalPages
);

export const selectProductLoading = createSelector(
  selectProductState,
  (state: ProductState) => state.loading
);

export const selectProductError = createSelector(
  selectProductState,
  (state: ProductState) => state.error
);
