import { createAction, props } from '@ngrx/store';
import { Product, PagedResponse } from '../../models/product.model';

/**
 * ╔═══════════════════════════════════════════════════════════╗
 * ║  PRODUCT ACTIONS - ngrx Store Actions                    ║
 * ╚═══════════════════════════════════════════════════════════╝
 * 
 * CONCEPTS IMPLEMENTED:
 * ─────────────────────
 * 
 * 1. ACTIONS (Payload-Defined Events)
 *    - Actions are PLAIN OBJECTS that describe WHAT happened
 *    - Format: { type: '[Products] Load Products', payload: {...} }
 *    - Actions are DISPATCHED by components/services
 *    - Actions are CONSUMED by reducers/effects
 *    - Analogy: Actions = Events in a event sourcing system
 *    - Each action has a UNIQUE TYPE string (for debugging)
 * 
 * 2. CREATE ACTION PATTERN (ngrx/store)
 *    - createAction() = Factory function that creates action definitions
 *    - First param: Action type string ('[Products] Load Products')
 *      - Convention: '[Feature] Event' → Easy to search in devtools
 *      - Devtools group actions by feature → Easy debugging
 *    - Second param: props<{...}>() → Defines PAYLOAD structure
 *      - TypeScript enforces: Payload must match props type
 *      - Example: props<{ page: number }>() → Must pass { page: number }
 * 
 * 3. ACTION TRIADS (Success/Failure Pattern)
 *    - Every async operation has 3 actions:
 *      1. LOAD_PRODUCTS → Operation STARTED (loading = true)
 *      2. LOAD_PRODUCTS_SUCCESS → Operation SUCCEEDED (data loaded)
 *      3. LOAD_PRODUCTS_FAILURE → Operation FAILED (error stored)
 *    - Why 3 actions? Complete lifecycle tracking
 *    - Reducer handles each action differently:
 *      - STARTED: Set loading = true
 *      - SUCCESS: Set loading = false, update data
 *      - FAILURE: Set loading = false, store error
 * 
 * 4. UNIDIRECTIONAL DATA FLOW (Action-Driven State)
 *    - Component DISPATCHES action → Store processes action
 *    - Reducer LISTENS for action → Updates state
 *    - Component SELECTS state → Receives updated data
 *    - Data flows ONE direction: Component → Action → Reducer → Store → Selector → Component
 *    - NO direct state mutation (always through actions)
 *    - Makes state changes PREDICTABLE and DEBUGGABLE
 * 
 * 5. ACTION TYPES (Namespacing Convention)
 *    - '[Products] Load Products' → Product feature
 *    - '[Auth] Login' → Auth feature
 *    - '[Cart] Add Item' → Cart feature
 *    - Brackets '[Products]' = Feature namespace
 *    - Enables: Filter actions by feature in devtools
 *    - Enables: Debugging (easy to search for '[Products]')
 * 
 * 6. PAYLOAD TYPING (TypeScript Integration)
 *    - props<{ page: number; pageSize: number }>() → Strict typing
 *    - TypeScript enforces: Must pass correct payload type
 *    - Example: store.dispatch(loadProducts({ page: 1, pageSize: 20 }))
 *    - If you pass wrong type → Compile error (caught before runtime)
 * 
 * 7. ACTION CATEGORIES (CRUD + Special Operations)
 *    - LOAD: Fetch data from server (read operations)
 *    - CREATE: Add new product (write operation)
 *    - UPDATE: Modify existing product (write operation)
 *    - DELETE: Remove product (write operation)
 *    - Each category has Success/Failure variants
 * 
 * 8. IMPURE ACTIONS (Side Effects Trigger)
 *    - loadProducts → Triggers effect (API call)
 *    - loadProductsSuccess → Pure state update (no side effects)
 *    - Effects listen for IMPURE actions, dispatch PURE actions
 *    - Separation: Effects handle API, Reducers handle state
 */

// ═══════════════════════════════════════════════════════════
// LOAD PRODUCTS (Product List with Pagination & Filtering)
// ═══════════════════════════════════════════════════════════

/**
 * ACTION: Load Products
 * PAYLOAD: { page, pageSize, search?, categoryId? }
 * WHEN: Component calls store.dispatch(loadProducts({ page: 1, pageSize: 20 }))
 * EFFECT: Triggers API call (ProductEffects.loadProducts$)
 * REDUCER: Sets loading = true
 */
export const loadProducts = createAction(
  '[Products] Load Products',                              // Action type (for devtools grouping)
  props<{ 
    page: number;                                          // Page number (1-based)
    pageSize: number;                                      // Items per page
    search?: string;                                       // Optional: Search keyword
    categoryId?: string                                    // Optional: Filter by category
  }>()
);

/**
 * ACTION: Load Products Success
 * PAYLOAD: { response: PagedResponse<Product> }
 * WHEN: API call succeeds → Effect dispatches this action
 * REDUCER: Sets loading = false, updates products array, updates pagination
 */
export const loadProductsSuccess = createAction(
  '[Products] Load Products Success',
  props<{ response: PagedResponse<Product> }>()
);

/**
 * ACTION: Load Products Failure
 * PAYLOAD: { error: any }
 * WHEN: API call fails → Effect dispatches this action
 * REDUCER: Sets loading = false, stores error message
 */
export const loadProductsFailure = createAction(
  '[Products] Load Products Failure',
  props<{ error: any }>()
);

// ═══════════════════════════════════════════════════════════
// LOAD PRODUCT BY ID (Single Product Detail)
// ═══════════════════════════════════════════════════════════

/**
 * ACTION: Load Product By Id
 * PAYLOAD: { id: string }
 * WHEN: User clicks product detail page
 * EFFECT: Triggers API call to get single product
 */
export const loadProductById = createAction(
  '[Products] Load Product By Id',
  props<{ id: string }>()
);

/**
 * ACTION: Load Product By Id Success
 * PAYLOAD: { product: Product }
 * WHEN: API call succeeds
 * REDUCER: Sets selectedProduct, loading = false
 */
export const loadProductByIdSuccess = createAction(
  '[Products] Load Product By Id Success',
  props<{ product: Product }>()
);

/**
 * ACTION: Load Product By Id Failure
 * PAYLOAD: { error: any }
 * WHEN: API call fails (product not found, network error)
 * REDUCER: Sets loading = false, stores error
 */
export const loadProductByIdFailure = createAction(
  '[Products] Load Product By Id Failure',
  props<{ error: any }>()
);

// ═══════════════════════════════════════════════════════════
// LOAD FEATURED PRODUCTS (Homepage Products)
// ═══════════════════════════════════════════════════════════

/**
 * ACTION: Load Featured Products
 * PAYLOAD: { limit: number }
 * WHEN: Homepage loads, HomeComponent dispatches this
 * EFFECT: Triggers API call to get featured products
 */
export const loadFeaturedProducts = createAction(
  '[Products] Load Featured Products',
  props<{ limit: number }>()
);

/**
 * ACTION: Load Featured Products Success
 * PAYLOAD: { products: Product[] }
 * WHEN: API call succeeds
 * REDUCER: Sets featuredProducts, loading = false
 */
export const loadFeaturedProductsSuccess = createAction(
  '[Products] Load Featured Products Success',
  props<{ products: Product[] }>()
);

/**
 * ACTION: Load Featured Products Failure
 * PAYLOAD: { error: any }
 * WHEN: API call fails
 * REDUCER: Sets loading = false, stores error
 */
export const loadFeaturedProductsFailure = createAction(
  '[Products] Load Featured Products Failure',
  props<{ error: any }>()
);

// ═══════════════════════════════════════════════════════════
// CREATE PRODUCT (Admin: Add New Product)
// ═══════════════════════════════════════════════════════════

/**
 * ACTION: Create Product
 * PAYLOAD: { product: Partial<Product> }
 * WHEN: Admin submits new product form
 * EFFECT: Triggers API call to create product
 */
export const createProduct = createAction(
  '[Products] Create Product',
  props<{ product: Partial<Product> }>()
);

/**
 * ACTION: Create Product Success
 * PAYLOAD: { product: Product }
 * WHEN: API call succeeds (product created)
 * REDUCER: Adds new product to products array, loading = false
 */
export const createProductSuccess = createAction(
  '[Products] Create Product Success',
  props<{ product: Product }>()
);

/**
 * ACTION: Create Product Failure
 * PAYLOAD: { error: any }
 * WHEN: API call fails (validation error, network error)
 * REDUCER: Sets loading = false, stores error
 */
export const createProductFailure = createAction(
  '[Products] Create Product Failure',
  props<{ error: any }>()
);

// ═══════════════════════════════════════════════════════════
// UPDATE PRODUCT (Admin: Edit Existing Product)
// ═══════════════════════════════════════════════════════════

/**
 * ACTION: Update Product
 * PAYLOAD: { id: string; product: Partial<Product> }
 * WHEN: Admin submits edited product form
 * EFFECT: Triggers API call to update product
 */
export const updateProduct = createAction(
  '[Products] Update Product',
  props<{ id: string; product: Partial<Product> }>()
);

/**
 * ACTION: Update Product Success
 * PAYLOAD: { product: Product }
 * WHEN: API call succeeds (product updated)
 * REDUCER: Updates product in products array, loading = false
 */
export const updateProductSuccess = createAction(
  '[Products] Update Product Success',
  props<{ product: Product }>()
);

/**
 * ACTION: Update Product Failure
 * PAYLOAD: { error: any }
 * WHEN: API call fails
 * REDUCER: Sets loading = false, stores error
 */
export const updateProductFailure = createAction(
  '[Products] Update Product Failure',
  props<{ error: any }>()
);

// ═══════════════════════════════════════════════════════════
// DELETE PRODUCT (Admin: Remove Product)
// ═══════════════════════════════════════════════════════════

/**
 * ACTION: Delete Product
 * PAYLOAD: { id: string }
 * WHEN: Admin clicks delete button
 * EFFECT: Triggers API call to delete product
 */
export const deleteProduct = createAction(
  '[Products] Delete Product',
  props<{ id: string }>()
);

export const deleteProductSuccess = createAction(
  '[Products] Delete Product Success',
  props<{ id: string }>()
);

export const deleteProductFailure = createAction(
  '[Products] Delete Product Failure',
  props<{ error: any }>()
);

export const loadCategories = createAction('[Products] Load Categories');

export const loadCategoriesSuccess = createAction(
  '[Products] Load Categories Success',
  props<{ categories: any[] }>()
);

export const loadCategoriesFailure = createAction(
  '[Products] Load Categories Failure',
  props<{ error: any }>()
);
