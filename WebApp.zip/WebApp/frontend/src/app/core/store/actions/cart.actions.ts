import { createAction, props } from '@ngrx/store';
import { Cart, CartItem } from '../../models/cart.model';

// Cart Actions
export const loadCart = createAction('[Cart] Load Cart');

export const loadCartSuccess = createAction(
  '[Cart] Load Cart Success',
  props<{ cart: Cart }>()
);

export const loadCartFailure = createAction(
  '[Cart] Load Cart Failure',
  props<{ error: any }>()
);

export const addToCart = createAction(
  '[Cart] Add To Cart',
  props<{ productId: string; quantity: number }>()
);

export const addToCartSuccess = createAction(
  '[Cart] Add To Cart Success',
  props<{ cart: Cart }>()
);

export const addToCartFailure = createAction(
  '[Cart] Add To Cart Failure',
  props<{ error: any }>()
);

export const updateCartItem = createAction(
  '[Cart] Update Cart Item',
  props<{ itemId: string; quantity: number }>()
);

export const updateCartItemSuccess = createAction(
  '[Cart] Update Cart Item Success',
  props<{ cart: Cart }>()
);

export const updateCartItemFailure = createAction(
  '[Cart] Update Cart Item Failure',
  props<{ error: any }>()
);

export const removeFromCart = createAction(
  '[Cart] Remove From Cart',
  props<{ itemId: string }>()
);

export const removeFromCartSuccess = createAction(
  '[Cart] Remove From Cart Success',
  props<{ cart: Cart }>()
);

export const removeFromCartFailure = createAction(
  '[Cart] Remove From Cart Failure',
  props<{ error: any }>()
);

export const clearCart = createAction('[Cart] Clear Cart');

export const clearCartSuccess = createAction(
  '[Cart] Clear Cart Success',
  props<{ cart: Cart }>()
);

export const clearCartFailure = createAction(
  '[Cart] Clear Cart Failure',
  props<{ error: any }>()
);

export const applyCoupon = createAction(
  '[Cart] Apply Coupon',
  props<{ code: string }>()
);

export const applyCouponSuccess = createAction(
  '[Cart] Apply Coupon Success',
  props<{ cart: Cart }>()
);

export const applyCouponFailure = createAction(
  '[Cart] Apply Coupon Failure',
  props<{ error: any }>()
);

export const removeCoupon = createAction('[Cart] Remove Coupon');

export const removeCouponSuccess = createAction(
  '[Cart] Remove Coupon Success',
  props<{ cart: Cart }>()
);

export const removeCouponFailure = createAction(
  '[Cart] Remove Coupon Failure',
  props<{ error: any }>()
);
