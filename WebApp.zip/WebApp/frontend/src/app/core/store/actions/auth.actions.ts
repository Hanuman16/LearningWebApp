import { createAction, props } from '@ngrx/store';
import { AuthResponse, User } from '../../models/auth.model';

// Auth Actions
export const login = createAction(
  '[Auth] Login',
  props<{ request: { email: string; password: string } }>()
);

export const loginSuccess = createAction(
  '[Auth] Login Success',
  props<{ response: AuthResponse }>()
);

export const loginFailure = createAction(
  '[Auth] Login Failure',
  props<{ error: any }>()
);

export const logout = createAction('[Auth] Logout');

export const register = createAction(
  '[Auth] Register',
  props<{ request: { firstName: string; lastName: string; email: string; password: string; confirmPassword: string } }>()
);

export const registerSuccess = createAction(
  '[Auth] Register Success',
  props<{ response: AuthResponse }>()
);

export const registerFailure = createAction(
  '[Auth] Register Failure',
  props<{ error: any }>()
);

export const refreshToken = createAction(
  '[Auth] Refresh Token',
  props<{ refreshToken: string }>()
);

export const refreshTokenSuccess = createAction(
  '[Auth] Refresh Token Success',
  props<{ response: AuthResponse }>()
);

export const setCurrentUser = createAction(
  '[Auth] Set Current User',
  props<{ user: User }>()
);

export const clearCurrentUser = createAction('[Auth] Clear Current User');
