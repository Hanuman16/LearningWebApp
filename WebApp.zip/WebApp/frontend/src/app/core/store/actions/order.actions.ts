import { createAction, props } from '@ngrx/store';
import { Order, PagedResponse } from '../../models/order.model';

// Order Actions
export const loadOrders = createAction(
  '[Orders] Load Orders',
  props<{ page: number; pageSize: number }>()
);

export const loadOrdersSuccess = createAction(
  '[Orders] Load Orders Success',
  props<{ response: PagedResponse<Order> }>()
);

export const loadOrdersFailure = createAction(
  '[Orders] Load Orders Failure',
  props<{ error: any }>()
);

export const loadOrderById = createAction(
  '[Orders] Load Order By Id',
  props<{ id: string }>()
);

export const loadOrderByIdSuccess = createAction(
  '[Orders] Load Order By Id Success',
  props<{ order: Order }>()
);

export const loadOrderByIdFailure = createAction(
  '[Orders] Load Order By Id Failure',
  props<{ error: any }>()
);

export const createOrder = createAction(
  '[Orders] Create Order',
  props<{ order: Partial<Order> }>()
);

export const createOrderSuccess = createAction(
  '[Orders] Create Order Success',
  props<{ order: Order }>()
);

export const createOrderFailure = createAction(
  '[Orders] Create Order Failure',
  props<{ error: any }>()
);

export const updateOrderStatus = createAction(
  '[Orders] Update Order Status',
  props<{ id: string; status: string }>()
);

export const updateOrderStatusSuccess = createAction(
  '[Orders] Update Order Status Success',
  props<{ order: Order }>()
);

export const updateOrderStatusFailure = createAction(
  '[Orders] Update Order Status Failure',
  props<{ error: any }>()
);

export const cancelOrder = createAction(
  '[Orders] Cancel Order',
  props<{ id: string }>()
);

export const cancelOrderSuccess = createAction(
  '[Orders] Cancel Order Success',
  props<{ order: Order }>()
);

export const cancelOrderFailure = createAction(
  '[Orders] Cancel Order Failure',
  props<{ error: any }>()
);
