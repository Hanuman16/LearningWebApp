import { ActionReducerMap } from '@ngrx/store';
import { authReducer } from './reducers/auth.reducer';
import { productReducer } from './reducers/product.reducer';
import { cartReducer } from './reducers/cart.reducer';
import { orderReducer } from './reducers/order.reducer';
import { AuthState } from './states/auth.state';
import { ProductState } from './states/product.state';
import { CartState } from './states/cart.state';
import { OrderState } from './states/order.state';

/**
 * ╔═══════════════════════════════════════════════════════════╗
 * ║  ROOT STORE - ngrx Store Configuration                   ║
 * ╚═══════════════════════════════════════════════════════════╝
 * 
 * CONCEPTS IMPLEMENTED:
 * ─────────────────────
 * 
 * 1. CENTRALIZED STATE MANAGEMENT (ngrx/store)
 *    - Single source of truth: AppState contains ALL application state
 *    - WITHOUT ngrx: State scattered across services, components, variables
 *    - WITH ngrx: All state in ONE place (store) → predictable, debuggable
 *    - Analogy: Store = Database for frontend state
 * 
 * 2. STATE TREE ARCHITECTURE (Nested State)
 *    - AppState is ROOT of state tree
 *    - Each feature has its own SLICE (auth, products, cart, orders)
 *    - Analogy: AppState = { auth: {...}, products: {...}, cart: {...}, orders: {...} }
 *    - Each slice is managed by its own REDUCER
 *    - Enables modular architecture (each feature independent)
 * 
 * 3. ACTION REDUCER MAP (TypeScript Type Safety)
 *    - ActionReducerMap<AppState> = Type mapping: { sliceName: reducerFunction }
 *    - Tells ngrx: "auth slice is managed by authReducer"
 *    - TypeScript enforces: ALL slices must have reducers
 *    - If you add a new slice → TypeScript error if reducer missing
 * 
 * 4. UNIDIRECTIONAL DATA FLOW (Core ngrx Principle)
 *    - Components DISPATCH actions → REDUCERS update state → Components SELECT state
 *    - Data flows ONE direction: Component → Action → Reducer → Store → Selector → Component
 *    - NO circular dependencies (component can't directly modify state)
 *    - Makes state changes PREDICTABLE and DEBUGGABLE
 *    - Analogy: Like a factory assembly line (each step has one job)
 * 
 * 5. STATE SLICE PATTERN (Separation of Concerns)
 *    - auth slice: User login state, token, user profile
 *    - products slice: Product list, selected product, pagination
 *    - cart slice: Cart items, total price, quantities
 *    - orders slice: Order list, order details, order status
 *    - Each slice has: State interface, Initial state, Reducer, Actions, Effects
 *    - Enables team collaboration (different devs work on different slices)
 * 
 * 6. IMMUTABILITY PATTERN
 *    - State is NEVER mutated directly (never do: state.loading = true)
 *    - State is replaced with NEW object (spread operator: { ...state, loading: true })
 *    - Enables change detection (Angular compares object references)
 *    - Enables time-travel debugging (previous states preserved)
 * 
 * 7. SCALABILITY PATTERN
 *    - Adding new feature? Create new slice + reducer + actions
 *    - No changes to existing code (Open/Closed Principle)
 *    - Example: Add "reviews" slice → Create reviewReducer, reviewActions, etc.
 *    - Store grows horizontally (new slices), not vertically (bigger reducers)
 */

/**
 * APP STATE INTERFACE: Defines the SHAPE of entire application state
 * - Every property is REQUIRED (no optional properties)
 * - TypeScript enforces this structure across the entire app
 * - Selectors use this type for type-safe state access
 */
export interface AppState {
  auth: AuthState;          // Authentication slice (login state, user info, token)
  products: ProductState;   // Products slice (product list, featured, pagination)
  cart: CartState;          // Cart slice (cart items, quantities, totals)
  orders: OrderState;       // Orders slice (order list, order details, status)
}

/**
 * REDUCER MAP: Maps each state slice to its reducer function
 * - Tells ngrx: "When auth action dispatched, call authReducer"
 * - TypeScript enforces: ALL slices must have reducers
 * - Key = slice name (must match AppState property names)
 * - Value = reducer function (takes state + action → returns new state)
 */
export const reducers: ActionReducerMap<AppState> = {
  auth: authReducer,          // Auth slice managed by authReducer
  products: productReducer,   // Products slice managed by productReducer
  cart: cartReducer,          // Cart slice managed by cartReducer
  orders: orderReducer        // Orders slice managed by orderReducer
};
