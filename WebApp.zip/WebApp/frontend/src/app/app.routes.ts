import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { adminGuard } from './core/guards/admin.guard';

/**
 * ╔═══════════════════════════════════════════════════════════╗
 * ║  APP ROUTES - Angular Router Configuration               ║
 * ╚═══════════════════════════════════════════════════════════╝
 * 
 * CONCEPTS IMPLEMENTED:
 * ─────────────────────
 * 
 * 1. ROUTER MODULE (Angular Routing)
 *    - Central routing configuration for the entire application
 *    - Routes map URL paths to Angular components
 *    - When URL matches a route, Angular loads the corresponding component
 *    - Routes are evaluated in ORDER (first match wins)
 * 
 * 2. LAZY LOADING (Performance Optimization)
 *    - loadComponent: Loads component ONLY when route is visited
 *    - loadChildren: Loads entire feature module ONLY when route is visited
 *    - WITHOUT lazy loading: ALL components loaded at app startup (slow)
 *    - WITH lazy loading: Only home component loaded initially
 *    - Cart component loaded only when user clicks "Cart"
 *    - Admin routes loaded only when user visits /admin
 *    - REDUCES INITIAL BUNDLE SIZE by 50-70%
 *    - Syntax: () => import('./path/to/component').then(m => m.ComponentName)
 * 
 * 3. ROUTE GUARDS (Security)
 *    - canActivate: Protects routes from unauthorized access
 *    - authGuard: Requires user to be logged in
 *    - adminGuard: Requires user to have Admin role
 *    - If user is not authorized → redirect to login or forbidden page
 *    - Guards are EXECUTED BEFORE route is activated
 *    - Prevents unauthorized users from seeing protected pages
 * 
 * 4. WILDCARD ROUTE (404 Handling)
 *    - path: '**' matches ANY URL that doesn't match other routes
 *    - Redirects to home page (or could redirect to /not-found)
 *    - Prevents blank pages for invalid URLs
 *    - MUST be LAST route (evaluated last)
 * 
 * 5. ROUTE PARAMETERS (Dynamic Routes)
 *    - /products/:id → Product detail page (id is parameter)
 *    - /products?category=electronics → Filtered product list
 *    - Parameters accessed via ActivatedRoute service
 * 
 * 6. NESTED ROUTING (Feature Modules)
 *    - /admin → loadChildren → admin.routes.ts
 *    - /admin/products, /admin/orders defined in admin.routes.ts
 *    - Each feature module manages its own routes
 *    - Enables modular architecture
 * 
 * 7. LAZY LOADING: loadComponent vs loadChildren
 *    - loadComponent: Loads a SINGLE component (standalone)
 *    - loadChildren: Loads a ROUTER MODULE with multiple routes
 *    - Products page uses loadChildren (has sub-routes: list, create, edit)
 *    - Cart page uses loadComponent (single component)
 */

export const routes: Routes = [
  /**
   * HOME PAGE - Public, no authentication required
   * Lazy loaded: Only loaded when user visits root URL
   * Component: HomeComponent (displays featured products, categories)
   */
  {
    path: '',                                              // Root URL: / 
    loadComponent: () => import('./features/home/home.component')  // LAZY LOADING: Load only when needed
      .then(m => m.HomeComponent)                          // Extract HomeComponent from module
  },
  
  /**
   * PRODUCTS PAGE - Public catalog browsing
   * Lazy loaded: Products module loaded only when user visits /products
   * Uses loadChildren because products has SUB-ROUTES:
   *   - /products → Product list
   *   - /products/:id → Product detail
   *   - /products/create → Create product (admin only)
   *   - /products/:id/edit → Edit product (admin only)
   */
  {
    path: 'products',
    loadChildren: () => import('./features/products/products.routes')  // LAZY LOAD: Feature module with sub-routes
      .then(m => m.productsRoutes)
  },
  
  /**
   * CART PAGE - Requires authentication
   * GUARD: authGuard → User must be logged in to view cart
   * Why? Cart contains user-specific data (their saved items)
   * If not logged in → redirect to /login
   */
  {
    path: 'cart',
    loadComponent: () => import('./features/cart/cart-page/cart-page.component')
      .then(m => m.CartPageComponent),
    canActivate: [authGuard]                               // SECURITY: Only authenticated users can view cart
  },
  
  /**
   * CHECKOUT PAGE - Requires authentication
   * GUARD: authGuard → User must be logged in to place orders
   * Why? Need user address, payment info, order history
   */
  {
    path: 'checkout',
    loadComponent: () => import('./features/checkout/checkout-page/checkout-page.component')
      .then(m => m.CheckoutPageComponent),
    canActivate: [authGuard]                               // SECURITY: Only authenticated users can checkout
  },
  
  /**
   * ORDERS PAGE - Requires authentication
   * Lazy loaded: Orders module loaded only when user visits /orders
   * GUARD: authGuard → User can only see THEIR OWN orders
   */
  {
    path: 'orders',
    loadChildren: () => import('./features/orders/orders.routes')
      .then(m => m.ordersRoutes),
    canActivate: [authGuard]                               // SECURITY: Only authenticated users can view orders
  },
  
  /**
   * PROFILE PAGE - Requires authentication
   * Lazy loaded: Profile module loaded only when user visits /profile
   * GUARD: authGuard → User can only edit THEIR OWN profile
   */
  {
    path: 'profile',
    loadChildren: () => import('./features/profile/profile.routes')
      .then(m => m.profileRoutes),
    canActivate: [authGuard]                               // SECURITY: Only authenticated users can edit profile
  },
  
  /**
   * LOGIN PAGE - Public, NO authentication required
   * If user is already logged in → redirect to home (handled by guard in app.config)
   */
  {
    path: 'login',
    loadComponent: () => import('./features/auth/login/login.component')
      .then(m => m.LoginComponent)
  },
  
  /**
   * REGISTER PAGE - Public, NO authentication required
   * New users create accounts here
   */
  {
    path: 'register',
    loadComponent: () => import('./features/auth/register/register.component')
      .then(m => m.RegisterComponent)
  },
  
  /**
   * FORGOT PASSWORD PAGE - Public
   * Users request password reset here
   */
  {
    path: 'forgot-password',
    loadComponent: () => import('./features/auth/forgot-password/forgot-password.component')
      .then(m => m.ForgotPasswordComponent)
  },
  
  /**
   * ADMIN PANEL - Requires Admin role
   * Lazy loaded: Admin module loaded only when user visits /admin
   * GUARD: adminGuard → User must have Admin role
   * adminGuard checks:
   *   1. Is user authenticated? → If no, redirect to /login
   *   2. Does user have Admin role? → If no, redirect to /forbidden
   * If not admin → redirect to /forbidden (403)
   */
  {
    path: 'admin',
    loadChildren: () => import('./features/admin/admin.routes')
      .then(m => m.adminRoutes),
    canActivate: [adminGuard]                              // SECURITY: Admin-only access (role-based)
  },
  
  /**
   * WILDCARD ROUTE - 404 Handling
   * Matches ANY URL that doesn't match above routes
   * Loads custom NotFoundComponent for better UX
   * WHY: Custom 404 page with search, quick links, and navigation options
   * MUST be LAST route (evaluated last)
   */
  {
    path: '**',                                             // Wildcard: matches any unmatched URL
    loadComponent: () => import('./shared/components/not-found/not-found.component')  // CUSTOM 404 PAGE
      .then(m => m.NotFoundComponent)                        // Better UX than redirecting to home
  }
];
