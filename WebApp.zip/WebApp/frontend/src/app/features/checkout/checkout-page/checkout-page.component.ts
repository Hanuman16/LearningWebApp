import { Component, OnInit, inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { NgFor, NgIf } from '@angular/common';
import { CartService } from '../../../core/services/cart.service';
import { OrderService } from '../../../core/services/order.service';
import { Cart } from '../../../core/models/cart.model';
import { CreateOrderRequest } from '../../../core/models/order.model';

@Component({
  selector: 'app-checkout-page',
  standalone: true,
  imports: [RouterLink, NgFor, NgIf, ReactiveFormsModule],
  template: `
    <div class="container mx-auto px-4 py-8">
      <h1 class="text-3xl font-bold mb-8">Checkout</h1>
      
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Checkout Form -->
        <div class="lg:col-span-2">
          <form [formGroup]="checkoutForm" (ngSubmit)="onSubmit()">
            <!-- Shipping Information -->
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
              <h2 class="text-xl font-semibold mb-4">Shipping Information</h2>
              
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                  <input formControlName="shippingFirstName" type="text" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                  <input formControlName="shippingLastName" type="text" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                </div>
                <div class="md:col-span-2">
                  <label class="block text-sm font-medium text-gray-700 mb-1">Address Line 1</label>
                  <input formControlName="shippingLine1" type="text" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                </div>
                <div class="md:col-span-2">
                  <label class="block text-sm font-medium text-gray-700 mb-1">Address Line 2</label>
                  <input formControlName="shippingLine2" type="text" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-1">City</label>
                  <input formControlName="shippingCity" type="text" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-1">State</label>
                  <input formControlName="shippingState" type="text" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-1">Postal Code</label>
                  <input formControlName="shippingPostalCode" type="text" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-1">Country</label>
                  <input formControlName="shippingCountry" type="text" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                </div>
                <div class="md:col-span-2">
                  <label class="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                  <input formControlName="shippingPhone" type="tel" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                </div>
              </div>
            </div>
            
            <!-- Shipping Method -->
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
              <h2 class="text-xl font-semibold mb-4">Shipping Method</h2>
              <div class="space-y-3">
                <label class="flex items-center p-3 border rounded-md cursor-pointer">
                  <input type="radio" name="shippingMethod" value="standard" checked class="mr-3">
                  <div>
                    <span class="font-medium">Standard Shipping</span>
                    <span class="text-gray-600 ml-2">5-7 business days</span>
                    <span class="ml-2 font-semibold">$5.99</span>
                  </div>
                </label>
                <label class="flex items-center p-3 border rounded-md cursor-pointer">
                  <input type="radio" name="shippingMethod" value="express" class="mr-3">
                  <div>
                    <span class="font-medium">Express Shipping</span>
                    <span class="text-gray-600 ml-2">2-3 business days</span>
                    <span class="ml-2 font-semibold">$12.99</span>
                  </div>
                </label>
              </div>
            </div>
            
            <!-- Payment Method -->
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
              <h2 class="text-xl font-semibold mb-4">Payment Method</h2>
              <div class="space-y-3">
                <label class="flex items-center p-3 border rounded-md cursor-pointer">
                  <input type="radio" name="paymentMethod" value="credit_card" checked class="mr-3">
                  <span class="font-medium">Credit Card</span>
                </label>
                <label class="flex items-center p-3 border rounded-md cursor-pointer">
                  <input type="radio" name="paymentMethod" value="paypal" class="mr-3">
                  <span class="font-medium">PayPal</span>
                </label>
              </div>
            </div>
            
            <!-- Customer Notes -->
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
              <h2 class="text-xl font-semibold mb-4">Order Notes (Optional)</h2>
              <textarea formControlName="customerNotes" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary" placeholder="Any special instructions for your order?"></textarea>
            </div>
            
            <div *ngIf="errorMessage" class="text-red-600 text-sm mb-4">{{ errorMessage }}</div>
            
            <button type="submit" [disabled]="loading" class="w-full bg-primary text-white py-3 px-6 rounded-lg hover:bg-primary-dark disabled:bg-gray-400">
              {{ loading ? 'Processing...' : 'Place Order' }}
            </button>
          </form>
        </div>
        
        <!-- Order Summary -->
        <div>
          <div class="bg-white rounded-lg shadow-md p-6 sticky top-4">
            <h2 class="text-xl font-semibold mb-4">Order Summary</h2>
            
            <div *ngFor="let item of cart?.items" class="flex items-center gap-3 mb-3 pb-3 border-b">
              <img *ngIf="item.product?.images?.length" [src]="item.product!.images![0].url" [alt]="item.product?.name" class="w-12 h-12 object-cover rounded">
              <div class="flex-1">
                <p class="text-sm font-medium">{{ item.product?.name }}</p>
                <p class="text-sm text-gray-600">Qty: {{ item.quantity }}</p>
              </div>
              <p class="text-sm font-semibold">{{ item.subtotal.toFixed(2) }}</p>
            </div>
            
            <div class="space-y-2 mt-4">
              <div class="flex justify-between text-sm">
                <span>Subtotal</span>
                <span>{{ (cart?.subtotal ?? 0).toFixed(2) }}</span>
              </div>
              <div class="flex justify-between text-sm" *ngIf="cart && cart.discountAmount">
                <span>Discount</span>
                <span class="text-green-600">-{{ cart.discountAmount.toFixed(2) }}</span>
              </div>
              <div class="flex justify-between text-sm">
                <span>Shipping</span>
                <span>$5.99</span>
              </div>
              <div class="flex justify-between text-sm">
                <span>Tax</span>
                <span>{{ (cart?.taxAmount ?? 0).toFixed(2) }}</span>
              </div>
              <div class="border-t pt-2 flex justify-between font-bold text-lg">
                <span>Total</span>
                <span>{{ (cart?.total ?? 0).toFixed(2) }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: []
})
export class CheckoutPageComponent implements OnInit {
  private fb = inject(FormBuilder);
  private cartService = inject(CartService);
  private orderService = inject(OrderService);
  private router = inject(Router);
  
  checkoutForm: FormGroup = this.fb.group({
    shippingFirstName: ['', [Validators.required]],
    shippingLastName: ['', [Validators.required]],
    shippingLine1: ['', [Validators.required]],
    shippingLine2: [''],
    shippingCity: ['', [Validators.required]],
    shippingState: ['', [Validators.required]],
    shippingPostalCode: ['', [Validators.required]],
    shippingCountry: ['', [Validators.required]],
    shippingPhone: ['', [Validators.required]],
    customerNotes: ['']
  });
  
  cart: Cart | null = null;
  loading = false;
  errorMessage = '';
  
  ngOnInit(): void {
    this.loadCart();
  }
  
  loadCart(): void {
    this.cartService.getCart().subscribe({
      next: (cart: Cart) => {
        this.cart = cart;
      },
      error: (error: any) => {
        console.error('Error loading cart:', error);
        this.router.navigate(['/cart']);
      }
    });
  }
  
  onSubmit(): void {
    if (this.checkoutForm.invalid) {
      this.checkoutForm.markAllAsTouched();
      return;
    }
    
    if (!this.cart || this.cart.items.length === 0) {
      this.errorMessage = 'Your cart is empty';
      return;
    }
    
    this.loading = true;
    this.errorMessage = '';
    
    // TODO: Get selected shipping method and payment method from radio buttons
    const request: CreateOrderRequest = {
      shippingAddressId: '', // TODO: Get from saved addresses
      shippingMethodName: 'standard',
      paymentMethod: 'credit_card',
      customerNotes: this.checkoutForm.value.customerNotes
    };
    
    this.orderService.createOrder(request).subscribe({
      next: (order: any) => {
        this.router.navigate(['/orders', order.id]);
      },
      error: (error: any) => {
        this.errorMessage = error.error?.message || 'Failed to create order';
        this.loading = false;
      }
    });
  }
}
