import { Component, OnInit, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NgFor, NgIf, NgClass } from '@angular/common';
import { ProductService } from '../../../core/services/product.service';
import { Product } from '../../../core/models/product.model';

@Component({
  selector: 'app-product-management',
  standalone: true,
  imports: [RouterLink, NgFor, NgIf, NgClass],
  template: `
    <div class="container mx-auto px-4 py-8">
      <div class="flex justify-between items-center mb-8">
        <h1 class="text-3xl font-bold">Product Management</h1>
        <a routerLink="/admin/products/new" class="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-dark">
          + Add New Product
        </a>
      </div>
      
      <!-- Filters -->
      <div class="bg-white rounded-lg shadow-md p-4 mb-6">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
          <input type="text" placeholder="Search products..." class="px-3 py-2 border border-gray-300 rounded-md">
          <select class="px-3 py-2 border border-gray-300 rounded-md">
            <option value="">All Categories</option>
            <option value="electronics">Electronics</option>
            <option value="clothing">Clothing</option>
            <option value="books">Books</option>
          </select>
          <select class="px-3 py-2 border border-gray-300 rounded-md">
            <option value="">All Status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="draft">Draft</option>
          </select>
          <button class="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-dark">
            Apply Filters
          </button>
        </div>
      </div>
      
      <!-- Products Table -->
      <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">SKU</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Stock</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              <tr *ngFor="let product of products">
                <td class="px-6 py-4 whitespace-nowrap">
                  <div class="flex items-center">
                    <img *ngIf="product.images && product.images.length > 0" [src]="product.images[0].url" [alt]="product.name" class="w-10 h-10 object-cover rounded">
                    <div class="ml-4">
                      <div class="text-sm font-medium">{{ product.name }}</div>
                    </div>
                  </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">{{ product.sku }}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">{{ product.price.toFixed(2) }}</td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <span [class]="product.stockQuantity <= product.lowStockThreshold ? 'text-red-600' : 'text-green-600'">
                    {{ product.stockQuantity }}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">{{ product.category?.name }}</td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <span class="px-2 py-1 text-xs rounded-full"
                    [ngClass]="product.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'">
                    {{ product.isActive ? 'Active' : 'Inactive' }}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">
                  <div class="flex gap-2">
                    <a [routerLink]="['/admin/products', product.id]" class="text-blue-600 hover:text-blue-800">Edit</a>
                    <button (click)="toggleProduct(product.id, !product.isActive)" class="text-green-600 hover:text-green-800">
                      {{ product.isActive ? 'Deactivate' : 'Activate' }}
                    </button>
                    <button (click)="deleteProduct(product.id)" class="text-red-600 hover:text-red-800">Delete</button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
  styles: []
})
export class ProductManagementComponent implements OnInit {
  private productService = inject(ProductService);
  
  products: Product[] = [];
  
  ngOnInit(): void {
    this.loadProducts();
  }
  
  loadProducts(): void {
    this.productService.getAll().subscribe({
      next: (response: any) => {
        this.products = response.items;
      },
      error: (error: any) => {
        console.error('Error loading products:', error);
      }
    });
  }
  
  toggleProduct(id: string, isActive: boolean): void {
    this.productService.update(id, { isActive: isActive }).subscribe({
      next: () => {
        this.loadProducts();
      },
      error: (error: any) => {
        console.error('Error updating product:', error);
      }
    });
  }
  
  deleteProduct(id: string): void {
    if (confirm('Are you sure you want to delete this product?')) {
      this.productService.delete(id).subscribe({
        next: () => {
          this.loadProducts();
        },
        error: (error: any) => {
          console.error('Error deleting product:', error);
        }
      });
    }
  }
}
