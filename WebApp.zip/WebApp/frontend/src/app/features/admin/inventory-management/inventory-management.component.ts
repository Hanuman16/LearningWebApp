import { Component, OnInit, inject } from '@angular/core';
import { NgFor, NgIf, NgClass } from '@angular/common';
import { InventoryService } from '../../../core/services/inventory.service';
import { InventoryItem, InventorySummary } from '../../../core/models/inventory.model';

@Component({
  selector: 'app-inventory-management',
  standalone: true,
  imports: [NgFor, NgIf, NgClass],
  template: `
    <div class="container mx-auto px-4 py-8">
      <h1 class="text-3xl font-bold mb-8">Inventory Management</h1>
      
      <!-- Summary Cards -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow-md p-6">
          <p class="text-sm text-gray-600 mb-1">Total Items</p>
          <p class="text-3xl font-bold">{{ summary?.totalItems || 0 }}</p>
        </div>
        <div class="bg-white rounded-lg shadow-md p-6">
          <p class="text-sm text-gray-600 mb-1">Total Value</p>
          <p class="text-3xl font-bold">{{ summary?.totalValue?.toFixed(2) || '0.00' }}</p>
        </div>
        <div class="bg-white rounded-lg shadow-md p-6">
          <p class="text-sm text-gray-600 mb-1">Low Stock</p>
          <p class="text-3xl font-bold text-yellow-600">{{ summary?.lowStockItems || 0 }}</p>
        </div>
        <div class="bg-white rounded-lg shadow-md p-6">
          <p class="text-sm text-gray-600 mb-1">Out of Stock</p>
          <p class="text-3xl font-bold text-red-600">{{ summary?.outOfStockItems || 0 }}</p>
        </div>
      </div>
      
      <!-- Low Stock Alert -->
      <div *ngIf="lowStockItems.length > 0" class="bg-yellow-50 border border-yellow-200 rounded-lg shadow-md p-4 mb-6">
        <div class="flex items-center">
          <svg class="w-6 h-6 text-yellow-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
          </svg>
          <div>
            <h3 class="font-semibold text-yellow-800">Low Stock Alert</h3>
            <p class="text-sm text-yellow-700">{{ lowStockItems.length }} products need restocking</p>
          </div>
        </div>
      </div>
      
      <!-- Inventory Table -->
      <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="p-4 border-b">
          <div class="flex justify-between items-center">
            <input type="text" placeholder="Search inventory..." class="px-3 py-2 border border-gray-300 rounded-md flex-1 max-w-sm">
            <button class="ml-4 bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-dark">
              + Add Stock
            </button>
          </div>
        </div>
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">SKU</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Quantity</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Reserved</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Available</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Reorder Level</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              <tr *ngFor="let item of inventoryItems">
                <td class="px-6 py-4 whitespace-nowrap">
                  <div class="text-sm font-medium">{{ item.product?.name }}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">{{ item.product?.sku }}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">{{ item.quantity }}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">{{ item.reservedQuantity }}</td>
                <td class="px-6 py-4 whitespace-nowrap font-semibold">{{ item.quantity - item.reservedQuantity }}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">{{ item.reorderLevel }}</td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <span class="px-2 py-1 text-xs rounded-full"
                    [ngClass]="{
                      'bg-green-100 text-green-800': item.quantity > item.reorderLevel && item.quantity > 0,
                      'bg-yellow-100 text-yellow-800': item.quantity <= item.reorderLevel && item.quantity > 0,
                      'bg-red-100 text-red-800': item.quantity === 0
                    }">
                    {{ item.quantity === 0 ? 'Out of Stock' : item.quantity <= item.reorderLevel ? 'Low Stock' : 'In Stock' }}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">
                  <button (click)="updateStock(item)" class="text-blue-600 hover:text-blue-800">Update Stock</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
  styles: []
})
export class InventoryManagementComponent implements OnInit {
  private inventoryService = inject(InventoryService);
  
  inventoryItems: any[] = [];
  lowStockItems: any[] = [];
  summary: any = {};
  
  ngOnInit(): void {
    this.loadInventory();
    this.loadLowStock();
    this.loadSummary();
  }
  
  loadInventory(): void {
    this.inventoryService.getInventorySummary().subscribe({
      next: (data: InventorySummary) => {
        this.inventoryItems = data.items;
        this.summary = data;
      },
      error: (error: any) => {
        console.error('Error loading inventory:', error);
      }
    });
  }
  
  loadLowStock(): void {
    this.inventoryService.getLowStockItems().subscribe({
      next: (items: InventoryItem[]) => {
        this.lowStockItems = items;
      },
      error: (error: any) => {
        console.error('Error loading low stock items:', error);
      }
    });
  }
  
  loadSummary(): void {
    this.inventoryService.getInventorySummary().subscribe({
      next: (data: InventorySummary) => {
        this.summary = data;
      },
      error: (error: any) => {
        console.error('Error loading inventory summary:', error);
      }
    });
  }
  
  updateStock(item: InventoryItem): void {
    const quantity = prompt('Enter new stock quantity:', item.quantity.toString());
    if (quantity !== null && !isNaN(Number(quantity))) {
      this.inventoryService.updateStock(item.productId, Number(quantity)).subscribe({
        next: () => {
          this.loadInventory();
          this.loadLowStock();
        },
        error: (error: any) => {
          console.error('Error updating stock:', error);
        }
      });
    }
  }
}
