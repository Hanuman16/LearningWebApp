import { Component, OnInit, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NgFor, NgIf, NgClass, DatePipe } from '@angular/common';
import { OrderService } from '../../../core/services/order.service';
import { Order } from '../../../core/models/order.model';

@Component({
  selector: 'app-order-management',
  standalone: true,
  imports: [RouterLink, NgFor, NgIf, NgClass, DatePipe],
  providers: [DatePipe],
  template: `
    <div class="container mx-auto px-4 py-8">
      <h1 class="text-3xl font-bold mb-8">Order Management</h1>
      
      <!-- Filters -->
      <div class="bg-white rounded-lg shadow-md p-4 mb-6">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
          <input type="text" placeholder="Search by order number..." class="px-3 py-2 border border-gray-300 rounded-md">
          <select class="px-3 py-2 border border-gray-300 rounded-md">
            <option value="">All Status</option>
            <option value="Pending">Pending</option>
            <option value="Processing">Processing</option>
            <option value="Shipped">Shipped</option>
            <option value="Delivered">Delivered</option>
            <option value="Cancelled">Cancelled</option>
          </select>
          <input type="date" class="px-3 py-2 border border-gray-300 rounded-md">
          <button class="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-dark">
            Apply Filters
          </button>
        </div>
      </div>
      
      <!-- Orders Table -->
      <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Order #</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Payment</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              <tr *ngFor="let order of orders">
                <td class="px-6 py-4 whitespace-nowrap">
                  <a [routerLink]="['/orders', order.id]" class="text-primary hover:underline text-sm font-medium">
                    {{ order.orderNumber }}
                  </a>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">{{ order.customerNotes || 'N/A' }}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">{{ order.createdAt | date:'mediumDate' }}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-semibold">{{ order.totalAmount.toFixed(2) }}</td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <span class="px-2 py-1 text-xs rounded-full"
                    [ngClass]="{
                      'bg-yellow-100 text-yellow-800': order.status === 'Pending',
                      'bg-blue-100 text-blue-800': order.status === 'Processing',
                      'bg-green-100 text-green-800': order.status === 'Shipped' || order.status === 'Delivered',
                      'bg-red-100 text-red-800': order.status === 'Cancelled'
                    }">
                    {{ order.status }}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <span class="px-2 py-1 text-xs rounded-full"
                    [ngClass]="{
                      'bg-green-100 text-green-800': order.paymentStatus === 'Paid',
                      'bg-yellow-100 text-yellow-800': order.paymentStatus === 'Pending',
                      'bg-red-100 text-red-800': order.paymentStatus === 'Failed'
                    }">
                    {{ order.paymentStatus }}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">
                  <div class="flex gap-2">
                    <a [routerLink]="['/orders', order.id]" class="text-blue-600 hover:text-blue-800">View</a>
                    <button *ngIf="order.status === 'Pending' || order.status === 'Processing'" (click)="updateStatus(order.id, 'Shipped')" class="text-green-600 hover:text-green-800">Mark Shipped</button>
                    <button *ngIf="order.status !== 'Cancelled'" (click)="cancelOrder(order.id)" class="text-red-600 hover:text-red-800">Cancel</button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
  styles: []
})
export class OrderManagementComponent implements OnInit {
  private orderService = inject(OrderService);
  
  orders: Order[] = [];
  
  ngOnInit(): void {
    this.loadOrders();
  }
  
  loadOrders(): void {
    this.orderService.getMyOrders().subscribe({
      next: (response: any) => {
        this.orders = response.items;
      },
      error: (error: any) => {
        console.error('Error loading orders:', error);
      }
    });
  }
  
  updateStatus(id: string, status: string): void {
    this.orderService.updateStatus(id, { status: status }).subscribe({
      next: () => {
        this.loadOrders();
      },
      error: (error: any) => {
        console.error('Error updating order status:', error);
      }
    });
  }
  
  cancelOrder(id: string): void {
    if (confirm('Are you sure you want to cancel this order?')) {
      this.orderService.cancel(id).subscribe({
        next: () => {
          this.loadOrders();
        },
        error: (error) => {
          console.error('Error cancelling order:', error);
        }
      });
    }
  }
}
