import { Routes } from '@angular/router';
import { AdminDashboardComponent } from './dashboard/dashboard.component';
import { ProductManagementComponent } from './product-management/product-management.component';
import { OrderManagementComponent } from './order-management/order-management.component';
import { InventoryManagementComponent } from './inventory-management/inventory-management.component';

export const adminRoutes: Routes = [
  {
    path: '',
    component: AdminDashboardComponent
  },
  {
    path: 'products',
    component: ProductManagementComponent
  },
  {
    path: 'orders',
    component: OrderManagementComponent
  },
  {
    path: 'inventory',
    component: InventoryManagementComponent
  }
];
