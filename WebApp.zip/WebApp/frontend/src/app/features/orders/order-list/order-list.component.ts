import { Component, OnInit, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NgFor, NgIf, NgClass, DatePipe } from '@angular/common';
import { OrderService } from '../../../core/services/order.service';
import { Order } from '../../../core/models/order.model';

@Component({
  selector: 'app-order-list',
  standalone: true,
  imports: [RouterLink, NgFor, NgIf, NgClass, DatePipe],
  template: `
    <div class="container mx-auto px-4 py-8">
      <h1 class="text-3xl font-bold mb-8">My Orders</h1>
      
      <div *ngIf="orders.length > 0" class="space-y-4">
        <div *ngFor="let order of orders" class="bg-white rounded-lg shadow-md p-6">
          <div class="flex justify-between items-start mb-4">
            <div>
              <h2 class="text-lg font-semibold">Order #{{ order.orderNumber }}</h2>
              <p class="text-sm text-gray-600">{{ order.createdAt | date:'mediumDate' }}</p>
            </div>
            <span class="px-3 py-1 rounded-full text-sm font-medium"
              [ngClass]="{
                'bg-yellow-100 text-yellow-800': order.status === 'Pending',
                'bg-blue-100 text-blue-800': order.status === 'Processing',
                'bg-green-100 text-green-800': order.status === 'Shipped' || order.status === 'Delivered',
                'bg-red-100 text-red-800': order.status === 'Cancelled'
              }">
              {{ order.status }}
            </span>
          </div>
          
          <div class="mb-4">
            <div *ngFor="let item of order.items" class="flex items-center gap-3 mb-2">
              <img *ngIf="item.product?.images?.length" [src]="item.product!.images![0].url" [alt]="item.product?.name" class="w-12 h-12 object-cover rounded">
              <div class="flex-1">
                <p class="text-sm">{{ item.product?.name }}</p>
                <p class="text-xs text-gray-600">Qty: {{ item.quantity }} \${{ item.unitPrice.toFixed(2) }}</p>
              </div>
            </div>
          </div>
          
          <div class="flex justify-between items-center">
            <div>
              <p class="text-sm text-gray-600">Total: <span class="font-semibold text-lg">{{ order.totalAmount.toFixed(2) }}</span></p>
            </div>
            <div class="flex gap-2">
              <a [routerLink]="['/orders', order.id]" class="text-primary hover:underline">View Details</a>
              <button *ngIf="order.status === 'Delivered'" class="text-green-600 hover:text-green-800 text-sm">Write a Review</button>
            </div>
          </div>
        </div>
      </div>
      
      <div *ngIf="orders.length === 0" class="text-center py-12">
        <p class="text-gray-500 text-lg mb-4">You haven't placed any orders yet</p>
        <a routerLink="/products" class="inline-block bg-primary text-white px-6 py-3 rounded-lg hover:bg-primary-dark">
          Start Shopping
        </a>
      </div>
    </div>
  `,
  styles: []
})
export class OrderListComponent implements OnInit {
  private orderService = inject(OrderService);
  orders: Order[] = [];
  
  ngOnInit(): void {
    this.loadOrders();
  }
  
  loadOrders(): void {
    this.orderService.getMyOrders().subscribe({
      next: (response) => {
        this.orders = response.items;
      },
      error: (error) => {
        console.error('Error loading orders:', error);
      }
    });
  }
}
