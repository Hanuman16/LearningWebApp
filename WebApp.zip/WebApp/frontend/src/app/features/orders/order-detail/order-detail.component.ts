import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { NgFor, NgIf, DatePipe, NgClass } from '@angular/common';
import { OrderService } from '../../../core/services/order.service';
import { Order } from '../../../core/models/order.model';

@Component({
  selector: 'app-order-detail',
  standalone: true,
  imports: [RouterLink, NgFor, NgIf, DatePipe, NgClass],
  providers: [DatePipe],
  template: `
    <div class="container mx-auto px-4 py-8" *ngIf="order">
      <nav class="mb-6">
        <a routerLink="/orders" class="text-primary hover:underline">← Back to Orders</a>
      </nav>
      
      <h1 class="text-3xl font-bold mb-8">Order #{{ order.orderNumber }}</h1>
      
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Order Items -->
        <div class="lg:col-span-2">
          <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="p-6 border-b">
              <div class="flex justify-between items-center">
                <div>
                  <p class="text-sm text-gray-600">Order Date</p>
                  <p class="font-semibold">{{ order.createdAt | date:'mediumDate' }}</p>
                </div>
                <span class="px-3 py-1 rounded-full text-sm font-medium"
                  [ngClass]="{
                    'bg-yellow-100 text-yellow-800': order.status === 'Pending',
                    'bg-blue-100 text-blue-800': order.status === 'Processing',
                    'bg-green-100 text-green-800': order.status === 'Shipped' || order.status === 'Delivered',
                    'bg-red-100 text-red-800': order.status === 'Cancelled'
                  }">
                  {{ order.status }}
                </span>
              </div>
            </div>
            
            <div *ngFor="let item of order.items" class="p-4 border-b">
              <div class="flex items-center gap-4">
                <img *ngIf="item.product?.images?.length" [src]="item.product!.images![0].url" [alt]="item.product?.name" class="w-16 h-16 object-cover rounded">
                <div class="flex-1">
                  <h3 class="font-semibold">{{ item.product?.name }}</h3>
                  <p class="text-sm text-gray-600">Qty: {{ item.quantity }} × \${{ item.unitPrice.toFixed(2) }}</p>
                </div>
                <p class="font-semibold">{{ item.subtotal.toFixed(2) }}</p>
              </div>
            </div>
          </div>
          
          <!-- Order Notes -->
          <div *ngIf="order.customerNotes" class="bg-white rounded-lg shadow-md p-6 mt-4">
            <h2 class="text-lg font-semibold mb-2">Customer Notes</h2>
            <p class="text-gray-600">{{ order.customerNotes }}</p>
          </div>
        </div>
        
        <!-- Order Summary -->
        <div>
          <div class="bg-white rounded-lg shadow-md p-6 mb-4">
            <h2 class="text-lg font-semibold mb-4">Order Summary</h2>
            <div class="space-y-2">
              <div class="flex justify-between text-sm">
                <span>Subtotal</span>
                <span>{{ order.subtotal.toFixed(2) }}</span>
              </div>
              <div class="flex justify-between text-sm" *ngIf="order.discountAmount > 0">
                <span>Discount</span>
                <span class="text-green-600">-{{ order.discountAmount.toFixed(2) }}</span>
              </div>
              <div class="flex justify-between text-sm">
                <span>Shipping</span>
                <span>{{ order.shippingAmount.toFixed(2) }}</span>
              </div>
              <div class="flex justify-between text-sm">
                <span>Tax</span>
                <span>{{ order.taxAmount.toFixed(2) }}</span>
              </div>
              <div class="border-t pt-2 flex justify-between font-bold text-lg">
                <span>Total</span>
                <span>{{ order.totalAmount.toFixed(2) }}</span>
              </div>
            </div>
          </div>
          
          <!-- Shipping Address -->
          <div *ngIf="order.shippingAddress" class="bg-white rounded-lg shadow-md p-6 mb-4">
            <h2 class="text-lg font-semibold mb-2">Shipping Address</h2>
            <address class="not-italic text-sm text-gray-600">
              {{ order.shippingAddress.firstName }} {{ order.shippingAddress.lastName }}<br>
              {{ order.shippingAddress.line1 }}<br>
              <span *ngIf="order.shippingAddress.line2">{{ order.shippingAddress.line2 }},</span>
              {{ order.shippingAddress.city }}, {{ order.shippingAddress.state }} {{ order.shippingAddress.postalCode }}<br>
              {{ order.shippingAddress.country }}
            </address>
          </div>
          
          <!-- Tracking -->
          <div *ngIf="order.trackingNumber" class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-lg font-semibold mb-2">Tracking Information</h2>
            <p class="text-sm"><span class="font-medium">Tracking #:</span> {{ order.trackingNumber }}</p>
            <a *ngIf="order.trackingUrl" [href]="order.trackingUrl" target="_blank" class="text-primary hover:underline text-sm">Track Package →</a>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: []
})
export class OrderDetailComponent implements OnInit {
  private activatedRoute = inject(ActivatedRoute);
  private orderService = inject(OrderService);
  private datePipe = inject(DatePipe);
  
  order: Order | null = null;
  
  ngOnInit(): void {
    const id = this.activatedRoute.snapshot.params['id'];
    this.orderService.getById(id).subscribe({
      next: (order) => {
        this.order = order;
      },
      error: (error) => {
        console.error('Error loading order:', error);
      }
    });
  }
}
