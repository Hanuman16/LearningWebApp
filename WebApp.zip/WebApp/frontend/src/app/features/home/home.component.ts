import { Component, OnInit, inject } from '@angular/core';
import { ProductService } from '../../core/services/product.service';
import { Product } from '../../core/models/product.model';
import { ProductCardComponent } from '../../shared/components/product-card/product-card.component';
import { NgFor } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [ProductCardComponent, NgFor, RouterModule],
  template: `
    <div>
      <!-- Hero Section -->
      <section class="bg-gradient-to-r from-primary to-primary-dark text-white py-20">
        <div class="container mx-auto px-4 text-center">
          <h1 class="text-5xl font-bold mb-4">Welcome to E-Commerce</h1>
          <p class="text-xl mb-8">Discover amazing products at unbeatable prices</p>
          <a routerLink="/products" class="bg-white text-primary px-8 py-3 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors">
            Shop Now
          </a>
        </div>
      </section>

      <!-- Featured Products Section -->
      <section class="py-12">
        <div class="container mx-auto px-4">
          <h2 class="text-3xl font-bold mb-8 text-center">Featured Products</h2>
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <app-product-card *ngFor="let product of featuredProducts" [product]="product"></app-product-card>
          </div>
          <div class="text-center mt-8">
            <a routerLink="/products" class="inline-block bg-primary text-white px-6 py-3 rounded-lg hover:bg-primary-dark transition-colors">
              View All Products
            </a>
          </div>
        </div>
      </section>

      <!-- Categories Section -->
      <section class="py-12 bg-gray-50">
        <div class="container mx-auto px-4">
          <h2 class="text-3xl font-bold mb-8 text-center">Shop by Category</h2>
          <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
            <a routerLink="/products?category=electronics" class="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow cursor-pointer block">
              <div class="text-4xl mb-4">📱</div>
              <h3 class="text-lg font-semibold">Electronics</h3>
            </a>
            <a routerLink="/products?category=clothing" class="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow cursor-pointer block">
              <div class="text-4xl mb-4">👕</div>
              <h3 class="text-lg font-semibold">Clothing</h3>
            </a>
            <a routerLink="/products?category=home-garden" class="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow cursor-pointer block">
              <div class="text-4xl mb-4">🏠</div>
              <h3 class="text-lg font-semibold">Home & Garden</h3>
            </a>
            <a routerLink="/products?category=books" class="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow cursor-pointer block">
              <div class="text-4xl mb-4">📚</div>
              <h3 class="text-lg font-semibold">Books</h3>
            </a>
          </div>
        </div>
      </section>

      <!-- Features Section -->
      <section class="py-12">
        <div class="container mx-auto px-4">
          <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="text-center">
              <div class="text-4xl mb-4">🚚</div>
              <h3 class="text-xl font-semibold mb-2">Free Shipping</h3>
              <p class="text-gray-600">On orders over $50</p>
            </div>
            <div class="text-center">
              <div class="text-4xl mb-4">🔒</div>
              <h3 class="text-xl font-semibold mb-2">Secure Payment</h3>
              <p class="text-gray-600">100% secure transactions</p>
            </div>
            <div class="text-center">
              <div class="text-4xl mb-4">↩️</div>
              <h3 class="text-xl font-semibold mb-2">Easy Returns</h3>
              <p class="text-gray-600">30-day return policy</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  `,
  styles: []
})
export class HomeComponent implements OnInit {
  private productService = inject(ProductService);
  featuredProducts: Product[] = [];

  ngOnInit(): void {
    this.productService.getFeatured(8).subscribe({
      next: (products) => {
        this.featuredProducts = products;
      },
      error: (error) => {
        console.error('Error loading featured products:', error);
      }
    });
  }
}
