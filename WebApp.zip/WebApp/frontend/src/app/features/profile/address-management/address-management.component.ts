import { Component, OnInit, inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { NgFor, NgIf, NgClass } from '@angular/common';
import { AddressService } from '../../../core/services/address.service';
import { Address, CreateAddressRequest } from '../../../core/models/address.model';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-address-management',
  standalone: true,
  imports: [RouterLink, NgFor, NgIf, NgClass, ReactiveFormsModule],
  template: `
    <div class="container mx-auto px-4 py-8">
      <div class="flex justify-between items-center mb-8">
        <h1 class="text-3xl font-bold">My Addresses</h1>
        <button (click)="openAddModal()" class="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-dark">
          + Add New Address
        </button>
      </div>
      
      <!-- Addresses Grid -->
      <div *ngIf="addresses.length > 0" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div *ngFor="let address of addresses" class="bg-white rounded-lg shadow-md p-6 relative">
          <div class="absolute top-4 right-4 flex gap-2">
            <button (click)="editAddress(address)" class="text-blue-600 hover:text-blue-800">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
              </svg>
            </button>
            <button (click)="deleteAddress(address.id)" class="text-red-600 hover:text-red-800">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
              </svg>
            </button>
          </div>
          
          <div class="flex items-center gap-2 mb-3">
            <span class="px-2 py-1 rounded text-xs font-medium" [ngClass]="address.type === 'shipping' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'">
              {{ address.type }}
            </span>
            <span *ngIf="address.isDefault" class="px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800">
              Default
            </span>
          </div>
          
          <address class="not-italic text-sm text-gray-600">
            {{ address.firstName }} {{ address.lastName }}<br>
            {{ address.line1 }}<br>
            <span *ngIf="address.line2">{{ address.line2 }},</span>
            {{ address.city }}, {{ address.state }} {{ address.postalCode }}<br>
            {{ address.country }}<br>
            {{ address.phoneNumber }}
          </address>
          
          <button *ngIf="!address.isDefault" (click)="setDefault(address.id)" class="mt-3 text-sm text-primary hover:underline">
            Set as Default
          </button>
        </div>
      </div>
      
      <!-- Empty State -->
      <div *ngIf="addresses.length === 0" class="text-center py-12">
        <svg class="mx-auto h-12 w-12 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
        </svg>
        <p class="text-gray-500 text-lg mb-4">You haven't added any addresses yet</p>
        <button (click)="openAddModal()" class="bg-primary text-white px-6 py-3 rounded-lg hover:bg-primary-dark">
          Add Your First Address
        </button>
      </div>
    </div>
  `,
  styles: []
})
export class AddressManagementComponent implements OnInit {
  private fb = inject(FormBuilder);
  private addressService = inject(AddressService);
  
  addresses: Address[] = [];
  addressForm: FormGroup = this.fb.group({
    firstName: ['', [Validators.required]],
    lastName: ['', [Validators.required]],
    line1: ['', [Validators.required]],
    line2: [''],
    city: ['', [Validators.required]],
    state: ['', [Validators.required]],
    postalCode: ['', [Validators.required]],
    country: ['', [Validators.required]],
    phoneNumber: ['', [Validators.required]],
    isDefault: [false],
    type: ['shipping', [Validators.required]]
  });
  
  isEditing = false;
  editingId = '';
  
  ngOnInit(): void {
    this.loadAddresses();
  }
  
  loadAddresses(): void {
    this.addressService.getAll().subscribe({
      next: (addresses: Address[]) => {
        this.addresses = addresses;
      },
      error: (error: any) => {
        console.error('Error loading addresses:', error);
      }
    });
  }
  
  openAddModal(): void {
    this.isEditing = false;
    this.editingId = '';
    this.addressForm.reset({
      type: 'shipping',
      isDefault: this.addresses.length === 0
    });
    this.addressForm.get('isDefault')?.disable();
    this.addressForm.reset();
  }
  
  editAddress(address: Address): void {
    this.isEditing = true;
    this.editingId = address.id;
    this.addressForm.patchValue(address);
    this.addressForm.get('isDefault')?.disable();
  }
  
  onSubmit(): void {
    if (this.addressForm.invalid) {
      this.addressForm.markAllAsTouched();
      return;
    }
    
    const request: CreateAddressRequest = this.addressForm.value;
    
    if (this.isEditing) {
      this.addressService.update(this.editingId, request).subscribe({
        next: () => {
          this.loadAddresses();
          this.addressForm.reset();
        },
        error: (error: any) => {
          console.error('Error updating address:', error);
        }
      });
    } else {
      this.addressService.create(request).subscribe({
        next: () => {
          this.loadAddresses();
          this.addressForm.reset();
        },
        error: (error: any) => {
          console.error('Error creating address:', error);
        }
      });
    }
  }
  
  deleteAddress(id: string): void {
    if (confirm('Are you sure you want to delete this address?')) {
      this.addressService.delete(id).subscribe({
        next: () => {
          this.loadAddresses();
        },
        error: (error: any) => {
          console.error('Error deleting address:', error);
        }
      });
    }
  }
  
  setDefault(id: string): void {
    this.addressService.update(id, { isDefault: true }).subscribe({
      next: () => {
        this.loadAddresses();
      },
      error: (error: any) => {
        console.error('Error setting default address:', error);
      }
    });
  }
}
