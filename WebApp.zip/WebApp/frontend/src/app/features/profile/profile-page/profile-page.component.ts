import { Component, OnInit, inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { AddressService } from '../../../core/services/address.service';
import { User } from '../../../core/models/auth.model';
import { Address } from '../../../core/models/address.model';
import { NgIf, NgClass } from '@angular/common';

@Component({
  selector: 'app-profile-page',
  standalone: true,
  imports: [RouterLink, ReactiveFormsModule, NgIf],
  template: `
    <div class="container mx-auto px-4 py-8">
      <h1 class="text-3xl font-bold mb-8">My Profile</h1>
      
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Profile Form -->
        <div class="lg:col-span-2">
          <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold mb-4">Personal Information</h2>
            
            <form [formGroup]="profileForm" (ngSubmit)="onSubmit()">
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                  <input formControlName="firstName" type="text" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                  <input formControlName="lastName" type="text" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                </div>
                <div class="md:col-span-2">
                  <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <input type="email" [value]="user?.email" disabled class="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100">
                  <p class="text-xs text-gray-500 mt-1">Email cannot be changed</p>
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                  <input formControlName="phoneNumber" type="tel" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                </div>
              </div>
              
              <div *ngIf="errorMessage" class="text-red-600 text-sm mt-4">{{ errorMessage }}</div>
              <div *ngIf="successMessage" class="text-green-600 text-sm mt-4">{{ successMessage }}</div>
              
              <div class="mt-6">
                <button type="submit" [disabled]="loading || !profileForm.valid" class="bg-primary text-white px-6 py-2 rounded-lg hover:bg-primary-dark disabled:bg-gray-400">
                  {{ loading ? 'Saving...' : 'Save Changes' }}
                </button>
              </div>
            </form>
          </div>
        </div>
        
        <!-- Sidebar -->
        <div>
          <div class="bg-white rounded-lg shadow-md p-6 mb-4">
            <h3 class="font-semibold mb-4">Account</h3>
            <nav class="space-y-2">
              <a routerLink="/profile" class="block px-3 py-2 rounded-md bg-primary-light text-primary font-medium">Personal Information</a>
              <a routerLink="/profile/addresses" class="block px-3 py-2 rounded-md hover:bg-gray-100">Addresses</a>
              <a routerLink="/orders" class="block px-3 py-2 rounded-md hover:bg-gray-100">My Orders</a>
              <a routerLink="/wishlist" class="block px-3 py-2 rounded-md hover:bg-gray-100">Wishlist</a>
            </nav>
          </div>
          
          <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="font-semibold mb-4">Account Status</h3>
            <div class="space-y-2 text-sm">
              <div class="flex justify-between">
                <span class="text-gray-600">Status:</span>
                <span [class]="user?.isActive ? 'text-green-600' : 'text-red-600'">
                  {{ user?.isActive ? 'Active' : 'Inactive' }}
                </span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">Email Verified:</span>
                <span [class]="user?.emailConfirmed ? 'text-green-600' : 'text-yellow-600'">
                  {{ user?.emailConfirmed ? 'Yes' : 'No' }}
                </span>
              </div>
              <div *ngIf="user?.roles" class="flex justify-between">
                <span class="text-gray-600">Roles:</span>
                <span class="text-gray-800">{{ (user!.roles || []).join(', ') }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: []
})
export class ProfilePageComponent implements OnInit {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private router = inject(Router);
  
  profileForm: FormGroup = this.fb.group({
    firstName: ['', [Validators.required]],
    lastName: ['', [Validators.required]],
    phoneNumber: ['']
  });
  
  user: User | null = null;
  loading = false;
  errorMessage = '';
  successMessage = '';
  
  ngOnInit(): void {
    this.loadProfile();
  }
  
  loadProfile(): void {
    const userJson = localStorage.getItem('user');
    if (userJson) {
      this.user = JSON.parse(userJson);
      if (this.user) {
        this.profileForm.patchValue(this.user);
      }
    } else {
      this.router.navigate(['/login']);
    }
  }
  
  onSubmit(): void {
    if (this.profileForm.invalid) {
      this.profileForm.markAllAsTouched();
      return;
    }
    
    this.loading = true;
    this.errorMessage = '';
    this.successMessage = '';
    
    const request = {
      firstName: this.profileForm.value.firstName,
      lastName: this.profileForm.value.lastName,
      phoneNumber: this.profileForm.value.phoneNumber
    };
    
    this.authService.updateProfile(request).subscribe({
      next: (updatedUser: User) => {
        this.user = updatedUser;
        localStorage.setItem('user', JSON.stringify(updatedUser));
        this.successMessage = 'Profile updated successfully!';
        this.loading = false;
        
        setTimeout(() => {
          this.successMessage = '';
        }, 3000);
      },
      error: (error: any) => {
        this.errorMessage = error.error?.message || 'Failed to update profile';
        this.loading = false;
      }
    });
  }
}
