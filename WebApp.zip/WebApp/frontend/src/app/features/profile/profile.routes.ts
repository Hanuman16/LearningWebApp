import { Routes } from '@angular/router';
import { ProfilePageComponent } from './profile-page/profile-page.component';
import { AddressManagementComponent } from './address-management/address-management.component';

export const profileRoutes: Routes = [
  {
    path: '',
    component: ProfilePageComponent
  },
  {
    path: 'addresses',
    component: AddressManagementComponent
  }
];
