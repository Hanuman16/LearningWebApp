import { Component, OnInit, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NgFor, NgIf, NgClass } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CartService } from '../../../core/services/cart.service';
import { Cart, CartItem, UpdateCartItemRequest, ApplyCouponRequest } from '../../../core/models/cart.model';

@Component({
  selector: 'app-cart-page',
  standalone: true,
  imports: [RouterLink, NgFor, NgIf, NgClass, FormsModule],
  template: `
    <div class="container mx-auto px-4 py-8">
      <h1 class="text-3xl font-bold mb-8">Shopping Cart</h1>
      
      <div *ngIf="cart && cart.items.length > 0" class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Cart Items -->
        <div class="lg:col-span-2">
          <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div *ngFor="let item of cart.items" class="p-4 border-b last:border-b-0">
              <div class="flex items-center gap-4">
                <img *ngIf="item.product?.images?.length" [src]="item.product!.images![0].url" [alt]="item.product?.name" class="w-20 h-20 object-cover rounded">
                <div *ngIf="!item.product?.images?.length" class="w-20 h-20 bg-gray-200 rounded flex items-center justify-center">
                  <span class="text-gray-400 text-xs">No Image</span>
                </div>
                
                <div class="flex-1">
                  <a [routerLink]="['/products', item.product?.slug]" class="text-lg font-semibold hover:text-primary">{{ item.product?.name }}</a>
                  <p class="text-gray-600">{{ item.unitPrice.toFixed(2) }} each</p>
                </div>
                
                <div class="flex items-center gap-2">
                  <button (click)="updateQuantity(item.id, item.quantity - 1)" class="bg-gray-200 px-2 py-1 rounded">-</button>
                  <span class="w-10 text-center">{{ item.quantity }}</span>
                  <button (click)="updateQuantity(item.id, item.quantity + 1)" class="bg-gray-200 px-2 py-1 rounded">+</button>
                </div>
                
                <div class="text-right min-w-20">
                  <p class="font-semibold">{{ item.subtotal.toFixed(2) }}</p>
                  <button (click)="removeItem(item.id)" class="text-red-500 text-sm hover:text-red-700">Remove</button>
                </div>
              </div>
            </div>
          </div>
          
          <div class="mt-4 flex justify-between">
            <a routerLink="/products" class="text-primary hover:underline">← Continue Shopping</a>
            <button (click)="clearCart()" class="text-red-500 hover:text-red-700">Clear Cart</button>
          </div>
        </div>
        
        <!-- Order Summary -->
        <div>
          <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold mb-4">Order Summary</h2>
            
            <div class="space-y-2 mb-4">
              <div class="flex justify-between">
                <span>Subtotal</span>
                <span>{{ cart.subtotal.toFixed(2) }}</span>
              </div>
              <div class="flex justify-between" *ngIf="cart.discountAmount > 0">
                <span>Discount</span>
                <span class="text-green-600">-{{ cart.discountAmount.toFixed(2) }}</span>
              </div>
              <div class="flex justify-between">
                <span>Shipping</span>
                <span>{{ cart.shippingAmount.toFixed(2) }}</span>
              </div>
              <div class="flex justify-between">
                <span>Tax</span>
                <span>{{ cart.taxAmount.toFixed(2) }}</span>
              </div>
              <div class="border-t pt-2 flex justify-between font-bold text-lg">
                <span>Total</span>
                <span>{{ cart.total.toFixed(2) }}</span>
              </div>
            </div>
            
            <!-- Coupon Code -->
            <div class="mb-4">
              <div class="flex gap-2">
                <input [(ngModel)]="couponCode" type="text" placeholder="Coupon code" class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                <button (click)="applyCoupon()" class="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700">Apply</button>
              </div>
              <p *ngIf="couponMessage" class="text-sm mt-1" [ngClass]="{'text-green-600': couponSuccess, 'text-red-600': !couponSuccess}">{{ couponMessage }}</p>
            </div>
            
            <a routerLink="/checkout" class="block w-full bg-primary text-white text-center py-3 px-6 rounded-lg hover:bg-primary-dark">
              Proceed to Checkout
            </a>
          </div>
        </div>
      </div>
      
      <div *ngIf="!cart || cart.items.length === 0" class="text-center py-12">
        <p class="text-gray-500 text-lg mb-4">Your cart is empty</p>
        <a routerLink="/products" class="inline-block bg-primary text-white px-6 py-3 rounded-lg hover:bg-primary-dark">
          Start Shopping
        </a>
      </div>
    </div>
  `,
  styles: []
})
export class CartPageComponent implements OnInit {
  private cartService = inject(CartService);
  
  cart: Cart | null = null;
  couponCode = '';
  couponMessage = '';
  couponSuccess = false;
  
  ngOnInit(): void {
    this.loadCart();
  }
  
  loadCart(): void {
    this.cartService.getCart().subscribe({
      next: (cart: Cart | null) => {
        this.cart = cart;
      },
      error: (error: any) => {
        console.error('Error loading cart:', error);
      }
    });
  }
  
  updateQuantity(itemId: string, quantity: number): void {
    if (quantity < 1) return;
    
    this.cartService.updateItem(itemId, { itemId, quantity }).subscribe({
      next: (cart: Cart | null) => {
        this.cart = cart;
      },
      error: (error: any) => {
        console.error('Error updating quantity:', error);
      }
    });
  }
  
  removeItem(itemId: string): void {
    this.cartService.removeItem(itemId).subscribe({
      next: (cart: Cart | null) => {
        this.cart = cart;
      },
      error: (error: any) => {
        console.error('Error removing item:', error);
      }
    });
  }
  
  clearCart(): void {
    this.cartService.clearCart().subscribe({
      next: () => {
        this.cart = null;
      },
      error: (error: any) => {
        console.error('Error clearing cart:', error);
      }
    });
  }
  
  applyCoupon(): void {
    if (!this.couponCode.trim()) return;
    
    this.cartService.applyCoupon({ couponCode: this.couponCode.trim() }).subscribe({
      next: (cart: Cart | null) => {
        this.cart = cart;
        this.couponMessage = 'Coupon applied successfully!';
        this.couponSuccess = true;
        this.couponCode = '';
      },
      error: (error: any) => {
        this.couponMessage = error.error?.message || 'Invalid coupon code';
        this.couponSuccess = false;
      }
    });
  }
}
