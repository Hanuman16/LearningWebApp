import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { NgFor, NgIf, NgClass, DatePipe } from '@angular/common';
import { ProductService } from '../../../core/services/product.service';
import { CartService } from '../../../core/services/cart.service';
import { ReviewService } from '../../../core/services/review.service';
import { Product } from '../../../core/models/product.model';
import { Review } from '../../../core/models/review.model';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [RouterLink, NgFor, NgIf, NgClass, DatePipe],
  template: `
    <div class="container mx-auto px-4 py-8" *ngIf="product">
      <nav class="mb-6">
        <a routerLink="/products" class="text-primary hover:underline">← Back to Products</a>
      </nav>
      
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <!-- Product Images -->
        <div>
          <div class="bg-gray-100 rounded-lg overflow-hidden">
            <img *ngIf="product.images && product.images.length > 0" [src]="product.images[currentImageIndex].url" [alt]="product.images[currentImageIndex].altText || product.name" class="w-full h-96 object-cover">
            <div *ngIf="!product.images || product.images.length === 0" class="w-full h-96 flex items-center justify-center bg-gray-200">
              <span class="text-gray-400">No Image Available</span>
            </div>
          </div>
          <div *ngIf="product.images && product.images.length > 1" class="flex gap-2 mt-4">
            <img *ngFor="let image of product.images; let i = index" [src]="image.url" [alt]="image.altText" class="w-20 h-20 object-cover rounded cursor-pointer border-2" [ngClass]="{'border-primary': i === currentImageIndex, 'border-transparent': i !== currentImageIndex}" (click)="currentImageIndex = i">
          </div>
        </div>
        
        <!-- Product Info -->
        <div>
          <h1 class="text-3xl font-bold mb-2">{{ product.name }}</h1>
          <p class="text-gray-600 mb-4">{{ product.description }}</p>
          
          <div class="mb-4">
            <span class="text-3xl font-bold text-primary">{{ product.price.toFixed(2) }}</span>
            <ng-container *ngIf="product.compareAtPrice && product.compareAtPrice > product.price">
              <span class="text-lg text-gray-500 line-through ml-2">{{ product.compareAtPrice.toFixed(2) }}</span>
              <span class="text-sm text-red-500 ml-2">Save \${{ (product.compareAtPrice - product.price).toFixed(2) }}</span>
            </ng-container>
          </div>
          
          <div class="mb-4">
            <span class="text-sm" [ngClass]="{'text-red-500': product.stockQuantity <= product.lowStockThreshold, 'text-green-600': product.stockQuantity > product.lowStockThreshold}">
              {{ product.stockQuantity > 0 ? (product.stockQuantity <= product.lowStockThreshold ? 'Low Stock - Order Soon' : 'In Stock') : 'Out of Stock' }}
            </span>
          </div>
          
          <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 mb-2">Quantity</label>
            <div class="flex items-center">
              <button (click)="decreaseQuantity()" class="bg-gray-200 px-3 py-2 rounded-l">-</button>
              <input type="number" [value]="quantity" (change)="onQuantityChange($event)" min="1" [max]="product.stockQuantity" class="w-16 text-center py-2 border-t border-b">
              <button (click)="increaseQuantity()" class="bg-gray-200 px-3 py-2 rounded-r">+</button>
            </div>
          </div>
          
          <button (click)="addToCart()" [disabled]="product.stockQuantity === 0" class="w-full bg-primary text-white py-3 px-6 rounded-lg hover:bg-primary-dark disabled:bg-gray-400 mb-4">
            Add to Cart
          </button>
          
          <div class="border-t pt-4">
            <p class="text-sm text-gray-600"><span class="font-semibold">SKU:</span> {{ product.sku }}</p>
            <p class="text-sm text-gray-600"><span class="font-semibold">Category:</span> {{ product.category?.name }}</p>
          </div>
        </div>
      </div>
      
      <!-- Reviews Section -->
      <div class="mt-12">
        <h2 class="text-2xl font-bold mb-6">Customer Reviews</h2>
        <div *ngIf="reviews.length > 0">
          <div *ngFor="let review of reviews" class="border-b pb-4 mb-4">
            <div class="flex items-center justify-between">
              <div>
                <span class="font-semibold">{{ review.userName || 'Anonymous' }}</span>
                <span class="text-yellow-500 ml-2" *ngIf="review.rating">{{ '★'.repeat(review.rating) }}{{ '☆'.repeat(5 - review.rating) }}</span>
              </div>
              <span class="text-sm text-gray-500">{{ review.createdAt | date:'mediumDate' }}</span>
            </div>
            <h3 class="font-semibold mt-2">{{ review.title }}</h3>
            <p class="text-gray-600 mt-1">{{ review.comment }}</p>
          </div>
        </div>
        <div *ngIf="reviews.length === 0" class="text-center py-8">
          <p class="text-gray-500">No reviews yet. Be the first to review this product!</p>
        </div>
      </div>
    </div>
  `,
  styles: []
})
export class ProductDetailComponent implements OnInit {
  private activatedRoute = inject(ActivatedRoute);
  private productService = inject(ProductService);
  private cartService = inject(CartService);
  private reviewService = inject(ReviewService);
  
  product: Product | null = null;
  reviews: Review[] = [];
  quantity = 1;
  currentImageIndex = 0;
  
  ngOnInit(): void {
    const slug = this.activatedRoute.snapshot.paramMap.get('slug');
    if (slug) {
      // Backend returns plain array, not PagedResponse
      this.productService.getAll(1, 100).subscribe({
        next: (response: any) => {
          // Handle both array response and PagedResponse format
          const products = Array.isArray(response) ? response : (response.items || response.data || []);
          this.product = products.find((p: Product) => p.slug === slug) || null;
          // Load reviews once product is found
          if (this.product) {
            this.reviewService.getProductReviews(this.product.id).subscribe({
              next: (reviews) => {
                this.reviews = reviews;
              },
              error: (err) => {
                console.error('Error loading reviews:', err);
                this.reviews = [];
              }
            });
          }
        },
        error: (err) => {
          console.error('Error loading product:', err);
        }
      });
    }
  }
  
  addToCart(): void {
    if (this.product) {
      this.cartService.addItem({
        productId: this.product.id,
        quantity: this.quantity
      }).subscribe({
        next: (cart) => {
          console.log('Added to cart:', cart);
          alert(`Added ${this.quantity} x ${this.product?.name} to cart!`);
        },
        error: (err) => {
          console.error('Error adding to cart:', err);
          alert('Failed to add item to cart');
        }
      });
    }
  }
  
  increaseQuantity(): void {
    if (this.product && this.quantity < this.product.stockQuantity) {
      this.quantity++;
    }
  }
  
  decreaseQuantity(): void {
    if (this.quantity > 1) {
      this.quantity--;
    }
  }
  
  onQuantityChange(event: Event): void {
    const value = parseInt((event.target as HTMLInputElement).value, 10);
    if (!isNaN(value) && value > 0 && this.product) {
      this.quantity = Math.min(value, this.product.stockQuantity);
    }
  }
}
