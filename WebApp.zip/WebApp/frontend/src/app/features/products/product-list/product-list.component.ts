import { Component, OnInit, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { NgFor, NgIf } from '@angular/common';
import { ProductService } from '../../../core/services/product.service';
import { Product, ProductSearchParams } from '../../../core/models/product.model';
import { ProductCardComponent } from '../../../shared/components/product-card/product-card.component';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink, NgFor, NgIf, ProductCardComponent],
  template: `
    <div class="container mx-auto px-4 py-8">
      <h1 class="text-3xl font-bold mb-8">Products</h1>
      
      <div class="flex flex-col lg:flex-row gap-8">
        <!-- Filters Sidebar -->
        <aside class="lg:w-1/4">
          <div class="bg-white p-6 rounded-lg shadow-md">
            <h2 class="text-xl font-semibold mb-4">Filters</h2>
            
            <form [formGroup]="filterForm">
              <!-- Search -->
              <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Search</label>
                <input formControlName="searchQuery" type="text" placeholder="Search products..." 
                  class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
              </div>
              
              <!-- Category -->
              <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select formControlName="categoryId" 
                  class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                  <option value="">All Categories</option>
                </select>
              </div>
              
              <!-- Price Range -->
              <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Price Range</label>
                <div class="flex gap-2">
                  <input formControlName="minPrice" type="number" placeholder="Min" 
                    class="w-1/2 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                  <input formControlName="maxPrice" type="number" placeholder="Max" 
                    class="w-1/2 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                </div>
              </div>
              
              <!-- Sort By -->
              <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Sort By</label>
                <select formControlName="sortBy" (change)="onSortChange()"
                  class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary">
                  <option value="newest">Newest</option>
                  <option value="price">Price: Low to High</option>
                  <option value="price">Price: High to Low</option>
                  <option value="name">Name: A to Z</option>
                  <option value="popularity">Popularity</option>
                </select>
              </div>
              
              <button (click)="applyFilters()" type="button"
                class="w-full bg-primary text-white py-2 px-4 rounded-md hover:bg-primary-dark">
                Apply Filters
              </button>
            </form>
          </div>
        </aside>
        
        <!-- Products Grid -->
        <main class="lg:w-3/4">
          <div *ngIf="products.length > 0" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <app-product-card *ngFor="let product of products" [product]="product"></app-product-card>
          </div>
          
          <div *ngIf="products.length === 0 && !loading" class="text-center py-12">
            <p class="text-gray-500 text-lg">No products found.</p>
          </div>
          
          <div *ngIf="loading" class="text-center py-12">
            <p class="text-gray-500 text-lg">Loading products...</p>
          </div>
          
          <!-- Pagination -->
          <div *ngIf="totalPages > 1" class="flex justify-center mt-8 space-x-2">
            <button (click)="previousPage()" [disabled]="pageNumber === 1"
              class="px-4 py-2 border border-gray-300 rounded-md disabled:opacity-50">Previous</button>
            <span class="px-4 py-2">Page {{ pageNumber }} of {{ totalPages }}</span>
            <button (click)="nextPage()" [disabled]="pageNumber === totalPages"
              class="px-4 py-2 border border-gray-300 rounded-md disabled:opacity-50">Next</button>
          </div>
        </main>
      </div>
    </div>
  `,
  styles: []
})
export class ProductListComponent implements OnInit {
  private fb = inject(FormBuilder);
  private productService = inject(ProductService);
  private route = inject(ActivatedRoute);
  
  filterForm: FormGroup = this.fb.group({
    searchQuery: [''],
    categoryId: [''],
    minPrice: [null],
    maxPrice: [null],
    sortBy: ['newest']
  });
  
  products: Product[] = [];
  loading = false;
  pageNumber = 1;
  pageSize = 12;
  totalPages = 1;
  totalCount = 0;
  
  ngOnInit(): void {
    // Read category from URL query params
    this.route.queryParams.subscribe(params => {
      const categorySlug = params['category'];
      if (categorySlug) {
        // Get all categories and find the matching one
        this.productService.getCategories().subscribe(categories => {
          const category = categories.find(c => c.slug?.toLowerCase() === categorySlug.toLowerCase());
          if (category) {
            this.filterForm.patchValue({ categoryId: category.id });
          }
        });
      }
    });
    this.loadProducts();
  }
  
  loadProducts(): void {
    this.loading = true;
    const params: ProductSearchParams = {
      searchQuery: this.filterForm.value.searchQuery || undefined,
      categoryId: this.filterForm.value.categoryId || undefined,
      minPrice: this.filterForm.value.minPrice || undefined,
      maxPrice: this.filterForm.value.maxPrice || undefined,
      sortBy: this.filterForm.value.sortBy as any || undefined,
      sortOrder: 'asc',
      pageNumber: this.pageNumber,
      pageSize: this.pageSize
    };
    
    this.productService.getAll(
      this.pageNumber,
      this.pageSize,
      undefined,
      this.filterForm.value.categoryId || undefined
    ).subscribe({
      next: (response: any) => {
        this.products = response.items;
        this.totalCount = response.totalCount;
        this.totalPages = Math.ceil(this.totalCount / this.pageSize);
        this.loading = false;
      },
      error: (error: any) => {
        console.error('Error loading products:', error);
        this.loading = false;
      }
    });
  }
  
  applyFilters(): void {
    this.pageNumber = 1;
    this.loadProducts();
  }
  
  onSortChange(): void {
    this.loadProducts();
  }
  
  previousPage(): void {
    if (this.pageNumber > 1) {
      this.pageNumber--;
      this.loadProducts();
    }
  }
  
  nextPage(): void {
    if (this.pageNumber < this.totalPages) {
      this.pageNumber++;
      this.loadProducts();
    }
  }
}
