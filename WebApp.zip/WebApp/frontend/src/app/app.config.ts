import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideStore, ActionReducerMap } from '@ngrx/store';
import { provideStoreDevtools } from '@ngrx/store-devtools';
import { provideEffects } from '@ngrx/effects';
import { provideAnimations } from '@angular/platform-browser/animations';
import { routes } from './app.routes';
import { authInterceptor } from './core/interceptors/auth.interceptor';
import { errorInterceptor } from './core/interceptors/error.interceptor';
import { reducers, AppState } from './core/store/root-store';
import { AuthEffects } from './core/store/effects/auth.effects';
import { ProductEffects } from './core/store/effects/product.effects';
import { CartEffects } from './core/store/effects/cart.effects';
import { CookieConsentComponent } from './shared/components/cookie-consent/cookie-consent.component';
import { MobileMenuComponent } from './shared/components/mobile-menu/mobile-menu.component';
import { ToastComponent } from './shared/components/toast/toast.component';

/**
 * ╔═══════════════════════════════════════════════════════════╗
 * ║  APPLICATION CONFIGURATION                               ║
 * ╚═══════════════════════════════════════════════════════════╝
 * 
 * CONCEPTS IMPLEMENTED:
 * ─────────────────────
 * 
 * 1. DEPENDENCY INJECTION (DI)
 *    - provideRouter: Routes configuration for navigation
 *    - provideHttpClient: HTTP client with interceptors
 *    - provideStore: ngrx state management
 *    - provideEffects: RxJS effects for side effects
 *    - provideAnimations: Angular Material animations
 * 
 * 2. INTERCEPTOR PATTERN
 *    - authInterceptor: Adds JWT token to requests
 *    - errorInterceptor: Handles HTTP errors globally
 * 
 * 3. STATE MANAGEMENT
 *    - ngrx Store: Centralized state
 *    - Effects: Side effects (API calls)
 *    - DevTools: Debugging in development
 */
export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(withInterceptors([authInterceptor, errorInterceptor])),
    provideStore(reducers as ActionReducerMap<AppState>),
    provideStoreDevtools({ maxAge: 25, logOnly: false }),
    provideEffects(AuthEffects, ProductEffects, CartEffects),
    provideAnimations(),
    
    /**
     * DECLARATIVE COMPONENTS
     * WHY: These components are used in app.component.html
     * NOTE: In Angular 17+, standalone components don't need to be declared
     * They just need to be imported where used
     */
    CookieConsentComponent,
    MobileMenuComponent,
    ToastComponent
  ]
};
