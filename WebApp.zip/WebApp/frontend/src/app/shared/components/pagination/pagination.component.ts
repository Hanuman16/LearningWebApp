import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { NgIf, NgFor } from '@angular/common';

@Component({
  selector: 'app-pagination',
  standalone: true,
  imports: [NgIf, NgFor],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div *ngIf="totalItems > pageSize" class="flex justify-center items-center gap-2 mt-6">
      <button
        (click)="previousPage()"
        [disabled]="currentPage === 1"
        class="px-3 py-2 rounded-md border border-gray-300 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50">
        Previous
      </button>
      
      <button
        *ngFor="let page of pages"
        (click)="pageChanged.emit(page)"
        [class.bg-primary]="page === currentPage"
        [class.text-white]="page === currentPage"
        [class.bg-transparent]="page !== currentPage"
        class="px-3 py-2 rounded-md border border-gray-300 hover:bg-gray-50 min-w-[2.5rem] text-center">
        {{ page }}
      </button>
      
      <button
        (click)="nextPage()"
        [disabled]="currentPage === totalPages"
        class="px-3 py-2 rounded-md border border-gray-300 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50">
        Next
      </button>
    </div>
  `,
  styles: []
})
export class PaginationComponent {
  @Input() totalItems: number = 0;
  @Input() pageSize: number = 10;
  @Input() currentPage: number = 1;
  @Output() pageChanged = new EventEmitter<number>();
  
  @Output() pageChange = new EventEmitter<number>();
  
  get totalPages(): number {
    return Math.ceil(this.totalItems / this.pageSize);
  }
  
  get pages(): number[] {
    const pages: number[] = [];
    for (let i = 1; i <= this.totalPages; i++) {
      pages.push(i);
    }
    return pages;
  }
  
  previousPage(): void {
    if (this.currentPage > 1) {
      this.pageChanged.emit(this.currentPage - 1);
    }
  }
  
  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.pageChanged.emit(this.currentPage + 1);
    }
  }
}
