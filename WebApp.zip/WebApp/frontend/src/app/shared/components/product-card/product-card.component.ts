import { Component, Input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Product } from '../../../core/models/product.model';
import { NgIf, NgClass } from '@angular/common';

@Component({
  selector: 'app-product-card',
  standalone: true,
  imports: [RouterLink, NgIf, NgClass],
  template: `
    <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <a [routerLink]="['/products', product.slug]" class="block">
        <div class="aspect-w-1 aspect-h-1 w-full overflow-hidden bg-gray-200">
          <img 
            *ngIf="product.images && product.images.length > 0"
            [src]="product.images[0].url" 
            [alt]="product.images[0].altText || product.name"
            class="w-full h-48 object-cover"
          />
          <div *ngIf="!product.images || product.images.length === 0" class="w-full h-48 flex items-center justify-center bg-gray-200">
            <span class="text-gray-400">No Image</span>
          </div>
        </div>
      </a>
      
      <div class="p-4">
        <a [routerLink]="['/products', product.slug]" class="block">
          <h3 class="text-lg font-semibold text-gray-900 hover:text-primary truncate">{{ product.name }}</h3>
        </a>
        
        <p class="text-sm text-gray-600 mt-1 line-clamp-2">{{ product.description }}</p>
        
        <div class="mt-2 flex items-center justify-between">
          <span class="text-xl font-bold text-primary">{{ product.price.toFixed(2) }}</span>
          <ng-container *ngIf="product.compareAtPrice && product.compareAtPrice > product.price">
            <span class="text-sm text-gray-500 line-through">{{ product.compareAtPrice.toFixed(2) }}</span>
            <span class="text-xs text-red-500 ml-2">Sale</span>
          </ng-container>
        </div>
        
        <div class="mt-2 flex items-center justify-between">
          <span class="text-sm text-gray-600" [ngClass]="{'text-red-500': product.stockQuantity <= product.lowStockThreshold, 'text-green-600': product.stockQuantity > product.lowStockThreshold}">
            {{ product.stockQuantity > 0 ? (product.stockQuantity <= product.lowStockThreshold ? 'Low Stock' : 'In Stock') : 'Out of Stock' }}
          </span>
        </div>
        
        <button 
          class="mt-3 w-full bg-primary text-white py-2 px-4 rounded hover:bg-primary-dark disabled:bg-gray-400"
          [disabled]="product.stockQuantity === 0"
          (click)="addToCart()"
        >
          Add to Cart
        </button>
      </div>
    </div>
  `,
  styles: []
})
export class ProductCardComponent {
  @Input() product!: Product;

  addToCart(): void {
    // TODO: Implement add to cart logic
  }
}
