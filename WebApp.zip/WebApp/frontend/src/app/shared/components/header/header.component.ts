import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterLink, NgIf],
  template: `
    <header class="bg-white shadow-md">
      <nav class="container mx-auto px-4 py-3">
        <div class="flex justify-between items-center">
          <a routerLink="/" class="text-2xl font-bold text-primary">E-Commerce</a>
          
          <div class="flex items-center space-x-4">
            <a routerLink="/" class="text-gray-700 hover:text-primary">Home</a>
            <a routerLink="/products" class="text-gray-700 hover:text-primary">Products</a>
            <a routerLink="/cart" class="text-gray-700 hover:text-primary relative">
              Cart
              <span class="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">0</span>
            </a>
            <a routerLink="/orders" class="text-gray-700 hover:text-primary">Orders</a>
            <a routerLink="/profile" class="text-gray-700 hover:text-primary">Profile</a>
            <a routerLink="/admin" class="text-gray-700 hover:text-primary" *ngIf="isAdmin">Admin</a>
            <button *ngIf="isAuthenticated" (click)="logout()" class="text-red-600 hover:text-red-800">Logout</button>
            <a routerLink="/login" *ngIf="!isAuthenticated" class="text-gray-700 hover:text-primary">Login</a>
            <a routerLink="/register" *ngIf="!isAuthenticated" class="bg-primary text-white px-4 py-2 rounded hover:bg-primary-dark">Register</a>
          </div>
        </div>
      </nav>
    </header>
  `,
  styles: []
})
export class HeaderComponent {
  isAuthenticated = false;
  isAdmin = false;

  logout(): void {
    // TODO: Implement logout logic
  }
}
