import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

/**
 * ╔═══════════════════════════════════════════════════════════╗
 * ║  FOOTER COMPONENT - Site Footer with Working Links       ║
 * ╚═══════════════════════════════════════════════════════════╝
 * 
 * CONCEPTS IMPLEMENTED:
 * ─────────────────────
 * 
 * 1. UX ENHANCEMENT (Navigation)
 *    - Footer provides site-wide navigation
 *    - Quick links to important pages (About, Contact, Privacy, Terms)
 *    - Social media links for brand engagement
 *    - Copyright notice with dynamic year
 * 
 * 2. ACCESSIBILITY (a11y)
 *    - Semantic HTML <footer> element
 *    - Proper heading hierarchy (h3 for sections)
 *    - Link text is descriptive (not "click here")
 *    - Keyboard navigable
 * 
 * 3. RESPONSIVE DESIGN
 *    - Grid layout: 1 column on mobile, 4 columns on desktop
 *    - Tailwind CSS responsive classes (grid-cols-1 md:grid-cols-4)
 *    - Touch-friendly tap targets
 * 
 * 4. SEO (Search Engine Optimization)
 *    - Internal linking improves site structure
 *    - Helps search engines discover important pages
 *    - Better user experience reduces bounce rate
 * 
 * 5. SOLID PRINCIPLES:
 *    - SRP: Component only renders footer UI
 *    - ISP: Focused interface for footer navigation
 *    - DIP: Uses RouterLink (Angular's abstraction)
 */
@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [RouterLink],
  template: `
    <footer class="bg-gray-800 text-white mt-auto" role="contentinfo">
      <div class="container mx-auto px-4 py-8">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
          <!-- Company Info -->
          <div>
            <h3 class="text-lg font-semibold mb-4">E-Commerce</h3>
            <p class="text-gray-400 mb-4">
              Your trusted online shopping destination for quality products at great prices.
            </p>
            <!-- Social Media Links -->
            <div class="flex space-x-4">
              <a 
                href="https://facebook.com" 
                target="_blank" 
                rel="noopener noreferrer"
                class="text-gray-400 hover:text-white transition-colors"
                aria-label="Follow us on Facebook"
              >
                Facebook
              </a>
              <a 
                href="https://twitter.com" 
                target="_blank" 
                rel="noopener noreferrer"
                class="text-gray-400 hover:text-white transition-colors"
                aria-label="Follow us on Twitter"
              >
                Twitter
              </a>
              <a 
                href="https://instagram.com" 
                target="_blank" 
                rel="noopener noreferrer"
                class="text-gray-400 hover:text-white transition-colors"
                aria-label="Follow us on Instagram"
              >
                Instagram
              </a>
              <a 
                href="https://linkedin.com" 
                target="_blank" 
                rel="noopener noreferrer"
                class="text-gray-400 hover:text-white transition-colors"
                aria-label="Follow us on LinkedIn"
              >
                LinkedIn
              </a>
            </div>
          </div>

          <!-- Quick Links -->
          <div>
            <h3 class="text-lg font-semibold mb-4">Quick Links</h3>
            <ul class="space-y-2">
              <li>
                <a routerLink="/" class="text-gray-400 hover:text-white transition-colors">Home</a>
              </li>
              <li>
                <a routerLink="/products" class="text-gray-400 hover:text-white transition-colors">Products</a>
              </li>
              <li>
                <a routerLink="/cart" class="text-gray-400 hover:text-white transition-colors">Shopping Cart</a>
              </li>
              <li>
                <a routerLink="/orders" class="text-gray-400 hover:text-white transition-colors" *ngIf="isLoggedIn">My Orders</a>
              </li>
            </ul>
          </div>

          <!-- Customer Service -->
          <div>
            <h3 class="text-lg font-semibold mb-4">Customer Service</h3>
            <ul class="space-y-2">
              <li>
                <a routerLink="/contact" class="text-gray-400 hover:text-white transition-colors">Contact Us</a>
              </li>
              <li>
                <a routerLink="/faq" class="text-gray-400 hover:text-white transition-colors">FAQs</a>
              </li>
              <li>
                <a routerLink="/shipping" class="text-gray-400 hover:text-white transition-colors">Shipping Info</a>
              </li>
              <li>
                <a routerLink="/returns" class="text-gray-400 hover:text-white transition-colors">Returns Policy</a>
              </li>
            </ul>
          </div>

          <!-- Legal -->
          <div>
            <h3 class="text-lg font-semibold mb-4">Legal</h3>
            <ul class="space-y-2">
              <li>
                <a routerLink="/privacy-policy" class="text-gray-400 hover:text-white transition-colors">Privacy Policy</a>
              </li>
              <li>
                <a routerLink="/terms-conditions" class="text-gray-400 hover:text-white transition-colors">Terms & Conditions</a>
              </li>
              <li>
                <a routerLink="/cookie-policy" class="text-gray-400 hover:text-white transition-colors">Cookie Policy</a>
              </li>
            </ul>
          </div>
        </div>

        <!-- Copyright -->
        <div class="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; {{currentYear}} E-Commerce Store. All rights reserved.</p>
        </div>
      </div>
    </footer>
  `,
  styles: []
})
export class FooterComponent {
  /**
   * Current year for copyright notice
   * WHY: Automatically updates each year (no manual maintenance)
   */
  currentYear: number = new Date().getFullYear();
  
  /**
   * Check if user is logged in
   * WHY: Show/hide user-specific links
   */
  isLoggedIn: boolean = false;

  constructor() {
    // Implement auth check based on your auth service
    // this.authService.isAuthenticated$.subscribe(auth => this.isLoggedIn = auth);
  }
}
