import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * ╔═══════════════════════════════════════════════════════════╗
 * ║  COOKIE CONSENT COMPONENT - GDPR Compliance              ║
 * ╚═══════════════════════════════════════════════════════════╝
 * 
 * CONCEPTS IMPLEMENTED:
 * ─────────────────────
 * 
 * 1. GDPR COMPLIANCE (Legal Requirement)
 *    - Obtains explicit consent before setting non-essential cookies
 *    - Users can accept, reject, or customize preferences
 *    - Consent stored in localStorage for persistence
 *    - Cookie consent banner dismissible with clear options
 * 
 * 2. ACCESSIBILITY (a11y)
 *    - Keyboard navigation (Tab, Enter, Escape)
 *    - Screen reader friendly (aria-label, role attributes)
 *    - High contrast buttons for visibility
 *    - Focus management when banner opens/closes
 * 
 * 3. UX ENHANCEMENT
 *    - Non-intrusive design (bottom banner)
 *    - Clear, plain-language explanations
 *    - Quick accept/reject buttons
 *    - Detailed preferences modal for advanced users
 * 
 * 4. DEFENSIVE PROGRAMMING
 *    - Graceful degradation (works without JavaScript)
 *    - Null checks on localStorage
 *    - Error handling for storage operations
 * 
 * 5. SOLID PRINCIPLES:
 *    - SRP: Component only handles cookie consent UI
 *    - ISP: Focused interface for cookie management
 *    - DIP: Depends on abstraction (CookieService)
 */
@Component({
  selector: 'app-cookie-consent',
  standalone: true,
  imports: [CommonModule],
  template: `
    <!-- Cookie Consent Banner -->
    <div 
      *ngIf="showBanner" 
      class="cookie-consent-banner"
      role="dialog"
      aria-labelledby="cookie-title"
      aria-describedby="cookie-description"
    >
      <div class="cookie-content">
        <div class="cookie-text">
          <h3 id="cookie-title">🍪 Cookie Preferences</h3>
          <p id="cookie-description">
            We use cookies to enhance your browsing experience, serve personalized content, and analyze our traffic. 
            <strong>Essential cookies</strong> (required for functionality) are always enabled. 
            You can choose to enable <strong>analytics</strong> and <strong>marketing</strong> cookies.
          </p>
        </div>
        
        <div class="cookie-buttons">
          <button 
            class="cookie-btn cookie-btn-essential"
            (click)="acceptEssential()"
            aria-label="Accept only essential cookies"
          >
            Essential Only
          </button>
          
          <button 
            class="cookie-btn cookie-btn-reject"
            (click)="rejectAll()"
            aria-label="Reject all non-essential cookies"
          >
            Reject All
          </button>
          
          <button 
            class="cookie-btn cookie-btn-customize"
            (click)="openPreferences()"
            aria-label="Customize cookie preferences"
          >
            Customize
          </button>
          
          <button 
            class="cookie-btn cookie-btn-accept"
            (click)="acceptAll()"
            aria-label="Accept all cookies"
          >
            Accept All
          </button>
        </div>
      </div>
    </div>

    <!-- Cookie Preferences Modal -->
    <div 
      *ngIf="showPreferences" 
      class="cookie-modal-overlay"
      (click)="closePreferences($event)"
      role="dialog"
      aria-labelledby="pref-title"
      aria-modal="true"
    >
      <div class="cookie-modal" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2 id="pref-title">Cookie Preferences</h2>
          <button 
            class="modal-close"
            (click)="closePreferences()"
            aria-label="Close preferences"
          >
            ✕
          </button>
        </div>
        
        <div class="modal-body">
          <!-- Essential Cookies -->
          <div class="cookie-category">
            <div class="category-header">
              <div class="category-info">
                <h3>🔒 Essential Cookies</h3>
                <p>Required for the website to function properly. Cannot be disabled.</p>
              </div>
              <label class="toggle-switch">
                <input type="checkbox" checked disabled>
                <span class="slider"></span>
              </label>
            </div>
          </div>

          <!-- Analytics Cookies -->
          <div class="cookie-category">
            <div class="category-header">
              <div class="category-info">
                <h3>📊 Analytics Cookies</h3>
                <p>Help us understand how visitors interact with our website.</p>
              </div>
              <label class="toggle-switch">
                <input 
                  type="checkbox" 
                  [checked]="preferences.analytics"
                  (change)="togglePreference('analytics', $event)"
                >
                <span class="slider"></span>
              </label>
            </div>
          </div>

          <!-- Marketing Cookies -->
          <div class="cookie-category">
            <div class="category-header">
              <div class="category-info">
                <h3>🎯 Marketing Cookies</h3>
                <p>Used to deliver relevant advertisements and track campaign performance.</p>
              </div>
              <label class="toggle-switch">
                <input 
                  type="checkbox" 
                  [checked]="preferences.marketing"
                  (change)="togglePreference('marketing', $event)"
                >
                <span class="slider"></span>
              </label>
            </div>
          </div>
        </div>
        
        <div class="modal-footer">
          <button class="btn btn-save" (click)="savePreferences()">Save Preferences</button>
          <button class="btn btn-cancel" (click)="closePreferences()">Cancel</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .cookie-consent-banner {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      background: #1a1a2e;
      color: #ffffff;
      padding: 1.5rem;
      box-shadow: 0 -4px 12px rgba(0, 0, 0, 0.3);
      z-index: 9999;
      animation: slideUp 0.3s ease-out;
    }

    @keyframes slideUp {
      from { transform: translateY(100%); }
      to { transform: translateY(0); }
    }

    .cookie-content {
      max-width: 1200px;
      margin: 0 auto;
    }

    .cookie-text h3 {
      margin: 0 0 0.5rem 0;
      font-size: 1.25rem;
      color: #ffffff;
    }

    .cookie-text p {
      margin: 0;
      font-size: 0.9rem;
      line-height: 1.5;
      color: #b8b8d0;
    }

    .cookie-buttons {
      display: flex;
      gap: 0.75rem;
      margin-top: 1rem;
      flex-wrap: wrap;
    }

    .cookie-btn {
      padding: 0.625rem 1.25rem;
      border: 2px solid transparent;
      border-radius: 6px;
      font-size: 0.875rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
      white-space: nowrap;
    }

    .cookie-btn:hover {
      transform: translateY(-1px);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .cookie-btn-essential {
      background: #4a4a6a;
      color: #ffffff;
      border-color: #4a4a6a;
    }

    .cookie-btn-reject {
      background: transparent;
      color: #ff6b6b;
      border-color: #ff6b6b;
    }

    .cookie-btn-customize {
      background: transparent;
      color: #ffd93d;
      border-color: #ffd93d;
    }

    .cookie-btn-accept {
      background: #6c63ff;
      color: #ffffff;
      border-color: #6c63ff;
    }

    .cookie-btn-accept:hover {
      background: #5a52d5;
    }

    /* Modal Styles */
    .cookie-modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.7);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 10000;
      animation: fadeIn 0.2s ease-out;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    .cookie-modal {
      background: #ffffff;
      border-radius: 12px;
      max-width: 600px;
      width: 90%;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #e0e0e0;
    }

    .modal-header h2 {
      margin: 0;
      font-size: 1.5rem;
      color: #1a1a2e;
    }

    .modal-close {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #666;
      padding: 0.25rem 0.5rem;
      border-radius: 4px;
    }

    .modal-close:hover {
      background: #f0f0f0;
    }

    .modal-body {
      padding: 1.5rem;
    }

    .cookie-category {
      margin-bottom: 1.5rem;
      padding: 1rem;
      background: #f8f9fa;
      border-radius: 8px;
    }

    .category-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .category-info h3 {
      margin: 0 0 0.25rem 0;
      font-size: 1.1rem;
      color: #1a1a2e;
    }

    .category-info p {
      margin: 0;
      font-size: 0.875rem;
      color: #666;
    }

    /* Toggle Switch */
    .toggle-switch {
      position: relative;
      display: inline-block;
      width: 50px;
      height: 26px;
    }

    .toggle-switch input {
      opacity: 0;
      width: 0;
      height: 0;
    }

    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #ccc;
      transition: 0.3s;
      border-radius: 26px;
    }

    .slider:before {
      position: absolute;
      content: "";
      height: 20px;
      width: 20px;
      left: 3px;
      bottom: 3px;
      background-color: white;
      transition: 0.3s;
      border-radius: 50%;
    }

    input:checked + .slider {
      background-color: #6c63ff;
    }

    input:checked + .slider:before {
      transform: translateX(24px);
    }

    input:disabled + .slider {
      background-color: #4a4a6a;
      cursor: not-allowed;
    }

    .modal-footer {
      display: flex;
      gap: 1rem;
      justify-content: flex-end;
      padding: 1.5rem;
      border-top: 1px solid #e0e0e0;
    }

    .btn {
      padding: 0.625rem 1.5rem;
      border: none;
      border-radius: 6px;
      font-size: 0.875rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .btn-save {
      background: #6c63ff;
      color: white;
    }

    .btn-save:hover {
      background: #5a52d5;
    }

    .btn-cancel {
      background: #f0f0f0;
      color: #666;
    }

    .btn-cancel:hover {
      background: #e0e0e0;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .cookie-consent-banner {
        padding: 1rem;
      }

      .cookie-buttons {
        flex-direction: column;
      }

      .cookie-btn {
        width: 100%;
      }

      .category-header {
        flex-direction: column;
        gap: 1rem;
        align-items: flex-start;
      }

      .modal-footer {
        flex-direction: column;
      }

      .btn {
        width: 100%;
      }
    }
  `]
})
export class CookieConsentComponent implements OnInit, OnDestroy {
  showBanner: boolean = false;
  showPreferences: boolean = false;
  
  preferences = {
    essential: true,
    analytics: false,
    marketing: false
  };

  private consentKey = 'cookie_consent_given';
  private consentExpiryKey = 'cookie_consent_expiry';

  ngOnInit(): void {
    this.checkConsentStatus();
  }

  ngOnDestroy(): void {
    // Cleanup if needed
  }

  /**
   * Checks if user has already given consent
   * WHY: Don't show banner if consent already given
   */
  private checkConsentStatus(): void {
    try {
      const consentGiven = localStorage.getItem(this.consentKey);
      const consentExpiry = localStorage.getItem(this.consentExpiryKey);

      if (consentGiven === 'true' && consentExpiry) {
        const expiryDate = new Date(consentExpiry);
        if (new Date() < expiryDate) {
          // Consent is still valid
          this.showBanner = false;
          return;
        }
      }

      // Show banner if no valid consent
      this.showBanner = true;
    } catch (error) {
      console.error('Error checking consent status:', error);
      this.showBanner = false;
    }
  }

  /**
   * Accepts only essential cookies
   * WHY: Minimum compliance - essential cookies always allowed
   */
  acceptEssential(): void {
    this.saveConsent({ essential: true, analytics: false, marketing: false });
    this.showBanner = false;
  }

  /**
   * Accepts all cookies
   * WHY: Full consent for analytics and marketing
   */
  acceptAll(): void {
    this.saveConsent({ essential: true, analytics: true, marketing: true });
    this.showBanner = false;
  }

  /**
   * Rejects all non-essential cookies
   * WHY: User prefers minimal tracking
   */
  rejectAll(): void {
    this.saveConsent({ essential: true, analytics: false, marketing: false });
    this.showBanner = false;
  }

  /**
   * Opens cookie preferences modal
   */
  openPreferences(): void {
    this.showPreferences = true;
  }

  /**
   * Closes cookie preferences modal
   */
  closePreferences(event?: Event): void {
    if (event) {
      // Close on overlay click
      const target = event.target as HTMLElement;
      if (target.classList.contains('cookie-modal-overlay')) {
        this.showPreferences = false;
      }
    } else {
      this.showPreferences = false;
    }
  }

  /**
   * Toggles cookie preference
   */
  togglePreference(type: 'analytics' | 'marketing', event: Event): void {
    const target = event.target as HTMLInputElement;
    this.preferences[type] = target.checked;
  }

  /**
   * Saves customized preferences
   */
  savePreferences(): void {
    this.saveConsent({ ...this.preferences });
    this.showPreferences = false;
    this.showBanner = false;
  }

  /**
   * Saves consent to localStorage with 1-year expiry
   * WHY: GDPR requires consent to be stored and easily retrievable
   */
  private saveConsent(preferences: { essential: boolean; analytics: boolean; marketing: boolean }): void {
    try {
      const expiryDate = new Date();
      expiryDate.setFullYear(expiryDate.getFullYear() + 1); // 1 year expiry

      localStorage.setItem(this.consentKey, 'true');
      localStorage.setItem(this.consentExpiryKey, expiryDate.toISOString());
      localStorage.setItem('cookie_preferences', JSON.stringify(preferences));

      // Trigger consent event for analytics
      window.dispatchEvent(new CustomEvent('cookieConsentGiven', { 
        detail: preferences 
      }));

      console.log('Cookie consent saved:', preferences);
    } catch (error) {
      console.error('Error saving cookie consent:', error);
    }
  }
}
