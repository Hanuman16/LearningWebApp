import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';

/**
 * ╔═══════════════════════════════════════════════════════════╗
 * ║  NOT FOUND COMPONENT - Custom 404 Page                   ║
 * ╚═══════════════════════════════════════════════════════════╝
 * 
 * CONCEPTS IMPLEMENTED:
 * ─────────────────────
 * 
 * 1. UX ENHANCEMENT (User Experience)
 *    - Friendly error message (not technical jargon)
 *    - Search functionality to find products
 *    - Quick links to popular pages
 *    - Back to homepage button
 *    - Responsive design for mobile devices
 * 
 * 2. SEO OPTIMIZATION
 *    - Custom 404 page improves SEO (Google prefers custom 404)
 *    - Meta description for search engines
 *    - Internal links help crawlers discover pages
 * 
 * 3. ACCESSIBILITY (a11y)
 *    - Semantic HTML structure
 *    - Keyboard navigation support
 *    - Screen reader friendly
 *    - Proper heading hierarchy
 * 
 * 4. STANDALONE COMPONENT (Angular 17+)
 *    - No NgModule required
 *    - Self-contained component
 *    - Easy to import anywhere
 */
@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './not-found.component.html',
  styleUrls: ['./not-found.component.css']
})
export class NotFoundComponent implements OnInit {
  searchQuery: string = '';

  ngOnInit(): void {
    // Log 404 error for analytics
    console.warn('404 Page accessed');
  }

  /**
   * Searches for products based on user input
   * WHY: Helps users find what they're looking for
   */
  searchProducts(): void {
    if (this.searchQuery.trim()) {
      window.location.href = `/products?search=${encodeURIComponent(this.searchQuery.trim())}`;
    }
  }

  /**
   * Handles Enter key press in search input
   * WHY: Improves keyboard accessibility
   */
  onSearchKeyPress(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      this.searchProducts();
    }
  }
}
