import { Component, Input } from '@angular/core';
import { NgIf } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-empty-state',
  standalone: true,
  imports: [NgIf, RouterLink],
  template: `
    <div class="text-center py-12">
      <svg *ngIf="icon === 'cart'" class="mx-auto h-12 w-12 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path>
      </svg>
      <svg *ngIf="icon === 'order'" class="mx-auto h-12 w-12 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
      </svg>
      <svg *ngIf="icon === 'product'" class="mx-auto h-12 w-12 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
      </svg>
      <svg *ngIf="icon === 'search'" class="mx-auto h-12 w-12 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
      </svg>
      <svg *ngIf="!icon || icon === 'default'" class="mx-auto h-12 w-12 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
      </svg>
      
      <h3 class="text-lg font-medium text-gray-900 mb-2">{{ title || 'No items found' }}</h3>
      <p class="text-gray-500 mb-4">{{ message || 'There are no items to display.' }}</p>
      
      <ng-container *ngIf="buttonLink">
        <a *ngIf="buttonText" [routerLink]="buttonLink" class="inline-block bg-primary text-white px-6 py-3 rounded-lg hover:bg-primary-dark">
          {{ buttonText }}
        </a>
        <a *ngIf="!buttonText" [routerLink]="buttonLink" class="inline-block bg-primary text-white px-6 py-3 rounded-lg hover:bg-primary-dark">
          Go Home
        </a>
      </ng-container>
    </div>
  `,
  styles: []
})
export class EmptyStateComponent {
  @Input() icon: 'cart' | 'order' | 'product' | 'search' | 'default' = 'default';
  @Input() title: string = '';
  @Input() message: string = '';
  @Input() buttonLink: string | string[] | null = null;
  @Input() buttonText: string = '';
}
