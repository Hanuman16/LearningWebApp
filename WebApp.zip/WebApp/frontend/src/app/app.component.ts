import { Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './shared/components/header/header.component';
import { FooterComponent } from './shared/components/footer/footer.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, FooterComponent],
  template: `
    <div class="min-h-screen flex flex-col">
      <header></header>
      <main class="flex-1">
        <router-outlet></router-outlet>
      </main>
      <footer></footer>
    </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'E-Commerce';
}
