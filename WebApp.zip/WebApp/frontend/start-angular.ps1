# Wrapper script to start Angular dev server without analytics prompt
$env:NG_CLI_ANALYTICS = "false"
$env:NPM_CONFIG_ANALYTICS = "false"

# Run Angular CLI
& "c:\Users\XPY1KOR\Desktop\WebApp\frontend\node_modules\@angular\cli\bin\ng.cmd" serve --port 4200 --host 0.0.0.0
